ERI parsing definition file
===========================

Version Info
------------
AUGUST 22, 2015 ver01

[TOC]

Commands that can be parsed
===========================

readpower_power1
--------
 - Command name: `readpower_power1`
 - Command to send: `readpower`
```
{{Power Button force sensor value/([0-9]+)/}}
```

readpower_power2
--------
 - Command name: `readpower_power2`
 - Command to send: `readpower`
```
{{Power Button force sensor value2/([0-9]+)/}}
```

readpower_volumnDown
--------
 - Command name: `readpower_volumnDown`
 - Command to send: `readvoldn`
```
{{Volume Down force sensor value/([0-9]+)/}}
```

readpower_volumnUp
--------
 - Command name: `readpower_volumnUp`
 - Command to send: `readvolup`
```
{{Volume Up force sensor value/([0-9]+)/}}
```

readx
--------
 - Command name: `readx`
 - Command to send: `readx`
```
{{X_Axis}}mm
```

ready
--------
 - Command name: `ready`
 - Command to send: `ready`
```
{{Y_Axis}}mm
```

readz
--------
 - Command name: `readz`
 - Command to send: `readz`
```
{{Z_Axis}}mm
```

