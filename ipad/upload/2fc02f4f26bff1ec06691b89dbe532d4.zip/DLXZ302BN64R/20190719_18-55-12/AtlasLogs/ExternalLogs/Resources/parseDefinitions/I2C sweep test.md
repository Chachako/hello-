ERI parsing definition file
===========================

Version Info
------------
AUGUST 22, 2015 ver01

[TOC]

Commands that can be parsed
===========================


Display I2C sweep test
--------
 - Command name: `i2c -s 0`
 - Command to send: `i2c -s 0`
```
Sweeping bus 0
Bus 0 IC exists at Address: (7-bit) 0x38 (8-bit) 0x70
Bus 0 IC exists at Address: (7-bit) 0x6B (8-bit) 0xD6
{{anything}}
```


Display I2C sweep test
--------
 - Command name: `i2c -s 1`
 - Command to send: `i2c -s 1`
```
Sweeping bus 1
Bus 1 IC exists at Address: (7-bit) 0x3A (8-bit) 0x74
{{anything}}
```


Display I2C sweep test
--------
 - Command name: `i2c -s 1_1`
 - Command to send: `i2c -s 1`
```
Sweeping bus 1
{{anything}}
Bus 1 IC exists at Address: (7-bit) 0x3C (8-bit) 0x78
```


Display I2C sweep test
--------
 - Command name: `i2c -s 2`
 - Command to send: `i2c -s 2`
```
Sweeping bus 2
{{anything}}
Bus 2 IC exists at Address: (7-bit) 0x3A (8-bit) 0x74
{{anything}}
```

Display I2C sweep test
--------
 - Command name: `i2c -s 2_2`
 - Command to send: `i2c -s 2`
```
Sweeping bus 2
{{anything}}
{{anything}}
Bus 2 IC exists at Address: (7-bit) 0x3C (8-bit) 0x78
```


Display I2C sweep test
--------
 - Command name: `i2c -s 4`
 - Command to send: `i2c -s 4`
```
Sweeping bus 4
{{anything}}
Bus 4 IC exists at Address: (7-bit) 0x18 (8-bit) 0x30
Bus 4 IC exists at Address: (7-bit) 0x19 (8-bit) 0x32
Bus 4 IC exists at Address: (7-bit) 0x1A (8-bit) 0x34
Bus 4 IC exists at Address: (7-bit) 0x1B (8-bit) 0x36
Bus 4 IC exists at Address: (7-bit) 0x1C (8-bit) 0x38
Bus 4 IC exists at Address: (7-bit) 0x1D (8-bit) 0x3A
Bus 4 IC exists at Address: (7-bit) 0x1E (8-bit) 0x3C
Bus 4 IC exists at Address: (7-bit) 0x1F (8-bit) 0x3E
Bus 4 IC exists at Address: (7-bit) 0x20 (8-bit) 0x40
Bus 4 IC exists at Address: (7-bit) 0x21 (8-bit) 0x42
Bus 4 IC exists at Address: (7-bit) 0x22 (8-bit) 0x44
Bus 4 IC exists at Address: (7-bit) 0x23 (8-bit) 0x46
Bus 4 IC exists at Address: (7-bit) 0x24 (8-bit) 0x48
Bus 4 IC exists at Address: (7-bit) 0x25 (8-bit) 0x4A
Bus 4 IC exists at Address: (7-bit) 0x26 (8-bit) 0x4C
Bus 4 IC exists at Address: (7-bit) 0x27 (8-bit) 0x4E
Bus 4 IC exists at Address: (7-bit) 0x56 (8-bit) 0xAC
Bus 4 IC exists at Address: (7-bit) 0x70 (8-bit) 0xE0
Bus 4 IC exists at Address: (7-bit) 0x71 (8-bit) 0xE2
Bus 4 IC exists at Address: (7-bit) 0x72 (8-bit) 0xE4
```


Display I2C sweep test
--------
 - Command name: `i2c -s 6`
 - Command to send: `i2c -s 6`
```
Sweeping bus 6
Bus 6 IC exists at Address: (7-bit) 0x29 (8-bit) 0x52
{{anything}}
{{anything}}
{{anything}}
```


Display I2C sweep test
--------
 - Command name: `i2c -s 6_2`
 - Command to send: `i2c -s 6`
```
Sweeping bus 6
{{anything}}
{{anything}}
Bus 6 IC exists at Address: (7-bit) 0x39 (8-bit) 0x72
{{anything}}
```


Display I2C sweep test
--------
 - Command name: `i2c -s 6_3`
 - Command to send: `i2c -s 6`
```
Sweeping bus 6
{{anything}}
Bus 6 IC exists at Address: (7-bit) 0x33 (8-bit) 0x66
{{anything}}
Bus 6 IC exists at Address: (7-bit) 0x58 (8-bit) 0xB0
```


Display I2C sweep test
--------
 - Command name: `i2c -s 7`
 - Command to send: `i2c -s 7`
```
Sweeping bus 7
Bus 7 IC exists at Address: (7-bit) 0x55 (8-bit) 0xAA
```


Display I2C sweep test
--------
 - Command name: `i2c -s 8`
 - Command to send: `i2c -s 8`
```
Sweeping bus 8
Bus 8 IC exists at Address: (7-bit) 0x75 (8-bit) 0xEA
```

Display I2C sweep test
--------
 - Command name: `i2c -s 9`
 - Command to send: `i2c -s 9`
```
Sweeping bus 9
Bus 9 IC exists at Address: (7-bit) 0x38 (8-bit) 0x70
Bus 9 IC exists at Address: (7-bit) 0x6B (8-bit) 0xD6
```


Display I2C sweep test
--------
 - Command name: `i2c -s 10`
 - Command to send: `i2c -s 10`
```
Sweeping bus 10
{{anything}}
Bus 10 IC exists at Address: (7-bit) 0x41 (8-bit) 0x82
Bus 10 IC exists at Address: (7-bit) 0x55 (8-bit) 0xAA
```


Display I2C sweep test
--------
 - Command name: `i2c -s 11`
 - Command to send: `i2c -s 11`
```
Sweeping bus 11
Bus 11 IC exists at Address: (7-bit) 0x3C (8-bit) 0x78
Bus 11 IC exists at Address: (7-bit) 0x40 (8-bit) 0x80
```
