
sensor --sel prox --get nvm
--------
 - Command name: `sensor --sel prox --get nvm`
 - Command to send: `sensor --sel prox --get nvm`
```
prox:
	nvm = 
00000000: {{anything}}
00000010: {{anything}}
00000020: {{anything}}
00000030: {{anything}}
00000040: {{anything}}
00000050: {{anything}}
00000060: {{anything}}
00000070: {{data_0x70}} {{data_0x71}} {{anything}} {{anything}} {{anything}} {{anything}} {{anything}} {{anything}} {{anything}} {{anything}} {{anything}} {{anything}} {{anything}} {{anything}} {{anything}} {{anything}} |{{anything}}|

OK
```


Read Yogi fault Status
--------
 - Command name: `Read Yogi fault Status`
 - Command to send: `i2c -d 6 0x33 0x24 1`
```
Reading 1 bytes from register offset 0x24 into {{anything}}, buffer read:	
Data:  {{YogiFaultStatusData}} 
```


i2c -d 6 0x33 0x32 1
--------
 - Command name: `i2c -d 6 0x33 0x32 1`
 - Command to send: `i2c -d 6 0x33 0x32 1`
```
Reading 1 bytes from register offset 0x32 into {{anything}}, buffer read:	
Data:  {{TEMP_SNS_CODE}} 
```

i2c -d 6 0x33 0x0F 1
--------
 - Command name: `i2c -d 6 0x33 0x0F 1`
 - Command to send: `i2c -d 6 0x33 0x0F 1`
```
Reading 1 bytes from register offset 0x0F into {{anything}}, buffer read:	
Data:  {{TEMP_SNS_TRIM}} 
```


i2c -d 6 0x33 0x1D 0x01
--------
 - Command name: `i2c -d 6 0x33 0x1D 0x01`
 - Command to send: `i2c -d 6 0x33 0x1D 0x01`
```
Reading 1 bytes from register offset 0x1D into {{anything}}, buffer read:	
Data:  {{Yogi_SEL_ICWMAX_data}} 
```


i2c -d 6 0x33 0x14 0x01
--------
 - Command name: `i2c -d 6 0x33 0x14 0x01`
 - Command to send: `i2c -d 6 0x33 0x14 0x01`
```
Reading 1 bytes from register offset 0x14 into {{anything}}, buffer read:	
Data:  {{Yogi_FAULT_B_LIM_data}} 
```


Read_Yogi_FAULT_C_LIM_1
--------
 - Command name: `Read_Yogi_FAULT_C_LIM_1`
 - Command to send: `i2c -d 6 0x33 0x14 0x01`
```
Reading 1 bytes from register offset 0x14 into {{anything}}, buffer read:	
Data:  {{FAULT_C_LIM_data1}} 
```

i2c -d 6 0x33 0x15 0x01
--------
 - Command name: `i2c -d 6 0x33 0x15 0x01`
 - Command to send: `i2c -d 6 0x33 0x15 0x01`
```
Reading 1 bytes from register offset 0x15 into {{anything}}, buffer read:	
Data:  {{FAULT_C_LIM_data2}} 
```

i2c -d 6 0x33 0x16 0x01
--------
 - Command name: `i2c -d 6 0x33 0x16 0x01`
 - Command to send: `i2c -d 6 0x33 0x16 0x01`
```
Reading 1 bytes from register offset 0x16 into {{anything}}, buffer read:	
Data:  {{FAULT_C_LIM_data3}} 
```

Read Yogi_FAULT_D_LIM_1
--------
 - Command name: `Read Yogi_FAULT_D_LIM_1`
 - Command to send: `i2c -d 6 0x33 0x16 0x01`
```
Reading 1 bytes from register offset 0x16 into {{anything}}, buffer read:	
Data:  {{Yogi_FAULT_D_LIM_data1}} 
```

i2c -d 6 0x33 0x17 0x01
--------
 - Command name: `i2c -d 6 0x33 0x17 0x01`
 - Command to send: `i2c -d 6 0x33 0x17 0x01`
```
Reading 1 bytes from register offset 0x17 into {{anything}}, buffer read:	
Data:  {{Yogi_FAULT_D_LIM_data2}} 
```

i2c -d 6 0x33 0x18 0x01
--------
 - Command name: `i2c -d 6 0x33 0x18 0x01`
 - Command to send: `i2c -d 6 0x33 0x18 0x01`
```
Reading 1 bytes from register offset 0x18 into {{anything}}, buffer read:	
Data:  {{Yogi_FAULT_D_LIM_data3}} 
```

Read Yogi_FAULT_E_UP_COUNT_and_FAULT_E_DN_COUNT
--------
 - Command name: `Read Yogi_FAULT_E_UP_COUNT_and_FAULT_E_DN_COUNT`
 - Command to send: `i2c -d 6 0x33 0x18 0x01`
```
Reading 1 bytes from register offset 0x18 into {{anything}}, buffer read:	
Data:  {{FAULT_E_UP_COUNT_and_FAULT_E_DN_COUNT_data1}} 
```


i2c -d 6 0x33 0x19 0x01
--------
 - Command name: `i2c -d 6 0x33 0x19 0x01`
 - Command to send: `i2c -d 6 0x33 0x19 0x01`
```
Reading 1 bytes from register offset 0x19 into {{anything}}, buffer read:	
Data:  {{FAULT_E_UP_COUNT_and_FAULT_E_DN_COUNT_data2}} 
```


Read Yogi_FAULT_E_LIM_1
--------
 - Command name: `Read Yogi_FAULT_E_LIM_1`
 - Command to send: `i2c -d 6 0x33 0x19 0x01`
```
Reading 1 bytes from register offset 0x19 into {{anything}}, buffer read:	
Data:  {{Yogi_FAULT_E_LIM_data1}} 
```


i2c -d 6 0x33 0x1A 0x01
--------
 - Command name: `i2c -d 6 0x33 0x1A 0x01`
 - Command to send: `i2c -d 6 0x33 0x1A 0x01`
```
Reading 1 bytes from register offset 0x1A into {{anything}}, buffer read:	
Data:  {{Yogi_FAULT_E_LIM_data2}} 
```


i2c -d 6 0x33 0x1B 0x01
--------
 - Command name: `i2c -d 6 0x33 0x1B 0x01`
 - Command to send: `i2c -d 6 0x33 0x1B 0x01`
```
Reading 1 bytes from register offset 0x1B into {{anything}}, buffer read:	
Data:  {{Yogi_FAULT_E_LIM_data3}} 
```

Read Yogi_POR_DELAY_1
--------
 - Command name: `Read Yogi_POR_DELAY_1`
 - Command to send: `i2c -d 6 0x33 0x1B 0x01`
```
Reading 1 bytes from register offset 0x1B into {{anything}}, buffer read:	
Data:  {{Yogi_POR_DELAY_data1}} 
```


i2c -d 6 0x33 0x1C 0x01
--------
 - Command name: `i2c -d 6 0x33 0x1C 0x01`
 - Command to send: `i2c -d 6 0x33 0x1C 0x01`
```
Reading 1 bytes from register offset 0x1C into {{anything}}, buffer read:	
Data:  {{Yogi_POR_DELAY_data2}} 
```


i2c -d 6 0x33 0x20 0x01
--------
 - Command name: `i2c -d 6 0x33 0x20 0x01`
 - Command to send: `i2c -d 6 0x33 0x20 0x01`
```
Reading 1 bytes from register offset 0x20 into {{anything}}, buffer read:	
Data:  {{Yogi_SEL_STATUS_IOL_data1}} 
```



i2c -d 6 0x33 0x21 0x01
--------
 - Command name: `i2c -d 6 0x33 0x21 0x01`
 - Command to send: `i2c -d 6 0x33 0x21 0x01`
```
Reading 1 bytes from register offset 0x21 into {{anything}}, buffer read:	
Data:  {{Yogi_SEL_STATUS_IOL_data2}} 
```


Read Yogi_SEL_SDA_IOL_1
--------
 - Command name: `Read Yogi_SEL_SDA_IOL_1`
 - Command to send: `i2c -d 6 0x33 0x20 0x01`
```
Reading 1 bytes from register offset 0x20 into {{anything}}, buffer read:	
Data:  {{Yogi_SEL_SDA_IOL_data1}} 
```



i2c -d 6 0x33 0x13 0x01
--------
 - Command name: `i2c -d 6 0x33 0x13 0x01`
 - Command to send: `i2c -d 6 0x33 0x13 0x01`
```
Reading 1 bytes from register offset 0x13 into {{anything}}, buffer read:	
Data:  {{Yogi_DB_IPULSEMAX_data}} 
```



Read Yogi_DB_ICWMAX1
--------
 - Command name: `Read Yogi_DB_ICWMAX1`
 - Command to send: `i2c -d 6 0x33 0x13 0x01`
```
Reading 1 bytes from register offset 0x13 into {{anything}}, buffer read:	
Data:  {{Yogi_DB_ICWMAX1_data}} 
```



Read Yogi_DB_ICWMAX2
--------
 - Command name: `Read Yogi_DB_ICWMAX2`
 - Command to send: `i2c -d 6 0x33 0x20 0x01`
```
Reading 1 bytes from register offset 0x20 into {{anything}}, buffer read:	
Data:  {{Yogi_DB_ICWMAX2_data}} 
```

Read Yogi_DB_PSM_1
--------
 - Command name: `Read Yogi_DB_PSM_1`
 - Command to send: `i2c -d 6 0x33 0x13 0x01`
```
Reading 1 bytes from register offset 0x13 into {{anything}}, buffer read:	
Data:  {{Yogi_DB_PSM_data_1}} 
```

Read Yogi_DB_PSM_2
--------
 - Command name: `Read Yogi_DB_PSM_2`
 - Command to send: `i2c -d 6 0x33 0x14 0x01`
```
Reading 1 bytes from register offset 0x14 into {{anything}}, buffer read:	
Data:  {{Yogi_DB_PSM_data_2}} 
```


Read Yogi_SEL_VTHR_PSM_OVLO
--------
 - Command name: `Read Yogi_SEL_VTHR_PSM_OVLO`
 - Command to send: `i2c -d 6 0x33 0x1C 0x01`
```
Reading 1 bytes from register offset 0x1C into {{anything}}, buffer read:	
Data:  {{Yogi_SEL_VTHR_PSM_OVLO_data}} 
```



Read Yogi_SEL_VTHR_PSM_UVLO
--------
 - Command name: `Read Yogi_SEL_VTHR_PSM_UVLO`
 - Command to send: `i2c -d 6 0x33 0x1C 0x01`
```
Reading 1 bytes from register offset 0x1C into {{anything}}, buffer read:	
Data:  {{Yogi_SEL_VTHR_PSM_UVLO_data}} 
```


sensor --sel prox --get nvm 1
--------
 - Command name: `sensor --sel prox --get nvm 1`
 - Command to send: `sensor --sel prox --get nvm`
```
prox:
	nvm = 
00000000: {{anything}} {{anything}} {{anything}} {{anything}} {{anything}} {{anything}} {{Rosaline_Post_DA_Test_Bit0_1_data}} {{anything}} {{anything}} {{anything}} {{anything}} {{anything}} {{anything}} {{anything}} {{anything}} {{anything}} |{{anything}}|
00000010: {{anything}}
00000020: {{anything}}
00000030: {{anything}}
00000040: {{anything}}
00000050: {{anything}}
00000060: {{anything}}
00000070: {{anything}}

OK
```



sensor --sel prox --get nvm 2
--------
 - Command name: `sensor --sel prox --get nvm 2`
 - Command to send: `sensor --sel prox --get nvm`
```
prox:
	nvm = 
00000000: {{anything}} {{anything}} {{anything}} {{anything}} {{anything}} {{anything}} {{anything}} {{Rosaline_Yogi_Prog_Flag_data}} {{anything}} {{anything}} {{anything}} {{anything}} {{anything}} {{anything}} {{anything}} {{anything}} |{{anything}}|
00000010: {{anything}}
00000020: {{anything}}
00000030: {{anything}}
00000040: {{anything}}
00000050: {{anything}}
00000060: {{anything}}
00000070: {{anything}}

OK

```


Rosaline Pulse Width
--------
 - Command name: `Rosaline Pulse Width`
 - Command to send: `sensor --sel prox --get nvm`
```
prox:
	nvm = 
00000000: {{anything}}
00000010: {{anything}}
00000020: {{anything}}
00000030: {{anything}}
00000040: {{anything}}
00000050: {{anything}}
00000060: {{anything}}
00000070: {{anything}} {{anything}} {{anything}} {{Rosaline_Pulse_Width_data}} {{Rosaline_Pulse_Width_data}} {{anything}} {{anything}} {{anything}} {{anything}} {{anything}} {{anything}} {{anything}} {{anything}} {{anything}} {{anything}} {{anything}} |{{anything}}|

OK
```


i2c -d 6 0x33 0x1F 0x01
--------
 - Command name: `i2c -d 6 0x33 0x1F 0x01`
 - Command to send: `i2c -d 6 0x33 0x1F 0x01`
```
Reading 1 bytes from register offset 0x1F into {{anything}}, buffer read:	
Data:  {{config12Reg}} 
```


i2c -d 6 0x33 0x1E 0x01
--------
 - Command name: `i2c -d 6 0x33 0x1E 0x01`
 - Command to send: `i2c -d 6 0x33 0x1E 0x01`
```
Reading 1 bytes from register offset 0x1E into {{anything}}, buffer read:	
Data:  {{config11Reg}} 
```

sensor --sel prox --get device_id
--------
 - Command name: `sensor --sel prox --get device_id`
 - Command to send: `sensor --sel prox --get device_id`
```
{{PROX_QT_DEV_ID/(0xD0)/}}
```

sensor --sel prox --get rev_id
--------
 - Command name: `sensor --sel prox --get rev_id`
 - Command to send: `sensor --sel prox --get rev_id`
```
{{PROX_QT_REV_ID/(0x12)/}}
```

