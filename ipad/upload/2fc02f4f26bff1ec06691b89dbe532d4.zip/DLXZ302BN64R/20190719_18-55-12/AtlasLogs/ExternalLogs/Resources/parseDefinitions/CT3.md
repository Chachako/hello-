ERI parsing definition file
===========================

Version Info
------------
AUGUST 22, 2015 ver01

[TOC]

Commands that can be parsed
===========================

ver
--------
 - Command name: `ver`
 - Command to send: `ver`
```
{{anything}}
{{anything}} ({{DIAG_VER}}). Revision
```

socgpio --port 1 --pin 20 --get
--------
 - Command name: `socgpio --port 1 --pin 20 --get`
 - Command to send: `socgpio --port 1 --pin 20 --get`
```
SoC GPIO[{{anything}},{{anything}}] = {{interrupt_value}}
OK
```

socgpio --port 1 --pin 21 --get
--------
 - Command name: `socgpio --port 1 --pin 21 --get`
 - Command to send: `socgpio --port 1 --pin 21 --get`
```
SoC GPIO[{{anything}},{{anything}}] = {{interrupt_value}}
OK
```

sn
--------
 - Command name: `sn`
 - Command to send: `sn`
```
Serial: {{serialnumber}}
```

Check Battery Level Before Test
--------
 - Command name: `preTestBatteryLevel`
 - Command to send: `device -k GasGauge -g charge-percentage`
```
{{Check Battery Level Before Test}}%
```

Check Battery Level After Test
--------
 - Command name: `afterTestBatteryLevel`
 - Command to send: `device -k GasGauge -g charge-percentage`
```
{{Check Battery Level After Test}}%
```

sensor --sel pressure --sample 1000ms --stats
--------
 - Command name: `sensor --sel pressure --sample 1000ms --stats`
 - Command to send: `sensor --sel pressure --sample 1000ms --stats`
```
	calculated odr: {{WV_Phosphorus_ODR}}
	average: pressure = {{WV_Phosphorus_Average}}, temp = {{WV_Phosphorus_Temp}}
	std-dev: pressure = {{WV_Phosphorus_std}}, temp = {{WV_Phosphorus_Temp_std}}
```

pmuadc --sel potomac --read vbat
--------
 - Command name: `pmuadc --sel potomac --read vbat`
 - Command to send: `pmuadc --sel potomac --read vbat`
```
expansion potomac: vbat: {{Battery Present Voltage}} mV
```

pmuadc --sel potomac --read tbat
--------
 - Command name: `pmuadc --sel potomac --read tbat`
 - Command to send: `pmuadc --sel potomac --read tbat`
```
expansion potomac: tbat: {{Battery NTC}} {{===}}
```


dev -k GasGauge --get nominal-capacity
--------
 - Command name: `dev -k GasGauge --get nominal-capacity`
 - Command to send: `dev -k GasGauge --get nominal-capacity`
```
{{Battery Check FCC}}mAh
```

dev -k GasGauge -p
--------
 - Command name: `dev -k GasGauge -p`
 - Command to send: `dev -k GasGauge -p`
```
design-capacity: "{{Battery Design-capacity}}mAh"
```

device -k GasGauge --get chem-capacity
--------
 - Command name: `device -k GasGauge --get chem-capacity`
 - Command to send: `device -k GasGauge --get chem-capacity`
```
{{Battery Qmax}}mAh
```

device -k GasGauge --get cycle-count
--------
 - Command name: `device -k GasGauge --get cycle-count`
 - Command to send: `device -k GasGauge --get cycle-count`
```
{{Battery Cycle Count}}
```

Read Battery Temp TG0B
--------
 - Command name: `Read Battery Temp TG0B`
 - Command to send: `device -k GasGauge -p`
```
temperature: "{{Read Battery Temp TG0B}}C"
```


sensor --sel compass --sample 100 --stream --stats
--------
 - Command name: `sensor --sel compass --sample 100 --stream --stats`
 - Command to send: `sensor --sel compass --sample 100 --stream --stats`
```
	calculated odr: {{VA_magnetometer_mean_ODR}}Hz
	average: X = {{VA_magnetometer_mean_X}}, Y = {{VA_magnetometer_mean_Y}}, Z = {{VA_magnetometer_mean_Z}}, T = {{VA_magnetometer_mean_Temp}}
	std-dev: X = {{VA_magnetometer_std_X}}, Y = {{VA_magnetometer_std_Y}}, Z = {{VA_magnetometer_std_Z}}, T = {{===}}
```

MCUTest
--------
 - Command name: `display -m mcu_log`
 - Command to send: `display -m mcu_log`
```
Hibiscus MCU Version Info:
    Device ID: C6.00
    MCU Bootloader Ver: {{Display MCU Test MCU Bootloader Ver}}
    MCU Firmware Ver: {{Display MCU Test MCU Firmware Ver}}

Live Buffer
Indx Rate FrameCnt
{{===}}
{{===}}

Live Histogram
Indx Rate FrameCnt
{{===}}

LIVE InvFrm Bins(3): {{Display MCU Test LIVE InvFrm Bins1}} {{Display MCU Test LIVE InvFrm Bins2}} {{Display MCU Test LIVE InvFrm Bins3}} 
LIVE RptPol Bins(3): {{Display MCU Test LIVE RptPol Bins1}} {{Display MCU Test LIVE RptPol Bins2}} {{Display MCU Test LIVE RptPol Bins3}} 
LIVE CurrCaVal {{Display MCU Test LIVE CurrCaVal}}
LIVE MaxCaVal {{Display MCU Test LIVE MaxCaVal}}
LIVE Log {{Display MCU Test LIVE Log}}
NVM InvFrm Bins(3): {{Display MCU Test NVM InvFrm Bins1}} {{Display MCU Test NVM InvFrm Bins2}} {{Display MCU Test NVM InvFrm Bins3}} 
NVM RptPol Bins(3): {{Display MCU Test NVM RptPol Bins1}} {{Display MCU Test NVM RptPol Bins2}} {{Display MCU Test NVM RptPol Bins3}} 
NVM TotalFrmCt {{Display MCU Test NVM TotalFrmCt}}
NVM IdxLastBad {{Display MCU Test NVM IdxLastBad}}
NVM PwrOnCnt {{Display MCU Test NVM PwrOnCnt}}
NVM PPOrSDPwrOffs {{Display MCU Test NVM PPOrSDPwrOffs}}
NVM PolPwrOffs {{Display MCU Test NVM PolPwrOffs}}
NVM MaxCaVal {{Display MCU Test NVM MaxCaVal}}
NVM Log {{Display MCU Test NVM Log}}
NVM Last {{Display MCU Test NVM Last}}
NVM ConsPolPwrOffs {{Display MCU Test NVM ConsPolPwrOffs}}
NVM GoodPwrOffs {{Display MCU Test NVM GoodPwrOffs}}

OK
```

chipid
--------
 - Command name: `chipid`
 - Command to send: `chipid`
```
Chip  ID: {{AP_CHIPID}} Version
```

device -k GasGauge --get full-capacity
--------
 - Command name: `device -k GasGauge --get full-capacity`
 - Command to send: `device -k GasGauge --get full-capacity`
```
{{Battery Check FCC}}mAh
```

sensor --sel compass --sample 1000ms --stats
--------
 - Command name: `sensor --sel compass --sample 1000ms --stats`
 - Command to send: `sensor --sel compass --sample 1000ms --stats`
```
compass:
	# of samples captured: {{===}}
	# of bad samples (corrupted/lost): 0
	calculated odr: {{VA_Magnetometer_ODR}}Hz
	average: X = {{VA_Magnetometer_Average_X}}, Y = {{VA_Magnetometer_Average_Y}}, Z = {{VA_Magnetometer_Average_Z}}, T = {{VA_Magnetometer_Average_Temp}}
	std-dev: X = {{VA_Magnetometer_std_X}}, Y = {{VA_Magnetometer_std_Y}}, Z = {{VA_Magnetometer_std_Z}}, T = {{===}}
	rms:     X = {{===}}, Y = {{===}}, Z = {{===}}, T = {{===}}
	min: X = {{===}}, Y = {{===}}, Z = {{===}}, T = {{===}}
	max: X = {{===}}, Y = {{===}}, Z = {{===}}, T = {{===}}
	range: X = {{===}}, Y = {{===}}, Z = {{===}}, T = {{===}}
	median: X = {{===}}, Y = {{===}}, Z = {{===}}, T = {{===}}
OK
```

i2c -v 0 0x18 0x08 0x2
--------
 - Command name: `i2c -v 0 0x18 0x08 0x2`
 - Command to send: `i2c -v 0 0x18 0x08 0x2`
```
Set  bytes:	0x02 	Writing 1 bytes
```

i2c -v 0 0x18 0x0A 0x7C 0x15 multiple
--------
 - Command name: `i2c -v 0 0x18 0x0A 0x7C 0x15 multiple`
 - Command to send: `i2c -v 0 0x18 0x0A 0x7C 0x15 multiple`
```
Set  bytes:	0x7C 0x15 	Writing 2 bytes
```

i2c -d 0 0x18 0x05 1
--------
 - Command name: `i2c -d 0 0x18 0x05 1`
 - Command to send: `i2c -d 0 0x18 0x05 1`
```
Reading 1 bytes from register offset 0x05 into {{===}}, buffer read:	
Data:  0x0{{Wake Rx module up with Tx ping-nominal}} 
```

Check Battery Present Voltage Before Test
--------
 - Command name: `Check Battery Present Voltage Before Test`
 - Command to send: `pmuadc --sel potomac --read vbat`
```
PMU ADC test
expansion potomac: vbat: {{Check Battery Present Voltage Before Test}} mV
```

Check Battery Present Voltage After Test
--------
 - Command name: `Check Battery Present Voltage After Test`
 - Command to send: `pmuadc --sel potomac --read vbat`
```
PMU ADC test
expansion potomac: vbat: {{Check Battery Present Voltage After Test}} mV
```


i2c -v 3 0x20 0x5b 0x00;i2c -v 3 0x19 0x2a 0x80
--------
 - Command name: `i2c -v 3 0x20 0x5b 0x00;i2c -v 3 0x19 0x2a 0x80`
 - Command to send: `i2c -v 3 0x20 0x5b 0x00;i2c -v 3 0x19 0x2a 0x80`
```
Set  bytes:	0x00 	Writing 1 bytes
Set  bytes:	0x80 	Writing 1 bytes
```

i2c -v 3 0x20 0x80 0x10;i2c -v 3 0x20 0xb6 0x00;i2c -v 3 0x20 0xb7 0x00;i2c -v 3 0x20 0xb8 0xFF;i2c -v 3 0x20 0xb9 0x03;i2c -v 3 0x20 0xba 0x00;i2c -v 3 0x20 0xbb 0x00
--------
 - Command name: `i2c -v 3 0x20 0x80 0x10;i2c -v 3 0x20 0xb6 0x00;i2c -v 3 0x20 0xb7 0x00;i2c -v 3 0x20 0xb8 0xFF;i2c -v 3 0x20 0xb9 0x03;i2c -v 3 0x20 0xba 0x00;i2c -v 3 0x20 0xbb 0x00`
 - Command to send: `i2c -v 3 0x20 0x80 0x10;i2c -v 3 0x20 0xb6 0x00;i2c -v 3 0x20 0xb7 0x00;i2c -v 3 0x20 0xb8 0xFF;i2c -v 3 0x20 0xb9 0x03;i2c -v 3 0x20 0xba 0x00;i2c -v 3 0x20 0xbb 0x00`
```
Set  bytes:	0x10 	Writing 1 bytes
Set  bytes:	0x00 	Writing 1 bytes
Set  bytes:	0x00 	Writing 1 bytes
Set  bytes:	0xFF 	Writing 1 bytes
Set  bytes:	0x03 	Writing 1 bytes
Set  bytes:	0x00 	Writing 1 bytes
Set  bytes:	0x00 	Writing 1 bytes
```

Check Battery Level Before Test
--------
 - Command name: `Check Battery Level Before Test`
 - Command to send: `device -k GasGauge -g charge-percentage`
```
{{Check Battery Level Before Test}}%
```

Check Battery Level After Test
--------
 - Command name: `Check Battery Level After Test`
 - Command to send: `device -k GasGauge -g charge-percentage`
```
{{Check Battery Level After Test}}%
```

Check Battery Level Before Test
--------
 - Command name: `Check Battery Level Before Test`
 - Command to send: `device -k GasGauge -g charge-percentage`
```
{{Check Battery Level Before Test}}%
```

Check Battery Voltage Before Test
--------
 - Command name: `Check Battery Voltage Before Test`
 - Command to send: `pmuadc --sel potomac --read vbat`
```
expansion potomac: vbat: {{Check Battery Voltage Before Test}} mV
```

Check Battery Voltage After Test
--------
 - Command name: `Check Battery Voltage After Test`
 - Command to send: `pmuadc --sel potomac --read vbat`
```
expansion potomac: vbat: {{Check Battery Voltage After Test}} mV
```

sensor --sel compass --sample 100 --stream --stats
--------
 - Command name: `sensor --sel compass --sample 100 --stream --stats`
 - Command to send: `sensor --sel compass --sample 100 --stream --stats`
```
	calculated odr: {{VA_magnetometer_mean_ODR}}Hz
	average: X = {{VA_magnetometer_mean_X}}, Y = {{VA_magnetometer_mean_Y}}, Z = {{VA_magnetometer_mean_Z}}, T = {{VA_magnetometer_mean_Temp}}
	std-dev: X = {{VA_magnetometer_std_X}}, Y = {{VA_magnetometer_std_Y}}, Z = {{VA_magnetometer_std_Z}}, T = {{===}}
```

sensor --listsensors
--------
 - Command name: `sensor --listsensors`
 - Command to send: `sensor --listsensors`
```
Name: compass
Description: {{===}}
Installed: yes
```



i2c -v 0 0x18 0x08 0x1
--------
 - Command name: `i2c -v 0 0x18 0x08 0x1`
 - Command to send: `i2c -v 0 0x18 0x08 0x1`
```
Set  bytes:	0x01 	Writing 1 bytes
```

i2c -d 0 0x18 0x07 1
--------
 - Command name: `i2c -d 0 0x18 0x07 1`
 - Command to send: `i2c -d 0 0x18 0x07 1`
```
Reading 1 bytes from register offset 0x07 into {{===}}, buffer read:	
Data:  {{===}} 
```

i2c -v 0 0x18 0x08 0x3
--------
 - Command name: `i2c -v 0 0x18 0x08 0x3`
 - Command to send: `i2c -v 0 0x18 0x08 0x3`
```
Set  bytes:	0x03 	Writing 1 bytes
```

i2c -d 0 0x18 0x06 2 multiple
--------
 - Command name: `i2c -d 0 0x18 0x06 2 multiple`
 - Command to send: `i2c -d 0 0x18 0x06 2 multiple`
```
Reading 2 bytes from register offset 0x06 into {{===}}, buffer read:	
Data:  {{===}}  {{===}} 
```

i2c -v 0 0x18 0x0A 0x7C 0x15 multiple
--------
 - Command name: `i2c -v 0 0x18 0x0A 0x7C 0x15 multiple`
 - Command to send: `i2c -v 0 0x18 0x0A 0x7C 0x15 multiple`
```
Set  bytes:	0x7C 0x15 	Writing 2 bytes
```

pmurw -w 0xb29 0xff
--------
 - Command name: `pmurw -w 0xb29 0xff`
 - Command to send: `pmurw -w 0xb29 0xff`
```
Wrote 1 bytes:	0xFF
```

pmurw -w 0xb2a 0xff
--------
 - Command name: `pmurw -w 0xb2a 0xff`
 - Command to send: `pmurw -w 0xb2a 0xff`
```
Wrote 1 bytes:	0xFF
```

pmurw -w 0xb2b 0xff
--------
 - Command name: `pmurw -w 0xb2b 0xff`
 - Command to send: `pmurw -w 0xb2b 0xff`
```
Wrote 1 bytes:	0xFF 
```

pmurw -r 0xbad 1
--------
 - Command name: `pmurw -r 0xbad 1`
 - Command to send: `pmurw -r 0xbad 1`
```
Read 1 bytes:	 0x00 
```

pmurw -w 0x0b00 0xbc
--------
 - Command name: `pmurw -w 0x0b00 0xbc`
 - Command to send: `pmurw -w 0x0b00 0xbc`
```
Wrote 1 bytes:	0xBC 
```

pmurw -w 0x0b01 0x07
--------
 - Command name: `pmurw -w 0x0b01 0x07`
 - Command to send: `pmurw -w 0x0b01 0x07`
```
Wrote 1 bytes:	0x07 
```

pmurw -w 0x0b00 0xf4
--------
 - Command name: `pmurw -w 0x0b00 0xf4`
 - Command to send: `pmurw -w 0x0b00 0xf4`
```
Wrote 1 bytes:	0xF4 
```

pmurw -w 0x0b01 0x01
--------
 - Command name: `pmurw -w 0x0b01 0x01`
 - Command to send: `pmurw -w 0x0b01 0x01`
```
Wrote 1 bytes:	0x01 
```

processaudio -p fft -i record0 -o '--normalize false --minHz 2990 --maxHz 3010'
--------
 - Command name: `processaudio -p fft -i record0 -o '--normalize false --minHz 2990 --maxHz 3010'`
 - Command to send: `processaudio -p fft -i record0 -o '--normalize false --minHz 2990 --maxHz 3010'`
```
Channel 0:
Using {{===}} bins, Peak Bin={{===}}; Peak Magnitude={{MIC_EDGE_L_PK_MAG}}; Frequency: {{===}} +/- {{===}} Hz
DC Magnitude={{MIC_EDGE_L_DC_MAG}}
Signal Bins={{===}}
SINAD={{===}} dB
Peak Power: {{===}} dB
Signal Power: {{===}} dB
Noise Power: {{===}} dB
Average Noise PSD: {{===}} dB
Noise Margin: {{===}} dB
THD+N: {{===}} dB
Channel 1:
Using {{===}} bins, Peak Bin={{===}}; Peak Magnitude={{MIC_EDGE_R_PK_MAG}}; Frequency: {{===}} +/- {{===}} Hz
DC Magnitude={{MIC_EDGE_R_DC_MAG}}
Signal Bins={{===}}
SINAD={{===}} dB
Peak Power: {{===}} dB
Signal Power: {{===}} dB
Noise Power: {{===}} dB
Average Noise PSD: {{===}} dB
Noise Margin: {{===}} dB
THD+N: {{===}} dB
Channel 2:
Using {{===}} bins, Peak Bin={{===}}; Peak Magnitude={{MIC_TM_PK_MAG}}; Frequency: {{===}} +/- {{===}} Hz
DC Magnitude={{MIC_TM_DC_MAG}}
Signal Bins={{===}}
SINAD={{===}} dB
Peak Power: {{===}} dB
Signal Power: {{===}} dB
Noise Power: {{===}} dB
Average Noise PSD: {{===}} dB
Noise Margin: {{===}} dB
THD+N: {{===}} dB
Channel 3:
Using {{===}} bins, Peak Bin={{===}}; Peak Magnitude={{MIC_HOUSING_PK_MAG}}; Frequency: {{===}} +/- {{===}} Hz
DC Magnitude={{MIC_HOUSING_DC_MAG}}
Signal Bins={{===}}
SINAD={{===}} dB
Peak Power: {{===}} dB
Signal Power: {{===}} dB
Noise Power: {{===}} dB
Average Noise PSD: {{===}} dB
Noise Margin: {{===}} dB
THD+N: {{===}} dB
OK
```



sensor --sel als1 --sample 3 --stream
--------
 - Command name: `sensor --sel als1 --sample 3 --stream`
 - Command to send: `sensor --sel als1 --sample 3 --stream`
```
Capturing{{/\s*/}}3{{/\s*/}}samples{{/\s*/}}from:
als1{{/\s*/}}@{{/\s*/}}{{===}}{{/\s*/}}Hz
{{/[\s\S]*/}}
Output{{/\s*/}}format{{/\s*/}}={{/\s*/}}abstime{{/\s*/}}:{{/\s*/}}relativetime{{/\s*/}}:{{/\s*/}}sample
als1:{{/\s*/}}{{===}}s{{/\s*/}}:{{/\s*/}}{{===}}us{{/\s*/}}({{===}}s{{/\s*/}}:{{/\s*/}}{{===}}us){{/\s*/}}={{/\s*/}}Channel0{{/\s*/}}={{/\s*/}}{{red1}},{{/\s*/}}Channel1{{/\s*/}}={{/\s*/}}{{green1}},{{/\s*/}}Channel2{{/\s*/}}={{/\s*/}}{{blue1}},{{/\s*/}}Channel3{{/\s*/}}={{/\s*/}}{{clear1}}
als1:{{/\s*/}}{{===}}s{{/\s*/}}:{{/\s*/}}{{===}}us{{/\s*/}}({{===}}s{{/\s*/}}:{{/\s*/}}{{===}}us){{/\s*/}}={{/\s*/}}Channel0{{/\s*/}}={{/\s*/}}{{red2}},{{/\s*/}}Channel1{{/\s*/}}={{/\s*/}}{{green2}},{{/\s*/}}Channel2{{/\s*/}}={{/\s*/}}{{blue2}},{{/\s*/}}Channel3{{/\s*/}}={{/\s*/}}{{clear2}}
als1:{{/\s*/}}{{===}}s{{/\s*/}}:{{/\s*/}}{{===}}us{{/\s*/}}({{===}}s{{/\s*/}}:{{/\s*/}}{{===}}us){{/\s*/}}={{/\s*/}}Channel0{{/\s*/}}={{/\s*/}}{{red3}},{{/\s*/}}Channel1{{/\s*/}}={{/\s*/}}{{green3}},{{/\s*/}}Channel2{{/\s*/}}={{/\s*/}}{{blue3}},{{/\s*/}}Channel3{{/\s*/}}={{/\s*/}}{{clear3}}
OK
```

sensor --sel als2 --sample 3 --stream
--------
 - Command name: `sensor --sel als2 --sample 3 --stream`
 - Command to send: `sensor --sel als2 --sample 3 --stream`
```
Capturing{{/\s*/}}3{{/\s*/}}samples{{/\s*/}}from:
als2{{/\s*/}}@{{/\s*/}}{{===}} Hz
{{/[\s\S]*/}}
Output{{/\s*/}}format{{/\s*/}}={{/\s*/}}abstime{{/\s*/}}:{{/\s*/}}relativetime{{/\s*/}}:{{/\s*/}}sample
als2:{{/\s*/}}{{===}}s{{/\s*/}}:{{/\s*/}}{{===}}us{{/\s*/}}({{===}}s{{/\s*/}}:{{/\s*/}}{{===}}us){{/\s*/}}={{/\s*/}}Channel0{{/\s*/}}={{/\s*/}}{{red1}},{{/\s*/}}Channel1{{/\s*/}}={{/\s*/}}{{green1}},{{/\s*/}}Channel2{{/\s*/}}={{/\s*/}}{{blue1}},{{/\s*/}}Channel3{{/\s*/}}={{/\s*/}}{{clear1}}
als2:{{/\s*/}}{{===}}s{{/\s*/}}:{{/\s*/}}{{===}}us{{/\s*/}}({{===}}s{{/\s*/}}:{{/\s*/}}{{===}}us){{/\s*/}}={{/\s*/}}Channel0{{/\s*/}}={{/\s*/}}{{red2}},{{/\s*/}}Channel1{{/\s*/}}={{/\s*/}}{{green2}},{{/\s*/}}Channel2{{/\s*/}}={{/\s*/}}{{blue2}},{{/\s*/}}Channel3{{/\s*/}}={{/\s*/}}{{clear2}}
als2:{{/\s*/}}{{===}}s{{/\s*/}}:{{/\s*/}}{{===}}us{{/\s*/}}({{===}}s{{/\s*/}}:{{/\s*/}}{{===}}us){{/\s*/}}={{/\s*/}}Channel0{{/\s*/}}={{/\s*/}}{{red3}},{{/\s*/}}Channel1{{/\s*/}}={{/\s*/}}{{green3}},{{/\s*/}}Channel2{{/\s*/}}={{/\s*/}}{{blue3}},{{/\s*/}}Channel3{{/\s*/}}={{/\s*/}}{{clear3}}
OK
```

pmurw -w 0x0b00 0xf3
--------
 - Command name: `pmurw -w 0x0b00 0xf3`
 - Command to send: `pmurw -w 0x0b00 0xf3`
```
Wrote 1 bytes:	0xF3 
```

Accelerometer sensor -l
--------
 - Command name: `Accelerometer sensor -l`
 - Command to send: `sensor -l`
```
Name: accel
Description: {{===}} {{===}} Accelerometer ({{===}})
Installed: yes

Name: gyro
Description: {{===}} {{===}} Gyro ({{===}})
Installed: yes
```

sensor --sel accel,gyro --sample 500ms --stats
--------
 - Command name: `sensor --sel accel,gyro --sample 500ms --stats`
 - Command to send: `sensor --sel accel,gyro --sample 500ms --stats`
```
accel:
	# of samples captured: {{===}}
	# of bad samples (corrupted/lost): {{===}}
	calculated odr: {{CM_Accel_odr}}Hz
	average: X = {{CM_Accel_Average_X}}, Y = {{CM_Accel_Average_Y}}, Z = {{CM_Accel_Average_Z}}, T = {{===}}
	std-dev: X = {{CM_Accel_std_X}}, Y = {{CM_Accel_std_Y}}, Z = {{CM_Accel_std_Z}}, T = {{===}}
	{{===}}
	{{===}}
	{{===}}
	{{===}}
	{{===}}

gyro:
	# of samples captured: {{===}}
	# of bad samples (corrupted/lost): {{===}}
	calculated odr: {{CM_Gyro_odr}}Hz
	average: X = {{CM_Gyro_Average_X}}, Y = {{CM_Gyro_Average_Y}}, Z = {{CM_Gyro_Average_Z}}, T = {{CM_Gyro_nmDC_Temp}}
	std-dev: X = {{CM_Gyro_std_X}}, Y = {{CM_Gyro_std_Y}}, Z = {{CM_Gyro_std_Z}}, T = {{===}}
	{{===}}
	{{===}}
	{{===}}
	{{===}}
	{{===}}
OK
```


display -m serial_number
--------
 - Command name: `display -m serial_number`
 - Command to send: `display -m serial_number`
```
Panel LCM#: {{sn1}}
     {{sn2}}

OK
```

pmubutton
--------
 - Command name: `pmubutton`
 - Command to send: `pmubutton`
```
Hold:{{PowerStatus}},VolDown:{{VolStatus}}
```

buttoncnt
--------
 - Command name: `buttoncnt`
 - Command to send: `pmubutton`
```
Button Count
Press Pwr+VolUp or Press 'Q'/'q' To Stop Test
{{Hold gets pressed 1 times}}.
{{VolDn gets pressed 1 times}}.
{{VolUp gets pressed 1 times}}.
```

q
--------
 - Command name: `q`
 - Command to send: `q`
```
{{Hold gets pressed 1 times}}.
{{VolDn gets pressed 1 times}}.
{{VolUp gets pressed 1 times}}.
```

i2c -w 0 0x55 0x40 multiple
--------
 - Command name: `i2c -w 0 0x55 0x40 multiple`
 - Command to send: `i2c -w 0 0x55 0x40 multiple`
```
Set  bytes:	0x40 	Writing 1 bytes
```

i2c -r 0 0x55 5
--------
 - Command name: `i2c -r 0 0x55 5`
 - Command to send: `i2c -r 0 0x55 5`
```
Reading 5 bytes into 0xF7883698, buffer read:	 {{===}}  {{===}}  0x01  0x01  0x0{{===/([B8C])/}} 
```

i2c -v 1 0x13 0x00 0x01
--------
 - Command name: `i2c -v 1 0x13 0x00 0x01`
 - Command to send: `i2c -v 1 0x13 0x00 0x01`
```
Set  bytes:	0x01 	Writing 1 bytes
```

i2c -v 1 0x13 0x01 0x00
--------
 - Command name: `i2c -v 1 0x13 0x01 0x00`
 - Command to send: `i2c -v 1 0x13 0x01 0x00`
```
Set  bytes:	0x00 	Writing 1 bytes
```

i2c -d 6 0x29 0xE3 0x04
--------
 - Command name: `i2c -d 6 0x29 0xE3 0x04`
 - Command to send: `i2c -d 6 0x29 0xE3 0x04`
```
Reading 4 bytes from register offset 0xE3 into {{===}}, buffer read:	
Data:  {{ChipID}} 
```

i2c -d 6 0x29 0xE2 0x01
--------
 - Command name: `i2c -d 6 0x29 0xE2 0x01`
 - Command to send: `i2c -d 6 0x29 0xE2 0x01`
```
Reading 1 bytes from register offset 0xE2 into {{===}}, buffer read:	
Data:  0x{{===/([0-9A-F][13579BDF])/}} 
```

i2c -d 6 0x39 0xE2 0x01
--------
 - Command name: `i2c -d 6 0x39 0xE2 0x01`
 - Command to send: `i2c -d 6 0x39 0xE2 0x01`
```
Reading 1 bytes from register offset 0xE2 into {{===}}, buffer read:	
Data:  0x{{===/([0-9A-F][13579BDF])/}} 
```

i2c -d 6 0x39 0xE3 0x04
--------
 - Command name: `i2c -d 6 0x39 0xE3 0x04`
 - Command to send: `i2c -d 6 0x39 0xE3 0x04`
```
Reading 4 bytes from register offset 0xE3 into {{===}}, buffer read:	
Data:  {{ChipID}} 
```

hallsensor1_missed
--------
 - Command name: `hallsensor1_missed`
 - Command to send: `hallsensor --irqindex 1 --meas 6 --delay 500`
```
measuring irq index #1 (PMU gpio 11)
0: missed intr (pin = 0x1) 
1: missed intr (pin = 0x1) 
2: missed intr (pin = 0x1) 
3: missed intr (pin = 0x1) 
4: missed intr (pin = 0x1) 
5: missed intr (pin = 0x1) 
```

hallsensor1_detect
--------
 - Command name: `hallsensor1_detect`
 - Command to send: `hallsensor --irqindex 1 --meas 6 --delay 500`
```
measuring irq index #1 (PMU gpio 11)
0: detect intr (pin = 0x0) 
1: detect intr (pin = 0x0) 
2: detect intr (pin = 0x0) 
3: detect intr (pin = 0x0) 
4: detect intr (pin = 0x0) 
5: detect intr (pin = 0x0) 
```

hallsensor0_missed
--------
 - Command name: `hallsensor0_missed`
 - Command to send: `hallsensor --irqindex 0 --meas 6 --delay 500`
```
measuring irq index #0 (PMU gpio 1)
0: missed intr (pin = 0x1) 
1: missed intr (pin = 0x1) 
2: missed intr (pin = 0x1) 
3: missed intr (pin = 0x1) 
4: missed intr (pin = 0x1) 
5: missed intr (pin = 0x1) 
```

hallsensor0_detect
--------
 - Command name: `hallsensor0_detect`
 - Command to send: `hallsensor --irqindex 0 --meas 6 --delay 500`
```
measuring irq index #0 (PMU gpio 1)
0: detect intr (pin = 0x0) 
1: detect intr (pin = 0x0) 
2: detect intr (pin = 0x0) 
3: detect intr (pin = 0x0) 
4: detect intr (pin = 0x0) 
5: detect intr (pin = 0x0) 
```

sensorreg -s compass -r 0x00
--------
 - Command name: `sensorreg -s compass -r 0x00`
 - Command to send: `sensorreg -s compass -r 0x00`
```
Reading in 1 registers from 0x0:
0x00 = {{SupplierID}}
OK
```

sensorreg -s compass -r 0x01
--------
 - Command name: `sensorreg -s compass -r 0x01`
 - Command to send: `sensorreg -s compass -r 0x01`
```
Reading in 1 registers from 0x1:
0x01 = {{ChipID}}
OK
```

sensorreg -s compass -r 0x02
--------
 - Command name: `sensorreg -s compass -r 0x02`
 - Command to send: `sensorreg -s compass -r 0x02`
```
Reading in 1 registers from 0x2:
{{===}} = {{registerX}}
OK
```

sensor --sel accel --exectest selftest_manual
--------
 - Command name: `sensor --sel accel --exectest selftest_manual`
 - Command to send: `sensor --sel accel --exectest selftest_manual`
```
SymErr-result: passed
test-result: passed
PASS
```

sensor --sel gyro --exectest selftest
--------
 - Command name: `sensor --sel gyro --exectest selftest`
 - Command to send: `sensor --sel gyro --exectest selftest`
```
Built in selftest passed.
test-result: {{===}}
PASS
```

i2c -r 4 0x55 32
--------
 - Command name: `i2c -r 4 0x55 32`
 - Command to send: `i2c -r 4 0x55 32`
```
Reading 32 bytes into {{===}}, buffer read:	{{data/(( 0x\w\w ){32})/}}
```

i2c -r 4 0x55 12
--------
 - Command name: `i2c -r 4 0x55 12`
 - Command to send: `i2c -r 4 0x55 12`
```
Reading 12 bytes into {{===}}, buffer read:	{{data/(( 0x\w\w ){12})/}}
```

i2c -r 4 0x55 4
--------
 - Command name: `i2c -r 4 0x55 4`
 - Command to send: `i2c -r 4 0x55 4`
```
Reading 4 bytes into {{===}}, buffer read:	{{data/(( 0x\w\w ){4})/}}
```

i2c -r 4 0x55 3
--------
 - Command name: `i2c -r 4 0x55 3`
 - Command to send: `i2c -r 4 0x55 3`
```
Reading 3 bytes into {{===}}, buffer read:	{{data/(( 0x\w\w ){3})/}}
```

i2c -r 4 0x55 0x20
--------
 - Command name: `i2c -r 4 0x55 0x20`
 - Command to send: `i2c -r 4 0x55 0x20`
```
Reading 32 bytes into {{===}}, buffer read:	{{data/(( 0x\w\w ){32})/}}
```

cat nandfs
--------
 - Command name: `cat nandfs`
 - Command to send: `cat nandfs:\\AppleInternal\\Diags\\Logs\\Smokey\\LcmCal\\PDCA.plist`
```
{{===}}
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
	<key>0</key>
	<dict>
		<key>Attributes</key>
		<dict>
			<key>serialnumber</key>   <string>{{===}}</string>
			<key>softwarename</key>   <string>LcmCal</string>
			<key>softwareversion</key><string>{{===}}</string>
		</dict>
		<key>Tests</key>
		<array>
			<dict>
				<key>testname</key>       <string>LcmCal</string>
				<key>subtestname</key>    <string>SequenceVersion</string>
				<key>result</key>         <string>{{===}}</string>
				<key>value</key>          <string>{{===}}</string>
				<key>lowerlimit</key>     <string>{{===}}</string>
				<key>upperlimit</key>     <string>{{===}}</string>
				<key>units</key>          <string>{{===}}</string>
				<key>priority</key>       <string>{{===}}</string>
			</dict>
			<dict>
				<key>testname</key>       <string>LcmCal</string>
				<key>subtestname</key>    <string>ConvertLcmCal: DBCl</string>
				<key>subsubtestname</key> <string>Iteration 1</string>
				<key>result</key>         <string>{{DBClResult}}</string>
				<key>value</key>          <string>{{DBClValue}}</string>
				<key>lowerlimit</key>     <string>{{===}}</string>
				<key>upperlimit</key>     <string>{{===}}</string>
				<key>units</key>          <string>{{===}}</string>
				<key>priority</key>       <string>{{===}}</string>
			</dict>
			<dict>
				<key>testname</key>       <string>LcmCal</string>
				<key>subtestname</key>    <string>ConvertLcmCal: DTCl</string>
				<key>subsubtestname</key> <string>Iteration 1</string>
				<key>result</key>         <string>{{DTClResult}}</string>
				<key>value</key>          <string>{{DTClValue}}</string>
				<key>lowerlimit</key>     <string>{{===}}</string>
				<key>upperlimit</key>     <string>{{===}}</string>
				<key>units</key>          <string>{{===}}</string>
				<key>priority</key>       <string>{{===}}</string>
			</dict>
			<dict>
				<key>testname</key>       <string>LcmCal</string>
				<key>subtestname</key>    <string>ConvertLcmCal</string>
				<key>subsubtestname</key> <string>Iteration 1</string>
				<key>result</key>         <string>{{===}}</string>
				<key>value</key>          <string>{{===}}</string>
				<key>lowerlimit</key>     <string>{{===}}</string>
				<key>upperlimit</key>     <string>{{===}}</string>
				<key>units</key>          <string>{{===}}</string>
				<key>priority</key>       <string>{{===}}</string>
			</dict>
		</array>
		<key>overallresult</key><string>{{overallresult}}</string>
		<key>startTime</key>    <string>{{===}}</string>
		<key>stopTime</key>     <string>{{===}}</string>
	</dict>
</dict>
</plist>
```

i2c -d 6 0x39 0xE3 4
--------
 - Command name: `i2c -d 6 0x39 0xE3 4`
 - Command to send: `i2c -d 6 0x39 0xE3 4`
```
Reading 4 bytes from register offset 0xE3 into {{===}}, buffer read:	
Data:  {{C3ChipID}} 
```

i2c -d 6 0x29 0xE3 4
--------
 - Command name: `i2c -d 6 0x29 0xE3 4`
 - Command to send: `i2c -d 6 0x29 0xE3 4`
```
Reading 4 bytes from register offset 0xE3 into {{===}}, buffer read:	
Data:  {{C4ChipID}} 
```

sensor --sel als1 --set gain 512
--------
 - Command name: `sensor --sel als1 --set gain 512`
 - Command to send: `sensor --sel als1 --set gain 512`
```
Setting parameter 'gain' to {{gain1}} for 'als1'
OK
```

sensor --sel als1 --set integration_cycles 90
--------
 - Command name: `sensor --sel als1 --set integration_cycles 90`
 - Command to send: `sensor --sel als1 --set integration_cycles 90`
```
Setting parameter 'integration_cycles' to {{cycles1}} for 'als1'
```

sensor --sel als2 --set gain 512
--------
 - Command name: `sensor --sel als2 --set gain 512`
 - Command to send: `sensor --sel als2 --set gain 512`
```
Setting parameter 'gain' to {{gain2}} for 'als2'
OK
```

sensor --sel als2 --set integration_cycles 90
--------
 - Command name: `sensor --sel als2 --set integration_cycles 90`
 - Command to send: `sensor --sel als2 --set integration_cycles 90`
```
Setting parameter 'integration_cycles' to {{cycles2}} for 'als2'
```

sensor --sel prox --sample 47 --stats
--------
 - Command name: `No Target Sample`
 - Command to send: `sensor --sel prox --sample 47 --stats`
```
Stats:

prox:
	# of samples captured: 47
	# of bad samples (corrupted/lost): 0
	calculated odr: {{===}}
	average: rawrange = {{PROX_QT_NO_TARGET_RAW_DIST_AVE}}
	average: signalrateperspad = {{PROX_QT_NO_TARGET_SIG_AVE}}, ambientrateperspad = {{PROX_QT_NO_TARGET_AMB_AVE}}
	average: refsignalrateperspad = {{PROX_QT_NO_TARGET_REF_SIG_AVE}}
	average: totalsignalrate = {{===}}, totalambientrate = {{===}}
	average: totalrefsignalrate = {{===}}
	average: integrationtime = {{===}}
	std-dev: rawrange = {{PROX_QT_NO_TARGET_RAW_DIST_STD}}
	std-dev: signalrateperspad = {{PROX_QT_NO_TARGET_SIG_STD}}, ambientrateperspad = {{PROX_QT_NO_TARGET_AMB_STD}}
	std-dev: refsignalrateperspad = {{PROX_QT_NO_TARGET_REF_SIG_STD}}
	std-dev: totalsignalrate = {{===}}, totalambientrate = {{===}}
	std-dev: totalrefsignalrate = {{===}}
	std-dev: integrationtime = {{===}}
	rms: rawrange = {{===}}
	rms: signalrateperspad = {{===}}, ambientrateperspad = {{===}}
	rms: refsignalrateperspad = {{===}}
	rms: totalsignalrate = {{===}}, totalambientrate = {{===}}
	rms: totalrefsignalrate = {{===}}
	rms: integrationtime = {{===}}
OK
```

sensor --sel prox --sample 47 --stats
--------
 - Command name: `Target Sample`
 - Command to send: `sensor --sel prox --sample 47 --stats`
```
Stats:

prox:
	# of samples captured: 47
	# of bad samples (corrupted/lost): 0
	calculated odr: {{===}}
	average: rawrange = {{PROX_QT_TARGET_RAW_DIST_AVE}}
	average: signalrateperspad = {{PROX_QT_TARGET_SIG_AVE}}, ambientrateperspad = {{PROX_QT_TARGET_AMB_AVE}}
	average: refsignalrateperspad = {{PROX_QT_TARGET_REF_SIG_AVE}}
	average: totalsignalrate = {{===}}, totalambientrate = {{===}}
	average: totalrefsignalrate = {{===}}
	average: integrationtime = {{===}}
	std-dev: rawrange = {{PROX_QT_TARGET_RAW_DIST_STD}}
	std-dev: signalrateperspad = {{PROX_QT_TARGET_SIG_STD}}, ambientrateperspad = {{PROX_QT_TARGET_AMB_STD}}
	std-dev: refsignalrateperspad = {{PROX_QT_TARGET_REF_SIG_STD}}
	std-dev: totalsignalrate = {{===}}, totalambientrate = {{===}}
	std-dev: totalrefsignalrate = {{===}}
	std-dev: integrationtime = {{===}}
	rms: rawrange = {{===}}
	rms: signalrateperspad = {{===}}, ambientrateperspad = {{===}}
	rms: refsignalrateperspad = {{===}}
	rms: totalsignalrate = {{===}}, totalambientrate = {{===}}
	rms: totalrefsignalrate = {{===}}
	rms: integrationtime = {{===}}
OK
```

sensor --sel prox --get device_id
--------
 - Command name: `sensor --sel prox --get device_id`
 - Command to send: `sensor --sel prox --get device_id`
```
prox:
	device_id = {{device_id}}
OK
```

sensor --sel prox --get rev_id
--------
 - Command name: `sensor --sel prox --get rev_id`
 - Command to send: `sensor --sel prox --get rev_id`
```
prox:
	rev_id = {{rev_id}}
OK
```

sensor --sel accel --get
--------
 - Command name: `sensor --sel accel --get`
 - Command to send: `sensor --sel accel --get`
```
accel:
	manu_id = {{===}}
	chip_id = {{===}}
	rev_id = {{===}}
	mems_id = {{===}}
	asic_id = {{===}}
	lpm = {{===}}
	lpm_duty_cycle = {{===}}
	startup_time = {{===}}
	rate = {{rate1}}
	bw = {{===}}
	datatype = {{===}}
	dynamic_range = {{range1}}
OK
```

sensor --sel gyro --get
--------
 - Command name: `sensor --sel gyro --get`
 - Command to send: `sensor --sel gyro --get`
```
gyro:
	manu_id = {{===}}
	chip_id = {{===}}
	rev_id = {{===}}
	mems_id = {{===}}
	asic_id = {{===}}
	lpm = {{===}}
	lpm_duty_cycle = {{===}}
	startup_time = {{===}}
	rate = {{rate2}}
	bw = {{===}}
	datatype = {{===}}
	dynamic_range = {{range2}}
	galp = {{===}}
OK
```



sensorreg --sel pressure -r 0x80
--------
 - Command name: `sensorreg --sel pressure -r 0x80`
 - Command to send: `sensorreg --sel pressure -r 0x80`
``` 
Reading in 1 registers from 0x80:
0x80 = {{WV_Phosphorus_Mfg_ID}}
OK
```

ensorreg --sel pressure -r 0x81
--------
 - Command name: `sensorreg --sel pressure -r 0x81`
 - Command to send: `sensorreg --sel pressure -r 0x81`
``` 
Reading in 1 registers from 0x81:
0x81 = {{WV_Phosphorus_Chip_ID}}
OK
```

sensorreg --sel pressure -r 0xA1 1
--------
 - Command name: `sensorreg --sel pressure -r 0xA1 1`
 - Command to send: `sensorreg --sel pressure -r 0xA1 1`
``` 
Reading in 1 registers from 0xA1:
0xA1 = {{WV_Phosphorus_Trim_Rev}}
OK
``` 

sensorreg --sel pressure -r 0xA3 1
--------
 - Command name: `sensorreg --sel pressure -r 0xA3 1`
 - Command to send: `sensorreg --sel pressure -r 0xA3 1`
``` 
Reading in 1 registers from 0xA3:
0xA3 = {{WV_Phosphorus_Trim_Rev2}}
OK
```

sensorreg --sel pressure -r 0xA4 1
--------
 - Command name: `sensorreg --sel pressure -r 0xA4 1`
 - Command to send: `sensorreg --sel pressure -r 0xA4 1`
``` 
Reading in 1 registers from 0xA4:
0xA4 = {{WV_Phosphorus_Trim_Rev3}}
OK
```

detect_pressure
--------
 - Command name: `detect_pressure`
 - Command to send: `sensor --listsensors`
``` 
Name: pressure
Description: Bosch BMP284 Pressure (Phosphorous) SPI
Installed: yes
```

sensorreg --sel pressure -r 0xD0 1
--------
 - Command name: `sensorreg --sel pressure -r 0xD0 1`
 - Command to send: `sensorreg --sel pressure -r 0xD0 1`
``` 
Reading in 1 registers from 0xD0:
0xD0 = {{===}}
OK
```

sensorreg --sel pressure -r 0xF3 3
--------
 - Command name: `sensorreg --sel pressure -r 0xF3 3`
 - Command to send: `sensorreg --sel pressure -r 0xF3 3`
``` 
Reading in 3 registers from 0xF3:
0xF3 = {{===}}
0xF4 = {{===}}
0xF5 = {{===}}
OK
```

sensorreg --sel pressure -r 0xF7 6
--------
 - Command name: `sensorreg --sel pressure -r 0xF7 6`
 - Command to send: `sensorreg --sel pressure -r 0xF7 6`
``` 
Reading in 6 registers from 0xF7:
0xF7 = {{===}}
0xF8 = {{===}}
0xF9 = {{===}}
0xFA = {{===}}
0xFB = {{===}}
0xFC = {{===}}
OK
```

sensor --sel pressure --sample 1000ms --stats
--------
 - Command name: `sensor --sel pressure --sample 1000ms --stats`
 - Command to send: `sensor --sel pressure --sample 1000ms --stats`
``` 
pressure:
	# of samples captured: 26
	# of bad samples (corrupted/lost): 0
	calculated odr: {{WV_Phosphorus_ODR}}Hz
	average: pressure = {{WV_Phosphorus_Average}}, temp = {{WV_Phosphorus_Temp_average}}
	std-dev: pressure = {{WV_Phosphorus_std}}, temp = {{WV_Phosphorus_Temp_std}}
	{{===}}
	{{===}}
	{{===}}
	{{===}}
	{{===}}
OK
```

front_nvm
--------
 - Command name: `front_nvm`
 - Command to send: `camisp --nvmdump`
``` 
NVM Data {{2176}} bytes : 
0x0 : {{0x0}} 
0x8 : {{0x8}} 
0x10 : {{0x10}} 
0x18 : {{0x18}} 
0x20 : {{0x20}} 
0x28 : {{0x28}} 
0x30 : {{0x30}} 
0x38 : {{0x38}} 
0x40 : {{0x40}} 
0x48 : {{0x48}} 
0x50 : {{0x50}} 
0x58 : {{0x58}} 
0x60 : {{0x60}} 
0x68 : {{0x68}} 
0x70 : {{0x70}} 
0x78 : {{0x78}} 
0x80 : {{0x80}} 
0x88 : {{0x88}} 
0x90 : {{0x90}} 
0x98 : {{0x98}} 
0xA0 : {{0xA0}} 
0xA8 : {{0xA8}} 
0xB0 : {{0xB0}} 
0xB8 : {{0xB8}} 
0xC0 : {{0xC0}} 
0xC8 : {{0xC8}} 
0xD0 : {{0xD0}} 
0xD8 : {{0xD8}} 
0xE0 : {{0xE0}} 
0xE8 : {{0xE8}} 
0xF0 : {{0xF0}} 
0xF8 : {{0xF8}} 
0x100 : {{0x100}} 
0x108 : {{0x108}} 
0x110 : {{0x110}} 
0x118 : {{0x118}} 
0x120 : {{0x120}} 
0x128 : {{0x128}} 
0x130 : {{0x130}} 
0x138 : {{0x138}} 
0x140 : {{0x140}} 
0x148 : {{0x148}} 
0x150 : {{0x150}} 
0x158 : {{0x158}} 
0x160 : {{0x160}} 
0x168 : {{0x168}} 
0x170 : {{0x170}} 
0x178 : {{0x178}} 
0x180 : {{0x180}} 
0x188 : {{0x188}} 
0x190 : {{0x190}} 
0x198 : {{0x198}} 
0x1A0 : {{0x1A0}} 
0x1A8 : {{0x1A8}} 
0x1B0 : {{0x1B0}} 
0x1B8 : {{0x1B8}} 
0x1C0 : {{0x1C0}} 
0x1C8 : {{0x1C8}} 
0x1D0 : {{0x1D0}} 
0x1D8 : {{0x1D8}} 
0x1E0 : {{0x1E0}} 
0x1E8 : {{0x1E8}} 
0x1F0 : {{0x1F0}} 
0x1F8 : {{0x1F8}} 
0x200 : {{0x200}} 
0x208 : {{0x208}} 
0x210 : {{0x210}} 
0x218 : {{0x218}} 
0x220 : {{0x220}} 
0x228 : {{0x228}} 
0x230 : {{0x230}} 
0x238 : {{0x238}} 
0x240 : {{0x240}} 
0x248 : {{0x248}} 
0x250 : {{0x250}} 
0x258 : {{0x258}} 
0x260 : {{0x260}} 
0x268 : {{0x268}} 
0x270 : {{0x270}} 
0x278 : {{0x278}} 
0x280 : {{0x280}} 
0x288 : {{0x288}} 
0x290 : {{0x290}} 
0x298 : {{0x298}} 
0x2A0 : {{0x2A0}} 
0x2A8 : {{0x2A8}} 
0x2B0 : {{0x2B0}} 
0x2B8 : {{0x2B8}} 
0x2C0 : {{0x2C0}} 
0x2C8 : {{0x2C8}} 
0x2D0 : {{0x2D0}} 
0x2D8 : {{0x2D8}} 
0x2E0 : {{0x2E0}} 
0x2E8 : {{0x2E8}} 
0x2F0 : {{0x2F0}} 
0x2F8 : {{0x2F8}} 
0x300 : {{0x300}} 
0x308 : {{0x308}} 
0x310 : {{0x310}} 
0x318 : {{0x318}} 
0x320 : {{0x320}} 
0x328 : {{0x328}} 
0x330 : {{0x330}} 
0x338 : {{0x338}} 
0x340 : {{0x340}} 
0x348 : {{0x348}} 
0x350 : {{0x350}} 
0x358 : {{0x358}} 
0x360 : {{0x360}} 
0x368 : {{0x368}} 
0x370 : {{0x370}} 
0x378 : {{0x378}} 
0x380 : {{0x380}} 
0x388 : {{0x388}} 
0x390 : {{0x390}} 
0x398 : {{0x398}} 
0x3A0 : {{0x3A0}} 
0x3A8 : {{0x3A8}} 
0x3B0 : {{0x3B0}} 
0x3B8 : {{0x3B8}} 
0x3C0 : {{0x3C0}} 
0x3C8 : {{0x3C8}} 
0x3D0 : {{0x3D0}} 
0x3D8 : {{0x3D8}} 
0x3E0 : {{0x3E0}} 
0x3E8 : {{0x3E8}} 
0x3F0 : {{0x3F0}} 
0x3F8 : {{0x3F8}} 
{{end_index}} : 
```

boardid
--------
 - Command name: `boardid`
 - Command to send: `boardid`
```
Board Id: {{board_id}}
```

baseband -p
--------
 - Command name: `baseband -p`
 - Command to send: `baseband -p`
``` 
{{===}}
  sim-card-installed: "{{sim_card_installed}}"
  sim-tray-installed: "{{sim_tray_installed}}"
{{===}}

OK
```

temperature --all
--------
 - Command name: `temperature --all`
 - Command to send: `temperature --all`
```
Device: pmu
	TCAL
	    Instant: {{Read PMU TCAL Temp (deg C)}} deg C
	TJINT
	    Instant: {{===}} deg C
	TDEV1
	    Instant: {{Read PMU Temp1 TDEV1 (deg C)}} deg C
	TDEV2
	    Instant: {{Read PMU Temp2 TDEV2 (deg C)}} deg C
	TDEV3
	    Instant: {{Read PMU Temp3 TDEV3 (deg C)}} deg C
	TDEV4
	    Instant: {{Read PMU Temp4 TDEV4 (deg C)}} deg C
	TDEV5
	    Instant: {{Read PMU Temp5 TDEV5 (deg C)}} deg C
	TDEV6
	    Instant: {{Read PMU Temp6 TDEV6 (deg C)}} deg C
	TDEV7
	    Instant: {{Read PMU Temp7 TDEV7 (deg C)}} deg C
	TDEV8
	    Instant: {{Read PMU Temp8 TDEV8 (deg C)}} deg C
Device: pmu2
	TJINT
	    Instant: {{===}} deg C
	TCAL
	    Instant: {{Read PMU2 TCAL Temp (deg C)}} deg C
	TDEV1
	    Instant: {{Read PMU2 TDEV1 Temp (deg C)}} deg C
	TDEV2
	    Instant: {{Read PMU2 TDEV2 Temp (deg C)}} deg C
```

smokey --run1
--------
 - Command name: `smokey --run1`
 - Command to send: `smokey --run Wildfire DisplayBehavior=NoDisplay ControlBitAccess=ReadOnly BrickRequired=None ResultsBehavior=NoFile LogBehavior=ConsoleOnly --test MamaBearStateTest`
``` 
:-) camisp --i2cread {{anything}}
RunI2cRead {{anything}}
{{RunI2cRead}}
Pass
------------------------------------------------------------------------------
[{{anything}}] {{anything}} 			Exit code = {{anything}}
------------------------------------------------------------------------------
{{MamaBear}}
Hark, Station! Behold the data I present you!
{{MamaBear_Armed_State}}
------------------------------------------------------------------------------
[{{anything}}] {{anything}} 			camisp --exit
------------------------------------------------------------------------------
:-) camisp --exit
RunExit
Pass
------------------------------------------------------------------------------
```


smokey --run2
--------
 - Command name: `smokey --run2`
 - Command to send: `smokey --run Wildfire DisplayBehavior=NoDisplay ControlBitAccess=ReadOnly BrickRequired=None ResultsBehavior=NoFile LogBehavior=ConsoleOnly --test PearlStatus`
``` 
------------------------------------------------------------------------------
:-) camisp --method pearl rigel status
Device status:Fault Status 0x7C,0x7E,0x80,0x82,0x84:{{Device status:Fault Status 0x7C,0x7E,0x80,0x82,0x84}}
CC State 0x1C,0xF0:{{CC State 0x1C,0xF0}}
Rigel State {{Rigel State_CC}}
Pass
------------------------------------------------------------------------------
[{{===}}] {{===}} 			Exit code = {{===}}
------------------------------------------------------------------------------
Hark, Station! Behold the data I present you!
{{FaultStatus}}
Hark, Station! Behold the data I present you!
{{RigelState}}
------------------------------------------------------------------------------
[{{===}}] {{===}} 			camisp --method pearl romeo cap
------------------------------------------------------------------------------
:-) camisp --method pearl romeo cap
Device status:Capacitance:{{===}}
Status:{{===}}
Pass
------------------------------------------------------------------------------
[{{===}}] {{===}} 			Exit code = {{===}}
------------------------------------------------------------------------------
CapValue:{{CapValue}}
Hark, Station! Behold the data I present you!
{{===}}
------------------------------------------------------------------------------
[{{===}}] {{===}} 			camisp --exit
------------------------------------------------------------------------------
:-) camisp --exit
RunExit
Pass
------------------------------------------------------------------------------
```


Grape Short Test
--------
 - Command name: `Grape Short Test`
 - Command to send: `smokey --run TouchShortsTest`
```
Shorts Sig Table (X): ({{anything}})
{{Shorts_Sig_Table_X}}
  Low Limit = {{anything}}
  High Limit = {{Sig_X_High_Limit}}


Shorts Gnd Table (X): ({{anything}})
{{Shorts_Gnd_Table_X}}
  Low Limit = {{anything}}
  High Limit = {{Gnd_X_High_Limit}}


Shorts Sig Table (Y): ({{anything}})
{{Shorts_Sig_Table_Y}}
  Low Limit = {{anything}}
  High Limit = {{Sig_Y_High_Limit}}


Shorts Gnd Table (Y): ({{anything}})
{{Shorts_Gnd_Table_Y}}
  Low Limit = {{anything}}
  High Limit = {{Gnd_Y_High_Limit}}
{{/[\s\S]*/}}Passed
```



touch -p firmware-version
--------
 - Command name: `touch -p firmware-version`
 - Command to send: `touch -p firmware-version`
```
firmware-version: {{Grape Firmware Version}}
OK
```


Grape Offset Test
--------
 - Command name: `Grape Offset Test`
 - Command to send: `touch --test offset --run --option "--no_matrix"`
```
--> Test data for 'OFFS_DCSIG':
--> Limits check for 'OFFS_DCSIG_MIN': LOW = {{d}}, VALUE = {{b}}, HIGH = {{c}}, pass!
--> Limits check for 'OFFS_DCSIG_AVG': LOW = {{d1}}, VALUE = {{b1}}, HIGH = {{c1}}, pass!
--> Limits check for 'OFFS_DCSIG_MAX': LOW = {{d2}}, VALUE = {{b2}}, HIGH = {{c2}}, pass!

--> Test data for 'OFFS_PHASE':
--> Limits check for 'OFFS_PHASE_MIN': LOW = {{d3}}, VALUE = {{b3}}, HIGH = {{c3}}, pass!
--> Limits check for 'OFFS_PHASE_AVG': LOW = {{d4}}, VALUE = {{b4}}, HIGH = {{c4}}, pass!
--> Limits check for 'OFFS_PHASE_MAX': LOW = {{d5}}, VALUE = {{b5}}, HIGH = {{c5}}, pass!
{{anything}}
{{anything}}
{{anything}}
{{anything}}

PASS

```

Grape Firmware Version
--------
 - Command name: `Grape Firmware Version`
 - Command to send: `touch -p firmware-version`
```
firmware-version: {{Grape Firmware Version}}
OK
```

Rosaline_toggle_interrupt
--------
 - Command name: `Rosaline_toggle_interrupt`
 - Command to send: `sensor --sel prox --sample 1s --stats`
```
prox:
	{{anything}} of samples captured: {{Rosalinedata}}
	{{anything}} of bad samples (corrupted/lost): {{anything}}
	calculated odr: {{anything}}
	average: rawrange {{anything}}
	average: signalrateperspad {{anything}}
	average: refsignalrateperspad {{anything}}
	average: totalsignalrate{{anything}}
	average: totalrefsignalrate {{anything}}
	average: integrationtime {{anything}}
	std-dev: rawrange {{anything}}
	std-dev: signalrateperspad {{anything}}
	std-dev: refsignalrateperspad {{anything}}
	std-dev: totalsignalrate {{anything}}
	std-dev: totalrefsignalrate {{anything}}
	std-dev: integrationtime {{anything}}
	rms: rawrange {{anything}}
	rms: signalrateperspad {{anything}}
	rms: refsignalrateperspad {{anything}}
	rms: totalsignalrate{{anything}}
	rms: totalrefsignalrate {{anything}}
	rms: integrationtime {{anything}}
OK
```


Read Juliet ID
--------
 - Command name: `Read Juliet ID`
 - Command to send: `camisp --id`
```
RunGetId 
{{Juliet_ID}}
Pass
```


camisp --sn
--------
 - Command name: `camisp --sn`
 - Command to send: `camisp --sn`
```
Serial Number: {{Juliet_SN}}
Pass
```

Orion Bellatrix ADC temperature read (deg C/bit)
--------
 - Command name: `i2c -d 2 0x13 0xA5 1`
 - Command to send: `i2c -d 2 0x13 0xA5 1`
```
Data:  {{No_Upload_PDCA}}
```

Orion Bellatrix ADC temperature read (deg C/bit)
--------
 - Command name: `i2c -d 2 0x13 0xA4 1`
 - Command to send: `i2c -d 2 0x13 0xA4 1`
```
Data:  {{No_Upload_PDCA}}
```

Orion Output Bellatrix State
--------
 - Command name: `i2c -d 2 0x13 0x1A 1`
 - Command to send: `i2c -d 2 0x13 0x1A 1`
```
Data:  {{No_Upload_PDCA}}
```

Orion input communications test 500pF
--------
 - Command name: `Orion input communications test 500pF`
 - Command to send: `i2c -d 2 0x13 0x74 8`
```
Data:  {{No_Upload_PDCA}}
```

Orion Input Bellatrix State2
--------
 - Command name: `Orion Input Bellatrix State2`
 - Command to send: `i2c -d 2 0x13 0x1A 1`
```
Data:  {{No_Upload_PDCA}}
```

Orion input communications test 1nF
--------
 - Command name: `Orion input communications test 1nF`
 - Command to send: `i2c -d 2 0x13 0x74 8`
```
Data:  {{No_Upload_PDCA}}
```

Orion Output Bellatrix State Boost
--------
 - Command name: `Orion Output Bellatrix State Boost`
 - Command to send: `i2c -d 2 0x13 0x74 8`
```
Data:  {{No_Upload_PDCA}}
```

Orion Bellatrix ADC ACCPWR read
--------
 - Command name: `Orion Bellatrix ADC ACCPWR read`
 - Command to send: `i2c -d 2 0x13 0x74 8`
```
Data:  {{No_Upload_PDCA}}
```

Orion Bellatrix ADC VP read Boost
--------
 - Command name: `Orion Bellatrix ADC VP read Boost`
 - Command to send: `i2c -d 2 0x13 0x74 8`
```
Data:  {{No_Upload_PDCA}}
```


Orion Input Bellatrix State3
--------
 - Command name: `Orion Input Bellatrix State3`
 - Command to send: `i2c -d 2 0x13 0x1A 1`
```
Data:  {{No_Upload_PDCA}}
```

Rosaline Pulse Width
--------
 - Command name: `Rosaline Pulse Width`
 - Command to send: `sensor --sel prox --get nvm`
```
prox:
	nvm = 
00000000: {{anything}}
00000010: {{anything}}
00000020: {{anything}}
00000030: {{anything}}
00000040: {{anything}}
00000050: {{anything}}
00000060: {{anything}}
00000070: {{anything}} {{anything}} {{anything}} {{Rosaline_Pulse_Width_data}} {{anything}} {{anything}} {{anything}} {{anything}} {{anything}} {{anything}} {{anything}} {{anything}} {{anything}} {{anything}} {{anything}} {{anything}} |{{anything}}|

OK
```

Read Temp
--------
 - Command name: `Read Temp`
 - Command to send: `temperature --all`
```
Device: pmu
	TCAL
	    Instant: {{Read PMU TCAL Temp}} deg C
	{{anything}}
	    {{anything}}
	TDEV1
	    Instant: {{Read PMU Temp1 TDEV1}} deg C
	TDEV2
	    Instant: {{Read PMU Temp2 TDEV2}} deg C
	TDEV3
	    Instant: {{Read PMU Temp3 TDEV3}} deg C
	TDEV4
	    Instant: {{Read PMU Temp4 TDEV4}} deg C
	TDEV5
	    Instant: {{Read PMU Temp5 TDEV5}} deg C
	TDEV6
	    Instant: {{Read PMU Temp6 TDEV6}} deg C
	TDEV7
	    Instant: {{Read PMU Temp7 TDEV7}} deg C
	TDEV8
	    Instant: {{Read PMU Temp8 TDEV8}} deg C
Device: pmu2
	{{anything}}
	    {{anything}}
	TCAL
	    Instant: {{Read PMU2 TCAL Temp}} deg C
	TDEV1
	    Instant: {{Read PMU2 TDEV1 Temp}} deg C
	TDEV2
	    Instant: {{Read PMU2 TDEV2 Temp}} deg C

```


 EDPBERTest 
--------
 - Command name: `display --method ber --options -g`
 - Command to send: ` display --method ber --options "-g"`
```
Reading EDP Panel BER stats...
{{Err_Count}}

OK
```

sensorreg -s compass -r 0x40 62
--------
 - Command name: `sensorreg -s compass -r 0x40 62`
 - Command to send: `sensorreg -s compass -r 0x40 62`
```
Reading in 62 registers from 0x40:
0x40 = {{0x40}}
0x41 = {{0x41}}
0x42 = {{0x42}}
0x43 = {{0x43}}
0x44 = {{0x44}}
0x45 = {{0x45}}
0x46 = {{0x46}}
0x47 = {{0x47}}
0x48 = {{0x48}}
0x49 = {{0x49}}
0x4A = {{0x4A}}
0x4B = {{0x4B}}
0x4C = {{0x4C}}
0x4D = {{0x4D}}
0x4E = {{0x4E}}
0x4F = {{0x4F}}
0x50 = {{0x50}}
0x51 = {{0x51}}
0x52 = {{0x52}}
0x53 = {{0x53}}
0x54 = {{0x54}}
0x55 = {{0x55}}
0x56 = {{0x56}}
0x57 = {{0x57}}
0x58 = {{0x58}}
0x59 = {{0x59}}
0x5A = {{0x5A}}
0x5B = {{0x5B}}
0x5C = {{0x5C}}
0x5D = {{0x5D}}
0x5E = {{0x5E}}
0x5F = {{0x5F}}
0x60 = {{0x60}}
0x61 = {{0x61}}
0x62 = {{0x62}}
0x63 = {{0x63}}
0x64 = {{0x64}}
0x65 = {{0x65}}
0x66 = {{0x66}}
0x67 = {{0x67}}
0x68 = {{0x68}}
0x69 = {{0x69}}
0x6A = {{0x6A}}
0x6B = {{0x6B}}
0x6C = {{0x6C}}
0x6D = {{0x6D}}
0x6E = {{0x6E}}
0x6F = {{0x6F}}
0x70 = {{0x70}}
0x71 = {{0x71}}
0x72 = {{0x72}}
0x73 = {{0x73}}
0x74 = {{0x74}}
0x75 = {{0x75}}
0x76 = {{0x76}}
0x77 = {{0x77}}
0x78 = {{0x78}}
0x79 = {{0x79}}
0x7A = {{0x7A}}
0x7B = {{0x7B}}
0x7C = {{0x7C}}
0x7D = {{0x7D}}
OK
```
