ERI parsing definition file
===========================

Version Info
------------
2017_10_16  ver01

[Scorpius]

Commands that can be parsed
===========================

getv
--------
 - Command name: `getv`
 - Command to send: `getv`
```
Vrect Voltage: {{voltage}}mv
```

geti
--------
 - Command name: `geti`
 - Command to send: `geti`
```
Vrect Current:{{current}}ma
```




