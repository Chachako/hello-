ERI parsing definition file
===========================

Version Info
------------
AUGUST 22, 2015 ver01

[TOC]

Commands that can be parsed
===========================

a
--------
 - Command name: `a`
 - Command to send: `a`
```
A1,A12,B1,B12: Skipped
A2:            No Adjacent Pin Short{{===}}
A3:            No Adjacent Pin Short{{===}}
A4,A9,B4,B9:   No Adjacent Pin Short{{===}}
A5:            No Adjacent Pin Short{{===}}
A6:            No Adjacent Pin Short{{===}}
A7:            No Adjacent Pin Short{{===}}
A8:            No Adjacent Pin Short{{===}}
A10:           No Adjacent Pin Short{{===}}
A11:           No Adjacent Pin Short{{===}}
B2:            No Adjacent Pin Short{{===}}
B3:            No Adjacent Pin Short{{===}}
B5:            No Adjacent Pin Short{{===}}
B6:            No Adjacent Pin Short{{===}}
B7:            No Adjacent Pin Short{{===}}
B8:            No Adjacent Pin Short{{===}}
B10:           No Adjacent Pin Short{{===}}
B11:           No Adjacent Pin Short{{===}}
```

d
--------
 - Command name: `d`
 - Command to send: `d`
```
A2:            > 1000k{{===}}
A3:            > 1000k{{===}}
A6:            > 1000k{{===}}
A7:            > 1000k{{===}}
A10:           > 1000k{{===}}
A11:           > 1000k{{===}}
B2:            > 1000k{{===}}
B3:            > 1000k{{===}}
B6:            > 1000k{{===}}
B7:            > 1000k{{===}}
B10:           > 1000k{{===}}
B11:           > 1000k{{===}}
```

