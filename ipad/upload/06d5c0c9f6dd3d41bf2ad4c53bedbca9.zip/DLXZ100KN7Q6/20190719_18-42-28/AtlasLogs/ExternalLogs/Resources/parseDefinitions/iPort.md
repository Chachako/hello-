ERI parsing definition file
===========================

Version Info
------------
AUGUST 22, 2015 ver01

[TOC]

Commands that can be parsed
===========================

getversion
--------
 - Command name: `getversion`
 - Command to send: `getversion`
```
"version": "{{iport_ver}}"
```

debug key1
--------
 - Command name: `debug key1`
 - Command to send: `debug key1`
```
{"debug": "key1"}
{"group": "message", "item": "start"}
{"pos": "Left", "group": "adj", "item": "a01-a02", "value": 219107.59, "typ": "res", "lim": {"open": 20000000, "short": 5}, "result": "Pass"}
{"pos": "Left", "group": "adj", "item": "a02-a03", "value": 448012.81, "typ": "res", "lim": {"open": 20000000, "short": 5}, "result": "Pass"}
{"pos": "Left", "group": "adj", "item": "a03-a04", "value": 240299.80, "typ": "res", "lim": {"open": 20000000, "short": 5}, "result": "Pass"}
{"pos": "Left", "group": "adj", "item": "a04-a05", "value": 732269.81, "typ": "res", "lim": {"open": 20000000, "short": 5}, "result": "Pass"}
{"pos": "Left", "group": "adj", "item": "a05-a06", "value": 551453.19, "typ": "res", "lim": {"open": 20000000, "short": 5}, "result": "Pass"}
{"pos": "Left", "group": "adj", "item": "a06-a07", "value": 13472266.00, "typ": "res", "lim": {"open": 20000000, "short": 5}, "result": "Pass"}
{"pos": "Left", "group": "adj", "item": "a07-a08", "value": 13472266.00, "typ": "res", "lim": {"open": 20000000, "short": 5}, "result": "Pass"}
{"pos": "Left", "group": "adj", "item": "a08-a09", "value": 13472266.00, "typ": "res", "lim": {"open": 20000000, "short": 5}, "result": "Pass"}
{"pos": "Left", "group": "adj", "item": "a09-a10", "value": 244753.80, "typ": "res", "lim": {"open": 20000000, "short": 5}, "result": "Pass"}
{"pos": "Left", "group": "adj", "item": "a10-a11", "value": 447151.59, "typ": "res", "lim": {"open": 20000000, "short": 5}, "result": "Pass"}
{"pos": "Left", "group": "adj", "item": "a11-a12", "value": 222179.00, "typ": "res", "lim": {"open": 20000000, "short": 5}, "result": "Pass"}
{"pos": "Left", "group": "adj", "item": "b01-b02", "value": 192137.91, "typ": "res", "lim": {"open": 20000000, "short": 5}, "result": "Pass"}
{"pos": "Left", "group": "adj", "item": "b02-b03", "value": 425944.69, "typ": "res", "lim": {"open": 20000000, "short": 5}, "result": "Pass"}
{"pos": "Left", "group": "adj", "item": "b03-b04", "value": 235877.20, "typ": "res", "lim": {"open": 20000000, "short": 5}, "result": "Pass"}
{"pos": "Left", "group": "adj", "item": "b04-b05", "value": 743540.13, "typ": "res", "lim": {"open": 20000000, "short": 5}, "result": "Pass"}
{"pos": "Left", "group": "adj", "item": "b05-b06", "value": 551453.19, "typ": "res", "lim": {"open": 20000000, "short": 5}, "result": "Pass"}
{"pos": "Left", "group": "adj", "item": "b06-b07", "value": 13472266.00, "typ": "res", "lim": {"open": 20000000, "short": 5}, "result": "Pass"}
{"pos": "Left", "group": "adj", "item": "b07-b08", "value": 13472266.00, "typ": "res", "lim": {"open": 20000000, "short": 5}, "result": "Pass"}
{"pos": "Left", "group": "adj", "item": "b08-b09", "value": 13472266.00, "typ": "res", "lim": {"open": 20000000, "short": 5}, "result": "Pass"}
{"pos": "Left", "group": "adj", "item": "b09-b10", "value": 246672.30, "typ": "res", "lim": {"open": 20000000, "short": 5}, "result": "Pass"}
{"pos": "Left", "group": "adj", "item": "b10-b11", "value": 447151.59, "typ": "res", "lim": {"open": 20000000, "short": 5}, "result": "Pass"}
{"pos": "Left", "group": "adj", "item": "b11-b12", "value": 220948.59, "typ": "res", "lim": {"open": 20000000, "short": 5}, "result": "Pass"}
{"pos": "Left", "group": "adj", "item": "a02-b11", "value": 448875.19, "typ": "res", "lim": {"open": 20000000, "short": 5}, "result": "Pass"}
{"pos": "Left", "group": "adj", "item": "a03-b10", "value": 449738.50, "typ": "res", "lim": {"open": 20000000, "short": 5}, "result": "Pass"}
{"pos": "Left", "group": "adj", "item": "a05-b08", "value": 13472266.00, "typ": "res", "lim": {"open": 20000000, "short": 5}, "result": "Pass"}
{"pos": "Left", "group": "adj", "item": "a06-b07", "value": 13472266.00, "typ": "res", "lim": {"open": 20000000, "short": 5}, "result": "Pass"}
{"pos": "Left", "group": "adj", "item": "a07-b06", "value": 13472266.00, "typ": "res", "lim": {"open": 20000000, "short": 5}, "result": "Pass"}
{"pos": "Left", "group": "adj", "item": "a08-b05", "value": 13472266.00, "typ": "res", "lim": {"open": 20000000, "short": 5}, "result": "Pass"}
{"pos": "Left", "group": "adj", "item": "a10-b03", "value": 436894.81, "typ": "res", "lim": {"open": 20000000, "short": 5}, "result": "Pass"}
{"pos": "Left", "group": "adj", "item": "a11-b02", "value": 435199.31, "typ": "res", "lim": {"open": 20000000, "short": 5}, "result": "Pass"}
{"pos": "Left", "group": "gnd", "item": "a02-a01", "value": 2258.00, "typ": "vdrp", "lim": {"open": 2500, "short": 50}, "result": "Pass"}
{"pos": "Left", "group": "gnd", "item": "a03-a01", "value": 2257.00, "typ": "vdrp", "lim": {"open": 2500, "short": 50}, "result": "Pass"}
{"pos": "Left", "group": "gnd", "item": "a04-a01", "value": 159.00, "typ": "vdrp", "lim": {"open": 600, "short": 50}, "result": "Pass"}
{"pos": "Left", "group": "gnd", "item": "a05-a01", "value": 533.00, "typ": "vdrp", "lim": {"open": 1000, "short": 50}, "result": "Pass"}
{"pos": "Left", "group": "gnd", "item": "a06-a01", "value": 2276.00, "typ": "vdrp", "lim": {"open": 2500, "short": 50}, "result": "Pass"}
{"pos": "Left", "group": "gnd", "item": "a07-a01", "value": 2276.00, "typ": "vdrp", "lim": {"open": 2500, "short": 50}, "result": "Pass"}
{"pos": "Left", "group": "gnd", "item": "a08-a01", "value": 2276.00, "typ": "vdrp", "lim": {"open": 2500, "short": 50}, "result": "Pass"}
{"pos": "Left", "group": "gnd", "item": "a09-a01", "value": 159.00, "typ": "vdrp", "lim": {"open": 600, "short": 50}, "result": "Pass"}
{"pos": "Left", "group": "gnd", "item": "b02-a01", "value": 2257.00, "typ": "vdrp", "lim": {"open": 2500, "short": 50}, "result": "Pass"}
{"pos": "Left", "group": "gnd", "item": "b03-a01", "value": 2257.00, "typ": "vdrp", "lim": {"open": 2500, "short": 50}, "result": "Pass"}
{"pos": "Left", "group": "gnd", "item": "b04-a01", "value": 159.00, "typ": "vdrp", "lim": {"open": 600, "short": 50}, "result": "Pass"}
{"pos": "Left", "group": "gnd", "item": "b05-a01", "value": 532.00, "typ": "vdrp", "lim": {"open": 1000, "short": 50}, "result": "Pass"}
{"pos": "Left", "group": "gnd", "item": "b06-a01", "value": 2276.00, "typ": "vdrp", "lim": {"open": 2500, "short": 50}, "result": "Pass"}
{"pos": "Left", "group": "gnd", "item": "b07-a01", "value": 2275.00, "typ": "vdrp", "lim": {"open": 2500, "short": 50}, "result": "Pass"}
{"pos": "Left", "group": "gnd", "item": "b08-a01", "value": 2276.00, "typ": "vdrp", "lim": {"open": 2500, "short": 50}, "result": "Pass"}
{"pos": "Left", "group": "gnd", "item": "b09-a01", "value": 159.00, "typ": "vdrp", "lim": {"open": 600, "short": 50}, "result": "Pass"}
{"group": "message","item": "end"}
```
