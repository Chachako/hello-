function set_hid( reportID, payloadArray )
    local payloadArray1 = {}
    for i,v in ipairs(payloadArray) do
        table.insert(payloadArray1, string.format("%X", v))
    end 
    local payload = table.concat(payloadArray1, " ")
    local cmd = string.format("hidreport -du 0xFF00,0x0036 hset %X %X %s", reportID, reportID, payload)
    return doOsCmd(cmd)
end

function get_hid( reportID )
  local cmd = string.format("hidreport -du 0xFF00,0x0036 get 0x%02X", reportID)
  return doOsCmd(cmd)
end

-- -- For LPP test
-- local function MakeFloat(byte0, byte1, byte2, byte3)
--   local raw = byte0
--   raw = bit32.bor(raw, bit32.lshift(byte1, 8))
--   raw = bit32.bor(raw, bit32.lshift(byte2, 16))
--   raw = bit32.bor(raw, bit32.lshift(byte3, 24))
  
--   local sign = bit32.extract(raw, 31, 1)
--   local exponent = bit32.extract(raw, 23, 8)
--   local mantissa = bit32.extract(raw, 0, 23)
  
--   local n = 1
--   for i = -23, -1 do
--     n = n + (math.pow(2, i) * bit32.extract(mantissa, 0, 1))
--     mantissa = bit32.rshift(mantissa, 1)
--   end  
--   n = n * (math.pow(2, exponent - 127))
--   if (sign == 1) then
--     n = n * -1
--   end  
--   return n
-- end
local function MakeFloat(byte0, byte1, byte2, byte3)
  local raw = byte0
  raw = raw | (byte1 << 8)
  raw = raw | (byte2 << 16)
  raw = raw | (byte3 << 24)
  local sign =  (raw >> 31) & 0x01 --bit32.extract(raw, 31, 1)
  local exponent = (raw >> 23) & 0xFF --bit32.extract(raw, 23, 8)
  local mantissa = raw & (2^23 - 1) --bit32.extract(raw, 0, 23)
  local n = 1
  for i = -23, -1 do
    n = n + ((2 ^ i) * (mantissa & 1))
    mantissa = mantissa >> 1
  end  
  n = n * ((2 ^ (exponent - 127)))
  if (sign == 1) then
    n = n * -1
  end  
  return n
end

--E.g. get_smokey_data("buffer read:   0xaA  0xbB  0xcC", 3) ==> "aAbBcC", true, ""
function get_smokey_data(full_command_recv, expected_byte_count)
  local bool_result = true
  local fail_info = ""
  local str = string.match(full_command_recv or "", "Reading " .. tostring(expected_byte_count) .. " bytes.-buffer read:%s+([^%c]+)")
  local str1 = string.gsub(str or "", "%s", "")
  local data = string.gsub(str1 or "", "0[Xx]", "")
  if string.len(data) / 2 ~= expected_byte_count then
    bool_result = false
    fail_info = "Data length is not " .. tostring(expected_byte_count) .. ", data: " .. data
  end
  return data, bool_result, fail_info
end 

--E.g. get_smokey_bytes("buffer read:  0xaA  0xbB  0xcC", 3) ==> {"aA", "bB", "cC"}, true, ""
function get_smokey_bytes(full_command_recv, expected_byte_count)
  local bool_result = true
  local fail_info = ""
  local str = string.match(full_command_recv or "", "Reading " .. tostring(expected_byte_count) .. " bytes.-buffer read:%s+([^%c]+)")
  local str1 = string.gsub(str or "", "%s", "")
  local data = string.gsub(str1 or "", "0[Xx]", "")
  if string.len(data) / 2 ~= expected_byte_count then
    bool_result = false
    fail_info = "Data length is not " .. tostring(expected_byte_count) .. ", data: " .. data
    return data, bool_result, fail_info
  end
    
  local bytes = {}
  for i in string.gmatch(data, "..") do
    table.insert(bytes, i)
  end
  return bytes, bool_result, fail_info
end


function Sys_I_Vboost_OFF(self)  ----base I
  local _,mlbiRecv = doScorpiusCmd("getmlbi\r")
  local testValue = string.match(mlbiRecv or "","Current:%s+(.-)ma")
  if not testValue then
    ResultTable.resultCode = false
    ResultTable.resultString = "No Data"
    return
  end

  local bResult = testValue and true or false
  if string.find(self.name or "","Vboost%_OFF") then
    if bResult then
      ComTable["VboostOff"] = testValue
    end
  elseif string.find(self.name or "", "Sys_I@3C") then
    if bResult then
      ComTable["Sys_I@3C"] = testValue
    end
  elseif string.find(self.name or "","Vboost%_ON") then
    if bResult then
      ComTable["VboostOn"] = testValue
    end
  elseif string.find(self.name or "","Sys_I@10C") then
    if bResult then
      ComTable["Sys_I@10C"] = testValue
    end
  end
  bResult = compareAandB(tonumber(testValue)/1000.0,self.limitSet.lower,self.limitSet.upper,true)
  ResultTable.resultCode = bResult
  ResultTable.resultString = tostring(tonumber(testValue)/1000.0)

end

function Sys_V_Vboost_OFF(self)  ------Base V
  local _,mlbvRecv = doScorpiusCmd("getmlbv\r")
  local testValue = string.match(mlbvRecv or "","MLB Voltage:%s+(.-)mv")
  if not testValue then
    ResultTable.resultCode = false
    ResultTable.resultString = "No Data"
    return
  end

  local bResult = testValue and true or false
  if string.find(self.name or "", "Sys_V@3C") then
    if bResult then
      ComTable["Sys_V@3C"] = testValue
    end
  elseif string.find(self.name or "","Vboost%_ON") then
    if bResult then
      ComTable["VboostOnBaseV"] = testValue
    end
  elseif string.find(self.name or "","Vboost%_OFF") then
    if bResult then
      ComTable["VboostOffBaseV"] = testValue
    end
  elseif string.find(self.name or "","Sys_V@10C") then
    if bResult then
      ComTable["Sys_V@10C"] = testValue
    end
  end
  bResult = compareAandB(tonumber(testValue)/1000.0,self.limitSet.lower,self.limitSet.upper,true)
  ResultTable.resultCode = bResult
  ResultTable.resultString = tostring(tonumber(testValue)/1000.0)

end

function Sys_P_Vboost_OFF(self)  ------Base P
  if ComTable["VboostOffBaseV"] and ComTable["VboostOff"] then
    local testResult = (tonumber(ComTable["VboostOffBaseV"])/1000.0 * (tonumber(ComTable["VboostOff"])/1000.0))

    ComTable["VboostOffBaseP"] = testResult
    local bResult =compareAandB(testResult,self.limitSet.lower,self.limitSet.upper,true) --testResult and true or false
    ResultTable.resultCode = bResult
    ResultTable.resultString = testResult
  else
    ResultTable.resultCode = false
    ResultTable.resultString = "No Data"
  end
end

function itemPhaseshifted(self)
  ComTable["firstValue"] = 1600       
  ComTable["loopTest"] = 0xb3

   doDiagsCmd("i2c -v 7 0x55 0x1f 0x00\n")
    app.wait(200)
    doDiagsCmd("i2c -v 7 0x55 0x0f 0x00\n")
    app.wait(200)
    doScorpiusCmd("eload set 0\r")
    app.wait(200)
    doScorpiusCmd("set mode none\r")
    app.wait(200)
    doDiagsCmd("i2c -v 7 0x55 0x0f 0x01\n")
    app.wait(200)
    doDiagsCmd("i2c -v 7 0x55 0x03 0x06 0x40 multiple\n")
    app.wait(200)
    doDiagsCmd("i2c -v 7 0x55 0x0b 0x00 0xb3 multiple\n")
    app.wait(200)
    doScorpiusCmd("set mode rx\r")

    app.wait(200)
    doScorpiusCmd("eload set 8\r")
    app.wait(200)
     --change to mode 1 because of the Vrect has ASK ripple(0301)

  local finalResult = ""
  local  _,getVValue = doScorpiusCmd("ikt adc\r")

  local _,testValue = string.match(getVValue or "","Vrect = (.-)Vrect = (.-) V")

  if not testValue then
    ResultTable.resultCode = false --bResult
    ResultTable.resultString ="No Data"
    return
  end

  if not compareAandB((tonumber(testValue)),self.lowerValue,self.upperValue,true) then
    print("Looptest ok")
    finalResult = loopTest(ComTable["loopTest"],self.upperValue,self.lowerValue,testValue)
    if tonumber(ComTable["loopTest"]) == 180 and not compareAandB(tonumber(testValue),self.lowerValue,self.upperValue,true) then
      finalResult = loopTest(ComTable["loopTest"],self.upperValue,self.lowerValue,testValue)
    end
  else
    finalResult = testValue
  end
  local bResult = compareAandB(tonumber( finalResult),self.limitSet.lower,self.limitSet.upper,true)
  finalResult=finalResult
  ResultTable.resultCode = bResult
  ResultTable.resultString =tostring(finalResult)

end

function itemPhaseshifted1(self) --20180322
   app.wait(200)
   doScorpiusCmd("set mode rx\r")
  local finalResult = ""
 
  local  _,getVValue = doScorpiusCmd("ikt adc\r") --20180322

  local _,testValue = string.match(getVValue or "","Vrect = (.-)Vrect = (.-) V")

  if not testValue then
    ResultTable.resultCode = false --bResult
    ResultTable.resultString ="No Data"
    return
  end

  if not compareAandB((tonumber(testValue)),self.lowerValue2,self.upperValue2,true) then
    print("Looptest ok")
    finalResult = loopTest(ComTable["loopTest"],self.upperValue2,self.lowerValue2,testValue)
    if tonumber(ComTable["loopTest"]) == 180 and not compareAandB(tonumber(testValue),self.lowerValue2,self.upperValue2,true) then
      finalResult = loopTest(ComTable["loopTest"],self.upperValue2,self.lowerValue2,testValue)
    end
  else
    finalResult = testValue
  end
end




function Sys_P_Delta_of_Test(self)  ------change p
  if string.find(self.name or "", "Delta_of_3C") then
    local current = ((tonumber(ComTable["Sys_V@3C"])/1000.0) * (tonumber(ComTable["Sys_I@3C"])/1000.0))
    local testResult = current - tonumber(ComTable["VboostOffBaseP"])
    local bResult = compareAandB(tonumber(testResult),self.limitSet.lower,self.limitSet.upper,true) --testResult and true or false
    ResultTable.resultCode = bResult
    ResultTable.resultString = testResult
  elseif string.find(self.name or "","Delta_of_10C") then
    local current = ((tonumber(ComTable["Sys_V@10C"])/1000.0) * (tonumber(ComTable["Sys_I@10C"])/1000.0))
    local testResult = current - tonumber(ComTable["VboostOffBaseP"])
    local bResult = compareAandB(tonumber(testResult),self.limitSet.lower,self.limitSet.upper,true) 
    ResultTable.resultCode = bResult
    ResultTable.resultString = testResult
  elseif string.find(self.name or "","Delta%_of%_Vboost") then
    local current = ((tonumber(ComTable["VboostOnBaseV"])/1000.0) * (tonumber(ComTable["VboostOn"])/1000.0))
    local testResult = current - tonumber(ComTable["VboostOffBaseP"])
    local bResult = compareAandB(tonumber(testResult),self.limitSet.lower,self.limitSet.upper,true) 
    ResultTable.resultCode = bResult
    ResultTable.resultString = testResult
  end

end

-- function itemVrect_20mA_old(self)
--   loopTest(self.target_vrect)
--   local testiValue = nil
--   if self.name:match("@0.1C") then
--     local _,getcurrentValue = doScorpiusCmd("ikt adc\r")
--     testiValue = string.match(getcurrentValue or "","Current = (.-) A")
--     testiValue = tonumber(testiValue) * 1000
--   else  
--     local _,getcurrentValue = doScorpiusCmd("eload adc\r")
--     testiValue = string.match(getcurrentValue or "","Current = (.-) mA")
--   end
--   ComTable["Current"] = tonumber(testiValue) 
--   testiValue = testiValue and tonumber(testiValue) or "No Data"
--   local bResult = compareAandB(tonumber(testiValue)/1000,self.limitSet.lower,self.limitSet.upper,true) 
--   ResultTable.resultCode = bResult
--   ResultTable.resultString =tostring(testiValue)/1000
-- end

function itemgetCurrent(self)
  local _,getVValue = doScorpiusCmd("ikt adc\r")
  local _,testValue = string.match(getVValue or "","Vrect = (.-)Vrect = (.-) V")

  if (tonumber(testValue) == nil) then
    ResultTable.resultCode = false
    ResultTable.resultString = "No Data"
    return
  end

  ComTable["Voltage"] = tonumber( testValue)
  
  testValue=testValue
  local bResult = compareAandB(tonumber(testValue),self.limitSet.lower,self.limitSet.upper,true) 
  ResultTable.resultCode = bResult
  ResultTable.resultString = testValue or "No Data"
end

function itemGetPower(self)
  if ((tonumber(ComTable["Voltage"]) == nil) and (tonumber(ComTable["Current"]))) then
    ResultTable.resultCode = false
    ResultTable.resultString = "No Data"
    return
  end

  local testValue = ComTable["Voltage"] * ComTable["Current"]/1000
  local bResult = compareAandB(testValue,self.limitSet.lower,self.limitSet.upper,true)
  ResultTable.resultCode = bResult
  ResultTable.resultString = testValue or "No Data"
end

function ASK_Period_Measurement(self)
  local periodNumber = 0
  local periodNumberFlag = 0
  isOutLoopFlag = false
  if(self.flag == true) then
    ComTable_Period = {}
    ComTable_Period1 = {}
    repeat 
      periodNumberFlag = periodNumberFlag +1
      doDiagsCmd("i2c -w 7 0x55 0x13\n") ----need comfirm
      app.wait(500)

      local _,Rtrecv = doDiagsCmd("i2c -r 7 0x55 4\n")  -- add at 20171205 by henry
      print("Loop ========= 0x32 Start",Rtrecv)
      recv1 = string.match(Rtrecv or "","buffer read:%s+(.-)\n")
      local periodNumber = string.gsub(recv1 or "","0x",""):gsub(" ","")
      print("periodNumber_1:",periodNumber)
      periodNumber = "0x" .. string.sub(periodNumber,5,8)
      print("periodNumber_2:",periodNumber)
      if tonumber(periodNumber) == nil then
        ResultTable.resultString = "diag return error"
        return false
      end

      if (tonumber(periodNumber) >= tonumber(0x46)) then --add at 20171208 by henry
        isOutLoopFlag = true
      end

      if (periodNumberFlag >=50) then
        isOutLoopFlag = true
      end


     until( isOutLoopFlag == true)

      for i = 3,1,-1 do -- changed by henry at 20171208
      doDiagsCmd("i2c -w 7 0x55 0x4F\n")
      local _,RtrecvData = doDiagsCmd("i2c -r 7 0x55 32\n")
      local count2 = 0
      for j in string.gmatch(RtrecvData or "", "0x(%w+)%s+") do 
        if(count2 >2 and count2 <=32) then
          table.insert(ComTable_Period,j)  
        end
        count2 = count2+1
      end
    end

    for i=1, #ComTable_Period do
      if(i%2==1) then
        local tempValue = ComTable_Period[i]
        ComTable_Period[i] = ComTable_Period[i+1]
        ComTable_Period[i+1] = tempValue 
        ComTable_Period1[#ComTable_Period1+1] = tonumber("0x" .. ComTable_Period[i+1] .. ComTable_Period[i]) --Changed at 20171204 by Henry
      end
    end

    for key, value in pairs(ComTable_Period1) do 
      print("Elaine====key",key)  
      print("Elaine====value",value)
    end
  end

  if(string.find(self.name or "", "Tran21th")) then
    for key=1, #ComTable_Period1 do 
      local bResult = compareAandB(tonumber(ComTable_Period1[21]),self.limitSet.lower,self.limitSet.upper,true)

      ResultTable.resultCode = bResult
      ResultTable.resultString = tonumber(ComTable_Period1[21])
    end

  elseif (string.find(self.name or "", "Tran22th")) then
    for key=1, #ComTable_Period1 do 
      local bResult = compareAandB(tonumber(ComTable_Period1[22]),self.limitSet.lower,self.limitSet.upper,true)
      ResultTable.resultCode = bResult
      ResultTable.resultString = tonumber(ComTable_Period1[22])
    end

  elseif (string.find(self.name or "", "Tran23th")) then
    for key=1, #ComTable_Period1 do 
      local bResult = compareAandB(tonumber(ComTable_Period1[23]),self.limitSet.lower,self.limitSet.upper,true)
      ResultTable.resultCode = bResult
      ResultTable.resultString = tonumber(ComTable_Period1[23])
    end

  elseif (string.find(self.name or "", "Tran24th")) then
    for key=1, #ComTable_Period1 do 
      local bResult = compareAandB(tonumber(ComTable_Period1[24]),self.limitSet.lower,self.limitSet.upper,true)
      ResultTable.resultCode = bResult
      ResultTable.resultString = tonumber(ComTable_Period1[24])
    end

  elseif (string.find(self.name or "", "Tran25th")) then
    for key=1, #ComTable_Period1 do 
      local bResult = compareAandB(tonumber(ComTable_Period1[25]),self.limitSet.lower,self.limitSet.upper,true)
      ResultTable.resultCode = bResult
      ResultTable.resultString = tonumber(ComTable_Period1[25])
    end

  elseif (string.find(self.name or "", "Tran26th")) then
    for key=1, #ComTable_Period1 do 
      local bResult = compareAandB(tonumber(ComTable_Period1[26]),self.limitSet.lower,self.limitSet.upper,true)
      ResultTable.resultCode = bResult
      ResultTable.resultString = tonumber(ComTable_Period1[26])
    end

  elseif (string.find(self.name or "", "Tran27th")) then
    for key=1, #ComTable_Period1 do 
      local bResult = compareAandB(tonumber(ComTable_Period1[27]),self.limitSet.lower,self.limitSet.upper,true)
      ResultTable.resultCode = bResult
      ResultTable.resultString = tonumber(ComTable_Period1[27])
    end

  elseif (string.find(self.name or "", "Tran28th")) then
    for key=1, #ComTable_Period1 do 
      local bResult = compareAandB(tonumber(ComTable_Period1[28]),self.limitSet.lower,self.limitSet.upper,true)
      ResultTable.resultCode = bResult
      ResultTable.resultString = tonumber(ComTable_Period1[28])
    end

  elseif (string.find(self.name or "", "Tran29th")) then
    for key=1, #ComTable_Period1 do 
      local bResult = compareAandB(tonumber(ComTable_Period1[29]),self.limitSet.lower,self.limitSet.upper,true)
      ResultTable.resultCode = bResult
      ResultTable.resultString = tonumber(ComTable_Period1[29])
    end

  elseif (string.find(self.name or "", "Tran30th")) then
    for key=1, #ComTable_Period1 do 
      local bResult = compareAandB(tonumber(ComTable_Period1[30]),self.limitSet.lower,self.limitSet.upper,true)
      ResultTable.resultCode = bResult
      ResultTable.resultString = tonumber(ComTable_Period1[30])
    end
  elseif (string.find(self.name or "", "Tran31th")) then
    for key=1, #ComTable_Period1 do 
      local bResult = compareAandB(tonumber(ComTable_Period1[31]),self.limitSet.lower,self.limitSet.upper,true)
      ResultTable.resultCode = bResult
      ResultTable.resultString = tonumber(ComTable_Period1[31])
    end
  elseif (string.find(self.name or "", "Tran32th")) then
    for key=1, #ComTable_Period1 do 
      local bResult = compareAandB(tonumber(ComTable_Period1[32]),self.limitSet.lower,self.limitSet.upper,true)
      ResultTable.resultCode = bResult
      ResultTable.resultString = tonumber(ComTable_Period1[32])
    end    
  elseif (string.find(self.name or "", "Tran16th")) then
    for key=1, #ComTable_Period1 do 
      local bResult = compareAandB(tonumber(ComTable_Period1[16]),self.limitSet.lower,self.limitSet.upper,true)
      ResultTable.resultCode = bResult
      ResultTable.resultString = tonumber(ComTable_Period1[16])
    end
  elseif (string.find(self.name or "", "Tran17th")) then
    for key=1, #ComTable_Period1 do 
      local bResult = compareAandB(tonumber(ComTable_Period1[17]),self.limitSet.lower,self.limitSet.upper,true)
      ResultTable.resultCode = bResult
      ResultTable.resultString = tonumber(ComTable_Period1[17])
    end
  elseif (string.find(self.name or "", "Tran18th")) then
    for key=1, #ComTable_Period1 do 
      local bResult = compareAandB(tonumber(ComTable_Period1[18]),self.limitSet.lower,self.limitSet.upper,true)
      ResultTable.resultCode = bResult
      ResultTable.resultString = tonumber(ComTable_Period1[18])
    end
  elseif (string.find(self.name or "", "Tran19th")) then
    for key=1, #ComTable_Period1 do 
      local bResult = compareAandB(tonumber(ComTable_Period1[19]),self.limitSet.lower,self.limitSet.upper,true)
      ResultTable.resultCode = bResult
      ResultTable.resultString = tonumber(ComTable_Period1[19])
    end
  elseif (string.find(self.name or "", "Tran20th")) then
    for key=1, #ComTable_Period1 do 
      local bResult = compareAandB(tonumber(ComTable_Period1[20]),self.limitSet.lower,self.limitSet.upper,true)
      ResultTable.resultCode = bResult
      ResultTable.resultString = tonumber(ComTable_Period1[20])
    end   
  end
end




ComTable["eload_start"] =nil

function itemgetVoltage(self)
  local testValue = ComTable["Vrect_Fix_Get"]

  ComTable["Voltage135"] = tonumber(testValue)
  testValue=testValue
  local bResult = compareAandB(testValue,self.limitSet.lower,self.limitSet.upper,true) --testValue and true or false
  g_VrectValue = nil
  g_VrectValue = testValue

  ResultTable.resultCode = bResult
  ResultTable.resultString = testValue or "No Data"
end


function itemgetVoltage2(self)  
 if GetVrec4 == nil then
 testValue = GetVrec5
end

 if  GetVrec4 == nil and GetVrec5 == nil then
testValue = GetVrec3
 
 else 
testValu = GetVrec4
end
  if tonumber(testValue) == nil then
    ResultTable.resultCode = false
    ResultTable.resultString = "No Data"
    return
  end

  ComTable["Voltage135"] = tonumber(testValue)
  testValue=testValue
  local bResult = compareAandB(testValue,self.limitSet.lower,self.limitSet.upper,true) --testValue and true or false
  print(testValue)
  g_VrectValue = nil
  g_VrectValue = testValue

  ResultTable.resultCode = bResult
  ResultTable.resultString = testValue or "No Data"
end

function itemGetPower135ma(self)

  if (tonumber(ComTable["Voltage135"]) == nil) or (tonumber(ComTable["Current135ma"]) == nil) then
    ResultTable.resultString = false
    ResultTable.resultString = "No Data"
    return
  end
  local testValue = ComTable["Voltage135"] * ComTable["Current135ma"]/1000
  local bResult = compareAandB(testValue,self.limitSet.lower,self.limitSet.upper,true)

  ResultTable.resultCode = bResult
  ResultTable.resultString = testValue or "No Data"
end





-- function itemFodfunction_old(self)
--   table.insert(g_ResultLog, "g_IrectValue: '" .. tostring(g_IrectValue) .. "'")
--   table.insert(g_ResultLog, "g_VrectValue: '" .. tostring(g_VrectValue) .. "'")
--   table.insert(g_ResultLog, "g_IbootValue: '" .. tostring(g_IbootValue) .. "'")
--   table.insert(g_ResultLog, "g_VbootValue: '" .. tostring(g_VbootValue) .. "'")
--   if (tonumber(g_IrectValue) == nil) or (tonumber(g_VrectValue) == nil) or (tonumber(g_IbootValue) == nil) or (tonumber(g_VbootValue) == nil) then
--     ResultTable.resultString = "No Data"
--     ResultTable.resultCode = false
--     return 
--   end
  
--   local resultValue = tonumber(g_IrectValue)*tonumber(g_VrectValue)/(tonumber(g_IbootValue)*tonumber(g_VbootValue))

--   local bResult = compareAandB(resultValue,self.limitSet.lower,self.limitSet.upper,true)
--   ResultTable.resultCode = bResult
--   ResultTable.resultString = tostring(resultValue)
-- end


function Break_Point(self)
  print("------- breakbeforeV =",ComTable["breakbeforeV"])
  print("------- breakbeforeI =",ComTable["breakbeforeI"])

  local _,getcurrentValue = doScorpiusCmd("eload adc\r")
  break_testIValue = string.match(getcurrentValue or "","Current = (.-) mA")
  local _,getVValue = doScorpiusCmd("ikt adc\r")
  break_testVValue = string.match(getVValue or "","Vrect = (.-) V")


  if string.find(self.name or "","Current") then
    if ComTable["breakbeforeV"] == nil then
      if tonumber(break_testVValue) >0 then
        if break_testIValue == 0 then
          bResult = false
        end
        bResult = true
      else
        bResult = false
      end
      testValue = break_testIValue/1000
    else
      if ComTable["breakbeforeV"] == 0 then
        bResult = false
        testValue = ComTable["breakbeforeI"]
      else
        bResult = true
        testValue =  ComTable["breakbeforeI"]
      end
    end
  elseif string.find(self.name or "","Vrect") then
    if ComTable["breakbeforeV"] == nil then
      if tonumber(break_testVValue) >0 then
        bResult = true
      else
        bResult = false
      end
      testValue = break_testVValue
    else  
      if ComTable["breakbeforeV"] == 0 then
        bResult = false
        testValue = ComTable["breakbeforeV"]
      else
        bResult = true
        testValue = ComTable["breakbeforeV"]
      end
    end
  end 
  testValue = tostring(tonumber(testValue)/1000)
  ResultTable.resultCode = bResult
  ResultTable.resultString = testValue
end


function itemTempFun(self)
  doDiagsCmd("i2c -w 7 0x55 0x43 multiple\n")
  local _,recv1=doDiagsCmd("i2c -r 7 0x55 4\n")
  recv1 = string.match(recv1 or "","buffer read:%s+(.-)\n")
  local milliVort = string.gsub(recv1 or "","0x",""):gsub(" ","")
  milliVort = "0x" .. string.sub(milliVort,5,8)
  local mvValue = tonumber(milliVort)
  local bResult = recv1 and true or false

  ResultTable.resultCode = bResult
  ResultTable.resultString = tostring(mvValue or "Fail")
end

function getOptValue(baseCmd)
  local baseStep = string.match(baseCmd or "", "%d*%.*%d+") or 0.1
  local OptVal = 0
  if tonumber(baseStep) < 0.1 or baseCmd == nil then
    OptVal = getVal()
    return OptVal
  else
    getOneOptimalPoint(baseCmd)                                    --get one optimal point and move to in each baseStep.
    baseStep = tonumber(baseStep)/2
    baseStep = (baseStep == 0.125) and 0.1 or baseStep
    baseCmd = baseCmd:gsub("%d*%.*%d+", baseStep)
    return getOptValue(baseCmd)   
  end
end







function itemPreambleData(self)
  local value_wanted = self.name:match("Amount_(%d+)")
  local matched_count = 0
  for i,v in ipairs(ComTable["Preamble_data"]) do
    if tonumber("0x" .. v) == tonumber(value_wanted) then matched_count = matched_count + 1 end
  end  
  ResultTable.resultCode = true
  ResultTable.resultString = matched_count
end  

function itemErrorState(self)
--  if #ComTable["data_packet"] ~= 800 then
  if #ComTable["data_packet"] ~= 200 then --Changed by henry at 20171211 --2018/02/27
    ResultTable.resultCode = false
    ResultTable.resultString = "Data count is not 200; data count: " .. tostring(#ComTable["data_packet"])
    return
  end  
  local bResult = true
  local failCount = 0
  local resultTab = {}
--  ComTable["error_count"] = 0
  for i,v in pairs(ComTable["data_packet"]) do
    if (i-1)%8 == 0 then
      local value = ComTable["data_packet"][i+1]
      local value_need = string.sub(value, 1, 1)
      if tonumber(value_need) ~= self.passValue then
        failCount = failCount + 1
      end  
      table.insert(resultTab, value_need)
    end  
  end
  ComTable["error_data"] = resultTab
  bResult = failCount <= self.allow_failCount and true or false
  local tResult = table.concat(resultTab, "_")
  ResultTable.resultCode = bResult
  ResultTable.resultString = tResult
end  

function itemErrorData(self)
  local value_wanted = self.name:match("Amount_(%d+)")
  local matched_count = 0
  for i,v in ipairs(ComTable["error_data"]) do
    if tonumber("0x" .. v)  == tonumber(value_wanted) then matched_count = matched_count + 1 end
  end  
  ResultTable.resultCode = true
  ResultTable.resultString = matched_count
end  

function itemPacketInteval(self)
  local bResult = true
  local failCount = 0
  local resultTab = {}
  for i,v in pairs(ComTable["data_packet"]) do
    if (i-1)%8 == 0 then
      local value_need = ComTable["data_packet"][i+2] .. ComTable["data_packet"][i+3]
      value_need = tonumber("0x" .. value_need)
      if compareAandB(value_need, self.lowerValue, self.upperValue, true) ~= true then
        failCount = failCount + 1
      end  
      table.insert(resultTab, value_need)
    end  
  end
  bResult = failCount <= self.allow_failCount and true or false
  local tResult = table.concat(resultTab, "_")
  ResultTable.resultCode = bResult
  ResultTable.resultString = tResult
end  

function itemASK_RawData(self)
  local bResult = true
  local failCount = 0
  local resultTab = {}
  for i,v in pairs(ComTable["data_packet"]) do
    if (i-1)%8 == 0 then
      local value_need = ComTable["data_packet"][i+5] .. ComTable["data_packet"][i+6]
      if compareAandB(tonumber(value_need), self.lowerValue, self.upperValue, true) ~= true then
        failCount = failCount + 1
      end  
      table.insert(resultTab, value_need)
    end  
  end
  bResult = failCount <= self.allow_failCount and true or false
  local tResult = table.concat(resultTab, "_")
  ResultTable.resultCode = bResult
  ResultTable.resultString = tResult
end  

function itemGoodPercent(self)
  
  local tResult = string.format("Good:%s/Fail:%s", ComTable["total_count"] - ComTable["error_count"], ComTable["error_count"])
  ResultTable.resultCode = true
  ResultTable.resultString = tResult
end  

function itemOverallPercent(self)
  local tResult = (1 - ComTable["error_count"] / ComTable["total_count"]) * 100
  ResultTable.resultCode = compareAandB(tResult, self.limitSet.lower, self.limitSet.upper, true)
  ResultTable.resultString = tResult
end 

function positionRead_X(self)
  local _,rtRecv = doMikeyCmd("readx\r")
  rtRecv = string.match(rtRecv or "", "([.%d]+)mm")
  local tResult = tonumber(rtRecv)
  ResultTable.resultCode = compareAandB(tResult, self.limitSet.lower, self.limitSet.upper, true)
  ResultTable.resultString = tResult
end  

function positionRead_Y(self)
  local _,rtRecv = doMikeyCmd("ready\r")
  rtRecv = string.match(rtRecv or "", "([.%d]+)mm")
  local tResult = tonumber(rtRecv)
  ResultTable.resultCode = compareAandB(tResult, self.limitSet.lower, self.limitSet.upper, true)
  ResultTable.resultString = tResult
end  

function positionRead_Z(self)
  local _,rtRecv = doMikeyCmd("readz\r")
  rtRecv = string.match(rtRecv or "", "([.%d]+)mm")
  local tResult = tonumber(rtRecv)
  ResultTable.resultCode = compareAandB(tResult, self.limitSet.lower, self.limitSet.upper, true)
  ResultTable.resultString = tResult
end  

function uploadAttributeFromSFC(self)
  if not sn then
    ResultTable.resultCode = false;
    ResultTable.resultString = "no SN"
    return
  end

  local tbSFCQueryRecord = {}
  local url = app.getGHInfo("SFC_URL")
  local stationID = app.getGHInfo("STATION_ID")
  if (not url) or (not stationID) then
    ResultTable.resultCode = false
    ResultTable.resultString = "Url or station ID is nill"
    return
  end
  local querystring = url .. "?sn=".. sn .."&c=QUERY_RECORD&tsid=".. string.upper(stationID) .. "&p=" ..self.key
  print("querystring",querystring)
  local bRtByURL,sfcRece,loginfo = querySFCRecordByURL(querystring)
  if not bRtByURL then
    ResultTable.resultCode = bRtByURL;
    ResultTable.resultString = "SFC issue"
    return
  end 
  for tbKey,tbValue in string.gmatch(sfcRece or "","([%l_%w]-)=(.-)%s") do
    tbSFCQueryRecord[tbKey] = tbValue
  end
  local testResult = tbSFCQueryRecord[self.key]
  print("testResult",testResult)

  local bResult = testResult and string.len(testResult)>0 and true or false
  if bResult then
    g_PDCAAttribute[string.upper(self.key)] = testResult
  end
  ResultTable.resultCode = bResult
  ResultTable.resultString = testResult or "No Data"
end




function Low_Power_TX_Ping_Test(self)
  -- for i=1, 5 do
    Low_Power_TX_Ping_Test_0(self)
  -- end  
    local bResult = compareAandB(ComTable["frepData"],self.limitSet.lower,self.limitSet.upper,true)
    ResultTable.resultCode = bResult
    ResultTable.resultString = ComTable["frepData"]
end  


function Low_Power_TX_Ping_Inductance(self)
  local bResult = compareAandB(ComTable["lData"],self.limitSet.lower,self.limitSet.upper,true)
  ResultTable.resultCode = bResult
  ResultTable.resultString = ComTable["lData"]

end

function Low_Power_TX_Ping_Qres(self)
table.insert(g_ResultLog,"q_res = " .. ComTable["q_res"])
table.insert(g_ResultLog,"lower = " .. tostring(self.limitSet.lower))
table.insert(g_ResultLog,"upper = " .. tostring(self.limitSet.upper))
  local bResult = compareAandB(ComTable["q_res"],self.limitSet.lower,self.limitSet.upper,true)
  ResultTable.resultCode = bResult
  ResultTable.resultString = ComTable["q_res"]
end

function Low_Power_TX_Ping_Delta_Frequency(self)

  local delta_value = ComTable["frepData_delta"]
  local bResult = compareAandB(tonumber(delta_value),self.limitSet.lower,self.limitSet.upper,true)
  ResultTable.resultCode = bResult
  ResultTable.resultString = delta_value
end  

function Low_Power_TX_Ping_Delta_Inductance(self)

  local delta_value = ComTable["lData_delta"]
  local bResult = compareAandB(tonumber(delta_value),self.limitSet.lower,self.limitSet.upper,true)
  ResultTable.resultCode = bResult
  ResultTable.resultString = delta_value
end  


function Low_Power_TX_Ping_Delta_Qres(self)

  local delta_value = ComTable["q_res_delta"]
  local bResult = compareAandB(tonumber(delta_value),self.limitSet.lower,self.limitSet.upper,true)
  ResultTable.resultCode = bResult
  ResultTable.resultString = delta_value
end  




--function itemIboostValueShow()

--  doDiagsCmd("smokey ScorpiusHid --run --test \"Set\" --args \"ReportID=0x33, ReportPayload={0x28; 0x00}\"\n")
--  app.wait(2000)
--  local _,recv1=doDiagsCmd("smokey ScorpiusHid --run --test \"Get\" --args \"ReportID=0x33\"\n")
--  local str = string.match(recv1 or "", "Reading 72 bytes.-buffer read:%s+([^%c]+)")
--  local str1 = string.gsub(str or "", "%s", "")
--  local data = string.gsub(str1 or "", "0[Xx]", "")

--  if string.len(data) / 2 ~= 72 then
--    -- ResultTable.resultCode = false
--    -- ResultTable.resultString = "Data length is not 78, data: " .. data
--    return 
--  end
--  -- local VBoost = data:sub(7,8) .. data:sub(5,6)
--  local IboostData = "0x" .. data:sub(15,16) ..data:sub(13,14)
--  table.insert(g_ResultLog, "Catch: " .. IboostData)
--  return tonumber(IboostData)/1000.0
--end

function itemIboostValueShow()
  doOsCmd("hidreport -du 0xFF00,0x0036 hset 33 33 28 00")
  app.wait(2000)
  local _, recv = doOsCmd("hidreport -du 0xFF00,0x0036 get 0x33")
  local bytes, bResult, fail_info = get_hid_bytes(recv)
  local IboostData = "0x" .. bytes[8] .. bytes[7]
  table.insert(g_ResultLog, "Catch: " .. IboostData)
  return tonumber(IboostData)/1000.0
end


--function itemVboostValueShow(self)
--  doDiagsCmd("smokey ScorpiusHid --run --test \"Set\" --args \"ReportID=0x33, ReportPayload={0x28; 0x00}\"\n")
--  app.wait(2000)
--  local _,recv1=doDiagsCmd("smokey ScorpiusHid --run --test \"Get\" --args \"ReportID=0x33\"\n")
--  local str = string.match(recv1 or "", "Reading 72 bytes.-buffer read:%s+([^%c]+)")
--  local str1 = string.gsub(str or "", "%s", "")
--  local data = string.gsub(str1 or "", "0[Xx]", "")

--  if string.len(data) / 2 ~= 72 then
--    -- ResultTable.resultCode = false
--    -- ResultTable.resultString = "Data length is not 78, data: " .. data
--    return 
--  end
--  local VboostData = "0x" .. data:sub(7,8) .. data:sub(5,6)
--  table.insert(g_ResultLog, "Catch: " .. VboostData)
--  return tonumber(VboostData)/1000.0
--end

function itemVboostValueShow()
  doOsCmd("hidreport -du 0xFF00,0x0036 hset 33 33 28 00")
  app.wait(2000)
  local _, recv = doOsCmd("hidreport -du 0xFF00,0x0036 get 0x33")
  local bytes, bResult, fail_info = get_hid_bytes(recv)
  local VboostData = "0x" .. bytes[4] .. bytes[3]
  table.insert(g_ResultLog, "Catch: " .. VboostData)
  return tonumber(VboostData)/1000.0
end

--function itemBridgePhaseValue(self)
--  -- doDiagsCmd("i2c -w 7 0x55 0x4A multiple\n")
--  -- local _,recv1=doDiagsCmd("i2c -r 7 0x55 4\n")

--  -- recv1 = string.match(recv1 or "","buffer read:%s+(.-)\n")
--  -- local milliVort = string.gsub(recv1 or "","0x",""):gsub(" ","")
--  -- BridgePhase_value2 = "0x" .. string.sub(milliVort,5,8)
--  -- if tonumber(BridgePhase_value2) == nil then
--  --   ResultTable.resultString = "no data"
--  --   return false
--  -- end

--  -- BridgePhase_value2=tonumber(BridgePhase_value2)
--  local _,recv1 = doDiagsCmd("smokey ScorpiusHid --run --test \"Get\" --args \"ReportID=0x22\"\n")
--  local str = string.match(recv1 or "", "Reading 48 bytes.-:%s+([^%c]+)")
--  local str1 = string.gsub(str or "", "%s", "")
--  local data = string.gsub(str1 or "", "0[Xx]", "")
--  if string.len(data) / 2 ~= 48 then
--    ResultTable.resultCode = false
--    ResultTable.resultString = "Data length is not 48, data: " .. data
--    return 
--  end  

--  local Bridge_Phase = "0x" .. data:sub(43,44) .. data:sub(41,42)
--  -- local Bridge_Frequency = "0x" .. data:sub(31,32) .. data:sub(29,30)
--  -- local Dead_time = data:sub(55,56) .. data:sub(53,54)
--  table.insert(g_ResultLog, "Catch: " .. Bridge_Phase)
-- return tonumber(Bridge_Phase)
--end



function itemBridgePhaseValue(self)
  doOsCmd("hidreport -du 0xFF00,0x0036 get 0x22")
  app.wait(1000)
  local _, recv = doOsCmd("hidreport -du 0xFF00,0x0036 get 0x22")
  local bytes, bResult, fail_info = get_hid_bytes(recv)
  local Bridge_Phase = "0x" .. bytes[22] .. bytes[21]
  table.insert(g_ResultLog, "Catch: " .. Bridge_Phase)
  return tonumber(Bridge_Phase)
end


function GetVin_MaxP(Vin,P)
              for j=1,60,1 do

                if PTable[j] ~=nil  then
                  --print(", P=" .. PTable[j])
                  if j==1 then
                    PTable["a"]=PTable[j]
                    --print(",P_a=" .. PTable["a"])
                  else
                    PTable["b"]=PTable[j]
                    --print(",P_b=" .. PTable["b"])
                  end
                  
                    if j>1 then
                      if tonumber(PTable["a"])>tonumber(PTable["b"]) then
                        PTable["c" .. Vin]=PTable["a"]
                        --print("a>b,c_Vin=" .. PTable["c" .. Vin])
                      elseif tonumber(PTable["a"])<tonumber(PTable["b"]) then
                        PTable["a"]=PTable["b"]
                        --print("a<b,P=" .. PTable["a"])
                        PTable["c" .. Vin]=PTable["a"]
                      else
                        PTable["c" .. Vin]=PTable["a"]
                      end
                    end
                end
                
                
              end
              print("GetVin_MaxP," .. Vin .."vin=" .. PTable["c" .. Vin] .. "w")
              table.insert(FinalTable, Vin .. "_" .. PTable["c" .. Vin])
end


-------Peter DOE1,
function simulatedVcritical(self)
  ----[[
  --1.Set V  6.5V (主板命令獲取)  Vin
  --1-1. 讀一下值(主板命令獲取)
    doFixtureCmd("move_cylinder:1,1\n")
    app.wait(200)
    doDiagsCmd("i2c -v 7 0x55 0x0f 0x00\n")
    app.wait(200)
    doDiagsCmd("i2c -v 7 0x55 0x0f 0x01\n")
    app.wait(200)
  
    doDiagsCmd("i2c -v 7 0x55 0x0b 0x00 0xb4 multiple\n")
    app.wait(200)
    doDiagsCmd("i2c -v 7 0x55 0x0b 0x00 0xb4 multiple\n")
    app.wait(200)
    doDiagsCmd("i2c -w 7 0x55 0x03 0x05 0x78 multiple\n")
    app.wait(200)
    doDiagsCmd("i2c -v 7 0x55 0x03 0x05 0xA9 multiple\n")
    
    
  
    doDiagsCmd("i2c -w 7 0x55 0x42\n")
    local _,Vin1=doDiagsCmd("i2c -r 7 0x55 4\n") 
    Vin1 = string.match(Vin1 or "","buffer read:%s+(.-)\n")
    
    Vin1 = string.gsub(Vin1 or "","0x",""):gsub(" ","")
    print("1 --Vin1:",Vin1)
      
    Vin1 = "0x" .. string.sub(Vin1,5,8)
    print("2 --Vin1:",Vin1)
      
    Vin1=tonumber(Vin1)
    print("3 --Vin1:",Vin1)


  -- 2.Set I 40 mA (治具命令獲取)	Iout 1
    doScorpiusCmd("eload set 40\r")
    _,Iout1 = doScorpiusCmd("eload adc\r")
    Iout1 = string.match(Iout1 or "","Current = (.-) mA")
    
  -- 3. Get V (治具命令獲取)  	    Vout 1 
    _,Vout1 = doScorpiusCmd("ikt adc\r")
    Vout1 = string.match(Vout1 or "","Vrect = (.-) V")
    Vout1= Vout1*1000
  -- 4.Set I 80 mA (治具命令獲取) Iout 2
    doScorpiusCmd("eload set 80\r")
    _,Iout2 = doScorpiusCmd("eload adc\r")
    Iout2 = string.match(Iout2 or "","Current = (.-) mA")

  -- 5.Get V (治具命令獲取)  Vout 2  
    _,Vout2 = doScorpiusCmd("ikt adc\r")
    Vout2 = string.match(Vout2 or "","Vrect = (.-) V")
    Vout2= Vout2*1000
  
    A = (Vout1 * Iout2 - Vout2 * Iout1)/ (Vin1 * Iout2 - Vin1 *Iout1)
    B = (Vout1 * Vin1 - Vout2 * Vin1) / ( Iout1 * Vin1 - Iout2 * Vin1)
    
  V_c =2*math.sqrt (-3.15*B) / A +0.3 
  I_c = -(A*Vin1) / (2*B)
  
  --8. show V_c
  bResult=V_c and true or false
  ResultTable.resultCode = bResult
  ResultTable.resultString = V_c
end
function RealVcritical_DOE1(self)
  if self.spec ~="3" then
    if self.spec == "2"then
      print("1---Vcritical_down_02=",Vcritical_down_02)
      bResult=Vcritical_down_02 and true or false
      ResultTable.resultCode = bResult
      ResultTable.resultString = Vcritical_down_02
      return
    elseif self.spec == "1" then
      print("1---Vcritical_down_01=",Vcritical_down_01)
      bResult=Vcritical_down_01 and true or false
      ResultTable.resultCode = bResult
      ResultTable.resultString = Vcritical_down_01
      return
    elseif self.spec == "4" then
      print("1---Vcritical_up_01=",Vcritical_up_01)
      bResult=Vcritical_up_01 and true or false
      ResultTable.resultCode = bResult
      ResultTable.resultString = Vcritical_up_01
      return
    elseif self.spec == "5" then
      print("1---Vcritical_up_02=",Vcritical_up_02)
      bResult=Vcritical_up_02 and true or false
      ResultTable.resultCode = bResult
      ResultTable.resultString = Vcritical_up_02
      return
    end
  end
Vcritical_8v=nil
Vcritical_down_02=nil
Vcritical_down_01=nil
Vcritical_up_01=nil
Vcritical_up_02=nil
--1.Vin : (8~11)V (主板命令獲取)
--不管Ｖ是多少(8,9…11 )，都要做一套Set Vin ->Set I out ->Get Vout  
--Iout (150~350)ma (治具命令獲取) /10ma

  --Set Vin (0x0448 -20) 
    
--6.5v "0x0448" --20 = +0.1v
local Vin=V_c
--1156 8v
--556 11v
local count=0
VinTable={}
PTable={}
FinalTable={}

for i = Vin,0,-20 do
  print("Vin =",i)
    local cmdValue = string.format("0x%04x",i)
    print("cmdValue =",cmdValue)
    local cmdNo1 = string.sub(cmdValue,1,4)
    print("cmdNo1 =",cmdNo1)
    local cmdNo2 = "0x" .. string.sub(cmdValue,5,6)
    print("cmdNo2 =",cmdNo2)
    local cmd = "i2c -v 7 0x55 0x03 " .. cmdNo1 .. " " .. cmdNo2 .. " multiple\n"
    print("doDiagsCmd =",cmd)
    
    doDiagsCmd(cmd)
    
    doDiagsCmd("i2c -w 7 0x55 0x42\n")
    _,Vin=doDiagsCmd("i2c -r 7 0x55 4\n") 
    
    print("0-----Vin=" .. Vin)
    
    Vin = string.match(Vin or "","buffer read:%s+(.-)\n")
    
    Vin = string.gsub(Vin or "","0x",""):gsub(" ","")
    print("Vin:",Vin)
      
    Vin = "0x" .. string.sub(Vin,5,8)
    print("Vin:",Vin)
      
    Vin=tonumber(Vin)
    print("-----RealVcritical------ Vin:",Vin)
    
    --print ("------ Vin=",Vin)
    table.insert(VinTable, Vin)
    
  -- 一個循環150ma~350ma(10ma++)
  -- Set Vin ->Set I out -> Get I/Vout ->Get P 
    local Iin=200
    PTable={} --clear
    for i = Iin,350,10 do
      --Get I/Vout ->Get P
      doScorpiusCmd ("eload set " .. tostring(i) .. "\r")
      _,Iout = doScorpiusCmd("eload adc\r")
      Iout = string.match(Iout or "","Current = (.-) mA")
                                                      print ("------ Iout=",Iout)
      _,Vout = doScorpiusCmd("ikt adc\r")
      Vout= string.match(Vout or "","Vrect = (.-) V")
                                                      print ("------ Vout=",Vout)
      Vout=Vout*1000
      P= (Iout/1000)*(Vout/1000)
                                                      print ("------ P=",P)
      table.insert(PTable, P)

      if tonumber(P) > 3.1 then
        if count == 0 then
        ------Nom_Irect_Fix_Get
        Nom_Irect_Fix_Get=Iout
        print("-----RealVcritical------ Nom_Irect_Fix_Get:",Nom_Irect_Fix_Get)
        
        ------Nom_Vrect_Fix_Get
        Nom_Vrect_Fix_Get=Vout
        print("-----RealVcritical------ Nom_Vrect_Fix_Get:",Nom_Vrect_Fix_Get)
        
        ------Nom_Iboost--------
        doDiagsCmd("i2c -w 7 0x55 0x41\n")
        _,Nom_Iboost=doDiagsCmd("i2c -r 7 0x55 4\n") 
            
            --print("0-----Nom_Iboost=" .. Nom_Iboost)
        Nom_Iboost = string.match(Nom_Iboost or "","buffer read:%s+(.-)\n")
        Nom_Iboost = string.gsub(Nom_Iboost or "","0x",""):gsub(" ","")
        --print("Iboost_value:",Iboost_value)
        Nom_Iboost = "0x" .. string.sub(Nom_Iboost,5,8)
        --print("Nom_Iboost:",Nom_Iboost)
              
        Nom_Iboost=tonumber(Nom_Iboost)
            
        print("-----RealVcritical------ Nom_Iboost:",Nom_Iboost)
            
        ------Nom_Vboost
        Nom_Vboost=Vin
        print("-----RealVcritical------ Nom_Vboost:",Nom_Vboost)
        
        ------Nom_FOD_threshold
        --Iout* Vout /Nom_Iboost(0x41)* Nom_Vboost (0x42)
        Nom_FOD_threshold=(Nom_Irect_Fix_Get*Nom_Vrect_Fix_Get) / (Nom_Iboost*Nom_Vboost)
        print("-----RealVcritical------ Nom_FOD_threshold:",Nom_FOD_threshold)
        
        ------Nom_Rx_Loading_power
        Nom_Rx_Loading_power=P
        print("-----RealVcritical------ Nom_Rx_Loading_power:",Nom_Rx_Loading_power)
      end
      
        count=count+1
        --compare and save max P for Vin
        GetVin_MaxP(Vin,P)
        --------------------------------
        if count ==3 then
          print ("count",count)
          --only print all Vin and Max P
          for i=1,500,1 do
            if FinalTable[i]==nil then
              break
            end
            print(" v and p=" .. FinalTable[i])
          end
          --------------------
          count1=0
          for i=100,1,-1 do
            
            if FinalTable[i]~=nil then
              count1=count1+1
              print("count=" .. count)
              print(FinalTable[i] .. "_i =" .. i)
              if count1 ==1 then
                Vcritical_up_02=FinalTable[i]
                
                print("2--- count1=" .. count1)
                print("2--- " .. FinalTable[i] .. "_i =" .. i)
                print("2--- Vcritical_up_02=" .. Vcritical_up_02)
                
              elseif count1 ==2 then
                Vcritical_up_01=FinalTable[i]
                
                print("2--- count1=" .. count1)
                print("2--- " .. FinalTable[i] .. "_i =" .. i)
                print("2--- Vcritical_up_01=" .. Vcritical_up_01)
                
              elseif count1 ==3 then  
                Vcritical_8v=FinalTable[i]
                print("2--- count1=" .. count1)
                print("2--- " .. FinalTable[i] .. "_i =" .. i)
                print("2--- Vcritical_8v=" .. Vcritical_8v)                
                
                
              elseif count1 ==4 then  
                Vcritical_down_01=FinalTable[i]
                 print("2--- count1=" .. count1)
                print("2--- " .. FinalTable[i] .. "_i =" .. i)
                print("2--- Vcritical_down_01=" .. Vcritical_down_01)               

                
              elseif count1 ==5 then
                Vcritical_down_02=FinalTable[i]
                 print("2--- count1=" .. count1)
                print("2--- " .. FinalTable[i] .. "_i =" .. i)
                print("2--- Vcritical_down_02=" .. Vcritical_down_02)               
              end
              --break
              if count1==5 then
--                  doDiagsCmd("i2c -v 7 0x55 0x0f 0x00\n")
--                  doScorpiusCmd("eload set 0\r")
                break
              end  
            end
          end

          print("1---Vcritical_8v=",Vcritical_8v)
          print("1---Vcritical_down_02=",Vcritical_down_02)
          print("1---Vcritical_down_01=",Vcritical_down_01)
          print("1---Vcritical_up_01=",Vcritical_up_01)
          print("1---Vcritical_up_02=",Vcritical_up_02)

          local bResult = Vcritical_8v and true or false
          ResultTable.resultCode = bResult
          ResultTable.resultString = Vcritical_8v
            
          doDiagsCmd("i2c -v 7 0x55 0x0f 0x00\n")
          doScorpiusCmd("eload set 0\r")
          return
       
        end
        break
      end
          if i==350 then
            --------------
            print("-------i=350")
            GetVin_MaxP(Vin,P)
            ----------------
          end
    end
end
  doDiagsCmd("i2c -v 7 0x55 0x0f 0x00\n")
  doScorpiusCmd("eload set 0\r")
end
-------Peter DOE2
function RealVcritical_DOE2(self)
  --Set Vin (0x0448 -20) 
    
--6.5v "0x0448" --20 = +0.1v
local Vin=556
--1156 8v
--556 11v
--Vinitiaal
local count=0
VinTable={}
PTable={}
FinalTable={}

-- by 0.5v (-100)

for i = Vin,100,-100 do
  print("Vin =",i)
    local cmdValue = string.format("0x%04x",i)
    print("cmdValue =",cmdValue)
    local cmdNo1 = string.sub(cmdValue,1,4)
    print("cmdNo1 =",cmdNo1)
    local cmdNo2 = "0x" .. string.sub(cmdValue,5,6)
    print("cmdNo2 =",cmdNo2)
    local cmd = "i2c -v 7 0x55 0x03 " .. cmdNo1 .. " " .. cmdNo2 .. " multiple\n"
    print("doDiagsCmd =",cmd)
    
    doDiagsCmd(cmd)
    
    doDiagsCmd("i2c -w 7 0x55 0x42\n")
    _,Vin=doDiagsCmd("i2c -r 7 0x55 4\n") 
    
    print("0-----Vin=" .. Vin)
    
    Vin = string.match(Vin or "","buffer read:%s+(.-)\n")
    Vin = string.gsub(Vin or "","0x",""):gsub(" ","")
--    print("Vin:",Vin)
    Vin = "0x" .. string.sub(Vin,5,8)
--    print("Vin:",Vin)
    Vin=tonumber(Vin)
    print("-----RealVcritical------ Vin:",Vin)
    
    table.insert(VinTable, Vin)
    
  -- 一個循環250ma~350ma(10ma++)
  -- Set Vin ->Set I out -> Get I/Vout ->Get P 
    local Iin=250
    PTable={} --clear
    for i = Iin,350,10 do
      --Get I/Vout ->Get P
      doScorpiusCmd ("eload set " .. tostring(i) .. "\r")
      _,Iout = doScorpiusCmd("eload adc\r")
      Iout = string.match(Iout or "","Current = (.-) mA")
       print ("------ Iout=",Iout)
      _,Vout = doScorpiusCmd("ikt adc\r")
      Vout= string.match(Vout or "","Vrect = (.-) V")
      print ("------ Vout=",Vout)
      Vout=Vout*1000
      P= (Iout/1000)*(Vout/1000)
      print ("------ P=",P)
      table.insert(PTable, P)
        ------Nom_Irect_Fix_Get
      Nom_Irect_Fix_Get=Iout
      print("-----RealVcritical------ Nom_Irect_Fix_Get:",Nom_Irect_Fix_Get)
        
      ------Nom_Vrect_Fix_Get
      Nom_Vrect_Fix_Get=Vout
      print("-----RealVcritical------ Nom_Vrect_Fix_Get:",Nom_Vrect_Fix_Get)
        
      ------Nom_Iboost--------
      doDiagsCmd("i2c -w 7 0x55 0x41\n")
      _,Nom_Iboost=doDiagsCmd("i2c -r 7 0x55 4\n") 
            
      --print("0-----Nom_Iboost=" .. Nom_Iboost)
      Nom_Iboost = string.match(Nom_Iboost or "","buffer read:%s+(.-)\n")
      Nom_Iboost = string.gsub(Nom_Iboost or "","0x",""):gsub(" ","")
       --print("Iboost_value:",Iboost_value)
      Nom_Iboost = "0x" .. string.sub(Nom_Iboost,5,8)
      --print("Nom_Iboost:",Nom_Iboost)
              
      Nom_Iboost=tonumber(Nom_Iboost)
            
      print("-----RealVcritical------ Nom_Iboost:",Nom_Iboost)
            
      ------Nom_Vboost
      Nom_Vboost=Vin
      print("-----RealVcritical------ Nom_Vboost:",Nom_Vboost)
        
      ------Nom_FOD_threshold
      --Iout* Vout /Nom_Iboost(0x41)* Nom_Vboost (0x42)
      Nom_FOD_threshold=(Nom_Irect_Fix_Get*Nom_Vrect_Fix_Get) / (Nom_Iboost*Nom_Vboost)
      print("-----RealVcritical------ Nom_FOD_threshold:",Nom_FOD_threshold)
        
      ------Nom_Rx_Loading_power
      Nom_Rx_Loading_power=P
      print("-----RealVcritical------ Nom_Rx_Loading_power:",Nom_Rx_Loading_power)

--1-------------PRECT >=3W?--------------
      if tonumber(P) > 3.1 then
      --set Ptarget
        --compare and save max P for Vin
        --GetVin_MaxP(Vin,P)
        
        if Vout>14300 then
            resultCode = false
            resultString = "OVP"   
              ResultTable.resultCode = resultCode
              ResultTable.resultString = resultString
            doDiagsCmd("i2c -v 7 0x55 0x0f 0x00\n")
            doScorpiusCmd("eload set 0\r")             
            return
        else
          --Record VBoost, IBoost, VRECT, IRECT, Pin, PRECT
            resultCode = true
            resultString = "10C"   --Record      
              ResultTable.resultCode = resultCode
              ResultTable.resultString = resultString
            doDiagsCmd("i2c -v 7 0x55 0x0f 0x00\n")
            doScorpiusCmd("eload set 0\r")
            return            
        end
      end
--2-------------PRECT @ Peak--------------      
      if i==350 then
            --------------
            print("-------i=350")
            GetVin_MaxP(Vin,P)
            ----------------
--3-------------VBoost >15V--------------     
          if Vin > 15000 then
            
              resultCode = false
              resultString = "10C Fail"

            if P>2.7 then
              --Record VBoost, IBoost, VRECT, IRECT, Pin, PRECT
              resultCode = false
              resultString = "9C Only" --Record
                ResultTable.resultCode = resultCode
                ResultTable.resultString = resultString
            doDiagsCmd("i2c -v 7 0x55 0x0f 0x00\n")
            doScorpiusCmd("eload set 0\r")
              return              
            else
              resultCode = false
              resultString = "9C Fail"
                ResultTable.resultCode = resultCode
                ResultTable.resultString = resultString
            doDiagsCmd("i2c -v 7 0x55 0x0f 0x00\n")
            doScorpiusCmd("eload set 0\r")
              return            
            end
            
          else
            break
          end
      end
    end
end
  ResultTable.resultCode = resultCode
  ResultTable.resultString = resultString
  
  doDiagsCmd("i2c -v 7 0x55 0x0f 0x00\n")
  doScorpiusCmd("eload set 0\r")
end




function Nom_Irect_Fix_Get(self)
  bResult=Nom_Irect_Fix_Get and true or false
  ResultTable.resultCode = bResult
  ResultTable.resultString = Nom_Irect_Fix_Get
end

function Nom_Vrect_Fix_Get(self)
  bResult=Nom_Vrect_Fix_Get and true or false
  ResultTable.resultCode = bResult
  ResultTable.resultString = Nom_Vrect_Fix_Get
end

function Nom_Iboost(self)
  bResult=Nom_Iboost and true or false
  ResultTable.resultCode = bResult
  ResultTable.resultString = Nom_Iboost
end

function Nom_Vboost(self)
  bResult=Nom_Vboost and true or false
  ResultTable.resultCode = bResult
  ResultTable.resultString = Nom_Vboost
end

function Nom_FOD_threshold(self)
  bResult=Nom_FOD_threshold and true or false
  ResultTable.resultCode = bResult
  ResultTable.resultString = Nom_FOD_threshold
end

function Nom_Rx_Loading_power(self)
  bResult=Nom_Rx_Loading_power and true or false
  ResultTable.resultCode = bResult
  ResultTable.resultString = Nom_Rx_Loading_power
end

function itemCtxValueShow()
  CtxData = ""
  doDiagsCmd("i2c -w 7 0x55 0x63\n")
app.wait(200)

  local _,recv1=doDiagsCmd("i2c -r 7 0x55 4\n")
print("----do read")
print (recv1)

  recv1 = string.match(recv1 or "","buffer read:%s+(.-)\n")
  CtxData = string.gsub(recv1 or "","0x",""):gsub(" ","")
  CtxData = "0x" .. string.sub(CtxData,5,8)
  
print("----get something")
print (CtxData)

  if tonumber(CtxData) == nil then
   print("no data")
   --CL_Iboost0C = tonumber(IboostData)
    return
  end
  return (tonumber(CtxData)/1000.0)
end





function itemFSK_ErrorReceived(self)
 
  ErResult = true
  local EfailCount = 0
  for i=1, 25 do
    if tableE[i] ~= self.passValue then
          EfailCount = EfailCount + 1
    end
  end
  
  ErResult = EfailCount <= self.allow_EfailCount and true or false
  
  ResultTable.resultCode = ErResult
  ResultTable.resultString = EResult
end


function itemFSK_GoodNum(self)
  local bResult = compareAandB(matchedFSK_count,self.limitSet.lower,self.limitSet.upper,true)
  ResultTable.resultCode = bResult
  ResultTable.resultString = matchedFSK_count
end

function itemFSK_OverallPercent(self)
  local bResult = compareAandB(tResult,self.limitSet.lower,self.limitSet.upper,true)
  ResultTable.resultCode = bResult
  ResultTable.resultString = tResult
end

function DOE3RealVcritical(self)
  local Vin= nil
  if self.spec=="V" then
    Vin= V_c
      
  elseif  self.spec=="P" then
    bResult= ComTable["RealVcritical_P"] and true or false
    ResultTable.resultCode = bResult
    ResultTable.resultString = ComTable["RealVcritical_P"]
    return
  elseif  self.spec=="4" then
    bResult= ComTable["RealVcritical_10ma_P"] and true or false
    ResultTable.resultCode = bResult
    ResultTable.resultString = ComTable["RealVcritical_10ma_P"]
    return
  elseif  self.spec=="5" then
    bResult= ComTable["RealVcritical_20ma_P"] and true or false
    ResultTable.resultCode = bResult
    ResultTable.resultString = ComTable["RealVcritical_20ma_P"]
    return
  end
    doDiagsCmd("i2c -v 7 0x55 0x0f 0x01\n")
    doDiagsCmd("i2c -v 7 0x55 0x0b 0x00 0xb4 multiple\n")
    i=(Vin-16.57)/-6.6904
    print("----i=" .. i)
    i=string.sub(i,3,5)
    print("----i=" .. i)
  
    local cmdValue = string.format("0x%04x",i)
    print("cmdValue =",cmdValue)
    local cmdNo1 = string.sub(cmdValue,1,4)
    print("cmdNo1 =",cmdNo1)
    local cmdNo2 = "0x" .. string.sub(cmdValue,5,6)
    print("cmdNo2 =",cmdNo2)
    local cmd = "i2c -v 7 0x55 0x03 " .. cmdNo1 .. " " .. cmdNo2 .. " multiple\n"
    print("doDiagsCmd =",cmd)
    
    doDiagsCmd(cmd)
    
    app.wait(100)
    --read Vin
    doDiagsCmd("i2c -w 7 0x55 0x42\n")
    _,Vin=doDiagsCmd("i2c -r 7 0x55 4\n") 
    
    print("0-----Vin=" .. Vin)
    
    Vin = string.match(Vin or "","buffer read:%s+(.-)\n")
    
    Vin = string.gsub(Vin or "","0x",""):gsub(" ","")
    print("Vin:",Vin)
      
    Vin = "0x" .. string.sub(Vin,5,8)
    print("Vin:",Vin)
      
    Vin=tonumber(Vin)
    print("-----RealVcritical------ Vin:",Vin)
    --20180314 Peter
    local Vc_1000 =V_c*1000
    if Vin<Vc_1000 then
      print("----if Vin<V_c , i=" .. i)
      for j = i,100,-10 do
          local cmdValue = string.format("0x%04x",j)
          local cmdNo1 = string.sub(cmdValue,1,4)
          local cmdNo2 = "0x" .. string.sub(cmdValue,5,6)
          local cmd = "i2c -v 7 0x55 0x03 " .. cmdNo1 .. " " .. cmdNo2 .. " multiple\n"
          print("doDiagsCmd =",cmd)
          
          doDiagsCmd(cmd)
          
          app.wait(100)
          --read Vin
          doDiagsCmd("i2c -w 7 0x55 0x42\n")
          _,Vin=doDiagsCmd("i2c -r 7 0x55 4\n") 
          print("0-----Vin=" .. Vin)
          Vin = string.match(Vin or "","buffer read:%s+(.-)\n")
          Vin = string.gsub(Vin or "","0x",""):gsub(" ","")
          print("1-----Vin=",Vin)
          Vin = "0x" .. string.sub(Vin,5,8)
          print("2-----Vin=",Vin)
            
          Vin=tonumber(Vin)
          print("--Final---RealVcritical------ Vin:",Vin)
          if Vin>=Vc_1000 then
            break
          end  
      end
    end
    local Iin=150

 for i = Iin,320,10 do
      --Get I/Vout ->Get P
      doScorpiusCmd ("eload set " .. tostring(i) .. "\r")
      _,Iout = doScorpiusCmd("eload adc\r")
      Iout = string.match(Iout or "","Current = (.-) mA")
      print ("------ Iout=",Iout)
      _,Vout = doScorpiusCmd("ikt adc\r")
      Vout= string.match(Vout or "","Vrect = (.-) V")
       print ("------ Vout=",Vout)
      Vout=Vout*1000
      P= (Iout/1000)*(Vout/1000)
      print ("------ P=",P)
      Nom_Irect_Fix_Get=Iout
      print("-----RealVcritical------ Nom_Irect_Fix_Get:",Nom_Irect_Fix_Get)
        
      ------Nom_Vrect_Fix_Get
      Nom_Vrect_Fix_Get=Vout
      print("-----RealVcritical------ Nom_Vrect_Fix_Get:",Nom_Vrect_Fix_Get)
        
      ------Nom_Iboost--------
      doDiagsCmd("i2c -w 7 0x55 0x41\n")
      _,Nom_Iboost=doDiagsCmd("i2c -r 7 0x55 4\n") 
            
      --print("0-----Nom_Iboost=" .. Nom_Iboost)
      Nom_Iboost = string.match(Nom_Iboost or "","buffer read:%s+(.-)\n")
      Nom_Iboost = string.gsub(Nom_Iboost or "","0x",""):gsub(" ","")
      --print("Iboost_value:",Iboost_value)
      Nom_Iboost = "0x" .. string.sub(Nom_Iboost,5,8)
      --print("Nom_Iboost:",Nom_Iboost)
              
      Nom_Iboost=tonumber(Nom_Iboost)
            
      print("-----RealVcritical------ Nom_Iboost:",Nom_Iboost)
            
      ------Nom_Vboost
      Nom_Vboost=Vin
      print("-----RealVcritical------ Nom_Vboost:",Nom_Vboost)
        
      ------Nom_FOD_threshold
      --Iout* Vout /Nom_Iboost(0x41)* Nom_Vboost (0x42)
      Nom_FOD_threshold=(Nom_Irect_Fix_Get*Nom_Vrect_Fix_Get) / (Nom_Iboost*Nom_Vboost)
      print("-----RealVcritical------ Nom_FOD_threshold:",Nom_FOD_threshold)
        
      ------Nom_Rx_Loading_power
      Nom_Rx_Loading_power=P
      print("-----RealVcritical------ Nom_Rx_Loading_power:",Nom_Rx_Loading_power)
        
      ComTable["RealVcritical_P"]=P
      
      if i==320 then
        --------------
        print("-------i=380")
        Nom_Irect_Fix_Get=Iout
        print("-----RealVcritical------ Nom_Irect_Fix_Get:",Nom_Irect_Fix_Get)
        
        ------Nom_Vrect_Fix_Get
        Nom_Vrect_Fix_Get=Vout
        print("-----RealVcritical------ Nom_Vrect_Fix_Get:",Nom_Vrect_Fix_Get)
        
        ------Nom_Iboost--------
        doDiagsCmd("i2c -w 7 0x55 0x41\n")
        _,Nom_Iboost=doDiagsCmd("i2c -r 7 0x55 4\n") 
            --print("0-----Nom_Iboost=" .. Nom_Iboost)
        Nom_Iboost = string.match(Nom_Iboost or "","buffer read:%s+(.-)\n")
        Nom_Iboost = string.gsub(Nom_Iboost or "","0x",""):gsub(" ","")
        --print("Iboost_value:",Iboost_value)
        Nom_Iboost = "0x" .. string.sub(Nom_Iboost,5,8)
        --print("Nom_Iboost:",Nom_Iboost)
        Nom_Iboost=tonumber(Nom_Iboost)
            
        print("-----RealVcritical------ Nom_Iboost:",Nom_Iboost)
            
        ------Nom_Vboost
        Nom_Vboost=Vin
        print("-----RealVcritical------ Nom_Vboost:",Nom_Vboost)
        ------Nom_FOD_threshold
        --Iout* Vout /Nom_Iboost(0x41)* Nom_Vboost (0x42)
        Nom_FOD_threshold=(Nom_Irect_Fix_Get*Nom_Vrect_Fix_Get) / (Nom_Iboost*Nom_Vboost)
        print("-----RealVcritical------ Nom_FOD_threshold:",Nom_FOD_threshold)
        ------Nom_Rx_Loading_power
        Nom_Rx_Loading_power=P
        print("-----RealVcritical------ Nom_Rx_Loading_power:",Nom_Rx_Loading_power)
        
        ComTable["RealVcritical_P"]=P
        
        Vin = Vin / 1000
        
        bResult=Vin and true or false
        ResultTable.resultCode = bResult
        ResultTable.resultString = Vin
          ----+10ma
        doScorpiusCmd ("eload set " .. tostring(i+10) .. "\r")
        _,Iout = doScorpiusCmd("eload adc\r")
        Iout = string.match(Iout or "","Current = (.-) mA")
        _,Vout = doScorpiusCmd("ikt adc\r")
        Vout= string.match(Vout or "","Vrect = (.-) V")
        Vout=Vout*1000
        ComTable["RealVcritical_10ma_P"]= (Iout/1000)*(Vout/1000)
        ----+20ma
        doScorpiusCmd ("eload set " .. tostring(i+20) .. "\r")
        _,Iout = doScorpiusCmd("eload adc\r")
        Iout = string.match(Iout or "","Current = (.-) mA")
        _,Vout = doScorpiusCmd("ikt adc\r")
        Vout= string.match(Vout or "","Vrect = (.-) V")
        Vout=Vout*1000
        ComTable["RealVcritical_20ma_P"]= (Iout/1000)*(Vout/1000)
        
        doDiagsCmd("i2c -v 7 0x55 0x0f 0x00\n")
        doScorpiusCmd("eload set 0\r")
        return
            ----------------
          end
    end
end

function itemReadEloadSN()
  local send, recv = doScorpiusCmd("diags get eloadsn\r")
  local eload_sn = string.match(recv or "", "(%w+_%w+)%s*Ginger>")
  ResultTable.resultCode = eload_sn and true or false
  ResultTable.resultString = eload_sn 
end  

function itemReadGingerVersion()
  local send, recv = doScorpiusCmd("diags get mlbsn\r")
  local ginger_ver = string.match(recv or "", "(%w+)%s*Ginger>")
  ResultTable.resultCode = ginger_ver and true or false
  ResultTable.resultString = ginger_ver 
end





function itemReadGingerFWVersion(self)
  local result = true
  local send, recv = doScorpiusCmd("get versions\r")
  local Ginger_Fw_ver = string.match(recv or "", "application:%s*([.%w]*)")


--  Ginger_Fw_Expect = "2.6.10"
--  if (Ginger_Fw_ver ~= Ginger_Fw_Expect) then
--    result = false
--  end
    ResultTable.resultCode = result
    ResultTable.resultString = result and Ginger_Fw_ver or "Expected '" .. Ginger_Fw_Expect .. "' got '" .. Ginger_Fw_ver .. "'"
    g_PDCAAttribute["Ginger_FW_version"] = Ginger_Fw_ver
end  

function itemReadIKTARAVersion(self)
  local result = true
  local send, recv = doScorpiusCmd("get versions\r")
  local Iktara_Fw_ver = string.match(recv or "", "Main version:%s*([.%w]*)")
--  Iktara_Fw_ver_expect = "2.2.1"
--  if Iktara_Fw_ver_expect ~= Iktara_Fw_ver then
--   STOP_FAIL = true
--   result = false
--  end

  ResultTable.resultCode = result
  ResultTable.resultString = result and Iktara_Fw_ver or "Expected '" .. Iktara_Fw_ver_expect .. "' got '" .. Iktara_Fw_ver .. "'" 
  g_PDCAAttribute["Ginger_Iktara_version"] = Iktara_Fw_ver
end  





function DOE3RealVcritical_I(self)
  local current = Iout / 1000
  ResultTable.resultCode = current and true or false
  ResultTable.resultString = current
end  
function DOE3RealVcritical_V(self)
  local voltage = Vout / 1000
  ResultTable.resultCode = voltage and true or false
  ResultTable.resultString = voltage
end 





----------------------------For Virus NonUI (Hidreport)------------------------------


function diags_to_NonUI(self)
  local bResult = false
  doDiagsCmd("nvram --set boot-command fsboot\n")
  doDiagsCmd("nvram --save\n")
  iPadSerial:send("reset\n")
  -- iPadSerial:close()
  app.wait(10000)
  table.insert(g_ResultLog, "App wait 10s")
  for i = 1,20 do
    table.insert(g_ResultLog, string.format("--------Retry %d times--------", i))
    msgTelnet = message.open("telnet localhost 10023")
    local recOpenTel = message.recv(msgTelnet, {"login:"}, 5, 0)
    local _,rtRecv = doOsCmd("root", "Password:")
    _, rtRecv , bResult = doOsCmd("alpine")
    if bResult then break end
    app.wait(2000)
  end
  ResultTable.resultCode = bResult
end





function doOsCmd(anCmd, endCode, recvtimeOut, messageObject)
 
 local _msgObj = messageObject or msgTelnet

 anCmd = anCmd .. "\n"
 local rtSend, rtSend_status_bool, rtRecv, recv_status, recv_status_bool = nil, nil, nil, nil, nil
 local startTime = utils.timeStart()
 rtSend = message.send(_msgObj,anCmd,5,0)
 local sendStatus = (rtSend>0) and "Success" or "Fail"
 local rtSend_status_bool = (rtSend>=0) and true or false
 local sendFormat = string.format("send[%s:%s]:%s", sendStatus, tostring(rtSend), anCmd or "cmd empty\n")
 local sendLog =  "["..utils.timestamp().."]:"..sendFormat
 table.insert(g_ResultLog, sendLog)

 local strEndCode = endCode or "iPad:~ root# "
 local timeOut = recvtimeOut or 10
 rtRecv, recv_status = message.recv(_msgObj,{strEndCode}, timeOut, -1)
 recv_status_bool = (recv_status > 0) and true or false
 local endTime = utils.timeEnd(startTime)
 local recvStatus = (recv_status_bool and "Success" or "Fail")
 local recvFormat = string.format("recv[%s:%s]:%s", recvStatus, tostring(recv_status), rtRecv or "no data\n")
 local recvLog = "["..utils.timestamp().."]:".. recvFormat
 table.insert(g_ResultLog, recvLog)
 table.insert(g_ResultLog, "[recv:finish]")
 return rtsend, rtRecv, rtSend_status_bool and recv_status_bool
end

--function doOsCmd(anCmd, endCode, recvtimeOut)
--  local rtsend, rtRecv, bResult = nil,nil,nil
--  local count = 0
--  repeat
--    rtsend, rtRecv, bResult = doOsCmd_0(anCmd, endCode, recvtimeOut)
--    count = count + 1
--  until (not string.match(rtRecv or "", "Error")) or count == 5
--  return rtsend, rtRecv, bResult
--end


function loginOS(self) 
  local bResult = false
  for i = 1,10 do
    msgTelnet = message.open("telnet localhost 10023")
    local recOpenTel = message.recv(msgTelnet, {"login:"}, 5, 0)
        print("----tenlet: ", recOpenTel)
    local _,rtRecv = doOsCmd("root","Password:")
    _, rtRecv , bResult = doOsCmd("alpine")
    if bResult then break end
    app.wait(2000)
    msgTelnet:close()
  end
  ResultTable.resultCode = bResult
end



function get_hid_bytes(full_command_recv, expected_byte_count_0)
  local bool_result = true
  local fail_info = ""
  local expected_byte_count = tonumber(string.match(full_command_recv or "", "GET feature (%d+) bytes"))
  if expected_byte_count_0 then expected_byte_count = expected_byte_count_0 + 1 end   --First byte is register address
  local bytes = {}
  local matched = string.match(full_command_recv, "GET feature %d+ bytes %(0x%w+%)(.+)iPad:~ root# ")
  for str in string.gmatch(matched or "", "%d+:%s*(.-)%s*\n") do
    local data = string.gsub(str or "", "%s", "")
    for i in string.gmatch(data, "..") do
      table.insert(bytes, i)
    end
  end  

  if #bytes ~= expected_byte_count then
    bool_result = false
    fail_info = string.format("Data length is not %d , data [%s]", expected_byte_count, table.concat(bytes, ", "))
    table.insert(g_ResultLog, "ERROR: " .. fail_info)
  end
  table.remove(bytes, 1)
  return bytes, bool_result, fail_info
end 



local function test_OS_cmds( self )
  local send, recv = doOsCmd("hidreport -du 0xFF00,0x0036 get 0x33")
  local bytes = get_hid_bytes(recv)
  table.insert(g_ResultLog, table.concat( bytes, ", "))
  ResultTable.resultCode = true
end


function itemMCU_FW_Check(self)
  local _, recv = doOsCmd("hidreport -du 0xFF00,0x0036 get 0xBB")
  -- local str = string.match(recv or "", "%d+:%s*(.-)%s*\n")

  -- local bytes, bResult, fail_info = get_hid_bytes(recv)
  --   if #bytes ~= 8 then 
  --   ResultTable.resultCode = bResult
  --   ResultTable.resultString = fail_info
  --   return
  -- end  

  -- local Bootloader_Type = bytes[2] .. bytes[1]
  -- local Bootloader_Version = bytes[4] .. bytes[3]
  -- local Main_FW_Type = bytes[6] .. bytes[5]
  -- local Main_FW_Version = bytes[8] .. bytes[7]

  -- local full_FW_version = table.concat(bytes, " ")
  local full_FW_version = string.match(recv or "", "FW Version: (0x%w+)")

  ResultTable.resultCode = full_FW_version and true or false --bResult
  ResultTable.resultString = full_FW_version
  -- if bResult then
  --   g_PDCAAttribute["TX_MCU_FW"] = full_FW_version
  -- end
end  

function Low_Power_TX_Ping_Test_0(self)
  -- doOsCmd("clcdControl --fixed_rr=10")
  -- doOsCmd("setbright 1")
  -- doOsCmd("diagstool lcdmura --rgb 225,0,0")
  
  set_hid(0x91, {})
  app.wait(200)

  ComLppTable = {}
  rtRecvLppData = ""


  ComTable["frepData"] = nil
  ComTable["lData"] = nil
  ComTable["q_res"] = nil

  ComTable["frepData_delta"] = nil
  ComTable["lData_delta"] = nil
  ComTable["q_res_delta"] = nil

  set_hid(0x0A, {0x08, 0, 0, 0}) 
  app.wait(200)

  doOsCmd("hidreport -du 0xFF00,0x0036 hset 01 01 00") --Debug mode disabled

  -- doOsCmd("hidreport -du 0xFF00,0x0036 hset 26 26 0 0 0 0") --Closed loop disabled

  -- doOsCmd("hidreport -du 0xFF00,0x0036 hset 22 22 02 07 00 00 00 00") --vboost off

  -- doOsCmd("hidreport -du 0xFF00,0x0036 hset 11 11 04") --send pulse width of 4 micro seconds

  doOsCmd("hidreport -du 0xFF00,0x0036 hset 11 11 05")   

  app.wait(15)

  local _, recv = doOsCmd("hidreport -du 0xFF00,0x0036 get 0x11")
  local bytes, bResult, fail_info = get_hid_bytes(recv)
  
 
  local Frequency = MakeFloat(tonumber("0x" .. bytes[1]), tonumber("0x" .. bytes[2]), tonumber("0x" .. bytes[3]), tonumber("0x" .. bytes[4]))
  local Inductance = MakeFloat(tonumber("0x" .. bytes[5]), tonumber("0x" .. bytes[6]), tonumber("0x" .. bytes[7]), tonumber("0x" .. bytes[8]))
  local Impedance = MakeFloat(tonumber("0x" .. bytes[9]), tonumber("0x" .. bytes[10]), tonumber("0x" .. bytes[11]), tonumber("0x" .. bytes[12]))
  local QFactor = MakeFloat(tonumber("0x" .. bytes[13]), tonumber("0x" .. bytes[14]), tonumber("0x" .. bytes[15]), tonumber("0x" .. bytes[16]))
  local FrequencyDelta = MakeFloat(tonumber("0x" .. bytes[17]), tonumber("0x" .. bytes[18]), tonumber("0x" .. bytes[19]), tonumber("0x" .. bytes[20]))
  local InductanceDelta = MakeFloat(tonumber("0x" .. bytes[21]), tonumber("0x" .. bytes[22]), tonumber("0x" .. bytes[23]), tonumber("0x" .. bytes[24]))
  local ImpedanceDelta = MakeFloat(tonumber("0x" .. bytes[25]), tonumber("0x" .. bytes[26]), tonumber("0x" .. bytes[27]), tonumber("0x" .. bytes[28]))
  local QFactorDelta = MakeFloat(tonumber("0x" .. bytes[29]), tonumber("0x" .. bytes[30]), tonumber("0x" .. bytes[31]), tonumber("0x" .. bytes[32]))
  local IsDecayLinear = MakeFloat(tonumber("0x" .. bytes[33]), tonumber("0x" .. bytes[34]), tonumber("0x" .. bytes[35]), tonumber("0x" .. bytes[36]))

  ComTable["frepData"] = Frequency / 1000
  ComTable["lData"] = Inductance * 1000 * 1000
  ComTable["q_res"] = QFactor

  ComTable["frepData_delta"] = FrequencyDelta / 1000
  ComTable["lData_delta"] = InductanceDelta * 1000 * 1000
  ComTable["q_res_delta"] = QFactorDelta
  
    local position = self.name:match("(.-_)")
    local ADC_data = get_rawADC_data() 
    local filePath = app.getLogFile({resultString="Henry" , sn = sn}):gsub(".txt","") .. position .. "_rawADC.csv"
    ComTable[position .. "_rawADC_path"] = filePath
    local data_to_write = string.format("%s, %s, %s, %s, %s, %s, %s", ComTable["frepData"], ComTable["lData"], ComTable["q_res"], ComTable["frepData_delta"], ComTable["lData_delta"], ComTable["q_res_delta"], table.concat(ADC_data, ", "))
    local file = io.open(filePath,'w')
    file:write(data_to_write .. "\n")
    file:close()

end


function itemTemp1Fun(self)
  set_hid(0x0A, {0x08, 0, 0, 0}) 
  app.wait(200)
  doOsCmd("hidreport -du 0xFF00,0x0036 hset 01 01 01")
  app.wait(200)
  ComTable["Temp1"] = nil
  ComTable["Temp2"] = nil
  ComTable["Temp3"] = nil
  doOsCmd("hidreport -du 0xFF00,0x0036 hset 33 33 28 00")
  app.wait(2000)
  local _, recv = doOsCmd("hidreport -du 0xFF00,0x0036 get 0x33")
  local bytes, bResult, fail_info = get_hid_bytes(recv, 72)
   if #bytes ~= 72 then 
    ResultTable.resultCode = bResult
    ResultTable.resultString = fail_info
    return
  end  
  
  ComTable["Temp1"] = "0x" .. bytes[12] .. bytes[11]
  ComTable["Temp2"] = "0x" .. bytes[16] .. bytes[15]
  ComTable["Temp3"] = "0x" .. bytes[20] .. bytes[19]
  table.insert(g_ResultLog, "Catch: " .. ComTable["Temp1"])
  local temperature1 = tonumber(ComTable["Temp1"])
  bResult = compareAandB(temperature1, self.limitSet.lower,self.limitSet.upper,true) 
  ResultTable.resultCode = bResult
  ResultTable.resultString =  temperature1 or fail_info
end

function itemTemp2Fun(self)
  table.insert(g_ResultLog, "Catch: " .. ComTable["Temp2"])
  local temperature2 = tonumber(ComTable["Temp2"])
  ResultTable.resultCode = temperature2 and true or false
  ResultTable.resultString =  temperature2
end  

function itemTemp3Fun(self)
  table.insert(g_ResultLog, "Catch: " .. ComTable["Temp3"])
  local temperature3 = tonumber(ComTable["Temp3"])
  ResultTable.resultCode = temperature3 and true or false
  ResultTable.resultString =  temperature3
end  

function Move_to_OptimalPoint()
    doFixtureCmd("scorpiuson\n")
    doOsCmd("hidreport -du 0xFF00,0x0036 hset 26 26 0 0 0 0")
    app.wait(200)
    doOsCmd("hidreport -du 0xFF00,0x0036 hset 01 01 00")
    app.wait(200)
    doScorpiusCmd("eload init\r")
    app.wait(200)
    doScorpiusCmd("set mode none\r")
    app.wait(200)
    doOsCmd("hidreport -du 0xFF00,0x0036 hset 01 01 01")
    app.wait(200)
    doOsCmd("hidreport -du 0xFF00,0x0036 hset 22 22 1 3 B4 0 0 0")
    doOsCmd("hidreport -du 0xFF00,0x0036 hset 24 24 78 05")
    app.wait(200)
    doScorpiusCmd("set mode rx\r")
    app.wait(1000)
    doScorpiusCmd("ikt signal 0\r")
    app.wait(200)
  
--horizontal direction
  local anCmd = "left 2\r"   
  local optValue_H = getOptValue_(anCmd)

--vertical direction
  local anCmd2 = "up 2\r"
  local optValue_V = getOptValue_(anCmd2)

  local bResult = optValue_H and optValue_V and true or false
  CommitResult(bResult, optValue_V)
end

-- function itemPhaseshifted3_old(self)
--   ComTable["DAC"] = 1550      -- 1550 for Pre_EVT
--   ComTable["Phase"] = 125
--   doOsCmd("hidreport -du 0xFF00,0x0036 hset 26 26 0 0 0 0")
--   app.wait(200)
--   doOsCmd("hidreport -du 0xFF00,0x0036 hset 01 01 00")
--   app.wait(200)
--   doScorpiusCmd("eload set 0\r")
--   app.wait(200)
--   doScorpiusCmd("set mode none\r")
--   app.wait(200)
--   doOsCmd("hidreport -du 0xFF00,0x0036 hset 01 01 01")
--   app.wait(200)
--   doOsCmd("hidreport -du 0xFF00,0x0036 hset 24 24 0E 06") --Changed from 1600 to 1550
--   app.wait(200)
--   doOsCmd("hidreport -du 0xFF00,0x0036 hset 22 22 1 3 7D 0 0 0")
--   app.wait(200)
--   doScorpiusCmd("set mode rx\r")
--   app.wait(200)
--   doScorpiusCmd("eload set 40\r")
--   app.wait(200)
--   local finalResult = loopTest(self.target_vrect)
--   local bResult = compareAandB(tonumber( finalResult),self.limitSet.lower,self.limitSet.upper,true)
--   finalResult=finalResult
--   ResultTable.resultCode = bResult
--   ResultTable.resultString =tostring(finalResult)
-- end

function TXFrequenceTest(self)
  local _, recv = doOsCmd("hidreport -du 0xFF00,0x0036 get 0x22")
  local bytes, bResult, fail_info = get_hid_bytes(recv, 48)
  if #bytes ~= 48 then 
    ResultTable.resultCode = bResult
    ResultTable.resultString = fail_info
    return
  end  
  local Bridge_Frequency = "0x" .. bytes[16] .. bytes[15]
  Dead_time = "0x" .. bytes[28] .. bytes[27]
  table.insert(g_ResultLog, "Catch: " .. Bridge_Frequency)
  Bridge_Frequency_number = tonumber(Bridge_Frequency) / 10
  bResult = compareAandB(Bridge_Frequency_number,self.limitSet.lower,self.limitSet.upper,true)
  ResultTable.resultCode = bResult
  ResultTable.resultString = Bridge_Frequency_number or fail_info
end
 

function PWMDeadTimeTest(self)
  table.insert(g_ResultLog, "Catch: " .. Dead_time)
  local Dead_time_number = tonumber(Dead_time)
  local bResult = compareAandB(Dead_time_number,self.limitSet.lower,self.limitSet.upper,true)
  ResultTable.resultCode = bResult
  ResultTable.resultString = Dead_time_number
end


function itemIboostfunction(self)
  IboostData = nil
  VboostData = nil
  Vctx = nil
  g_IbootValue = nil
  g_VbootValue = nil
  doOsCmd("hidreport -du 0xFF00,0x0036 hset 33 33 28 00")
  app.wait(2000)
  local _, recv = doOsCmd("hidreport -du 0xFF00,0x0036 get 0x33")
  local bytes, bResult, fail_info = get_hid_bytes(recv, 72)
   if #bytes ~= 72 then 
    ResultTable.resultCode = bResult
    ResultTable.resultString = fail_info
    return
  end  
  IboostData = "0x" .. bytes[8] .. bytes[7]
  VboostData = "0x" .. bytes[4] .. bytes[3]
  Vctx       = "0x" .. bytes[34] .. bytes[33]
  table.insert(g_ResultLog, "Catch: " .. IboostData)
  g_IbootValue = tonumber(IboostData)/1000.0
  bResult = compareAandB(g_IbootValue,self.limitSet.lower,self.limitSet.upper,true) 
  ResultTable.resultCode = bResult
  ResultTable.resultString = g_IbootValue or fail_info
end

function itemVboostfunction(self)
  table.insert(g_ResultLog, "Catch: " .. VboostData)
  local bResult = compareAandB(tonumber(VboostData)/1000.0,self.limitSet.lower,self.limitSet.upper,true) 
  g_VbootValue = nil
  g_VbootValue = VboostData and (tonumber(VboostData)/1000.0) or nil
  ResultTable.resultCode = bResult
  ResultTable.resultString = tonumber(VboostData)/1000.0
end

function itemVctx(self)
  table.insert(g_ResultLog, "Catch: " .. Vctx)
  local VboostData_number = tonumber(Vctx) / 1000
  local bResult = compareAandB(VboostData_number,self.limitSet.lower,self.limitSet.upper,true)
  ResultTable.resultCode = bResult
  ResultTable.resultString = VboostData_number
end

function itemBridgePhase(self)
  -- doOsCmd("hidreport -du 0xFF00,0x0036 get 0x22")
  -- app.wait(1000)
  local _, recv = doOsCmd("hidreport -du 0xFF00,0x0036 get 0x22")
  local bytes, bResult, fail_info = get_hid_bytes(recv, 48)
   if #bytes ~= 48 then 
    ResultTable.resultCode = bResult
    ResultTable.resultString = fail_info
    return
  end  
  local Bridge_Phase = "0x" .. bytes[22] .. bytes[21]
  table.insert(g_ResultLog, "Catch: " .. Bridge_Phase)
  BridgePhase_value=tonumber(Bridge_Phase)
  bResult = compareAandB(BridgePhase_value,self.limitSet.lower,self.limitSet.upper,true) 
  ResultTable.resultCode = bResult
  ResultTable.resultString = BridgePhase_value or fail_info
end

function itemASK_PacketAmountReceived(self) --2018/02/27
  doOsCmd("hidreport -du 0xFF00,0x0036 hset 01 01 01")
  doScorpiusCmd("ikt signal 1\r")
  app.wait(3000)
  doOsCmd("hidreport -du 0xFF00,0x0036 hset 20 20 00")
  doOsCmd("hidreport -du 0xFF00,0x0036 hset 1F 1F 00 19 06")
  app.wait(6000)
  table.insert(g_ResultLog,"wait 6000ms")
  doScorpiusCmd("ikt signal 0\r")
  local _, recv = doOsCmd("hidreport -du 0xFF00,0x0036 get 0x20")
  local bytes, bResult, fail_info = get_hid_bytes(recv, 12)
   if #bytes ~= 12 then 
    ResultTable.resultCode = bResult
    ResultTable.resultString = fail_info
    return
  end  
  
  local total_count   = tonumber("0x" .. bytes[8] .. bytes[7] .. bytes[6] .. bytes[5])
  local correct_count = tonumber("0x" .. bytes[12] .. bytes[11] .. bytes[10] .. bytes[9])

  ComTable["total_count"] = total_count
  ComTable["error_count"] = total_count - correct_count

  bResult = compareAandB(ComTable["total_count"],self.limitSet.lower,self.limitSet.upper,true)
  ResultTable.resultCode = bResult
  ResultTable.resultString = ComTable["total_count"]
end  


function itemPreambleBit(self)
  doOsCmd("hidreport -du 0xFF00,0x0036 hset 21 21 0 0 80 0")
  local _, recv = doOsCmd("hidreport -du 0xFF00,0x0036 get 0x21")
  local data_128, bResult, fail_info = get_hid_bytes(recv, 128)
   if #data_128 ~= 128 then 
    ResultTable.resultCode = bResult
    ResultTable.resultString = fail_info
    return
  end  

  doOsCmd("hidreport -du 0xFF00,0x0036 hset 21 21 0 0 48 0")
  local _, recv1 = doOsCmd("hidreport -du 0xFF00,0x0036 get 0x21")
  local data_72, bResult1, fail_info1 = get_hid_bytes(recv1, 72)
   if #data_72 ~= 72 then 
    ResultTable.resultCode = bResult1
    ResultTable.resultString = fail_info1
    return
  end
  data_128 = table.concat(data_128, "")
  data_72 = table.concat(data_72, "")
  
  local data_200 = data_128 .. data_72
  ComTable["data_packet"] = {}  
  for i=1, string.len(data_200 or ""), 2 do
    table.insert(ComTable["data_packet"], data_200:sub(i, i+1))
  end  

  local resultTab = {}
  local failCount = 0
  for i,v in pairs(ComTable["data_packet"]) do
    if (i-1)%8 == 0 then
      local value = ComTable["data_packet"][i+1]
      local value_need = string.sub(value, 2)
      if compareAandB(tonumber("0x" .. value_need), self.lowerValue, self.upperValue, true) ~= true then
        failCount = failCount + 1
      end  
      table.insert(resultTab, value_need)
    end  
  end
  ComTable["Preamble_data"] = resultTab
  bResult = failCount <= self.allow_failCount and true or false
  local tResult = table.concat(resultTab, "_")
  ResultTable.resultCode = bResult
  ResultTable.resultString = tResult
end  

function itemFSK_PacketAmountReceived(self) --2018/02/27
doOsCmd("hidreport -du 0xFF00,0x0036 hset 01 01 01")
print("itemFSK_stop")
  app.wait(200)
  doScorpiusCmd("ikt clearBuf\r")
  app.wait(200)
  local interval_ms = 0x0064
  local packets_count = 0x001E
  local sync_packet = 0
  doOsCmd(string.format("hidreport -du 0xFF00,0x0036 hset 25 25 %X %X %X %X %X 2E 55 AA", 
                        interval_ms & 0x00FF, interval_ms >> 8, packets_count & 0x00FF, packets_count >> 8, sync_packet))

  print("----FSK set----")
  app.wait(2000)
  
  local time_to_wait = interval_ms * packets_count + 1000
  app.wait(time_to_wait)
  table.insert(g_ResultLog,"wait " .. time_to_wait .. "ms")
  local _,rtRecv = doScorpiusCmd("ikt readFSK " .. packets_count .. "\r")
  print("StevenWU")
  print("----ikt readFSK 30---",rtRecv)
  local str="";
reRecv = string.match(rtRecv or "", "Number of Packets : (.+)")  
for v in string.gmatch(reRecv or "","Packets%s+%:%s+(%w+)[\n\r]?") do
  str=str..v;
  table.insert(g_ResultLog, "Pak: " .. v)
end

print("StevenWU")
--  print(str)
local tableT = {}
for i=5,29 do
table.insert(tableT,string.sub(str,i*16+9,i*16+14))
end

local TResult = table.concat(tableT, "_")

tableE = {}
for i=5,29 do
table.insert(tableE,string.sub(str,i*16+3,i*16+4))
end

EResult = table.concat(tableE, "_")

local bResult = true
local failCount = 0

valueFSK_wanted = self.passValue
matchedFSK_count = 0
for j=1, 25 do
print(tableT[j])
 if tableT[j] == valueFSK_wanted then 
   matchedFSK_count = matchedFSK_count + 1 
  else
   failCount = failCount + 1 
  end
end

  tResult = (1-(25- matchedFSK_count) / matchedFSK_count) * 100
  bResult = failCount <= self.allow_failCount and true or false

  ResultTable.resultCode = bResult
  ResultTable.resultString = TResult
end


-- function itemVrect_135mA_old(self)

--     g_IrectValue = nil
--     g_VrectValue = nil

--   doOsCmd("hidreport -du 0xFF00,0x0036 hset 01 01 01")
--   app.wait(200)
--   -- doOsCmd("hidreport -du 0xFF00,0x0036 hset 24 24 DC 05")
--   -- app.wait(200)
--   -- doOsCmd("hidreport -du 0xFF00,0x0036 hset 22 22 1 3 7D 0 0 0")


--   local eload_step =  10 
--   if self.eload_end ==45 then
--     ComTable["eload_start"] = 25
--   elseif self.eload_end == 110 then
--     ComTable["eload_start"] = 50
--     eload_step =  30
--   elseif self.eload_end == 150 then
--     ComTable["eload_start"] = 55
--   elseif self.eload_end == 225 then
--     ComTable["eload_start"] =105
--     eload_step =  20
--   end
-- --  if self.name:match("@10C") then
-- --    ComTable["loopTest"] = 180
-- -- end
-- --  if not self.name:match("@10C") then
-- --   ComTable["firstValue"] = 1500
-- -- end

--  if self.name:match("@2.5C") then
--   ComTable["eload_start"] = 115
--   self.eload_end = 115
-- end

--   for i = ComTable["eload_start"],self.eload_end, eload_step do
--     local cmd = "eload set " .. tostring(i) .. "\r"
--     app.wait(200)
--     doScorpiusCmd(cmd)
--     -- local _,getVValue = doScorpiusCmd("ikt adc\r")

--     -- local _,getAValue =doScorpiusCmd("ikt adc\r")

--     -- print("----- before getAValue  -----",getAValue)

--     -- local _,testValue = string.match(getVValue or "","Vrect = (.-)Vrect = (.-) V")

--     -- if tonumber(testValue) == nil then
--     --   return false
--     -- end
--     -- ComTable["loopFlag"] = testValue
--     -- ComTable["breakVValue1"]=testValue

--     -- print("----- before compare testValue  -----",testValue)
--     -- print("----- self.lowerValue  -----",self.lowerValue)
--     -- print("----- self.upperValue  -----",self.upperValue)

--     -- testValue=tonumber(testValue)
--     -- print("----- testValue  -----",testValue)

--     -- local  ret = (self.lowerValue<=testValue and testValue<=self.upperValue) and true or false
--     -- print("----- compare ret  -----",ret)

--     -- if ret==false then
--     --   print("----- loopTest start  -----")
--     --   ComTable["loopFlag"] = loopTest(ComTable["loopTest"],self.upperValue,self.lowerValue,testValue)

--     --   print("----- loopTest end  -----")
--     -- end
--     --  if tonumber(ComTable["loopTest"]) == 180 and not compareAandB(tonumber(ComTable["loopFlag"]),self.lowerValue,self.upperValue,true) then
--     --   print("testValue0925 Looptest ok ----2")
--     --   ComTable["loopFlag"] = loopTest(ComTable["loopTest"],self.upperValue,self.lowerValue,ComTable["loopFlag"])
--     -- end
--     ComTable["Vrect_Fix_Get"] = loopTest(self.target_vrect)
   
--   end
 
--       -- ComTable["Vrect_Fix_Get"] = ComTable["loopFlag"]
--   -- print(GetVrec5)
--   -- print(GetVrec4)
--   -- print(GetVrec3)

--   -- print("----- 135ma eti  -----")
-- --  print(GetVrec3)
 

--   _,ComTable["135ma"] = doScorpiusCmd("eload adc\r")

--   local testValue = string.match(ComTable["135ma"] or "","Current = (.-) mA")
--   ComTable["Current135ma"] = testValue

--   testValue1=testValue
 
--   g_IrectValue = tonumber(testValue1)/1000 or nil
--   local bResult = compareAandB(tonumber(testValue1)/1000,self.limitSet.lower,self.limitSet.upper,true) 
--   ResultTable.resultCode = bResult
--   ResultTable.resultString = testValue1/1000 or "No Data"
-- end



function itemVctxValueShow()
  doOsCmd("hidreport -du 0xFF00,0x0036 hset 33 33 28 00")
  app.wait(2000)
  local _, recv = doOsCmd("hidreport -du 0xFF00,0x0036 get 0x33")
  local bytes, bResult, fail_info = get_hid_bytes(recv)
  local Vctx = "0x" .. bytes[34] .. bytes[33]
  table.insert(g_ResultLog, "Catch vctx: " .. Vctx)
  return tonumber(Vctx)/1000.0
end

-- function CL_Charging(self)
--   if(self.key == 1) then
-- --    doFixtureCmd("scorpiuson\n")
--     set_hid(0x0A, {0x08, 0, 0, 0}) -- Tell Tx to enter Static Mode
--     doOsCmd("hidreport -du 0xFF00,0x0036 hset 26 26 0 0 0 0")
--     app.wait(200)
--     doOsCmd("hidreport -du 0xFF00,0x0036 hset 01 01 00")
--     app.wait(200)
--     doScorpiusCmd("eload set 0\r")
--     app.wait(200)
--     doScorpiusCmd("set mode none\r")
--     app.wait(200)
--     doOsCmd("hidreport -du 0xFF00,0x0036 hset 01 01 01")
--     app.wait(200)
--     doOsCmd("hidreport -du 0xFF00,0x0036 hset 22 22 1 3 7D 0 0 0")
--     app.wait(200)
--     -- doDiagsCmd("smokey ScorpiusHid --run --test \"Set\" --args \"ReportID=0x22, ReportPayload={0x0; 0x0; 0x3; 0; 0; 0}\"\n")
--     doOsCmd("hidreport -du 0xFF00,0x0036 hset 22 22 0 0 3 0 0 0")
--     app.wait(200)
--     doScorpiusCmd("set mode rx\r")
--     app.wait(200)    
--     doScorpiusCmd("set cap 0\r")
--     app.wait(200)
--     doScorpiusCmd("eload set 8\r")
--     app.wait(200)
--     doScorpiusCmd("ikt signal 0\r")
--     app.wait(500)

--     doScorpiusCmd("ikt startLogging\r")
--     -- doDiagsCmd("smokey ScorpiusHid --run --test \"Set\" --args \"ReportID=0x20, ReportPayload={}\"\n") 
--     doOsCmd("hidreport -du 0xFF00,0x0036 hset 20 20")
--     doOsCmd("hidreport -du 0xFF00,0x0036 hset 26 26 1 0 0 0")
--     app.wait(6000)
--     doScorpiusCmd("ikt setVrec 13.4\r")
--     app.wait(1000)
--     doScorpiusCmd("eload set 25\r")
--     app.wait(1000)
--     doScorpiusCmd("eload set 50\r")
--     app.wait(1000)
--     doScorpiusCmd("eload set 75\r")
--     app.wait(1000)
--     doScorpiusCmd("eload set 100\r")
--     app.wait(1000)
--     doScorpiusCmd("eload set 125\r")
--     app.wait(1000)
--     doScorpiusCmd("eload set 150\r")
--     app.wait(1000)
--     doScorpiusCmd("eload set 175\r")
--     app.wait(1000)
--     doScorpiusCmd("eload set 200\r")
--     app.wait(1000)
--      doScorpiusCmd("eload set 225\r")
--     app.wait(1000)
--     _,CL_Irecttest = doScorpiusCmd("eload adc\r")
--     _,CL_Vrecttest = doScorpiusCmd("ikt adc\r")
--     CL_Irect10C = string.match(CL_Irecttest or "","Current = (.-) mA")
--     CL_Vrect10C = string.match(CL_Vrecttest or "","Vrect = (.-) V")
--     CL_Iboost10C = itemIboostValueShow()
--     CL_Vboost10C = itemVboostValueShow()
--     CL_Phase10C = itemBridgePhaseValue()
--     CL_Rx_Loading10C = (CL_Irect10C*CL_Vrect10C)
--     CL_FOD10C = (CL_Irect10C*CL_Vrect10C)/(CL_Iboost10C*CL_Vboost10C)
--     CL_Vctx10C = itemVctxValueShow()
    
--     CL_Table = {CL_Irect10C/1000,CL_Vrect10C,CL_Iboost10C,CL_Vboost10C,CL_Phase10C,CL_Rx_Loading10C/1000,CL_FOD10C/1000, CL_Vctx10C}
    
--     doOsCmd("hidreport -du 0xFF00,0x0036 hset 26 26 0 0 0 0")
--     app.wait(200)
--     doScorpiusCmd("eload set 0\r")
    
--     local bResult = compareAandB(tonumber(CL_Table[self.key]),self.limitSet.lower,self.limitSet.upper,true)
--     ResultTable.resultCode = bResult
--     ResultTable.resultString = CL_Table[self.key] or "No Data"
--   else
--     local bResult = compareAandB(tonumber(CL_Table[self.key]),self.limitSet.lower,self.limitSet.upper,true)
--     ResultTable.resultCode = bResult
--     ResultTable.resultString = CL_Table[self.key] or "No Data"
--   end

-- end 

function CL_Charging(self)
    set_hid(0x0A, {0x08, 0, 0, 0})
    set_hid(0x01, {0})
    app.wait(200)

    doScorpiusCmd("set mode none\r")
    doScorpiusCmd("set mode rx\r")
    app.wait(1000)

  -- app.showDialog({btnTitle={"NO","YES"}, msg = "Please put dut on fixture", nil, async=false})

    set_hid(0x20, {}) -- Clear ASK/FSK buffer

    set_hid(0x91, {})
    app.wait(200)
    set_hid(0x93, {0, 0, 0, 0})
    app.wait(200)
    set_hid(0x92, {2, 0, 0, 0}) -- In diags mode should be {2, 0, 0, 0}; in os mode should be {2, 0, 0, 0, 0}
    app.wait(3000)

    local _, recv = get_hid(0xA)
    -- local bytes = get_smokey_bytes(recv)
    -- local bResult = tonumber(bytes[1]) == 4 and true or false --  In Diags mode
    local bResult = string.find(recv or "", "(Closed Loop)") and true or false

    doScorpiusCmd("set cap 0\r")
    doScorpiusCmd("eload set 8\r")
    doScorpiusCmd("ikt signal 0\r")
    doScorpiusCmd("ikt setVrec 14\r")
    set_hid(0x84, {3})
    -- doScorpiusCmd("ikt startLogging\r")

    app.wait(500)

    doScorpiusCmd("eload set 25\r")
    app.wait(500)
    doScorpiusCmd("eload set 50\r")
    app.wait(500)
    doScorpiusCmd("eload set 75\r")
    app.wait(500)
    doScorpiusCmd("eload set 100\r")
    app.wait(500)
    doScorpiusCmd("eload set 125\r")
    app.wait(500)
    doScorpiusCmd("eload set 150\r")
    app.wait(500)
    doScorpiusCmd("eload set 175\r")
    app.wait(500)
    doScorpiusCmd("eload set 200\r")
    app.wait(500)
    doScorpiusCmd("eload set 225\r")
    app.wait(500)


    ResultTable.resultCode = bResult
end 


function read_eload_Irect( self )
  ComTable["Irect_Fix"] = nil
  ComTable["Vrect_Fix"] = nil
  ComTable["Rx_Power"]  = nil
  local Irect,Vrect,Power = Rx_eload_getIrect_Vrect_Power()
  ComTable["Irect_Fix"] = Irect
  ComTable["Vrect_Fix"] = Vrect
  ComTable["Rx_Power"]  = Power

  ResultTable.resultCode = compareAandB(Irect,self.limitSet.lower,self.limitSet.upper,true)
  ResultTable.resultString = Irect
end

function read_eload_Vrect( self )
   ResultTable.resultCode = compareAandB(ComTable["Vrect_Fix"],self.limitSet.lower,self.limitSet.upper,true)
   ResultTable.resultString = ComTable["Vrect_Fix"]
end


function read_eload_Power( self )
   ResultTable.resultCode = compareAandB(ComTable["Rx_Power"],self.limitSet.lower,self.limitSet.upper,true)
   ResultTable.resultString = ComTable["Rx_Power"]
end


function itemCL_Comms(self)
  Tx_FSK_sent = nil
  Tx_ASK_received = nil
  Tx_Good_ASK_received = nil
  Rx_FSK_received = nil
  Rx_ASK_sent = nil

  set_hid(0x0A, {0x08,0,0,0}) -- Stop CloseLoop
  app.wait(1000)

  local _, recv = doScorpiusCmd("ikt numSentASK\r")
  Rx_ASK_sent = tonumber(string.match(recv or "", "Number of sent ASK packets: (%d+)"))
  table.insert(g_ResultLog, "Rx_ASK_sent: " .. Rx_ASK_sent)
  Rx_FSK_received=Rx_ASK_sent
  table.insert(g_ResultLog, "Rx_FSK_received: " .. Rx_FSK_received)



  -- local _,recv = doDiagsCmd("smokey ScorpiusHid --run --test \"Get\" --args \"ReportID=0x20\"\n")
  local _, recv = get_hid(0x20)
  local bytes, bool_result, fail_info = get_hid_bytes(recv)
  if not bool_result then
    ResultTable.resultCode = false
    ResultTable.resultString = fail_info
    return
  end  
  Tx_FSK_sent = tonumber("0x" .. bytes[4] .. bytes[3] .. bytes[2] .. bytes[1])
  Tx_ASK_received = tonumber("0x" .. bytes[8] .. bytes[7] .. bytes[6] .. bytes[5])
  Tx_Good_ASK_received = tonumber("0x" .. bytes[12] .. bytes[11] .. bytes[10] .. bytes[9])
  -- Rx_FSK_received = Need confirm from Rx i2c 
  -- Rx_ASK_sent = Need confirm from Rx i2c 

--  local value = math.floor(((Tx_FSK_sent - Tx_Good_ASK_received) / Tx_FSK_sent)*100+0.5)
  local value = 100 - (Tx_ASK_received/Tx_FSK_sent*100)
  local bResult = compareAandB(value,self.limitSet.lower,self.limitSet.upper,true)
  ResultTable.resultCode = bResult
  ResultTable.resultString = value
end 


function itemCL_Comms_ASK_Sent( self )
  ResultTable.resultCode = compareAandB(Rx_ASK_sent,self.limitSet.lower,self.limitSet.upper,true)
  ResultTable.resultString = Rx_ASK_sent
  -- Rx_ASK_sent = nil
end

function itemCL_Comms_ASK_Received( self )
  ResultTable.resultCode = compareAandB(Tx_ASK_received,self.limitSet.lower,self.limitSet.upper,true)
  ResultTable.resultString = Tx_ASK_received
  -- Tx_ASK_received =nil
end

function itemCL_Comms_FSK_Sent( self )
  ResultTable.resultCode = compareAandB(Tx_FSK_sent,self.limitSet.lower,self.limitSet.upper,true)
  ResultTable.resultString = Tx_FSK_sent
  -- Tx_FSK_sent = nil
end

function itemCL_Comms_FSK_Received( self )
  ResultTable.resultCode = compareAandB(Rx_FSK_received,self.limitSet.lower,self.limitSet.upper,true)
  ResultTable.resultString = Rx_FSK_received
  -- Rx_FSK_received = nil
end

function itemCL_Comms_FSK( self )

  local value = math.floor(((Tx_FSK_sent - Rx_FSK_received) / Tx_FSK_sent)*100 + 0.5)
  table.insert(g_ResultLog, "Tx_FSK_sent: " .. Tx_FSK_sent)
  table.insert(g_ResultLog, "Rx_FSK_received: " .. Rx_FSK_received)
  local bResult = compareAandB(value,self.limitSet.lower,self.limitSet.upper,true)
  ResultTable.resultCode = bResult
  ResultTable.resultString = value
end

function itemCL_Comms_ASK( self )
  local value = math.floor(((Rx_ASK_sent - Tx_Good_ASK_received) / Rx_ASK_sent)*100 + 0.5)
  table.insert(g_ResultLog, "Rx_ASK_sent: " .. Rx_ASK_sent)
  table.insert(g_ResultLog, "Tx_Good_ASK_received: " .. Tx_Good_ASK_received)
  local bResult = compareAandB(value,self.limitSet.lower,self.limitSet.upper,true)
  ResultTable.resultCode = bResult
  ResultTable.resultString = value
end  



function CL_ChargingOffset(self)
  if(self.key == 1) then
    doOsCmd("hidreport -du 0xFF00,0x0036 hset 26 26 0 0 0 0")
    app.wait(200)
    doOsCmd("hidreport -du 0xFF00,0x0036 hset 01 01 00")
    app.wait(200)
    doScorpiusCmd("eload set 0\r")
    app.wait(200)
    doScorpiusCmd("set mode none\r")
    app.wait(200)
    doOsCmd("hidreport -du 0xFF00,0x0036 hset 01 01 01")
    app.wait(200)
    doOsCmd("hidreport -du 0xFF00,0x0036 hset 22 22 1 3 B3 0 0 0")
    app.wait(200)
    doOsCmd("hidreport -du 0xFF00,0x0036 hset 24 24 40 06")
    app.wait(200)
    doScorpiusCmd("set mode rx\r")

    app.wait(200)
    doScorpiusCmd("eload set 8\r")
    app.wait(200)
    
    
    doScorpiusCmd("ikt signal 0\r")
    app.wait(500)

   
    doScorpiusCmd("ikt startLogging\r")
    -- doDiagsCmd("smokey ScorpiusHid --run --test \"Set\" --args \"ReportID=0x20, ReportPayload={}\"\n")
    -- doDiagsCmd("smokey ScorpiusHid --run --test \"Set\" --args \"ReportID=0x26, ReportPayload={1; 0; 0; 0}\"\n")  
    doOsCmd("hidreport -du 0xFF00,0x0036 hset 20 20")
    doOsCmd("hidreport -du 0xFF00,0x0036 hset 26 26 1 0 0 0")
        
    app.wait(6000)
    doScorpiusCmd("ikt setVrec 13.4\r")
    app.wait(1000)
    doScorpiusCmd("eload set 25\r")
    app.wait(1000)
    doScorpiusCmd("eload set 50\r")
    app.wait(1000)
    doScorpiusCmd("eload set 75\r")
    app.wait(1000)
    doScorpiusCmd("eload set 100\r")
    app.wait(1000)
    doScorpiusCmd("eload set 125\r")
    app.wait(1000)
    doScorpiusCmd("eload set 150\r")
    app.wait(1000)
    doScorpiusCmd("eload set 175\r")
    app.wait(1000)
    doScorpiusCmd("eload set 200\r")
    app.wait(1000)
     doScorpiusCmd("eload set 225\r")
    app.wait(1000)
    _,CL_Irecttest = doScorpiusCmd("eload adc\r")
    _,CL_Vrecttest = doScorpiusCmd("ikt adc\r")
    CL_Irect10C = string.match(CL_Irecttest or "","Current = (.-) mA")
    CL_Vrect10C = string.match(CL_Vrecttest or "","Vrect = (.-) V")
    CL_Iboost10C = itemIboostValueShow()
    CL_Vboost10C = itemVboostValueShow()
    CL_Phase10C = itemBridgePhaseValue()
    CL_Rx_Loading10C = (CL_Irect10C*CL_Vrect10C)
    CL_FOD10C = (CL_Irect10C*CL_Vrect10C)/(CL_Iboost10C*CL_Vboost10C)
    CL_Vctx10C = itemVctxValueShow()
    
    CL_Table = {CL_Irect10C/1000,CL_Vrect10C,CL_Iboost10C,CL_Vboost10C,CL_Phase10C,CL_Rx_Loading10C/1000,CL_FOD10C/1000, CL_Vctx10C}
    
    doOsCmd("hidreport -du 0xFF00,0x0036 hset 26 26 0 0 0 0")
    app.wait(200)
    doScorpiusCmd("eload set 0\r")
    
      local bResult = compareAandB(tonumber(CL_Table[self.key]),self.limitSet.lower,self.limitSet.upper,true)
      ResultTable.resultCode = bResult
      ResultTable.resultString = CL_Table[self.key] or "No Data"
  else
    
     local bResult = compareAandB(tonumber(CL_Table[self.key]),self.limitSet.lower,self.limitSet.upper,true)
      ResultTable.resultCode = bResult
      ResultTable.resultString = CL_Table[self.key] or "No Data"
  end

end 

function itemFixtureOffsetRight2back(self)
  doOsCmd("hidreport -du 0xFF00,0x0036 hset 26 26 0 0 0 0")
  doOsCmd("hidreport -du 0xFF00,0x0036 hset 01 01 00")
  
  -- doOsCmd("reboot","foreign host.")
  -- doDiagsCmd("reboot\n", nil, 1)
  message.close(msgTelnet)
  msgTelnet = nil;
  
  doScorpiusCmd("eload set 0\r")
  doScorpiusCmd("set mode none\r")
  -- doFixtureCmd("scorpiusoff\n")
  -- doFixtureCmd("cableoff\n")
  -- doFixtureCmd("lockoff\n")
  -- local bResult = string.find(rtRecv or "","OK") and true or false
  ResultTable.resultCode = true
end


function Low_Power_TX_Ping_Vctx100(self)
  doOsCmd("hidreport -du 0xFF00,0x0036 hset 78 78 38 0 0 0")
  app.wait(2000)
  local _, recv = doOsCmd("hidreport -du 0xFF00,0x0036 get 0x79")
  local bytes, bResult, fail_info = get_hid_bytes(recv, 6)
   if #bytes ~= 6 then 
    ResultTable.resultCode = bResult
    ResultTable.resultString = fail_info
    return
  end  
  local vctx = "0x" .. bytes[6] .. bytes[5]
  table.insert(g_ResultLog, "Catch: " .. vctx)
ResultTable.resultCode = bResult and compareAandB(tonumber(vctx) / 100,self.limitSet.lower,self.limitSet.upper,true)  ResultTable.resultString = tonumber(vctx)/100 or fail_info
end  




--function EnterOSMode_old(self)
--  doDiagsCmd("nvram --set boot-command fsboot\n")
--  -- doOsCmd("nvram auto-boot=\"true\"\n","root#")
--  doDiagsCmd("nvram --save\n")
----  doDiagsCmd("res\n", "login: ", 20)
--  iPadSerial:send("res\n", 5)
--  app.wait(10000)
--  local recOpenTel, i = nil, 0
--  repeat
--   app.wait(2000)
--    msgTelnet = message.open("telnet localhost 10023")
--    table.insert(g_ResultLog,"telnet localhost 10023")
--    local rtRecv, _ = message.recv(msgTelnet, {"login: "}, 5,0)
--    recOpenTel = string.match(rtRecv or "", "login")
--    table.insert(g_ResultLog,recOpenTel)
--    i = i + 1
--  until(recOpenTel or i >= 16)  

--  local _,rtRecv = doOsCmd("root","Password:")
--  _, rtRecv = doOsCmd("alpine","root#")
--  local bResult = string.match(rtRecv or " ",self.set[1]) and true or false
--  local logResult = bResult and "Pass" or "No data"
--  ResultTable.resultCode = bResult
--  ResultTable.resultString = logResult
--end


function itemCPUVirusInit(self)
  local _,rtRecv = doOsCmd_0("thermalScreenOneDutyCycle -l 4096 -n 30000 -i 10 -c 0 -f &","the parameters.",3)
  ComTable["killCpuValue"]  = string.match(rtRecv or "","%[%d+%]%s+(%d+)%s+")
  local bResult = string.match(rtRecv or " ","root#") and true or false
  ResultTable.resultCode = bResult
end


function itemGPUVirusInit(self)
  app.wait(500)
  local _,rtRecv = doOsCmd_0("/usr/local/bin/ShaderProfiler -forceDuration 120 -config /usr/local/share/ShaderProfiler/H8PowerVirus.json &","seconds",3)
  ComTable["killGpuValue"]  = string.match(rtRecv or "","%[%d+%]%s+(%d+)%s+")
  local bResult = rtRecv and true or false
  ResultTable.resultCode = bResult
end


function itemBacklightVirusinit(self)
  doOsCmd_0("defaults write com.apple.SwitchBoard ignoreDisplayTimeout 1")
  local _,rtRecv = doOsCmd_0("setbright")
  ComTable["backlight"] = string.match(rtRecv or "","Current:%s+(.-)%s%[")
  app.wait(500)
  _,rtRecv = doOsCmd_0("setbright 1")
  local bResult = string.match(rtRecv or " ","root#") and true or false
  ResultTable.resultCode = bResult
end


function itemDisplayVirusinit(self)
  app.wait(1000)
  local _,rtRecv = doOsCmd_0("clcdControl --fixed_rr=2; tconctl -w 8 0x5b 0; tconctl -w 8 0x80 0x0f; tconctl -O 1 0x2a 0x80")
  local bResult = rtRecv and true or false
  ResultTable.resultCode = bResult
end


-- function itemNandVirusInit(self)
--   for i=1,30 do
--     local rtSend3 = iPadSerial:send("\n", 5) 
--     print("virus login try======", i)
--     rtRecv, rtOK = iPadSerial:recv("login: ",3)
--     local rtSend4 = iPadSerial:send("root\n", 5) 
--     rtRecv, rtOK = iPadSerial:recv({"Password:"},3)
--     local rtSend5 = iPadSerial:send("alpine\n", 5) 
--     rtRecv, rtOK = iPadSerial:recv({"root#"},3)
--     if rtOK >= 0 then
--       print("login OK!--s---")
--       break;
--     end
--   end

--   local cmd = "for ((i=0 ; i<500 ; i++ )); do benchmark write junk; sleep 1; benchmark read junk; sleep 1; echo $i+1; done"
--   local rtSend = nil
--   local bResult = false
--   local send = iPadSerial:send(cmd .. "\n", 5) 
--   table.insert(g_ResultLog, "[sendcommand]: " .. cmd)
--   ResultTable.resultCode = send >= 0 and true or false
-- end

function itemNandVirusInit(self)
    doOsCmd_0("for ((i=0 ; i<200 ; i++ )); do nand_benchmark write junk; sleep 1; nand_benchmark read junk; sleep 1; echo $i+1; done", nil, 1)
    ResultTable.resultCode = true
end


function reBootUnit()
  doOsCmd("reboot","foreign host.")
  message.close(msgTelnet)
  msgTelnet = nil;
--  local rtRecv = iPadSerial:recv("login: ",30)
--  print(rtRecv)
  app.wait(10000)
  for i=1,20 do
    app.wait(2000)
    msgTelnet = message.open("telnet localhost 10023")
    table.insert(g_ResultLog,"telnet localhost 10023")
    recOpenTel,rtCode = message.recv(msgTelnet, {"login: "}, 3, 0)
    print("Kevin testaqaaa")
    print("Henry: what is the hell~~~~~~~", i)
    print(recOpenTel)
    print(rtCode) 
    if rtCode>0 then
      break
    end  
  end  
  print("Password---------")
  _,rtRecv = doOsCmd("root","Password:")
    print("alpine---------")
  _,rtRecv = doOsCmd("alpine","root#")
      print("LOGIN SUCCESS---------")
  if string.match(rtRecv or "","root#") then
    return true
  else 
    return false
  end  
end  

function reboot_to_OS(self)
  doFixtureCmd("scorpiusoff\n")
  ResultTable.resultCode = reBootUnit()
end  


-- function itemCameraVirusInit(self)

--   reBootUnit()
  
--   print("rm camISPseq.tx=======")
--   doOsCmd("rm camISPseq.txt","root#",3)
--   print("rm camISPseq.tx over=======")

--   cameraMsg = message.open("sh")
--     print("sh=======")

--   local cameraRecv = message.recv(cameraMsg,"sh",2,0)
--       print("sh over=======")

--   message.send(cameraMsg,"rsync -av /Users/gdlocal/camISPseq.txt rsync://root@localhost:10873/root/var/root/\n",3,0)
--       print("rsync -av /Users/gdlocal/camISPseq.txt rsync://root@localhost:10873/root/var/root/=======")

--   cameraRecv = message.recv(cameraMsg,"Password",2,0)
--   print("rsync over=======", cameraRecv)
--   message.send(cameraMsg,"alpine\n",3,0)
--   cameraRecv = message.recv(cameraMsg,"speedup is",2,0)
--   print("rsync aaaaa=======", cameraRecv)
--   message.close(cameraMsg)
--   app.wait(1000)
--   local cmd = "for ((i=0;i<500;i++)); do h10isp -s camISPseq.txt;echo \"loop:\" $1;done"
--   table.insert(g_ResultLog, cmd)
--   local bResult = true
--   for i=1,30 do
--     local rtSend3 = iPadSerial:send("\n", 5) 
--     rtRecv, rtOK = iPadSerial:recv("login: ",3)

--     local rtSend4 = iPadSerial:send("root\n", 5) 
--     rtRecv, rtOK = iPadSerial:recv({"Password:"},3)

--     local rtSend5 = iPadSerial:send("alpine\n", 5) 
--     rtRecv, rtOK = iPadSerial:recv({"root#"},3)

--     if rtOK >= 0 then
--       print("login OK!====")
--       break;
--     end
--   end

--   app.wait(3000)
--   -- local bResult = false
--   -- for i = 1, math.ceil(string.len(cmd)/16) do
--   --   app.wait(500)
--   --   local cmdSet16 = string.sub(cmd, (i-1) * 16 + 1, 16 * i)
--   --   local rtSend =iPadSerial:send(cmdSet16 .. "\n", 25) --sendOsCmd(cmdSet16 .. "\n",5)
--   --   iPadSerial:recv("root#", 1)
--   --   bResult = true
--   -- end

--   iPadSerial:send(cmd .. "\n", 5)
--   app.wait(3000)
--   doOsCmd("","root#")
--   doOsCmd("","root#")
--   doOsCmd("","root#")
--   ResultTable.resultCode = bResult
-- end

function itemCameraVirusInit(self)
  doOsCmd_0("rm camISPseq.txt")
  cameraMsg = message.open("sh")
  assert(({message.recv(cameraMsg,{"sh"})})[2] >= 0, "[message] Open sh fail")
  local _, recv, status = doOsCmd_0("rsync -av /Users/gdlocal/camISPseq.txt rsync://root@localhost:10873/root/var/root/", "Password", 10, cameraMsg)
  assert(status, recv)
  _, recv, status = doOsCmd_0("alpine", "speedup is", 10, cameraMsg)
  assert(status, recv)
  message.close(cameraMsg)
  doOsCmd_0("for ((i=0;i<200;i++)); do h10isp -s camISPseq.txt;echo \"loop:\" $1;done", nil, 1)
  ResultTable.resultCode = true
end  


function itemResetScorpius(self)
  doOsCmd("spuctl --writeregraw i2c 0 1 0 0x55 0x0f 0 0x00") 
  doOsCmd("spuctl --writeregraw i2c 0 1 0 0x55 0x0b 0 0x00 0x5A")
  local _,rtRecv = doOsCmd("spuctl --writeregraw i2c 0 1 0 0x55 0x03 0 0x07 0x08")
  local bResult = rtRecv and true or false
  ResultTable.resultCode = bResult
end



function itemCPUVirusShutDown(self)
  local cmd = "kill -9 " .. ComTable["killCpuValue"]
  doOsCmd(cmd)
  ComTable["killCpuValue"] = nil
  ResultTable.resultCode = true
end


function itemGPUVirusShutDown(self)
  local cmd = "kill -9 " .. ComTable["killGpuValue"]
  doOsCmd(cmd)
  ComTable["killGpuValue"] = nil
  ResultTable.resultCode = true
end


function itemBacklightVirusShutDown(self)
  if not ComTable["backlight"] then
    ResultTable.resultCode = false
    ResultTable.resultCode = "Backlight init fail"
    return
  end
  local cmd = "setbright "  .. ComTable["backlight"]
  local _,rtRecv = doOsCmd(cmd)
  ComTable["killGpuValue"] = nil
  local bResult = string.match(rtRecv or " ","root#") and true or false
  ResultTable.resultCode = bResult
end


function itemDisplayVirusShutDown(self)
  doOsCmd("powerswitch lcd off")
  local _,rtRecv = doOsCmd("powerswitch lcd on")
  local bResult = string.match(rtRecv or " ","root#") and true or false
  ResultTable.resultCode = bResult
  -- doOsCmd_0("reboot","foreign host.")
end

function itemCPUVirus1Init( self )
  doOsCmd_0("smcif -w CHI1 0") -- disable current for CPU virus
  -- local send, recv, status =  doOsCmd_0("/usr/local/bin/thermalVortexSyntheticDutyCycle -l 4096 -n 180 -i 50 -c 0 -f &", "parameters. ")
  local send, recv, status =  doOsCmd_0("thermalVortexSyntheticDutyCycle -l 4096 -n 30000 -i 10 -c 0 -f &", "parameters. ")
  ComTable["killCpuValue"]  = string.match(recv or "","%[%d+%]%s+(%d+)%s+")
  ResultTable.resultCode = status
end

function itemCPUVirus1ShutDown( self )
  local send, recv, status = doOsCmd("/usr/bin/killall thermalVortexSyntheticDutyCycle")
  ResultTable.resultCode = status
end







function Rx_getVrect_Irect_Power()
  local _, recv = doScorpiusCmd("ikt adc\r")
  local Irect = string.match(recv or "", "Current = (.-) A")
  local Vrect = string.match(recv or "", "Filtered Vrect = (.-) V")
  local Power = string.match(recv or "", "Power = (.-) mW")
  Irect = tonumber(Irect)
  Vrect = tonumber(Vrect)
  Power = tonumber(Power) / 1000
  print("---Get Vrect", Vrect, Irect, Power)
  return Vrect,Irect,Power
end

function Tx_setPhase( Phase )
  print(string.format("hidreport -du 0xFF00,0x0036 hset 22 22 1 3 0x%02X 0 0 0", Phase))
  doOsCmd(string.format("hidreport -du 0xFF00,0x0036 hset 22 22 1 3 0x%02X 0 0 0", Phase))
end

function Tx_setDAC( DAC )
  print(string.format("hidreport -du 0xFF00,0x0036 hset 24 24 %X %X", DAC & 0x00FF, DAC >> 8))
  doOsCmd(string.format("hidreport -du 0xFF00,0x0036 hset 24 24 %X %X", DAC & 0x00FF, DAC >> 8))
end


function adjustPhase(current_vrect, target_vrect_range, step)
  -- Current Phase = ComTable["Phase"]
  local Phase_range = {0, 180}
  local Phase_step = step or 1
  local max_repeat = 200
  local current_repeat = 0
  local currentVrect = current_vrect
  if currentVrect < target_vrect_range[1] then
    while (current_repeat < max_repeat) and (ComTable["Phase"] < Phase_range[2]) and (currentVrect < target_vrect_range[1]) do
      if ComTable["Phase"] + Phase_step > Phase_range[2] then 
        ComTable["Phase"] = Phase_range[2]
      else
        ComTable["Phase"] = ComTable["Phase"] + Phase_step
      end
      print("----current Phase", ComTable["Phase"], current_repeat)
      Tx_setPhase( ComTable["Phase"] )
      currentVrect = Rx_eload_getVrect_Irect_Power()
      current_repeat = current_repeat + 1
    end 
  elseif currentVrect > target_vrect_range[2] then
    while (current_repeat < max_repeat) and (ComTable["Phase"] > Phase_range[1]) and (currentVrect > target_vrect_range[2]) do
      if ComTable["Phase"] - Phase_step < Phase_range[1] then 
        ComTable["Phase"] = Phase_range[1]
      else
        ComTable["Phase"] = ComTable["Phase"] - Phase_step
      end
      print("----current Phase", ComTable["Phase"], current_repeat)
      Tx_setPhase( ComTable["Phase"] )
      currentVrect = Rx_eload_getVrect_Irect_Power()
      current_repeat = current_repeat + 1
    end 
  end
  return currentVrect
end



function adjustDAC(current_vrect, target_vrect_range, step)
  -- Current DAC = ComTable["DAC"]
  local max_DAC = ComTable["calibrated_max_DAC"] or ComTable["default_max_DAC"]
  local min_DAC = ComTable["calibrated_min_DAC"] or ComTable["default_min_DAC"]

  local DAC_range = {min_DAC, max_DAC}
  local DAC_step = step or 5
  local max_repeat = 300
  local current_repeat = 0
  local currentVrect = current_vrect
  if currentVrect < target_vrect_range[1] then
    while (current_repeat < max_repeat) and (ComTable["DAC"] > DAC_range[1]) and (currentVrect < target_vrect_range[1]) do
      if ComTable["DAC"] - DAC_step < DAC_range[1] then 
        ComTable["DAC"] = DAC_range[1]
      else
        ComTable["DAC"] = ComTable["DAC"] - DAC_step
      end
      print("----current DAC", ComTable["DAC"], current_repeat)
      Tx_setDAC( ComTable["DAC"] )
      currentVrect = Rx_eload_getVrect_Irect_Power()
      current_repeat = current_repeat + 1
    end 
  elseif currentVrect > target_vrect_range[2] then
    while (current_repeat < max_repeat) and (ComTable["DAC"] < DAC_range[2]) and (currentVrect > target_vrect_range[2]) do
      if ComTable["DAC"] + DAC_step > DAC_range[2] then 
        ComTable["DAC"] = DAC_range[2]
      else
        ComTable["DAC"] = ComTable["DAC"] + DAC_step
      end
      print("----current DAC", ComTable["DAC"], current_repeat)      
      Tx_setDAC( ComTable["DAC"] )
      currentVrect = Rx_eload_getVrect_Irect_Power()
      current_repeat = current_repeat + 1
    end
  end
  return currentVrect
end  

function loopTest(target_vrect, Phase_step, DAC_step)
  -- Current DAC = ComTable["DAC"]
  -- Current Phase = ComTable["Phase"]
  local vrect_deviation = target_vrect * 0.0075
  local target_vrect_range = {target_vrect - vrect_deviation, target_vrect + vrect_deviation}
  local current_vrect = Rx_eload_getVrect_Irect_Power()
  if current_vrect < target_vrect_range[1] then
    current_vrect = adjustPhase(current_vrect, target_vrect_range, Phase_step)
    if current_vrect < target_vrect_range[1] then
      current_vrect = adjustDAC(current_vrect, target_vrect_range, DAC_step)
    end  
  elseif current_vrect > target_vrect_range[2] then
    current_vrect = adjustDAC(current_vrect, target_vrect_range, DAC_step)
    if current_vrect > target_vrect_range[2] then
      current_vrect = adjustPhase(current_vrect, target_vrect_range, Phase_step)
    end
  end 
  return current_vrect
end



-- Each ASK packet contains 8 bytes which are broken down as follows:
-- Byte 1: Packet Number
-- Byte 2: Error state (bit 7-4); preamble number (bit 3-0)
-- Breakdown of error states as follows: 0000 = ASK_OK
-- 0001 = ASK_INVALID_START_BIT 0010 = ASK_INVALID_STOP_BIT 0011 = ASK_PARITY_ERROR 0100 = ASK_INVALID_BIT
-- 0101 = ASK_CHECKSUM_MISMATCH Byte 3 - 4: Packet Interval Time
-- Byte 5 - 8: Header, 2 Data, 1 Checksum
function ASKtest( self )
--  set_hid(0x0A, {0x08, 0, 0, 0}) -- Tell Tx to enter Static Mode
--  set_hid(0x01, {0x01}) -- Set Tx to DebugMode1
  set_hid(0x1F, {0x00, 0x0A, 0x02}) --Tell Tx to capture fixed number of ASK packets and what the timeout period should be  i.e. 10 packets, 2 seconds
  doScorpiusCmd("ikt send 0a3355\r")
  app.wait(3000)
  set_hid(0x21, {0, 0, 0x80, 0})  -- Read back data that was captured from the Tx. Each packet is 8 bytes. See Note further below for breakdown of each packet.
  local _, recv = get_hid(0x21)
  local bytes_0x80 = get_hid_bytes(recv, 0x80) -- Command to read first 128 bytes
  set_hid(0x21, {0x80, 0, 0x48, 0})
  local _, recv1 = get_hid(0x21)
  local bytes_0x48 = get_hid_bytes(recv1, 0x48) -- Command to read remaining 72 bytes
  local bytes = clone(bytes_0x80)
  for i,v in ipairs(bytes_0x48) do table.insert(bytes, v) end
  if # bytes ~= 200 then
    ResultTable.resultCode = false
    ResultTable.resultString = "Whole bytes count is not 200"
    return
  end  
  -- local bytes_80 = table.pack(table.unpack(bytes, 1, 80))

  local count_of_packets = 10
  local expected_preamble_bits = 11

  ComTable["ASK_Min_Preamble_Bits"] = 999999
  ComTable["ASK_Below_Expected_Preamble_Bits"] = 0
  ComTable["ASK_Error_State_Invalid_Start_Bit"] = 0
  ComTable["ASK_Error_State_Invalid_Stop_Bit"] = 0
  ComTable["ASK_Error_State_Parity_Error"] = 0
  ComTable["ASK_Error_State_Invalid_Bit"] = 0
  ComTable["ASK_Error_State_Checksum_Mismatch"] = 0
  ComTable["ASK_Min_Packet_Header"] = 999999
  ComTable["ASK_Max_Packet_Header"] = 0
  ComTable["ASK_Min_Packet_Data"] = 999999
  ComTable["ASK_Max_Packet_Data"] = 0
  ComTable["ASK_Min_Packet_Checksum"] = 999999
  ComTable["ASK_Max_Packet_Checksum"] = 0
  ComTable["ASK_Min_Packet_Interval"] = 999999
  ComTable["ASK_Max_Packet_Interval"] = 0
  ComTable["ASK_Number_of_good_packets"] = 0

  for i=0, count_of_packets-1 do
    local j = i*8
    local packetArray = {bytes[j+1], bytes[j+2], bytes[j+3], bytes[j+4], bytes[j+5], bytes[j+6], bytes[j+7], bytes[j+8]}
    table.insert(g_ResultLog, "-----Current packet: " .. table.concat(packetArray, " "))
    local packet_number = tonumber("0x" .. packetArray[1])
    local preamble_number = tonumber("0x" .. packetArray[2]) & 0x0F
    local Error_State = tonumber("0x" .. packetArray[2]) >> 4
    local Packet_Interval_Time = tonumber("0x" .. packetArray[3] .. packetArray[4])
    local Header = tonumber("0x" .. packetArray[5])
    local Data = tonumber("0x" .. packetArray[7] .. packetArray[6])
    local Checksum = tonumber("0x" .. packetArray[8])
  
    if (Error_State == 0) and (Header==32) and (Data == 21811) and (Checksum == 70) then
      ComTable["ASK_Number_of_good_packets"] = ComTable["ASK_Number_of_good_packets"] + 1
    end  
  
    if (ComTable["ASK_Min_Preamble_Bits"] > preamble_number) then
      ComTable["ASK_Min_Preamble_Bits"] = preamble_number
    end  
  
    if (preamble_number < expected_preamble_bits) then
      ComTable["ASK_Below_Expected_Preamble_Bits"] = ComTable["ASK_Below_Expected_Preamble_Bits"] + 1
    end   

    if (Error_State == 1) then
      ComTable["ASK_Error_State_Invalid_Start_Bit"] = ComTable["ASK_Error_State_Invalid_Start_Bit"] + 1
    elseif (Error_State == 2) then
      ComTable["ASK_Error_State_Invalid_Stop_Bit"] = ComTable["ASK_Error_State_Invalid_Stop_Bit"] + 1
    elseif (Error_State == 3) then  
      ComTable["ASK_Error_State_Parity_Error"] = ComTable["ASK_Error_State_Parity_Error"] + 1
    elseif (Error_State == 4) then 
      ComTable["ASK_Error_State_Invalid_Bit"] = ComTable["ASK_Error_State_Invalid_Bit"] + 1
    elseif (Error_State == 5) then 
      ComTable["ASK_Error_State_Checksum_Mismatch"] = ComTable["ASK_Error_State_Checksum_Mismatch"] + 1
    end
    
    if (packet_number > 1) and (ComTable["ASK_Max_Packet_Interval"] < Packet_Interval_Time) then
      ComTable["ASK_Max_Packet_Interval"] = Packet_Interval_Time
    end 
  
    if (packet_number > 1) and (ComTable["ASK_Min_Packet_Interval"] > Packet_Interval_Time) then
      ComTable["ASK_Min_Packet_Interval"] = Packet_Interval_Time
    end     

    if (ComTable["ASK_Max_Packet_Header"] < Header) then
      ComTable["ASK_Max_Packet_Header"] = Header
    end 
  
    if (ComTable["ASK_Min_Packet_Header"] > Header) then
      ComTable["ASK_Min_Packet_Header"] = Header
    end 

    if (ComTable["ASK_Max_Packet_Data"] < Data) then
      ComTable["ASK_Max_Packet_Data"] = Data
    end 
  
    if (ComTable["ASK_Min_Packet_Data"] > Data) then
      ComTable["ASK_Min_Packet_Data"] = Data
    end 
  
    if (ComTable["ASK_Max_Packet_Checksum"] < Checksum) then
      ComTable["ASK_Max_Packet_Checksum"] = Checksum
    end 

    if (ComTable["ASK_Min_Packet_Checksum"] > Checksum) then
      ComTable["ASK_Min_Packet_Checksum"] = Checksum
    end     
  end  
  ResultTable.resultCode = true
end

function getValFromComTable( self )
  local key = self.key
  if ComTable[key] == nil then
    ResultTable.resultCode = false
    ResultTable.resultString = "No Data"
    return
  end    
  ResultTable.resultCode = compareAandB(ComTable[key],self.limitSet.lower,self.limitSet.upper,true)
  ResultTable.resultString = ComTable[key]
end


function FSKtest( self )
--  set_hid(0x0A, {0x08, 0, 0, 0}) -- Tell Tx to enter Static Mode
--  set_hid(0x01, {0x01}) -- Set Tx to DebugMode1
  doScorpiusCmd("ikt clearBuf\r")
  set_hid(0x25, {0x64, 0x00, 0x0A, 0x00, 0x00, 0x2E, 0x55, 0xAA})  -- Tell Tx to send 10 FSK packets with fixed data.
  app.wait(2000)  --Allow 2 seconds after sending above command before issuing Rx read commands below.
  local _, recv = doScorpiusCmd("ikt readFSK 10\r")
  local bytes = {}
  for v in string.gmatch(recv or "", "%cPackets%s*:%s*(%w+)") do
    if string.len(v) ~= 16 then
      table.insert(g_ResultLog, "------Error: Wrong length packect: " .. v)
    end
    if string.len(v) == 16 then
      for m in string.gmatch(v, "..") do
        table.insert(bytes, m)
      end
    end
  end  
  if # bytes ~= 80 then
    ResultTable.resultCode = false
    ResultTable.resultString = "Whole bytes count is not 80"
    return
  end
  -- local bytes_80 = table.pack(table.unpack(bytes, 1, 80))

  local count_of_packets = 10
  local expected_preamble_bits = 11

  ComTable["FSK_Min_Preamble_Bits"] = 999999
  ComTable["FSK_Below_Expected_Preamble_Bits"] = 0
  ComTable["FSK_Error_State_Invalid_Start_Bit"] = 0
  ComTable["FSK_Error_State_Invalid_Stop_Bit"] = 0
  ComTable["FSK_Error_State_Parity_Error"] = 0
  ComTable["FSK_Error_State_Invalid_Bit"] = 0
  ComTable["FSK_Error_State_Checksum_Mismatch"] = 0
  ComTable["FSK_Error_State_Invalid_Preamble"] = 0
  ComTable["FSK_Min_Packet_Header"] = 999999
  ComTable["FSK_Max_Packet_Header"] = 0
  ComTable["FSK_Min_Packet_Data"] = 999999
  ComTable["FSK_Max_Packet_Data"] = 0
  ComTable["FSK_Min_Packet_Checksum"] = 999999
  ComTable["FSK_Max_Packet_Checksum"] = 0
  ComTable["FSK_Min_Packet_Interval"] = 999999
  ComTable["FSK_Max_Packet_Interval"] = 0
  ComTable["FSK_Number_of_good_packets"] = 0

  for i=0, count_of_packets-1 do
    local j = i*8
    local packetArray = {bytes[j+1], bytes[j+2], bytes[j+3], bytes[j+4], bytes[j+5], bytes[j+6], bytes[j+7], bytes[j+8]}
    table.insert(g_ResultLog, "-----Current packet: " .. table.concat(packetArray, " "))
    local packet_number = tonumber("0x" .. packetArray[1])
    local preamble_number = tonumber("0x" .. packetArray[2]) & 0x0F
    local Error_State = tonumber("0x" .. packetArray[2])
    local Packet_Interval_Time = tonumber("0x" .. packetArray[4] .. packetArray[3])
    local Header = tonumber("0x" .. packetArray[5])
    local Data = tonumber("0x" .. packetArray[6] .. packetArray[7])
    local Checksum = tonumber("0x" .. packetArray[8])
  
    if (Error_State == 0) and (Header==46) and (Data == 21930) and (Checksum == 209) then
      ComTable["FSK_Number_of_good_packets"] = ComTable["FSK_Number_of_good_packets"] + 1
    end  
  
    -- if (ComTable["FSK_Min_Preamble_Bits"] > preamble_number) then
    --   ComTable["FSK_Min_Preamble_Bits"] = preamble_number
    -- end  
  
    -- if (preamble_number < expected_preamble_bits) then
    --   ComTable["FSK_Below_Expected_Preamble_Bits"] = ComTable["FSK_Below_Expected_Preamble_Bits"] + 1
    -- end   

    if (Error_State == 1) then
      ComTable["FSK_Error_State_Invalid_Start_Bit"] = ComTable["FSK_Error_State_Invalid_Start_Bit"] + 1
    elseif (Error_State == 2) then
      ComTable["FSK_Error_State_Invalid_Stop_Bit"] = ComTable["FSK_Error_State_Invalid_Stop_Bit"] + 1
    elseif (Error_State == 3) then  
      ComTable["FSK_Error_State_Parity_Error"] = ComTable["FSK_Error_State_Parity_Error"] + 1
    elseif (Error_State == 4) then 
      ComTable["FSK_Error_State_Invalid_Bit"] = ComTable["FSK_Error_State_Invalid_Bit"] + 1
    elseif (Error_State == 5) then 
      ComTable["FSK_Error_State_Checksum_Mismatch"] = ComTable["FSK_Error_State_Checksum_Mismatch"] + 1
    elseif (Error_State == 6) then 
      ComTable["FSK_Error_State_Invalid_Preamble"] = ComTable["FSK_Error_State_Invalid_Preamble"] + 1
    end
    
    if (packet_number > 1) and (ComTable["FSK_Max_Packet_Interval"] < Packet_Interval_Time) then
      ComTable["FSK_Max_Packet_Interval"] = Packet_Interval_Time
    end 
  
    if (packet_number > 1) and (ComTable["FSK_Min_Packet_Interval"] > Packet_Interval_Time) then
      ComTable["FSK_Min_Packet_Interval"] = Packet_Interval_Time
    end     

    if (ComTable["FSK_Max_Packet_Header"] < Header) then
      ComTable["FSK_Max_Packet_Header"] = Header
    end 
  
    if (ComTable["FSK_Min_Packet_Header"] > Header) then
      ComTable["FSK_Min_Packet_Header"] = Header
    end 

    if (ComTable["FSK_Max_Packet_Data"] < Data) then
      ComTable["FSK_Max_Packet_Data"] = Data
    end 
  
    if (ComTable["FSK_Min_Packet_Data"] > Data) then
      ComTable["FSK_Min_Packet_Data"] = Data
    end 
  
    if (ComTable["FSK_Max_Packet_Checksum"] < Checksum) then
      ComTable["FSK_Max_Packet_Checksum"] = Checksum
    end 

    if (ComTable["FSK_Min_Packet_Checksum"] > Checksum) then
      ComTable["FSK_Min_Packet_Checksum"] = Checksum
    end     
  end  
  ResultTable.resultCode = true
end  


function itemPhaseshifted3(self)

  -- set_hid(0x91, {})
  -- app.wait(200)

  set_hid(0x0A, {0x08, 0, 0, 0})
  app.wait(200)


  
  set_hid(0x26, {0, 0, 0, 0})
  app.wait(200)
  set_hid(0x01, {0})
  app.wait(200)
  doScorpiusCmd("eload set 0\r")
  app.wait(200)
  doScorpiusCmd("set mode none\r")
  app.wait(200)
  set_hid(0x01, {1})
  app.wait(200)

--  set_hid(0x78, {41, 0, 0, 0})
--  local _, recv = get_hid(0x79)
--  local bytes = get_hid_bytes(recv, 12)

-- ComTable["calibrated_max_DAC"] = nil
-- ComTable["calibrated_min_DAC"] = nil
-- if #bytes == 12 then
--   ComTable["calibrated_max_DAC"] = tonumber("0x" .. bytes[10] .. bytes[9])  
--   ComTable["calibrated_min_DAC"] = tonumber("0x" .. bytes[6] .. bytes[5])  
-- end

 ComTable["DAC"] = ComTable["default_max_DAC"]   --Set initial DAC for Power Transfer test
 ComTable["Phase"] = 125    --Set initial Phase for Power Transfer test

  Tx_setDAC(ComTable["DAC"])
  app.wait(200)
  Tx_setPhase(ComTable["Phase"])
  app.wait(200)
  doScorpiusCmd("set mode rx\r")
  app.wait(200)
  doScorpiusCmd("eload set 40\r")
  app.wait(200)

  doScorpiusCmd("ikt write 0xF0000B80 0xAE010209\r")
  doScorpiusCmd("ikt write 0xF0000B80 0xAD050001\r")
  
  local finalResult = loopTest(self.target_vrect, 10, 20)
  finalResult = loopTest(self.target_vrect, 1, 5)
  local bResult = compareAandB(tonumber( finalResult),self.limitSet.lower,self.limitSet.upper,true)
  finalResult=finalResult
  ResultTable.resultCode = bResult
  ResultTable.resultString =tostring(finalResult)
end

function itemVrect_135mA(self)
  ComTable["Irect_Fix"] = nil
  ComTable["Vrect_Fix"] = nil
  ComTable["Rx_Power"] = nil

  set_hid(0x0A, {0x08, 0, 0, 0})
  app.wait(200)
  set_hid(0x01, {1})
  app.wait(200)

  loopTest(14, 10, 20)
  for i,v in ipairs(self.eloads) do
    local cmd = "eload set " .. tostring(v) .. "\r"
    app.wait(200)
    doScorpiusCmd(cmd)
    loopTest(self.target_vrect, 10, 20)
  end
  loopTest(self.target_vrect, 1, 5)
  ComTable["Irect_Fix"], ComTable["Vrect_Fix"], ComTable["Rx_Power"] = Rx_eload_getIrect_Vrect_Power()
  local bResult = compareAandB(ComTable["Irect_Fix"],self.limitSet.lower,self.limitSet.upper,true) 
  ResultTable.resultCode = bResult
  ResultTable.resultString = ComTable["Irect_Fix"] or "No Data"
end

function itemVrect_20mA(self)
  ComTable["Irect_Fix"] = nil
  ComTable["Vrect_Fix"] = nil
  ComTable["Rx_Power"] = nil

  set_hid(0x0A, {0x08, 0, 0, 0})
  app.wait(200)
  set_hid(0x01, {1})
  app.wait(200)

  loopTest(self.target_vrect, 10, 20)
  loopTest(self.target_vrect, 1, 5)

  ComTable["Irect_Fix"], ComTable["Vrect_Fix"], ComTable["Rx_Power"] = Rx_eload_getIrect_Vrect_Power()
  local bResult = compareAandB(ComTable["Irect_Fix"],self.limitSet.lower,self.limitSet.upper,true) 
  ResultTable.resultCode = bResult
  ResultTable.resultString = ComTable["Irect_Fix"]
end

function itemGetVrect(self)
  local bResult = compareAandB(ComTable["Vrect_Fix"],self.limitSet.lower,self.limitSet.upper,true) 
  ResultTable.resultCode = bResult
  ResultTable.resultString = ComTable["Vrect_Fix"] or "No Data"
end

function itemGetPower(self)
  local bResult = compareAandB(ComTable["Rx_Power"],self.limitSet.lower,self.limitSet.upper,true)
  ResultTable.resultCode = bResult
  ResultTable.resultString = ComTable["Rx_Power"] or "No Data"
end


function itemISenseConverted(self)

  ComTable["VBoostRaw"]       = nil
  ComTable["VBoostConverted"] = nil
  ComTable["ISenseRaw"]       = nil
  ComTable["ISenseConverted"] = nil
  ComTable["NTC1Raw"]         = nil
  ComTable["NTC1Converted"]   = nil
  ComTable["NTC2Raw"]         = nil
  ComTable["NTC2Converted"]   = nil
  ComTable["NTC3Raw"]         = nil
  ComTable["NTC3Converted"]   = nil
  ComTable["VCtxRaw"]         = nil
  ComTable["VCtxConverted"]   = nil
  ComTable["IPeakRaw"]        = nil

  set_hid(0x33, {0x28, 0x00})
  app.wait(2000)
  local _, recv = get_hid(0x33)
  local bytes, bResult, fail_info = get_hid_bytes(recv, 72)
  if #bytes ~= 72 then 
    ResultTable.resultCode = bResult
    ResultTable.resultString = fail_info
    return
  end  

  ComTable["VBoostRaw"]       = "0x" .. bytes[2] .. bytes[1]
  ComTable["VBoostConverted"] = "0x" .. bytes[4] .. bytes[3]
  ComTable["ISenseRaw"]       = "0x" .. bytes[6] .. bytes[5]
  ComTable["ISenseConverted"] = "0x" .. bytes[8] .. bytes[7]
  ComTable["NTC1Raw"]         = "0x" .. bytes[10] .. bytes[9]
  ComTable["NTC1Converted"]   = "0x" .. bytes[12] .. bytes[11]
  ComTable["NTC2Raw"]         = "0x" .. bytes[14] .. bytes[13]
  ComTable["NTC2Converted"]   = "0x" .. bytes[16] .. bytes[15]
  ComTable["NTC3Raw"]         = "0x" .. bytes[18] .. bytes[17]
  ComTable["NTC3Converted"]   = "0x" .. bytes[20] .. bytes[19]
  ComTable["VCtxRMS"]         = "0x" .. bytes[34] .. bytes[33]
  ComTable["VCtxIpeak"]       = MakeFloat(tonumber("0x" .. bytes[21]), tonumber("0x" .. bytes[22]), tonumber("0x" .. bytes[23]), tonumber("0x" .. bytes[24]))

  table.insert(g_ResultLog, "Catch: " .. ComTable["ISenseConverted"])
  local data = tonumber(ComTable["ISenseConverted"]) / 1000.0
  bResult = compareAandB(data,self.limitSet.lower,self.limitSet.upper,true) 
  ResultTable.resultCode = bResult
  ResultTable.resultString = data or fail_info
end

function itemISenseRaw(self)
  table.insert(g_ResultLog, "Catch: " .. ComTable["ISenseRaw"])
  local data = tonumber(ComTable["ISenseRaw"]) / 1000.0
  bResult = compareAandB(data,self.limitSet.lower,self.limitSet.upper,true) 
  ResultTable.resultCode = bResult
  ResultTable.resultString = data or "No data"
end  

function itemVBoostRaw(self)
  table.insert(g_ResultLog, "Catch: " .. ComTable["VBoostRaw"])
  local data = tonumber(ComTable["VBoostRaw"]) / 1000.0
  bResult = compareAandB(data,self.limitSet.lower,self.limitSet.upper,true) 
  ResultTable.resultCode = bResult
  ResultTable.resultString = data or "No data"
end 

function itemVBoostConverted(self)
  table.insert(g_ResultLog, "Catch: " .. ComTable["VBoostConverted"])
  local data = tonumber(ComTable["VBoostConverted"]) / 1000.0
  bResult = compareAandB(data,self.limitSet.lower,self.limitSet.upper,true) 
  ResultTable.resultCode = bResult
  ResultTable.resultString = data or "No data"
end

function itemNTC1Raw(self)
  table.insert(g_ResultLog, "Catch: " .. ComTable["NTC1Raw"])
  local data = tonumber(ComTable["NTC1Raw"])
  bResult = compareAandB(data,self.limitSet.lower,self.limitSet.upper,true) 
  ResultTable.resultCode = bResult
  ResultTable.resultString = data or "No data"
end 

function itemNTC1Converted(self)
  table.insert(g_ResultLog, "Catch: " .. ComTable["NTC1Converted"])
  local data = tonumber(ComTable["NTC1Converted"])
  bResult = compareAandB(data,self.limitSet.lower,self.limitSet.upper,true) 
  ResultTable.resultCode = bResult
  ResultTable.resultString = data or "No data"
end

function itemNTC2Raw(self)
  table.insert(g_ResultLog, "Catch: " .. ComTable["NTC2Raw"])
  local data = tonumber(ComTable["NTC2Raw"])
  bResult = compareAandB(data,self.limitSet.lower,self.limitSet.upper,true) 
  ResultTable.resultCode = bResult
  ResultTable.resultString = data or "No data"
end 

function itemNTC2Converted(self)
  table.insert(g_ResultLog, "Catch: " .. ComTable["NTC2Converted"])
  local data = tonumber(ComTable["NTC2Converted"])
  bResult = compareAandB(data,self.limitSet.lower,self.limitSet.upper,true) 
  ResultTable.resultCode = bResult
  ResultTable.resultString = data or "No data"
end

function itemNTC3Raw(self)
  table.insert(g_ResultLog, "Catch: " .. ComTable["NTC3Raw"])
  local data = tonumber(ComTable["NTC3Raw"])
  bResult = compareAandB(data,self.limitSet.lower,self.limitSet.upper,true) 
  ResultTable.resultCode = bResult
  ResultTable.resultString = data or "No data"
end 

function itemNTC3Converted(self)
  table.insert(g_ResultLog, "Catch: " .. ComTable["NTC3Converted"])
  local data = tonumber(ComTable["NTC3Converted"])
  bResult = compareAandB(data,self.limitSet.lower,self.limitSet.upper,true) 
  ResultTable.resultCode = bResult
  ResultTable.resultString = data or "No data"
end

function itemVctxRMS(self)
  table.insert(g_ResultLog, "Catch: " .. ComTable["VCtxRMS"])
  local data = tonumber(ComTable["VCtxRMS"]) / 1000.0
  bResult = compareAandB(data,self.limitSet.lower,self.limitSet.upper,true) 
  ResultTable.resultCode = bResult
  ResultTable.resultString = data or "No data"
end  

function itemVCtxIpeak(self)
  table.insert(g_ResultLog, "Catch: " .. ComTable["VCtxIpeak"])
  local data = ComTable["VCtxIpeak"] / 1000
  bResult = compareAandB(data,self.limitSet.lower,self.limitSet.upper,true) 
  ResultTable.resultCode = bResult
  ResultTable.resultString = data or "No data"
end 



function itemFodfunction(self)
  table.insert(g_ResultLog, "Rx_Power: '" .. tostring(ComTable["Rx_Power"]) .. "'")
  table.insert(g_ResultLog, "ISenseConverted: '" .. tostring(ComTable["ISenseConverted"]) .. "'")
  table.insert(g_ResultLog, "VBoostConverted: '" .. tostring(ComTable["VBoostConverted"]) .. "'")
  if (ComTable["Rx_Power"] == nil) or (ComTable["ISenseConverted"] == nil) or (ComTable["VBoostConverted"] == nil) then
    ResultTable.resultString = "No Data"
    ResultTable.resultCode = false
    return 
  end

  local Rx_Power = ComTable["Rx_Power"]
  local IBoost   = tonumber(ComTable["ISenseConverted"]) / 1000
  local VBoost   = tonumber(ComTable["VBoostConverted"]) / 1000

  local resultValue = (Rx_Power / (IBoost * VBoost)) * 100
  local bResult = compareAandB(resultValue,self.limitSet.lower,self.limitSet.upper,true)
  ResultTable.resultCode = bResult
  ResultTable.resultString = tostring(resultValue)
end


-- function add_ASK_FSK_items(position, chargeRate)
--   table.insert(TestItems, {name=position .. "OL_ASK_Test@" .. chargeRate, action = ASKtest})
--   table.insert(TestItems, {name=position .. "OL_ASK_Minimum_Preamble_bits@" .. chargeRate, action = getValFromComTable, key = "ASK_Min_Preamble_Bits", limitSet = {lower = 4,upper= 11}})
--   table.insert(TestItems, {name=position .. "OL_ASK_Below_Expected_Preamble_Bits@" .. chargeRate, action = getValFromComTable, key = "ASK_Below_Expected_Preamble_Bits", limitSet = {lower = "NA",upper= "NA"}})
--   table.insert(TestItems, {name=position .. "OL_ASK_ErrorState_Invalid_Start_Bit@" .. chargeRate, action = getValFromComTable, key = "ASK_Error_State_Invalid_Start_Bit", limitSet = {lower = 0,upper= 0}})
--   table.insert(TestItems, {name=position .. "OL_ASK_ErrorState_Invalid_Stop_Bit@" .. chargeRate, action = getValFromComTable, key = "ASK_Error_State_Invalid_Stop_Bit", limitSet = {lower = 0,upper= 0}})
--   table.insert(TestItems, {name=position .. "OL_ASK_ErrorState_Parity_Error@" .. chargeRate, action = getValFromComTable, key = "ASK_Error_State_Parity_Error", limitSet = {lower = 0,upper= 0}})
--   table.insert(TestItems, {name=position .. "OL_ASK_ErrorState_Invalid_Bit@" .. chargeRate, action = getValFromComTable, key = "ASK_Error_State_Invalid_Bit", limitSet = {lower = 0,upper= 0}})
--   table.insert(TestItems, {name=position .. "OL_ASK_ErrorState_Checksum_Mismatch@" .. chargeRate, action = getValFromComTable, key = "ASK_Error_State_Checksum_Mismatch", limitSet = {lower = 0,upper= 0}})
--   table.insert(TestItems, {name=position .. "OL_ASK_Max_Packet_Header@" .. chargeRate, action = getValFromComTable, key = "ASK_Max_Packet_Header", limitSet = {lower = 32,upper= 32}})
--   table.insert(TestItems, {name=position .. "OL_ASK_Min_Packet_Header@" .. chargeRate, action = getValFromComTable, key = "ASK_Min_Packet_Header", limitSet = {lower = 32,upper= 32}})
--   table.insert(TestItems, {name=position .. "OL_ASK_Max_Packet_Data@" .. chargeRate, action = getValFromComTable, key = "ASK_Max_Packet_Data", limitSet = {lower = 21811,upper= 21811}})
--   table.insert(TestItems, {name=position .. "OL_ASK_Min_Packet_Data@" .. chargeRate, action = getValFromComTable, key = "ASK_Min_Packet_Data", limitSet = {lower = 21811,upper= 21811}})
--   table.insert(TestItems, {name=position .. "OL_ASK_Max_Packet_Checksum@" .. chargeRate, action = getValFromComTable, key = "ASK_Max_Packet_Checksum", limitSet = {lower = 70,upper= 70}})
--   table.insert(TestItems, {name=position .. "OL_ASK_Min_Packet_Checksum@" .. chargeRate, action = getValFromComTable, key = "ASK_Min_Packet_Checksum", limitSet = {lower = 70,upper= 70}})
--   table.insert(TestItems, {name=position .. "OL_ASK_Max_Packet_Interval@" .. chargeRate, action = getValFromComTable, key = "ASK_Max_Packet_Interval", limitSet = {lower = 93,upper= 103}})
--   table.insert(TestItems, {name=position .. "OL_ASK_Min_Packet_Interval@" .. chargeRate, action = getValFromComTable, key = "ASK_Min_Packet_Interval", limitSet = {lower = 93,upper= 103}})
--   table.insert(TestItems, {name=position .. "OL_ASK_Number_of_good_packets@" .. chargeRate, action = getValFromComTable, key = "ASK_Number_of_good_packets", limitSet = {lower = 10,upper= 10}})
--   -- ----FSK Start------
--   table.insert(TestItems, {name=position .. "OL_FSK_Test@" .. chargeRate, action = FSKtest})
--   table.insert(TestItems, {name=position .. "OL_FSK_ErrorState_Invalid_Start_Bit@" .. chargeRate, action = getValFromComTable, key = "FSK_Error_State_Invalid_Start_Bit", limitSet = {lower = 0,upper= 0}})
--   table.insert(TestItems, {name=position .. "OL_FSK_ErrorState_Invalid_Stop_Bit@" .. chargeRate, action = getValFromComTable, key = "FSK_Error_State_Invalid_Stop_Bit", limitSet = {lower = 0,upper= 0}})
--   table.insert(TestItems, {name=position .. "OL_FSK_ErrorState_Parity_Error@" .. chargeRate, action = getValFromComTable, key = "FSK_Error_State_Parity_Error", limitSet = {lower = 0,upper= 0}})
--   table.insert(TestItems, {name=position .. "OL_FSK_ErrorState_Invalid_Bit@" .. chargeRate, action = getValFromComTable, key = "FSK_Error_State_Invalid_Bit", limitSet = {lower = 0,upper= 0}})
--   table.insert(TestItems, {name=position .. "OL_FSK_ErrorState_Checksum_Mismatch@" .. chargeRate, action = getValFromComTable, key = "FSK_Error_State_Checksum_Mismatch", limitSet = {lower = 0,upper= 0}})
--   table.insert(TestItems, {name=position .. "OL_FSK_ErrorState_Invalid_Preamble@" .. chargeRate, action = getValFromComTable, key = "FSK_Error_State_Invalid_Preamble", limitSet = {lower = 0,upper= 0}})
--   table.insert(TestItems, {name=position .. "OL_FSK_Max_Packet_Header@" .. chargeRate, action = getValFromComTable, key = "FSK_Max_Packet_Header", limitSet = {lower = 46,upper= 46}})
--   table.insert(TestItems, {name=position .. "OL_FSK_Min_Packet_Header@" .. chargeRate, action = getValFromComTable, key = "FSK_Min_Packet_Header", limitSet = {lower = 46,upper= 46}})
--   table.insert(TestItems, {name=position .. "OL_FSK_Max_Packet_Data@" .. chargeRate, action = getValFromComTable, key = "FSK_Max_Packet_Data", limitSet = {lower = 21930,upper= 21930}})
--   table.insert(TestItems, {name=position .. "OL_FSK_Min_Packet_Data@" .. chargeRate, action = getValFromComTable, key = "FSK_Min_Packet_Data", limitSet = {lower = 21930,upper= 21930}})
--   table.insert(TestItems, {name=position .. "OL_FSK_Max_Packet_Checksum@" .. chargeRate, action = getValFromComTable, key = "FSK_Max_Packet_Checksum", limitSet = {lower = 209,upper= 209}})
--   table.insert(TestItems, {name=position .. "OL_FSK_Min_Packet_Checksum@" .. chargeRate, action = getValFromComTable, key = "FSK_Min_Packet_Checksum", limitSet = {lower = 209,upper= 209}})
--   table.insert(TestItems, {name=position .. "OL_FSK_Max_Packet_Interval@" .. chargeRate, action = getValFromComTable, key = "FSK_Max_Packet_Interval", limitSet = {lower = 90,upper= 110}})
--   table.insert(TestItems, {name=position .. "OL_FSK_Min_Packet_Interval@" .. chargeRate, action = getValFromComTable, key = "FSK_Min_Packet_Interval", limitSet = {lower = 90,upper= 110}})
--   table.insert(TestItems, {name=position .. "OL_FSK_Number_of_good_packets@" .. chargeRate, action = getValFromComTable, key = "FSK_Number_of_good_packets", limitSet = {lower = 10,upper= 10}})

-- end




function Rx_eload_getVrect_Irect_Power()
  local _, recv = doScorpiusCmd("eload adc\r")
  local Irect = string.match(recv or "", "Eload Current = (.-) mA")
  local Vrect = string.match(recv or "", "Eload Voltage = (.-) V")
  local Power = string.match(recv or "", "Eload Power = (.-) W")
  Irect = tonumber(Irect) / 1000
  Vrect = tonumber(Vrect) 
  Power = tonumber(Power) 
  return Vrect,Irect,Power
end

function Rx_eload_getIrect_Vrect_Power()
  local _, recv = doScorpiusCmd("eload adc\r")
  local Irect = string.match(recv or "", "Eload Current = (.-) mA")
  local Vrect = string.match(recv or "", "Eload Voltage = (.-) V")
  local Power = string.match(recv or "", "Eload Power = (.-) W")
  Irect = tonumber(Irect) / 1000
  Vrect = tonumber(Vrect) 
  Power = tonumber(Power) 
  return Irect,Vrect,Power
end

function clone(object)
  local lookup_table = {}
  local function _copy(object)
    if type(object) ~= "table" then
      return object
    elseif lookup_table[object] then
      return lookup_table[object]
    end
    local newObject = {}
    lookup_table[object] = newObject
    for key, value in pairs(object) do
      newObject[_copy(key)] = _copy(value)
    end
    return setmetatable(newObject, getmetatable(object))
  end
  return _copy(object)
end


function rebootDutToOS( self )
  message.close(msgTelnet)
  msgTelnet = nil
  doDiagsCmd("reboot\n", nil, 1)
  EnterOSMode(self)
end


function itemCameraBERInitialize( self )
  ComTable["BER_start_time"] = nil
  ComTable["BER_full_time"] = nil
  ComTable["BER_file_path"] = nil  
  ComTable["BER_file_name"] = nil
  local absoluteFilePath = "/private/var/logs/BurnIn/PDCA/_pdca_BitErrorTest_" .. self.filename .. ".plist"
  doOsCmd("rm " .. absoluteFilePath)
  doOsCmd("/usr/local/bin/OSDCameraTester BitErrorTestOneSensor --camera=" .. self.tag .. " --time=" .. self.time .. " --width=" .. self.width .. " --height=" .. self.height .. " --fps=" .. self.fps .. " --linkHz=fastest --pattern=5 --label=" .. self.filename .. " &")
  ComTable["BER_start_time"] = utils.timeStart()
  ComTable["BER_full_time"] = self.time
  ComTable["BER_file_path"] = absoluteFilePath
  ComTable["BER_file_name"] = "_pdca_BitErrorTest_" .. self.filename .. ".plist"
  app.wait(2000)
  ResultTable.resultCode = true
end

function itemCollectBER( self )
  local interval = utils.timeEnd(ComTable["BER_start_time"])
  local fullTime = ComTable["BER_full_time"]
  local filePath = ComTable["BER_file_path"]
  if interval < fullTime then
    local timeToWait = math.ceil((fullTime-interval)*1000)
    app.wait(timeToWait)
  end
  app.wait(10000)
  
  local path_to_write = app.getLogFile({resultString="Henry" , sn = sn}):gsub(".txt","") .. ComTable["BER_file_name"]
  -- local msgShell = message.open("sh")
  -- local a,b = message.recv(msgShell, {"$"}, 5, 0)
  -- message.send(msgShell,"rsync -av rsync://root@localhost:10873/root/var/logs/BurnIn/PDCA/" .. ComTable["BER_file_name"] .. " " .. path_to_write .. "\n",5,0)
  -- a,b = message.recv(msgShell, {"Password:"}, 5, 0)
  -- message.send(msgShell,"alpine\n",5,0)
  -- a,b = message.recv(msgShell, {"sh"}, 2, 0)
  -- message.close(msgShell)


  local _,recv = doOsCmd("cat " .. filePath)
  os.execute("touch " .. path_to_write)
  local file = io.open(path_to_write, "w")
  file:write(recv)
  file:close()
  local data = plistParse(recv)
  ComTable["BER_data"] = data["0"]["Tests"]
  ResultTable.resultCode = data["0"]["overallresult"] == "PASS" and true or false
end

function itemShowBERData( self )
  if ComTable["BER_data"] == nil then
    ResultTable.resultCode = false
    ResultTable.resultString = "No Data"
    return 
  end
  local value = nil
  for i,v in ipairs(ComTable["BER_data"]) do
    if string.find(self.name, v["subsubtestname"]) then
      value = tonumber(v["value"])
      break
    end  
  end
  ResultTable.resultCode = compareAandB(value,self.limitSet.lower,self.limitSet.upper,true)
  ResultTable.resultString = value
end

function getComTable(self)
    local key = string.gsub(self.name,"%s+%b()","")
    key = string.gsub(key,"%s+%b[]","")   
    writeLog(key)
    writeLog(tostring(ComTable[key]))
    ResultTable.resultCode = ComTable[key] and true or false
    ResultTable.resultString = ComTable[key]
end

function getCloseLoopTxData( self )
    local po = self.name:match("(.-_)")
    local cl = self.name:match("(@.-C)")
    ComTable[po.."CL_Vctx_IPeak"..cl]  = nil
    ComTable[po.."CL_Vctx_RMS"..cl]    = nil
    ComTable[po.."CL_VBoost"..cl]      = nil
    ComTable[po.."CL_IBoost"..cl]      = nil
    local _,recv = get_hid(0x31)
    local bytes,bResult,failinfo = get_hid_bytes(recv, 28)
    if bResult ~= true then
        ResultTable.resultCode = false
        ResultTable.resultString = failinfo
        return
    end 
    ComTable[po.."CL_Vctx_IPeak"..cl]  = tonumber(string.format("0x%s%s%s%s", bytes[4], bytes[3], bytes[2], bytes[1])) / 1000 
    ComTable[po.."CL_Vctx_RMS"..cl]    = tonumber(string.format("0x%s%s", bytes[6], bytes[5])) / 1000
    ComTable[po.."CL_VBoost"..cl]      = tonumber(string.format("0x%s%s", bytes[8], bytes[7])) / 1000
    ComTable[po.."CL_IBoost"..cl]      = tonumber(string.format("0x%s%s", bytes[10], bytes[9])) / 1000
    ComTable[po.."CL_Tx_Temp_Sense1"..cl]      = tonumber(string.format("0x%s%s", bytes[16], bytes[15]))
    ComTable[po.."CL_Tx_Temp_Sense2"..cl]      = tonumber(string.format("0x%s%s", bytes[18], bytes[17]))
    ComTable[po.."CL_Tx_Temp_Sense3"..cl]      = tonumber(string.format("0x%s%s", bytes[20], bytes[19]))
    ResultTable.resultCode = bResult
end

function getCloseLoopRxData( self )
    local po = self.name:match("(.-_)")
    local cl = self.name:match("(@.-C)")
    ComTable[po.."CL_Vrect_Fix"..cl] = nil
    ComTable[po.."CL_Irect_Fix"..cl] = nil
    -- ComTable[po.."CL_ICharge_Fix"..cl] = nil
    local _,recv = doScorpiusCmd("eload adc\r")
    ComTable[po.."CL_Vrect_Fix"..cl] = tonumber(string.match(recv or "", "Eload Voltage = ([%d.]+) V")) 
    ComTable[po.."CL_Irect_Fix"..cl] = tonumber(string.match(recv or "", "Eload Current = ([%d.]+) mA")) / 1000
    -- ComTable[po.."CL_ICharge_Fix"..cl] = tonumber(string.match(recv or "", "actualChargeCurrent : (%d+) mA")) / 1000    
    ResultTable.resultCode = ComTable[po.."CL_Vrect_Fix"..cl] and ComTable[po.."CL_Irect_Fix"..cl] and true or false
end

function closeLoopCalPoAndEfficiency( self )
    local po = self.name:match("(.-_)")
    local cl = self.name:match("(@.-C)")
    ComTable[po.."CL_Rx_Loading_Power"..cl] = nil
    ComTable[po.."CL_Tx_Loading_Power"..cl] = nil
    ComTable[po.."CL_FOD_efficiency"..cl] = nil

    ComTable[po.."CL_Rx_Loading_Power"..cl] = ComTable[po.."CL_Vrect_Fix"..cl] * ComTable[po.."CL_Irect_Fix"..cl]
    ComTable[po.."CL_Tx_Loading_Power"..cl] = ComTable[po.."CL_VBoost"..cl] * ComTable[po.."CL_IBoost"..cl]
    ComTable[po.."CL_FOD_efficiency"..cl] = ComTable[po.."CL_Rx_Loading_Power"..cl] / ComTable[po.."CL_Tx_Loading_Power"..cl] * 100
    ResultTable.resultCode = ComTable[po.."CL_FOD_efficiency"..cl] and true or false
end

function  writeLog( str )
    table.insert(g_ResultLog, str)
end


function setRGBWAndReboot(self)
  local _, recv = doOsCmd("diagstool bootargs -a newLcdMura=RGBW")
  doOsCmd("reboot","foreign host.")
  message.close(msgTelnet)
  msgTelnet = nil
  ResultTable.resultCode = recv and true or false
end

function itemSetReflashRate( self )
  local refreshRate = self.refreshRate
  local part = math.ceil(240 / refreshRate)
  local _, recv = doOsCmd("clcdControl --fixed_rr=" .. part)
  ResultTable.resultCode = recv and true or false
end

function setBright100( self )
  local _, recv = doOsCmd("setbright 1")
  ResultTable.resultCode = recv and true or false
end

function itemSetDisplayColor( self )
  local RGBCode = self.code
  local _, rtRecv = doOsCmd("diagstool lcdmura --rgb " .. RGBCode)
  -- local rtRecv = app.showDialog({btnTitle={"NO","YES"}, msg = self.name, nil, async=false})
  local bResult = rtRecv and true or false
  ResultTable.resultCode = bResult
end


function CheckFOS(self)
    doOsCmd("diagstool lcdmura --imagepath /AppleInternal/Diags/LCMPatterns/2388x1668/J417/FATP/FATP1.png")
    local rtRecv1 = app.showDialog({btnTitle={"NO","YES"}, msg = "Grey bluish Yes/No",nil, async=false}) == "YES"
    
    doOsCmd("diagstool lcdmura --imagepath /AppleInternal/Diags/LCMPatterns/2388x1668/J417/FATP/FATP2.png")
    local rtRecv2 = app.showDialog({btnTitle={"NO","YES"}, msg = "Grey 127 Pattern Yes/No",nil, async=false}) == "YES"
    
    doOsCmd("diagstool lcdmura --imagepath /AppleInternal/Diags/LCMPatterns/2388x1668/J417/FATP/FATP3.png")
    local rtRecv3 = app.showDialog({btnTitle={"NO","YES"}, msg = "Grey 63 Pattern Yes/No",nil, async=false}) == "YES"
    
    doOsCmd("diagstool lcdmura --imagepath /AppleInternal/Diags/LCMPatterns/2388x1668/J417/FATP/FATP4.png")
    local rtRecv4 = app.showDialog({btnTitle={"NO","YES"}, msg = "White Yes/No",nil, async=false}) == "YES"
    
    doOsCmd("diagstool lcdmura --imagepath /AppleInternal/Diags/LCMPatterns/2388x1668/J417/FATP/FATP5.png")
    local rtRecv5 = app.showDialog({btnTitle={"NO","YES"}, msg = "Magenta Yes/No",nil, async=false}) == "YES"
    
    doOsCmd("diagstool lcdmura --imagepath /AppleInternal/Diags/LCMPatterns/2388x1668/J417/FATP/FATP7.png")
    local rtRecv6 = app.showDialog({btnTitle={"NO","YES"}, msg = "Black Yes/No",nil, async=false}) == "YES"
    
    doOsCmd("diagstool lcdmura --imagepath /AppleInternal/Diags/LCMPatterns/2388x1668/J417/FATP/FATP8.png")
    local rtRecv7 = app.showDialog({btnTitle={"NO","YES"}, msg = "Red Yes/No",nil, async=false}) == "YES"
    
    doOsCmd("diagstool lcdmura --imagepath /AppleInternal/Diags/LCMPatterns/2388x1668/J417/FATP/FATP9.png")
    local rtRecv8 = app.showDialog({btnTitle={"NO","YES"}, msg = "Green (Brightness) Yes/No",nil, async=false}) == "YES"
    
    doOsCmd("diagstool lcdmura --imagepath /AppleInternal/Diags/LCMPatterns/2388x1668/J417/FATP/FATP10.png")
    local rtRecv9 = app.showDialog({btnTitle={"NO","YES"}, msg = "Blue Yes/No",nil, async=false}) == "YES"
    
    doOsCmd("diagstool lcdmura --imagepath /AppleInternal/Diags/LCMPatterns/2388x1668/J417/FATP/FATP20.png")
    local rtRecv10 = app.showDialog({btnTitle={"NO","YES"}, msg = "checkers Yes/No",nil, async=false}) == "YES"
    
    doOsCmd("diagstool lcdmura --imagepath /AppleInternal/Diags/LCMPatterns/2388x1668/J417/FATP/FATP21.png")
    local rtRecv11 = app.showDialog({btnTitle={"NO","YES"}, msg = "Grey 32 Yes/No",nil, async=false}) == "YES"
    
    doOsCmd("diagstool lcdmura --imagepath /AppleInternal/Diags/LCMPatterns/2388x1668/J417/FATP/FATP14.png")
    local rtRecv12 = app.showDialog({btnTitle={"NO","YES"}, msg = "Grey Ramp (Vertical) Yes/No",nil, async=false}) == "YES"
    
    doOsCmd("diagstool lcdmura --imagepath /AppleInternal/Diags/LCMPatterns/2388x1668/J417/FATP/FATP13.png")
    local rtRecv13 = app.showDialog({btnTitle={"NO","YES"}, msg = "Grey Ramp (Horizontal) Yes/No",nil, async=false}) == "YES"
    
    doOsCmd("diagstool lcdmura --imagepath /AppleInternal/Diags/LCMPatterns/2388x1668/J417/FATP/FATP12.png")
    local rtRecv14 = app.showDialog({btnTitle={"NO","YES"}, msg = "Color bar (Vertical RGBW) Yes/No",nil, async=false}) == "YES"
    
    doOsCmd("diagstool lcdmura --imagepath /AppleInternal/Diags/LCMPatterns/2388x1668/J417/FATP/FATP11.png")
    local rtRecv15 = app.showDialog({btnTitle={"NO","YES"}, msg = "Color bar (Horizontal RGBW) Yes/No",nil, async=false}) == "YES"
    
    doOsCmd("diagstool lcdmura --imagepath /AppleInternal/Diags/LCMPatterns/2388x1668/J417/FATP/FATP16.png")
    local rtRecv16 = app.showDialog({btnTitle={"NO","YES"}, msg = "x-talk pattern (Vertical) Yes/No",nil, async=false}) == "YES"
    
    doOsCmd("diagstool lcdmura --imagepath /AppleInternal/Diags/LCMPatterns/2388x1668/J417/FATP/FATP15.png")
    local rtRecv17 = app.showDialog({btnTitle={"NO","YES"}, msg = "x-talk pattern (Horizontal) Yes/No",nil, async=false}) == "YES"
    
    doOsCmd("diagstool lcdmura --imagepath /AppleInternal/Diags/LCMPatterns/2388x1668/J417/FATP/FATP17.png")
    local rtRecv18 = app.showDialog({btnTitle={"NO","YES"}, msg = "Black Yes/No",nil, async=false}) == "YES"
    
    doOsCmd("diagstool lcdmura --imagepath /AppleInternal/Diags/LCMPatterns/2388x1668/J417/FATP/FATP18.png")
    local rtRecv19 = app.showDialog({btnTitle={"NO","YES"}, msg = "D27 Yes/No",nil, async=false}) == "YES"
    
    doOsCmd("diagstool lcdmura --imagepath /AppleInternal/Diags/LCMPatterns/2388x1668/J417/FATP/FATP19.png")
    local rtRecv20 =app.showDialog({btnTitle={"NO","YES"}, msg = "D110 Yes/No",nil, async=false}) == "YES"
    local bResult = rtRecv1 and rtRecv2 and rtRecv3 and rtRecv4 and rtRecv5 and rtRecv6 and rtRecv7 and rtRecv8 and rtRecv9 and rtRecv10 and rtRecv11 and rtRecv12 and rtRecv13 and rtRecv14 and rtRecv15 and rtRecv16 and rtRecv17 and rtRecv18 and rtRecv19 and rtRecv20 and true or false 
    ResultTable.resultCode = bResult and true or false
end



function pingPongAfterPowerTest(self)
    Tx_FSK_sent = nil
    Tx_ASK_received = nil
    Tx_Good_ASK_received = nil
    Rx_FSK_received = nil
    Rx_ASK_sent = nil

    -- doOsCmd("clcdControl --fixed_rr=10")
    -- doOsCmd("setbright 1")
    -- doOsCmd("diagstool lcdmura --rgb 225,0,0")

    -- doScorpiusCmd("set mode none\r")
    -- doScorpiusCmd("set mode rx\r")

    doScorpiusCmd("ikt write 0xF0000B80 0xAE010209\r")
    doScorpiusCmd("ikt write 0xF0000B80 0xAD050001\r")

    doScorpiusCmd("ikt read 0xF0000B80\r")

    -- if self.name:find("0%.1C") then
    --   doScorpiusCmd("eload set 40\r")
    -- elseif self.name:find("3C") then
    --   doScorpiusCmd("eload set 113\r")
    -- elseif self.name:find("10C") then  
    --   doScorpiusCmd("eload set 224\r")
    -- end

    doScorpiusCmd("eload adc\r")
    
    -- doScorpiusCmd("ikt clearBuf\r")


    doScorpiusCmd("ikt startLogging\r")
    set_hid(0x20, {})
    set_hid(0x26, {0x01; 0x00; 0x00; 0x00})
    app.wait(2000)
    set_hid(0x26, {0x00; 0x00; 0x00; 0x00})
    
    doScorpiusCmd("ikt read 0xF0000B80\r")
    local _, recv = doScorpiusCmd("ikt numSentASK\r")
    Rx_ASK_sent = tonumber(string.match(recv or "", "Number of sent ASK packets: (%d+)"))
    table.insert(g_ResultLog, "Rx_ASK_sent: " .. Rx_ASK_sent)
    Rx_FSK_received=Rx_ASK_sent
    table.insert(g_ResultLog, "Rx_FSK_received: " .. Rx_FSK_received)
    
    -- local _,recv = doDiagsCmd("smokey ScorpiusHid --run --test \"Get\" --args \"ReportID=0x20\"\n")
    local _, recv = get_hid(0x20)
    local bytes, bool_result, fail_info = get_hid_bytes(recv)
    if not bool_result then
      ResultTable.resultCode = false
      ResultTable.resultString = fail_info
      return
    end  
    Tx_FSK_sent = tonumber("0x" .. bytes[4] .. bytes[3] .. bytes[2] .. bytes[1])
    Tx_ASK_received = tonumber("0x" .. bytes[8] .. bytes[7] .. bytes[6] .. bytes[5])
    Tx_Good_ASK_received = tonumber("0x" .. bytes[12] .. bytes[11] .. bytes[10] .. bytes[9])
    -- Rx_FSK_received = Need confirm from Rx i2c 
    -- Rx_ASK_sent = Need confirm from Rx i2c 
--  local value = math.floor(((Tx_FSK_sent - Tx_Good_ASK_received) / Tx_FSK_sent)*100+0.5)
    ResultTable.resultCode = true
end 

function itemCL_Comms_Good_ASK_Received( self )
  ResultTable.resultCode = compareAandB(Tx_Good_ASK_received,self.limitSet.lower,self.limitSet.upper,true)
  ResultTable.resultString = Tx_Good_ASK_received
end

function itemCL_Comms_PER( self )
    local value = 100 - (Tx_Good_ASK_received/Tx_FSK_sent*100)
    local bResult = compareAandB(value,self.limitSet.lower,self.limitSet.upper,true)
    ResultTable.resultCode = bResult
    ResultTable.resultString = value
end

function  add_ASK_FSK_items(position, chargeRate)
    table.insert(TestItems, {name=position .. "PingPong Test@" .. chargeRate, action =  pingPongAfterPowerTest}) 
    table.insert(TestItems, {name=position .. "PP_PER@" .. chargeRate, action =  itemCL_Comms_PER, limitSet = {lower = 0,upper= 5}}) 
    table.insert(TestItems, {name=position .. "PP_FSK_Sent@" .. chargeRate, action =  itemCL_Comms_FSK_Sent,limitSet = {lower = "NA",upper= "NA"}})
    -- table.insert(TestItems, {name=position .. "PP_FSK_Received@" .. chargeRate, action =  itemCL_Comms_FSK_Received,limitSet = {lower = "NA",upper= "NA"}}) 
    table.insert(TestItems, {name=position .. "PP_ASK_Sent@" .. chargeRate, action =  itemCL_Comms_ASK_Sent,limitSet = {lower = "NA",upper= "NA"}}) 
    table.insert(TestItems, {name=position .. "PP_ASK_Received@" .. chargeRate, action =  itemCL_Comms_ASK_Received,limitSet = {lower = "NA",upper= "NA"}}) 
    table.insert(TestItems, {name=position .. "PP_Good_ASK_Received@" .. chargeRate, action =  itemCL_Comms_Good_ASK_Received,limitSet = {lower = "NA",upper= "NA"}}) 
end


function get_rawADC_data()
  set_hid(0x13, {0, 0}) 
  local ADC_dataTable = {}
  for i=1, 7 do
    local _,recv = get_hid(0x13)
    local bytes = get_hid_bytes(recv)
    for i=7, #bytes, 2 do
      local ADC = tonumber(string.format("0x%s%s", bytes[i+1], bytes[i]))
      table.insert(ADC_dataTable, ADC)
    end  
  end  
  return ADC_dataTable
end  

function SetToRed()
  doOsCmd("diagstool lcdmura --rgb 255 0 0")
end
