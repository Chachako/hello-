print("enter script")
package.cpath = Directory.frameworks .. '/?.dylib;' .. package.cpath
package.path = Directory.config .. '/?.lua;' .. package.path
package.path = Directory.home .. '/?.lua;' .. package.path
package.path = Directory.config .. "/Functions" .. '/?.lua;' .. package.path
package.path = Directory.plugins .. '/Library/?.lua;' .. package.path
package.path = Directory.plugins .. '/iPad/Public/?.lua;' .. package.path
package.path = Directory.homePublic .. '/?.lua;' .. package.path

app = require("app")  
serial = require("serial") 
message = require("message")

pcall(require,"CheckSerialPort")
pcall(require,"EZLinkTest")
pcall(require,"PublicPortCommunication")
pcall(require,"PublicWriteCB")
pcall(require,"PublicNetWorkCB")
pcall(require,"PublicWritePDCA")
pcall(require,"PublicSFCQuery")
pcall(require,"passCode")
utils = require("utils")

require("common")
require("PlistConverter")

TestItems = {}
g_PDCAAttribute = {} 
g_PDCAParametric = {} 
ComTable  = {}
g_ResultLog = {}

g_scopriusFlag = false
-------------------------------------------system callback function-------------------------------------------------
function onEnter(args)
  print("onEnter:")
  pcall(require,"Config")
  ScriptVersion = OverlayVersion
  pcall(require,"Extern_Station")
  pcall(require,"Extern_Debug")
  for i=1, #TestItems do
    if TestItems[i].limitSet ~= nil then
      testitemName = TestItems[i].name
      TestItems[i].name = testitemName .. "  [" .. tostring(TestItems[i].limitSet.lower) .. "," .. tostring(TestItems[i].limitSet.upper) .. "]"
    end 
  end  
  return TestItems
end

function onInit(args)
  print("onInit:", args.unitIndex)
  args_unitIndex = args.unitIndex

  if tostring(args.unitIndex) == "1" then
    os.execute(Directory.tools .. "/tcprelay --portoffset 10000 telnet rsync &")
  elseif tostring(args.unitIndex) == "2" then
    os.execute(Directory.tools .. "/tcprelay --portoffset 11000 telnet rsync &")
  elseif tostring(args.unitIndex) == "3" then
    os.execute(Directory.tools .. "/tcprelay --portoffset 12000 telnet rsync &")
  elseif tostring(args.unitIndex) == "4" then
    os.execute(Directory.tools .. "/tcprelay --portoffset 13000 telnet rsync &")
  end  
  
  if iPadSerial==nil then
    iPadPath = TestUnit[args.unitIndex].iPad.path
    iPadSerial = serial.open(TestUnit[args.unitIndex].iPad.path,0)
    serial.config(iPadSerial, TestUnit[args.unitIndex].iPad.config)
--    serial.setRunTimeout(iPadSerial,30*50)
--    serial.setRecvMax(iPadSerial,1024*1024*50)
    fixtureSerial = serial.open(TestUnit[args.unitIndex].Scorpius.path,0)
    serial.config(fixtureSerial, TestUnit[args.unitIndex].Scorpius.config)
    
    mikeySerial = serial.open(TestUnit[args.unitIndex].Fixture.path,true)
    serial.config(mikeySerial, TestUnit[args.unitIndex].Fixture.config)
  end
  return {InitInfo = getDylibVersion()}
end

function startTest(args)
  g_PDCAAttribute = {} 
  g_PDCAParametric = {}
  ComTable = {}
  app.updateInitInfo();
  stopFlag = false
  exitFlag = false

  g_finalResult = true

  STOP_FAIL = false
  -- os.execute("rm -f " .. Directory.home .. "/*.csv")

  for i=1, #TestItems do
    while true do
      if STOP_FAIL and (not TestItems[i].ESCAPE_STOP_FAIL) then 
        break
      end
    ResultTable = nil
    ResultTable = {}
    g_ResultLog = nil
    g_ResultLog = {}
    local PDCAParametricTmp = nil
    PDCAParametricTmp = {}
    TestItems[i].number = i
    local startTime = utils.timeStart()
    local bRt, rtInfo = pcall(TestItems[i].action, TestItems[i])
    local duration = utils.timeEnd(startTime)
    if not bRt then
      local anInfo = "Script exception:" .. rtInfo .. "\n"
      ResultTable.resultString = anInfo
      table.insert(g_ResultLog,anInfo)
      ResultTable.resultCode = false;
    end
    if not ResultTable.resultCode then
      g_finalResult = false;
      --break;
    end
    ResultTable.number = TestItems[i].number
    ResultTable.name = TestItems[i].name
    if ResultTable.resultString == nil then 
      ResultTable.resultString = ResultTable.resultCode and "Pass" or "Fail"
    end

    ResultTable.unit = ResultTable.unit or "NA"
    ResultTable.failMsg = ResultTable.resultCode and "Pass" or string.sub(ResultTable.resultString,0,510)
    PDCAParametricTmp.low = TestItems[i].limitSet and TestItems[i].limitSet.lower
    PDCAParametricTmp.value = ResultTable.resultString
    PDCAParametricTmp.high = TestItems[i].limitSet and TestItems[i].limitSet.upper
    PDCAParametricTmp.result = ResultTable.resultCode

    PDCAParametricTmp.priority = 0
    PDCAParametricTmp.testName = ResultTable.name
    PDCAParametricTmp.SubTestItem = ResultTable.SubTestItem
    PDCAParametricTmp.SubSubTestItem = ResultTable.SubSubTestItem
    PDCAParametricTmp.failMsg = ResultTable.failMsg
    PDCAParametricTmp.TestUnit = ResultTable.unit
    PDCAParametricTmp.duration = duration
    table.insert(g_PDCAParametric,PDCAParametricTmp)

    table.insert(g_ResultLog,(ResultTable.resultCode and "Pass  " or "Fail  ") .. ResultTable.resultString)
    local tmpLog = table.concat(g_ResultLog,"\n")
    for i=1,#g_ResultLog do
      print(g_ResultLog[i])
    end  
    ResultTable.log = tmpLog
    app.updateItemResult(ResultTable)

    if ResultTable.resultCode == false and TestItems[i].stopFailFlag == true then
      STOP_FAIL = true
    end  
    break
    end

    if stopFlag or exitFlag then
      g_finalResult = false
      break
    end
  end
  aResultString = g_finalResult and "Pass" or "Fail"
  ComTable = {}
  Orionacc1First11low2000w, Orionacc1Second1low2000, ACC1highcurrentdrop = nil;
  accelSensor,gyroSensor,rtRecv1,rtRecvWait200,rtRecv4,rtRecv5,rtRecv6,rtRecvCM1,rtRecvCM2,rtRecvCM3 = nil
  app.updateFinalResult({resultCode=g_finalResult, resultString=aResultString, sn = sn})

end  
function onStart(args)
  print("onStart:")
  stopFlag = false
  exitFlag = false
  sn = nil
  ComTable["offset"] = 0
  startTest(args)
end


function onStop(args)
  stopFlag = true

  -- doDiagsCmd("i2c -v 7 0x55 0x1f 0x00\n")
  -- doDiagsCmd("i2c -v 7 0x55 0x0f 0x00\n")
  -- doScorpiusCmd("eload set 0\r")
  -- doScorpiusCmd("ikt signal 0\r")
  -- doFixtureCmd("move_cylinder:1,0\n")
  -- doFixtureCmd("write_output:14,0\n")
  -- doFixtureCmd("move_cylinder:3,0\n")
end

function onExit(args)
  print("-----Close tcprelay 10000-----")
  exitFlag = true
  onStop(args)
end

function onMessage(args)
  print("onMessage:")
  local scanSN = args.sn
  messageSN = nil
  if not string.match(scanSN,"([^%w]+)") then
    if string.len(scanSN) == 12 then
      app.wait(500)
      scanSN = args.sn
    end 
    if string.len(scanSN) == 12 or string.len(scanSN) == 17 then
      messageSN = scanSN
    end
  end
  print("messageSN" , messageSN)
end


------------------------------------------Public common function---------------------------------------

require("Sequence")
