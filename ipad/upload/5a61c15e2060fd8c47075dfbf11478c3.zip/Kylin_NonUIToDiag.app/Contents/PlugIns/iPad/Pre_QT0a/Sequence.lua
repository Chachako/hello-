--------------------------------------------------------------------------------------------------------------------------------------------------------------
require("Functions")
require("Scoprius")
require("Scopius_Audit")

-- --------------------------------------------------------------------------------------------------------------------------------------------------------------
-- table.insert(TestItems,{name="Init Fixture",action=itemInitFixture}) 

-- table.insert(TestItems,{name="Potassium FW Version",action=PotassiumVersionCheck}) 
-- --------------------------------------------------------------------------------------------------------------------------------------------------------------
-- table.insert(TestItems, {name="Potassium Environment check", action=PotassiumEnvironmentcheck})
-- TestItems[#TestItems].specSet = {cable1 = "0x01 0x00 0x00 0x00",cable2 = "0x00 0x00 0x00 0x00",swd_clock = 3000000,heartbeat = 300000,default_channel = 0,channel_mask = "0x00000001"}

-- -- table.insert(TestItems, {name="Diag version", action=itemDiagVersion})
-- table.insert(TestItems, {name="Enter OS Mode", action=EnterOSMode, stopFailFlag=true, set = {"root#"}})
-- table.insert(TestItems, {name="Set RGBW And Reboot", action=setRGBWAndReboot})

table.insert(TestItems, {name="Re-Enter OS Mode", action=EnterOSMode, stopFailFlag=true, set = {"root#"}})

-- table.insert(TestItems, {name="Enter Diag", action=itemEnterDiag})--flexshorttest

-- table.insert(TestItems, {name="SN", action=itemUnitSn})

-- table.insert(TestItems, {name="Collect Image Data At F1", action=imageCollectAtF1})
-- table.insert(TestItems, {name="Collect Image Data At F3", action=imageCollectAtF3})
-- table.insert(TestItems, {name="Collect Image Data At 500Hz", action=imageCollectAt500Hz})
-- table.insert(TestItems, {name="Collect FF Frames", action=collectFFFrames})

-- table.insert(TestItems, {name="SN", action=itemUnitSn})
-- table.insert(TestItems, {name="Ratescaler test", action=ratescalerTest})
-- TestItems[#TestItems].limitSet = {lower=-100, upper=100}

-- table.insert(TestItems, {name="OS Version", action=itemOSVersion})

-- table.insert(TestItems,{name="Eload SN",action=itemReadEloadSN}) 
-- table.insert(TestItems,{name="Ginger version",action=itemReadGingerVersion})
-- table.insert(TestItems,{name="Ginger FW version",action=itemReadGingerFWVersion})
-- table.insert(TestItems,{name="Ginger Iktara version",action=itemReadIKTARAVersion})
-- -- table.insert(TestItems, {name="Scorpius SN", action=uploadAttributeFromSFC,key="scorpb_sn"})
-- table.insert(TestItems, {name="Check TX MCU FW", action=itemMCU_FW_Check})

-- ------------------------------------------------------------------------------------------------------------------------------------------------------------
-- table.insert(TestItems, {name="Initial Temperature1(deg C)", action = itemTemp1Fun,limitSet = {lower = 18,upper= 40}}) 
-- table.insert(TestItems, {name="Initial Temperature2(deg C)", action = itemTemp2Fun,limitSet = {lower = 18,upper= 40}}) 
-- table.insert(TestItems, {name="Initial Temperature3(deg C)", action = itemTemp3Fun,limitSet = {lower = 18,upper= 40}})

-- -- -- table.insert(TestItems,{name="Position test for Vrect",action=Move_to_OptimalPoint}) 


-- -- local nand_start_index = #TestItems


-- -- table.insert(TestItems, {name="Baseline_Vrect@0.1C Initial set up (V)", action = itemPhaseshifted3, target_vrect = 6.5,limitSet = {lower = 5,upper= 15}})
-- -- --------------------------------------------------------Nominal LPP Test Case--------------------------------------------------------------------------------------------------------------
-- table.insert(TestItems, {name="Baseline_LPP_Frequence (kHz)", action=Low_Power_TX_Ping_Test,limitSet = {lower = 63 ,upper= 82.2}}) 
-- local nand_start_index = #TestItems

-- table.insert(TestItems, {name="Baseline_LPP_Inductance (uH)", action=Low_Power_TX_Ping_Inductance,limitSet = {lower = 18.1,upper= 27}})
-- table.insert(TestItems, {name="Baseline_LPP_Q_res", action=Low_Power_TX_Ping_Qres,limitSet = {lower = 3,upper= 6}}) 
-- table.insert(TestItems, {name="Baseline_LPP_Frequency_delta (KHz)", action=Low_Power_TX_Ping_Delta_Frequency,limitSet = {lower = "NA",upper= "NA"}})  
-- table.insert(TestItems, {name="Baseline_LPP_Inductance_delta (uH)", action=Low_Power_TX_Ping_Delta_Inductance,limitSet = {lower = 2.3,upper= 11}})  
-- table.insert(TestItems, {name="Baseline_LPP_Q_res_delta", action=Low_Power_TX_Ping_Delta_Qres,limitSet = {lower = "NA",upper= "NA"}})  
-- table.insert(TestItems, {name="Baseline_LPP Ctx", action=Low_Power_TX_Ping_Vctx100,limitSet = {lower = 188,upper= 208}}) 

-- -- --------------------------------------------------------Nominal  0.1C Test Case-----------------------------------------------------------------------------------------
-- table.insert(TestItems, {name="Baseline_Re-Initialize", action = itemPhaseshifted3, target_vrect = 6.5,limitSet = {lower = 5,upper= 15}})
-- table.insert(TestItems, {name="Baseline_TX Frequence check (kHz)", action = TXFrequenceTest,limitSet = {lower = 127.6,upper= 127.8}})  
-- table.insert(TestItems, {name="Baseline_PWM Dead Time (nS)", action = PWMDeadTimeTest,limitSet = {lower = 50,upper= 200}}) 
-- table.insert(TestItems, {name="Baseline_OL_Irect_Fix@0.1C (A)", action = itemVrect_20mA,eload_end = 50,target_vrect = 6.5,limitSet = {lower = 0.035,upper= 0.045}})
-- table.insert(TestItems, {name="Baseline_OL_Vrect_Fix@0.1C (V)", action = itemGetVrect,limitSet = {lower = 6,upper= 7}})
-- table.insert(TestItems, {name="Baseline_OL_IBoost@0.1C (A)", action = itemISenseConverted,limitSet = {lower = 0.08,upper= 0.16}})   
-- table.insert(TestItems, {name="Baseline_OL_VBoost@0.1C (V)", action = itemVBoostConverted,limitSet = {lower = 5.94,upper= 7}}) 
-- table.insert(TestItems, {name="Baseline_OL_VCtx_RMS@0.1C (V)", action = itemVctxRMS,limitSet = {lower = 3,upper= 6}})
-- table.insert(TestItems, {name="Baseline_OL_VCtx_Ipeak@0.1C (A)", action = itemVCtxIpeak,limitSet = {lower = 0.3,upper= 0.63}}) 
-- table.insert(TestItems, {name="Baseline_OL_Bridge_Phase@0.1C (degree)", action = itemBridgePhase,limitSet = {lower = 0,upper= 181}})
-- -- table.insert(TestItems, {name="Rx_Loading_power@0.1C (W)", action = itemGetPower,limitSet = {lower = "NA",upper= "NA"}})
-- table.insert(TestItems, {name="Baseline_OL_FOD_threshold@0.1C (%)", action = itemFodfunction,limitSet = {lower = 31,upper= 65}}) 

-- add_ASK_FSK_items("Baseline_", "0.1C")
-- -- SetToRed()
-- -- add_ASK_FSK_items("Baseline_", "0.1C")
-- -- add_ASK_FSK_items("Baseline_", "0.1C")

-- --------------------------------------------------------Nominal  3C Test Case-----------------------------------------------------------------------------------------
-- table.insert(TestItems, {name="Baseline_OL_Irect_Fix@3C (A)", action = itemVrect_135mA,eloads= {113},target_vrect = 8,limitSet = {lower = 0.08,upper= 0.15}})
-- table.insert(TestItems, {name="Baseline_OL_Vrect_Fix@3C (V)", action = itemGetVrect,limitSet = {lower = 7.5,upper= 8.5}})
-- table.insert(TestItems, {name="Baseline_OL_IBoost@3C (A)", action = itemISenseConverted,limitSet = {lower = 0.21,upper= 0.44}})   
-- table.insert(TestItems, {name="Baseline_OL_VBoost@3C (V)", action = itemVBoostConverted,limitSet = {lower = 5.94,upper= 7.6}}) 
-- table.insert(TestItems, {name="Baseline_OL_VCtx_RMS@3C (V)", action = itemVctxRMS,limitSet = {lower = 3.5,upper= 6}})
-- table.insert(TestItems, {name="Baseline_OL_VCtx_Ipeak@3C (A)", action = itemVCtxIpeak,limitSet = {lower = 0.4,upper= 0.8}}) --wait confirm
-- table.insert(TestItems, {name="Baseline_OL_Bridge_Phase@3C (degree)", action = itemBridgePhase,limitSet = {lower = 0,upper= 181}})
-- table.insert(TestItems, {name="Baseline_OL_Rx_Loading_power@3C (W)", action = itemGetPower,limitSet = {lower = 0.8,upper= 1}})
-- table.insert(TestItems, {name="Baseline_OL_FOD_threshold@3C (%)", action = itemFodfunction,limitSet = {lower = 47,upper= 65}}) 

-- add_ASK_FSK_items("Baseline_", "3C")
-- -- add_ASK_FSK_items("Baseline_", "3C")
-- -- add_ASK_FSK_items("Baseline_", "3C")
-- --------------------------------------------------------Nominal  10C Test Case-----------------------------------------------------------------------------------------
-- table.insert(TestItems, {name="Baseline_OL_Irect_Fix@10C (A)", action = itemVrect_135mA,eloads = {150, 193, 224},target_vrect = 14,limitSet = {lower = 0.217,upper= 0.231}})
-- table.insert(TestItems, {name="Baseline_OL_Vrect_Fix@10C (V)", action = itemGetVrect,limitSet = {lower = 13.86,upper= 14.14}})
-- table.insert(TestItems, {name="Baseline_OL_IBoost@10C (A)", action = itemISenseConverted,limitSet = {lower = 0.36,upper= 0.68}})
-- table.insert(TestItems, {name="Baseline_OL_VBoost@10C (V)", action = itemVBoostConverted,limitSet = {lower = 9,upper= 14.3}})
-- table.insert(TestItems, {name="Baseline_OL_VCtx_RMS@10C (V)", action = itemVctxRMS,limitSet = {lower = 6.2,upper= 11.8}})
-- table.insert(TestItems, {name="Baseline_OL_VCtx_Ipeak@10C (A)", action = itemVCtxIpeak,limitSet = {lower = 0.73,upper= 1.38}}) 
-- table.insert(TestItems, {name="Baseline_OL_Bridge_Phase@10C (degree)", action = itemBridgePhase,limitSet = {lower = 0,upper= 181}})
-- table.insert(TestItems, {name="Baseline_OL_Rx_Loading_power@10C (W)", action = itemGetPower,limitSet = {lower = 3,upper= 3.3}})
-- table.insert(TestItems, {name="Baseline_OL_FOD_threshold@10C (%)", action = itemFodfunction,limitSet = {lower = 47,upper= 65}}) 


-- add_ASK_FSK_items("Baseline_", "10C")
-- -- add_ASK_FSK_items("Baseline_", "10C")
-- -- add_ASK_FSK_items("Baseline_", "10C")


-- ------Temperature------
-- table.insert(TestItems, {name="Baseline_Tx_Temp1@10C (deg C)", action = itemTemp1Fun,limitSet = {lower = 18,upper= 42}})
-- table.insert(TestItems, {name="Baseline_Tx_Temp2@10C (deg C)", action = itemTemp2Fun,limitSet = {lower = 18,upper= 42}})
-- table.insert(TestItems, {name="Baseline_Tx_Temp3@10C (deg C)", action = itemTemp3Fun,limitSet = {lower = 18,upper= 42}})

-- -----CL Test---------
-- table.insert(TestItems, {name="Baseline_Close_Loop@10C (A)", action = CL_Charging})
-- table.insert(TestItems, {name="Baseline_CL_Irect_Fix_Get@10C (A)", action = read_eload_Irect, limitSet = {lower = 0.16,upper= 0.28}})
-- table.insert(TestItems, {name="Baseline_CL_Vrect_Fix_Get@10C (V)", action =  read_eload_Vrect ,limitSet = {lower = 12.4,upper= 14.4}})

-- table.insert(TestItems, {name="Baseline_CL Get Tx data@10C", action = getCloseLoopTxData}) 
-- table.insert(TestItems, {name="Baseline_CL_VBoost@10C (V)", action = getComTable, limitSet = {lower = 9,upper= 14.3}})
-- table.insert(TestItems, {name="Baseline_CL_IBoost@10C (A)", action =  getComTable,limitSet = {lower = 0.36,upper= 0.68}})
-- table.insert(TestItems, {name="Baseline_CL_Tx_Temp_Sense1@10C (deg C)", action = getComTable, limitSet = {lower = 18,upper= 42}})
-- table.insert(TestItems, {name="Baseline_CL_Tx_Temp_Sense2@10C (deg C)", action =  getComTable ,limitSet = {lower = 18,upper= 42}})
-- table.insert(TestItems, {name="Baseline_CL_Tx_Temp_Sense3@10C (deg C)", action = getComTable, limitSet = {lower = 18,upper= 42}})
-- table.insert(TestItems, {name="Baseline_CL Get Rx data@10C", action = getCloseLoopRxData}) 
-- table.insert(TestItems, {name="Baseline_CL_Vctx_IPeak@10C (A)", action =  getComTable ,limitSet = {lower = 0.73,upper= 1.38}})
-- table.insert(TestItems, {name="Baseline_CL_Vctx_RMS@10C (V)", action = getComTable, limitSet = {lower = 6.2,upper= 11.8}})
-- table.insert(TestItems, {name="Baseline_CL Calculate power and efficiency@10C", action = closeLoopCalPoAndEfficiency}) 
-- table.insert(TestItems, {name="Baseline_CL_FOD_efficiency@10C (%)", action =  getComTable ,limitSet = {lower = 47,upper= 65}})


-- table.insert(TestItems, {name="Baseline_CL_Rx_Loading_power@10C (W)", action =  read_eload_Power,limitSet = {lower = 3,upper= 3.3}})
-- table.insert(TestItems, {name="Baseline_CL_Bridge_Phase@10C (degree)", action =  itemBridgePhase,limitSet = {lower = 0,upper= 181}})

-- table.insert(TestItems, {name="Baseline_CL_Overall_PER@10C (100%)", action =  itemCL_Comms,limitSet = {lower = 0,upper= 5}}) 
-- table.insert(TestItems, {name="Baseline_CL_FSK_Sent@10C", action =  itemCL_Comms_FSK_Sent,limitSet = {lower = "NA",upper= "NA"}})
-- table.insert(TestItems, {name="Baseline_CL_FSK_Received@10C", action =  itemCL_Comms_FSK_Received,limitSet = {lower = "NA",upper= "NA"}}) 
-- table.insert(TestItems, {name="Baseline_CL_ASK_Sent@10C", action =  itemCL_Comms_ASK_Sent,limitSet = {lower = "NA",upper= "NA"}}) 
-- table.insert(TestItems, {name="Baseline_CL_ASK_Received@10C", action =  itemCL_Comms_ASK_Received,limitSet = {lower = "NA",upper= "NA"}}) 
-- --table.insert(TestItems, {name="CL_Comms_FSK_PER@10C (100%)", action =  itemCL_Comms_FSK,limitSet = {lower = -5,upper= 5}}) 
-- --table.insert(TestItems, {name="CL_Comms_ASK_PER@10C (100%)", action =  itemCL_Comms_ASK,limitSet = {lower = -5,upper= 5}}) 

-- local nand_end_index = #TestItems


-- table.insert(TestItems, {name="Set Display Bright - 100%", action=setBright100})

-- local refreshRateArray = {24, 30, 60, 120}
-- local colorTable = {
--                     {"white","255,255,255","WH"}, 
--                     {"black","0,0,0","BK"}, 
--                     {"red","255,0,0","RD"}, 
--                     {"green","0,255,0","GN"}, 
--                     {"blue","0,0,255","BU"}
--                 }

-- for n, refreshRate in ipairs(refreshRateArray) do
--     table.insert(TestItems, {name="Set Refresh Rate - " .. refreshRate, action=itemSetReflashRate, refreshRate=refreshRate})
--     for m, colorInfo in ipairs(colorTable) do
--         table.insert(TestItems, {name="Set Display Color - " .. colorInfo[1], action=itemSetDisplayColor, code=colorInfo[2]})
--         if nand_start_index and nand_end_index then
--             for i=nand_start_index, nand_end_index do
--                 local testitem = clone(TestItems[i])
--                 testitem.name = colorInfo[3] .. refreshRate .. "_" .. testitem.name:gsub("^%w*_", "")
--                 table.insert(TestItems, testitem)
--             end
--         end
--     end
-- end

-- -- for n, refreshRate in ipairs(refreshRateArray) do
-- --     -- table.insert(TestItems, {name="Set Refresh Rate - " .. refreshRate, action=itemSetReflashRate, refreshRate=refreshRate})
-- --     for m, colorInfo in ipairs(colorTable) do
-- --         -- table.insert(TestItems, {name="Set Display Color - " .. colorInfo[1], action=itemSetDisplayColor, code=colorInfo[2]})
-- --         if nand_start_index and nand_end_index then
-- --             for i=nand_start_index, nand_end_index do
-- --                 local testitem = clone(TestItems[i])
-- --                 testitem.name = colorInfo[3] .. refreshRate .. "_" .. testitem.name:gsub("^%w*_", "")
-- --                 table.insert(TestItems, testitem)
-- --             end
-- --         end
-- --     end
-- -- end

 

-- table.insert(TestItems,{name="FOS_Check FOS",action=CheckFOS})

-- ----------------------------------------------------------------------------------------------
-- table.insert(TestItems, {name="Fixture offset Original Point", action = itemFixtureOffsetRight2back, ESCAPE_STOP_FAIL=true})
-- ----------------------------------------------------------------------------------------------
table.insert(TestItems, {name="Enter EFI Diag Mode", action=enterDiagMode})
-- table.insert(TestItems, {name="Write PDCA", action=itemWritePDCA, blobName="Test1", ESCAPE_STOP_FAIL=true})
-- -- ------------------------------------------------------------------------------------------
-- table.insert(TestItems, {name="Write Local Log", action=uploadDataToPDCA, blobName="Scorpius_Display", ESCAPE_STOP_FAIL=true})



