
#!/bin/bash
SN=$(/usr/local/bin/sysconfig read -k SrNm)
snarray=( $SN )
sernum="${snarray[9]}"

sw_vers
echo $sernum
setbatt drain &

for i in $(seq 0 100 1000); do setbrt -n $i; sleep 2; ggtool | grep -e 'B0AP' -e 'B0AV' -e 'B0AC'; done

