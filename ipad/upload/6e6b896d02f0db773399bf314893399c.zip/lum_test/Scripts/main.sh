#!/bin/bash
set -x

while [[ `reg read --width 4 0x23C1002C8 | xxd -b -c 24 | awk '{print substr($24,8,2)}'` == 1 ]];do 
    sleep 0.1
    # auriotest --duration 0.5 -n 1000 --volume 0.5 >/dev/null
    echo "Please pressing the Volume Up key to start!"

done

sleep 1

## python script
# killall python3
# nohup python3 /AppleInternal/Diags/Debug/lum_test/Scripts/lum_test.py &


## shell script
rm /AppleInternal/Diags/Debug/SMC_read/logs/power_dump.txt 
/AppleInternal/Diags/Debug/SMC_read/Scripts/dump.sh >> "/AppleInternal/Diags/Debug/SMC_read/logs/power_dump.txt" &


wait