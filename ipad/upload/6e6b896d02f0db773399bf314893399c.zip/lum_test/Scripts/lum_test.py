import os
import time
import subprocess
import argparse
import re
import csv



def parse_args():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("name", help = "name for scope sreen shot")
    args = parser.parse_args() 
    return args

def get_time_stamp():
    ct = time.time()
    local_time = time.localtime(ct)
    data_head = time.strftime("%Y-%m-%d %H:%M:%S", local_time)
    data_secs = (ct - int(ct)) * 1000
    time_stamp = "%s.%03d" % (data_head, data_secs)
    stamp = ("".join(time_stamp.split()[0].split("-"))+"".join(time_stamp.split()[1].split(":"))).replace('.', '')
    return time_stamp,stamp


def Sending_cmd(Send):
    Time = get_time_stamp()
    test = os.popen(Send).read()
    Time_1 = "\n" + Time[0] + " | "
    print(Time[0] + " | ",end="")
    print("iPad# "+Send)
    File.write(Time_1 + "iPad# "+Send)
    test = test.strip()
    for n in range(0,len(test.split("\n"))):
        print(Time[0] + " | ",end="")
        print(test.split("\n")[n])
        File.write(Time_1 + test.split("\n")[n])
    return test

def write_csv_header(mode):
    csvFile = open(path_csv, "w")
    if mode == "Gyro":
        fileHeader = ["Audio Freq","Gyro_std_X","Gyro_std_Y","Gyro_std_Z"]      
    writer = csv.writer(csvFile)
    writer.writerow(fileHeader)
    csvFile.close()

def write_csv(data):
    csvFile = open(path_csv, "a")
    writer = csv.writer(csvFile)                  
    writer.writerow(data)
    csvFile.close()


def lum_setting(n):
    
    time.sleep(1)
    Sending_cmd("sleep 0.5")
    Sending_cmd("displayPipeline pcc -d")
    Sending_cmd("clcdControl -G 1")
    Sending_cmd("displayPipeline dither -e")
    Sending_cmd("clcdControl --2D_uniformity=1")
    Sending_cmd("displayPipeline temperatureCompensation -e")
    Sending_cmd("clcdControl --enable_normal_mode=0")
    Sending_cmd("clcdControl --fixed_rr=4")
    Sending_cmd("clcdControl --enable_normal_mode=1")
    Sending_cmd("displayPipeline PCC2DData -f /var/root/lum/lum_%d.txt"%n)
    Sending_cmd("diagstool lcdmura -p3 1023,1023,1023")
    Sending_cmd("sleep 0.5")
    Sending_cmd("displayPipeline PCC2DData -f /var/root/lum/lum_%d.txt"%n)
    Sending_cmd("diagstool lcdmura -p3 1023,1023,1023")
    Sending_cmd("sleep 0.5")
    Sending_cmd("displayPipeline PCC2DData -f /var/root/lum/lum_%d.txt"%n)
    Sending_cmd("diagstool lcdmura -p3 1023,1023,1023")
    Sending_cmd("sleep 0.5")
    Sending_cmd("displayPipeline PCC2DData -f /var/root/lum/lum_%d.txt"%n)
    Sending_cmd("diagstool lcdmura -p3 1023,1023,1023")
    Sending_cmd("sleep 0.5")
    Sending_cmd("displayPipeline PCC2DData -f /var/root/lum/lum_%d.txt"%n)
    Sending_cmd("diagstool lcdmura -p3 1023,1023,1023")
    Sending_cmd("sleep 0.5")
    Sending_cmd("setbrt -n 1600")
    Sending_cmd("setbrt -n 1600")
    Sending_cmd("clcdControl --enable_normal_mode=0")
    Sending_cmd("sleep 0.5")
    time.sleep(1)

def load_cal():
    Sending_cmd("/usr/local/bin/OSDBCONTool write -m bcon -a 0x0002 -l 1 -v 0x01")
    Sending_cmd("/usr/local/bin/OSDBCONTool write -m bcon -a 0x0002 -l 1 -v 0x00")
    Sending_cmd("/usr/local/bin/OSDBCONTool write -m bcon -a 0x0002 -l 1 -v 0x02")
    Sending_cmd("/usr/local/bin/OSDBCONTool write -m bcon -a 0x0002 -l 1 -v 0x06")
    Sending_cmd("/usr/local/bin/OSDBCONTool write -m bcon -a 0x0100 -l 1 -v 0x08")
    Sending_cmd("/usr/local/bin/OSDBCONTool read -m bcon -a 0x0000 -l 1")
    Sending_cmd("IOMFB_FDR_Loader -i /var/root/FINAL_POSTCALFLASH/fdr.bin")
    Sending_cmd("sleep 0.5")

def Batt_read(n):
    voltage = []
    current = []
    voltage_avg = 0
    current_avg = 0
    power = []

    voltage.append("lum_%d_voltage"%n)
    current.append("lum_%d_current"%n)
    power.append("### lum_%d_Power:"%n)
    for x in range(1,51):
        time.sleep(1)
        B0AV = Sending_cmd("smcif -r B0AV")
        B0AC = Sending_cmd("smcif -r B0AC")
        B0AV_data = re.findall("\d+", B0AV)[1]
        B0AC_data = re.findall("\d+", B0AC)[1]
        print(B0AV_data,B0AC_data)
        # print(type(B0AV_data),type(B0AC_data))
        voltage_avg = (voltage_avg + int(B0AV_data))/1000.0
        current_avg = (current_avg + int(B0AC_data))/1000.0
        voltage.append(B0AV_data)
        current.append(B0AC_data)
    
    power_1 = voltage_avg*current_avg
    power.append(power_1)
    write_csv(voltage)
    write_csv(current)
    write_csv(power)

    return voltage, current, power



if __name__ == '__main__':


    File_path = "/AppleInternal/Diags/Debug/lum_test/logs/lum_test_logs.txt"
    path_csv = "/AppleInternal/Diags/Debug/lum_test/logs/lum_test_logs.csv"
    File = open(File_path,"w+")
    csvFile = open(path_csv, "w")
    csvFile.close()

    
    time.sleep(20)

    SN = Sending_cmd("sysconfig read -k SrNm").strip().split(" ")[-1]
    Sending_cmd("sw_vers")
    boot_args = Sending_cmd("nvram boot-args")
    Sending_cmd("sysconfig read -k SrNm")
    
    write_csv([SN])
    # write_csv([boot_args])
    write_csv([">>> Baseline"])
    Sending_cmd("powerswitch lcd off")
    time.sleep(2)
    Batt_read(0)
    Sending_cmd("powerswitch lcd on")
    time.sleep(2)


    write_csv([">>> Before_cal"])
    lum_setting(1)
    Batt_read(1)
    lum_setting(20)
    Batt_read(20)
    lum_setting(40)
    Batt_read(40)
    lum_setting(80)
    Batt_read(80)
    lum_setting(140)
    Batt_read(140)
    lum_setting(600)
    Batt_read(600)
    lum_setting(1000)
    Batt_read(1000)

    load_cal()
    time.sleep(2)
    write_csv([">>> After_cal"])
    lum_setting(1)
    Batt_read(1)
    lum_setting(20)
    Batt_read(20)
    lum_setting(40)
    Batt_read(40)
    lum_setting(80)
    Batt_read(80)
    lum_setting(140)
    Batt_read(140)
    lum_setting(600)
    Batt_read(600)
    lum_setting(1000)
    Batt_read(1000)
    lum_setting(1)

    time.sleep(0.5)
    os.rename(File_path,"/AppleInternal/Diags/Debug/lum_test/logs/%s_lum_test_logs.txt"%SN)
    os.rename(path_csv,"/AppleInternal/Diags/Debug/lum_test/logs/%s_lum_test_logs.csv"%SN)











