ERI parsing definition file
===========================

Version Info
------------
AUGUST 22, 2015 ver01

[TOC]

Commands that can be parsed
===========================

sn
--------
 - Command name: `sn`
 - Command to send: `sn`
```
Serial: {{serialnumber}}
```


bl -n
--------
 - Command name: `bl -n`
 - Command to send: `bl -n`
```
{{config}}
```

bl -l
--------
 - Command name: `bl -l`
 - Command to send: `bl -l`
 ```
{{config}}
```

version
--------
 - Command name: `Diag Version`
 - Command to send: `ver`
```
({{DIAG_VER}}). Revision
```

Check Battery Level Before Test
--------
 - Command name: `Check Battery Level Before Test`
 - Command to send: `device -k GasGauge -g charge-percentage`
```
{{Check Battery Level Before Test}}%
```

Check Battery Level After Test
--------
 - Command name: `Check Battery Level After Test`
 - Command to send: `device -k GasGauge -g charge-percentage`
```
{{Check Battery Level After Test}}%
```

Check Battery Voltage Before Test
--------
 - Command name: `Check Battery Voltage Before Test`
 - Command to send: `pmuadc --sel potomac --read vbat`
```
PMU ADC test
expansion potomac: vbat: {{Check Battery Voltage Before Test}} mV
```

Check Battery Voltage After Test
--------
 - Command name: `Check Battery Voltage After Test`
 - Command to send: `pmuadc --sel potomac --read vbat`
```
PMU ADC test
expansion potomac: vbat: {{Check Battery Voltage After Test}} mV
```

battery1
--------
 - Command name: `dev -k GasGauge -p`
 - Command to send: `dev -k GasGauge -p`
```
{{battery1}}
```

battery2
--------
 - Command name: `dev -k GasGauge -e read_blk 59 0`
 - Command to send: `dev -k GasGauge -e read_blk 59 0`
```
Class 59, Block 0:
0000000: {{battery_value}}
0000010: {{anything}}
OK
```

Boardid
--------
 - Command name: `boardid`
 - Command to send: `boardid`
```
Board Id: {{boardid}}
```

boardrev
--------
 - Command name: `boardrev`
 - Command to send: `boardrev`
```
Board Revision: {{boardRevision}}
```

chipid
--------
 - Command name: `chipid`
 - Command to send: `chipid`
``` 
Chip  ID: {{CHIP_ID}} Version
```


detect_camera
--------
 - Command name: `detect_camera`
 - Command to send: `camisp --find`
```
pick number {{===}}, back  detected 
pick number {{===}}, front  detected 
pick number {{===}}, front1  detected 
Pass
```


Compare HS Color with CLHS
--------
 - Command name: `syscfg print CLHS`
 - Command to send: `syscfg print CLHS`
```
{{CLHS_code}} 
```

Compare CG Color with CLCG
--------
 - Command name: `syscfg print CLCG`
 - Command to send: `syscfg print CLCG`
```
{{CLCG_code}} 
```



front_nvm
--------
 - Command name: `front_nvm`
 - Command to send: `camisp --nvm`
``` 
NVM Data {{2176}} bytes : 
0x0 : {{0x0}} 
0x8 : {{0x8}} 
0x10 : {{0x10}} 
0x18 : {{0x18}} 
0x20 : {{0x20}} 
0x28 : {{0x28}} 
0x30 : {{0x30}} 
0x38 : {{0x38}} 
0x40 : {{0x40}} 
0x48 : {{0x48}} 
0x50 : {{0x50}} 
0x58 : {{0x58}} 
0x60 : {{0x60}} 
0x68 : {{0x68}} 
0x70 : {{0x70}} 
0x78 : {{0x78}} 
0x80 : {{0x80}} 
0x88 : {{0x88}} 
0x90 : {{0x90}} 
0x98 : {{0x98}} 
0xA0 : {{0xA0}} 
0xA8 : {{0xA8}} 
0xB0 : {{0xB0}} 
0xB8 : {{0xB8}} 
0xC0 : {{0xC0}} 
0xC8 : {{0xC8}} 
0xD0 : {{0xD0}} 
0xD8 : {{0xD8}} 
0xE0 : {{0xE0}} 
0xE8 : {{0xE8}} 
0xF0 : {{0xF0}} 
0xF8 : {{0xF8}} 
0x100 : {{0x100}} 
0x108 : {{0x108}} 
0x110 : {{0x110}} 
0x118 : {{0x118}} 
0x120 : {{0x120}} 
0x128 : {{0x128}} 
0x130 : {{0x130}} 
0x138 : {{0x138}} 
0x140 : {{0x140}} 
0x148 : {{0x148}} 
0x150 : {{0x150}} 
0x158 : {{0x158}} 
0x160 : {{0x160}} 
0x168 : {{0x168}} 
0x170 : {{0x170}} 
0x178 : {{0x178}} 
0x180 : {{0x180}} 
0x188 : {{0x188}} 
0x190 : {{0x190}} 
0x198 : {{0x198}} 
0x1A0 : {{0x1A0}} 
0x1A8 : {{0x1A8}} 
0x1B0 : {{0x1B0}} 
0x1B8 : {{0x1B8}} 
0x1C0 : {{0x1C0}} 
0x1C8 : {{0x1C8}} 
0x1D0 : {{0x1D0}} 
0x1D8 : {{0x1D8}} 
0x1E0 : {{0x1E0}} 
0x1E8 : {{0x1E8}} 
0x1F0 : {{0x1F0}} 
0x1F8 : {{0x1F8}} 
0x200 : {{0x200}} 
0x208 : {{0x208}} 
0x210 : {{0x210}} 
0x218 : {{0x218}} 
0x220 : {{0x220}} 
0x228 : {{0x228}} 
0x230 : {{0x230}} 
0x238 : {{0x238}} 
0x240 : {{0x240}} 
0x248 : {{0x248}} 
0x250 : {{0x250}} 
0x258 : {{0x258}} 
0x260 : {{0x260}} 
0x268 : {{0x268}} 
0x270 : {{0x270}} 
0x278 : {{0x278}} 
0x280 : {{0x280}} 
0x288 : {{0x288}} 
0x290 : {{0x290}} 
0x298 : {{0x298}} 
0x2A0 : {{0x2A0}} 
0x2A8 : {{0x2A8}} 
0x2B0 : {{0x2B0}} 
0x2B8 : {{0x2B8}} 
0x2C0 : {{0x2C0}} 
0x2C8 : {{0x2C8}} 
0x2D0 : {{0x2D0}} 
0x2D8 : {{0x2D8}} 
0x2E0 : {{0x2E0}} 
0x2E8 : {{0x2E8}} 
0x2F0 : {{0x2F0}} 
0x2F8 : {{0x2F8}} 
0x300 : {{0x300}} 
0x308 : {{0x308}} 
0x310 : {{0x310}} 
0x318 : {{0x318}} 
0x320 : {{0x320}} 
0x328 : {{0x328}} 
0x330 : {{0x330}} 
0x338 : {{0x338}} 
0x340 : {{0x340}} 
0x348 : {{0x348}} 
0x350 : {{0x350}} 
0x358 : {{0x358}} 
0x360 : {{0x360}} 
0x368 : {{0x368}} 
0x370 : {{0x370}} 
0x378 : {{0x378}} 
0x380 : {{0x380}} 
0x388 : {{0x388}} 
0x390 : {{0x390}} 
0x398 : {{0x398}} 
0x3A0 : {{0x3A0}} 
0x3A8 : {{0x3A8}} 
0x3B0 : {{0x3B0}} 
0x3B8 : {{0x3B8}} 
0x3C0 : {{0x3C0}} 
0x3C8 : {{0x3C8}} 
0x3D0 : {{0x3D0}} 
0x3D8 : {{0x3D8}} 
0x3E0 : {{0x3E0}} 
0x3E8 : {{0x3E8}} 
0x3F0 : {{0x3F0}} 
0x3F8 : {{0x3F8}} 
0x400 : {{0x400}} 
0x408 : {{0x408}} 
0x410 : {{0x410}} 
0x418 : {{0x418}} 
0x420 : {{0x420}} 
0x428 : {{0x428}} 
0x430 : {{0x430}} 
0x438 : {{0x438}} 
0x440 : {{0x440}} 
0x448 : {{0x448}} 
0x450 : {{0x450}} 
0x458 : {{0x458}} 
0x460 : {{0x460}} 
0x468 : {{0x468}} 
0x470 : {{0x470}} 
0x478 : {{0x478}} 
0x480 : {{0x480}} 
0x488 : {{0x488}} 
0x490 : {{0x490}} 
0x498 : {{0x498}} 
0x4A0 : {{0x4A0}} 
0x4A8 : {{0x4A8}} 
0x4B0 : {{0x4B0}} 
0x4B8 : {{0x4B8}} 
0x4C0 : {{0x4C0}} 
0x4C8 : {{0x4C8}} 
0x4D0 : {{0x4D0}} 
0x4D8 : {{0x4D8}} 
0x4E0 : {{0x4E0}} 
0x4E8 : {{0x4E8}} 
0x4F0 : {{0x4F0}} 
0x4F8 : {{0x4F8}} 
0x500 : {{0x500}} 
0x508 : {{0x508}} 
0x510 : {{0x510}} 
0x518 : {{0x518}} 
0x520 : {{0x520}} 
0x528 : {{0x528}} 
0x530 : {{0x530}} 
0x538 : {{0x538}} 
0x540 : {{0x540}} 
0x548 : {{0x548}} 
0x550 : {{0x550}} 
0x558 : {{0x558}} 
0x560 : {{0x560}} 
0x568 : {{0x568}} 
0x570 : {{0x570}} 
0x578 : {{0x578}} 
0x580 : {{0x580}} 
0x588 : {{0x588}} 
0x590 : {{0x590}} 
0x598 : {{0x598}} 
0x5A0 : {{0x5A0}} 
0x5A8 : {{0x5A8}} 
0x5B0 : {{0x5B0}} 
{{end_index}} : 
```


Rosaline_toggle_interrupt
--------
 - Command name: `Rosaline_toggle_interrupt`
 - Command to send: `sensor --sel prox --sample 1s --stats`
```
prox:
	{{anything}} of samples captured: {{Rosalinedata}}
	{{anything}} of bad samples (corrupted/lost): {{anything}}
	calculated odr: {{anything}}
	average: rawrange {{anything}}
	average: signalrateperspad {{anything}}
	average: refsignalrateperspad {{anything}}
	average: totalsignalrate{{anything}}
	average: totalrefsignalrate {{anything}}
	average: integrationtime {{anything}}
	std-dev: rawrange {{anything}}
	std-dev: signalrateperspad {{anything}}
	std-dev: refsignalrateperspad {{anything}}
	std-dev: totalsignalrate {{anything}}
	std-dev: totalrefsignalrate {{anything}}
	std-dev: integrationtime {{anything}}
	rms: rawrange {{anything}}
	rms: signalrateperspad {{anything}}
	rms: refsignalrateperspad {{anything}}
	rms: totalsignalrate{{anything}}
	rms: totalrefsignalrate {{anything}}
	rms: integrationtime {{anything}}
OK
```

Upload Rosaline SN
--------
 - Command name: `Upload Rosaline SN`
 - Command to send: `sensor --sel prox --get serial_num`
```
serial_num = {{ROSALINE_SN}}
OK
```

reg read 0x4002
--------
 - Command name: `reg read 0x4002`
 - Command to send: `reg read 0x4002`
``` 
0x4002 {{===}} {{read1}}
OK
```

reg read 0x4001
--------
 - Command name: `reg read 0x4001`
 - Command to send: `reg read 0x4001`
``` 
0x4001 {{===}} {{read2}}
OK
```

socgpio --port 1 --pin 41 --get
--------
 - Command name: `socgpio --port 1 --pin 41 --get`
 - Command to send: `socgpio --port 1 --pin 41 --get`
``` 
SoC GPIO[1,41] = {{SoC_GPIO41}}
```


syscfg list
--------
 - Command name: `syscfg print WCAL`
 - Command to send: `syscfg print WCAL`
``` 
{{WCAL_value}}
```


Burn RxCL Key
--------
 - Command name: `Burn RxCL Key`
 - Command to send: `sensor --sel prox --get nvm`
```
00000070: {{RxCL_Key}} |
```


Grape Short Test
--------
 - Command name: `Grape Short Test`
 - Command to send: `smokey --run TouchShortsTest`
```
Shorts Sig Table (X): ({{anything}})
{{Shorts_Sig_Table_X}}
  Low Limit = {{anything}}
  High Limit = {{Sig_X_High_Limit}}


Shorts Gnd Table (X): ({{anything}})
{{Shorts_Gnd_Table_X}}
  Low Limit = {{anything}}
  High Limit = {{Gnd_X_High_Limit}}


Shorts Sig Table (Y): ({{anything}})
{{Shorts_Sig_Table_Y}}
  Low Limit = {{anything}}
  High Limit = {{Sig_Y_High_Limit}}


Shorts Gnd Table (Y): ({{anything}})
{{Shorts_Gnd_Table_Y}}
  Low Limit = {{anything}}
  High Limit = {{Gnd_Y_High_Limit}}
{{/[\s\S]*/}}Passed
```


ALS1_FH_RIGHT_Interrupt test
--------
 - Command name: `socgpio 20 get interrupt`
 - Command to send: `socgpio --port 1 --pin 20 --get`
```
SoC GPIO[{{anything}},{{anything}}] = {{interrupt_value}}
OK
```

ALS2_FH_LEFT_Interrupt test
--------
 - Command name: `socgpio 21 get interrupt`
 - Command to send: `socgpio --port 1 --pin 21 --get`
```
SoC GPIO[{{anything}},{{anything}}] = {{interrupt_value}}
OK
```

 EDPBERTest 
--------
 - Command name: `display --method ber --options -g`
 - Command to send: ` display --method ber --options "-g"`
```
Reading EDP Panel BER stats...
{{Err_Count}}

OK
```


Read PMU Temp test
--------
 - Command name: `Read PMU Temp`
 - Command to send: `temperature --all`
```
Device: pmu
	TCAL
	    Instant: {{Read PMU TCAL Temp}} deg C
	{{anything}}
	    {{anything}}
	TDEV1
	    Instant: {{Read PMU Temp1 TDEV1}} deg C
	TDEV2
	    Instant: {{Read PMU Temp2 TDEV2}} deg C
	TDEV3
	    Instant: {{Read PMU Temp3 TDEV3}} deg C
	TDEV4
	    Instant: {{Read PMU Temp4 TDEV4}} deg C
	TDEV5
	    Instant: {{Read PMU Temp5 TDEV5}} deg C
	TDEV6
	    Instant: {{Read PMU Temp6 TDEV6}} deg C
	TDEV7
	    Instant: {{Read PMU Temp7 TDEV7}} deg C
	TDEV8
	    Instant: {{Read PMU Temp8 TDEV8}} deg C
Device: pmu2
	{{anything}}
	    {{anything}}
	TCAL
	    Instant: {{Read PMU2 TCAL Temp}} deg C
	TDEV1
	    Instant: {{Read PMU2 TDEV1 Temp}} deg C
	TDEV2
	    Instant: {{Read PMU2 TDEV2 Temp}} deg C
```





Read Battery Temp TG0B
--------
 - Command name: `Read Battery Temp TG0B`
 - Command to send: `device -k GasGauge -p`
 ```
temperature: "{{Battery_Temp}}C"
```




smokey --run1
--------
 - Command name: `smokey --run1`
 - Command to send: `smokey --run Wildfire DisplayBehavior=NoDisplay ControlBitAccess=ReadOnly BrickRequired=None ResultsBehavior=NoFile LogBehavior=ConsoleOnly --test MamaBearStateTest`
``` 
:-) camisp --i2cread {{anything}}
RunI2cRead {{anything}}
{{RunI2cRead}}
Pass
------------------------------------------------------------------------------
[{{anything}}] {{anything}} 			Exit code = {{anything}}
------------------------------------------------------------------------------
{{MamaBear}}
Hark, Station! Behold the data I present you!
{{MamaBear_Armed_State}}
------------------------------------------------------------------------------
[{{anything}}] {{anything}} 			camisp --exit
------------------------------------------------------------------------------
:-) camisp --exit
RunExit
Pass
------------------------------------------------------------------------------
{{anything}}
{{anything}}
{{anything}}
{{anything}}
{{anything}}
{{anything}}
{{anything}}
{{anything}}

Passed

Writing final results
Skipping control bit write
Skipping PDCA plist write
```


smokey --run2
--------
 - Command name: `smokey --run2`
 - Command to send: `smokey --run Wildfire DisplayBehavior=NoDisplay ControlBitAccess=ReadOnly BrickRequired=None ResultsBehavior=NoFile LogBehavior=ConsoleOnly --test PearlStatus`
``` 
------------------------------------------------------------------------------
:-) camisp --method pearl rigel status
Device status:Fault Status 0x7C,0x7E,0x80,0x82,0x84:{{Device status:Fault Status 0x7C,0x7E,0x80,0x82,0x84}}
CC State 0x1C,0xF0:{{CC State 0x1C,0xF0}}
Rigel State {{Rigel State_CC}}
Pass
------------------------------------------------------------------------------
[{{===}}] {{===}} 			Exit code = {{===}}
------------------------------------------------------------------------------
Hark, Station! Behold the data I present you!
{{FaultStatus}}
Hark, Station! Behold the data I present you!
{{RigelState}}
------------------------------------------------------------------------------
[{{===}}] {{===}} 			camisp --method pearl romeo cap
------------------------------------------------------------------------------
:-) camisp --method pearl romeo cap
Device status:Capacitance:{{===}}
Status:{{===}}
Pass
------------------------------------------------------------------------------
[{{===}}] {{===}} 			Exit code = {{===}}
------------------------------------------------------------------------------
CapValue:{{CapValue}}
Hark, Station! Behold the data I present you!
{{===}}
------------------------------------------------------------------------------
[{{===}}] {{===}} 			camisp --exit
------------------------------------------------------------------------------
:-) camisp --exit
RunExit
Pass
------------------------------------------------------------------------------
{{anything}}
{{anything}}
{{anything}}
{{anything}}
{{anything}}
{{anything}}
{{anything}}

Passed

Writing final results
Skipping control bit write
Skipping PDCA plist write

```



sensor --sel prox --get nvm
--------
 - Command name: `sensor --sel prox --get nvm`
 - Command to send: `sensor --sel prox --get nvm`
``` 
	nvm = 
00000000: {{===}}
00000010: {{===}}
00000020: {{===}}
00000030: {{===}}
00000040: {{===}}
00000050: {{===}}
00000060: {{===}}
00000070: {{data}} |{{===}}|
```

i2c -z 2 -d 4 0x50 0x3d00 0x38
--------
 - Command name: `i2c -z 2 -d 4 0x50 0x3d00 0x38`
 - Command to send: `i2c -z 2 -d 4 0x50 0x3d00 0x38`
``` 
Data:  {{data}} 
```

i2c -z 2 -d 4 0x50 0x00b0 0x11
--------
 - Command name: `i2c -z 2 -d 4 0x50 0x00b0 0x11`
 - Command to send: `i2c -z 2 -d 4 0x50 0x00b0 0x11`
``` 
Data:  {{data}} 
```

i2c -z 2 -d 4 0x50 0x00C7 0x35
--------
 - Command name: `i2c -z 2 -d 4 0x50 0x00C7 0x35`
 - Command to send: `i2c -z 2 -d 4 0x50 0x00C7 0x35`
``` 
Data:  {{data}} 
```


Read_Juliet_SN
--------
 - Command name: `Read_Juliet_SN`
 - Command to send: `camisp --sn`
```
Serial Number: {{Juliet_SN}}
Pass
```



Check Titus Module Capacitance
--------
 - Command name: `Check Titus Module Capacitance`
 - Command to send: `camisp --method pearl romeo cap`
```
Device status:Capacitance:{{Titus_Module_Capacitance}}
Status:{{anything}}
Pass
```


Check Rigel Status
--------
 - Command name: `Check Rigel Status`
 - Command to send: `camisp --method pearl rigel status`
```
Device status:Fault Status {{anything}}:{{Fault_Status}}
CC State {{anything}}:{{CC_State}}
Rigel State {{anything}}:{{anything}}
Pass
```



Read Juliet ID
--------
 - Command name: `Read Juliet ID`
 - Command to send: `camisp --id`
```
RunGetId 
{{Juliet_ID}}
Pass
```



front_nvm
--------
 - Command name: `front_nvm`
 - Command to send: `camisp --nvmdump`
``` 
NVM Data {{2176}} bytes : 
0x0 : {{0x0}} 
0x8 : {{0x8}} 
0x10 : {{0x10}} 
0x18 : {{0x18}} 
0x20 : {{0x20}} 
0x28 : {{0x28}} 
0x30 : {{0x30}} 
0x38 : {{0x38}} 
0x40 : {{0x40}} 
0x48 : {{0x48}} 
0x50 : {{0x50}} 
0x58 : {{0x58}} 
0x60 : {{0x60}} 
0x68 : {{0x68}} 
0x70 : {{0x70}} 
0x78 : {{0x78}} 
0x80 : {{0x80}} 
0x88 : {{0x88}} 
0x90 : {{0x90}} 
0x98 : {{0x98}} 
0xA0 : {{0xA0}} 
0xA8 : {{0xA8}} 
0xB0 : {{0xB0}} 
0xB8 : {{0xB8}} 
0xC0 : {{0xC0}} 
0xC8 : {{0xC8}} 
0xD0 : {{0xD0}} 
0xD8 : {{0xD8}} 
0xE0 : {{0xE0}} 
0xE8 : {{0xE8}} 
0xF0 : {{0xF0}} 
0xF8 : {{0xF8}} 
0x100 : {{0x100}} 
0x108 : {{0x108}} 
0x110 : {{0x110}} 
0x118 : {{0x118}} 
0x120 : {{0x120}} 
0x128 : {{0x128}} 
0x130 : {{0x130}} 
0x138 : {{0x138}} 
0x140 : {{0x140}} 
0x148 : {{0x148}} 
0x150 : {{0x150}} 
0x158 : {{0x158}} 
0x160 : {{0x160}} 
0x168 : {{0x168}} 
0x170 : {{0x170}} 
0x178 : {{0x178}} 
0x180 : {{0x180}} 
0x188 : {{0x188}} 
0x190 : {{0x190}} 
0x198 : {{0x198}} 
0x1A0 : {{0x1A0}} 
0x1A8 : {{0x1A8}} 
0x1B0 : {{0x1B0}} 
0x1B8 : {{0x1B8}} 
0x1C0 : {{0x1C0}} 
0x1C8 : {{0x1C8}} 
0x1D0 : {{0x1D0}} 
0x1D8 : {{0x1D8}} 
0x1E0 : {{0x1E0}} 
0x1E8 : {{0x1E8}} 
0x1F0 : {{0x1F0}} 
0x1F8 : {{0x1F8}} 
0x200 : {{0x200}} 
0x208 : {{0x208}} 
0x210 : {{0x210}} 
0x218 : {{0x218}} 
0x220 : {{0x220}} 
0x228 : {{0x228}} 
0x230 : {{0x230}} 
0x238 : {{0x238}} 
0x240 : {{0x240}} 
0x248 : {{0x248}} 
0x250 : {{0x250}} 
0x258 : {{0x258}} 
0x260 : {{0x260}} 
0x268 : {{0x268}} 
0x270 : {{0x270}} 
0x278 : {{0x278}} 
0x280 : {{0x280}} 
0x288 : {{0x288}} 
0x290 : {{0x290}} 
0x298 : {{0x298}} 
0x2A0 : {{0x2A0}} 
0x2A8 : {{0x2A8}} 
0x2B0 : {{0x2B0}} 
0x2B8 : {{0x2B8}} 
0x2C0 : {{0x2C0}} 
0x2C8 : {{0x2C8}} 
0x2D0 : {{0x2D0}} 
0x2D8 : {{0x2D8}} 
0x2E0 : {{0x2E0}} 
0x2E8 : {{0x2E8}} 
0x2F0 : {{0x2F0}} 
0x2F8 : {{0x2F8}} 
0x300 : {{0x300}} 
0x308 : {{0x308}} 
0x310 : {{0x310}} 
0x318 : {{0x318}} 
0x320 : {{0x320}} 
0x328 : {{0x328}} 
0x330 : {{0x330}} 
0x338 : {{0x338}} 
0x340 : {{0x340}} 
0x348 : {{0x348}} 
0x350 : {{0x350}} 
0x358 : {{0x358}} 
0x360 : {{0x360}} 
0x368 : {{0x368}} 
0x370 : {{0x370}} 
0x378 : {{0x378}} 
0x380 : {{0x380}} 
0x388 : {{0x388}} 
0x390 : {{0x390}} 
0x398 : {{0x398}} 
0x3A0 : {{0x3A0}} 
0x3A8 : {{0x3A8}} 
0x3B0 : {{0x3B0}} 
0x3B8 : {{0x3B8}} 
0x3C0 : {{0x3C0}} 
0x3C8 : {{0x3C8}} 
0x3D0 : {{0x3D0}} 
0x3D8 : {{0x3D8}} 
0x3E0 : {{0x3E0}} 
0x3E8 : {{0x3E8}} 
0x3F0 : {{0x3F0}} 
0x3F8 : {{0x3F8}} 
{{end_index}} : 
```

prox serial_num
--------
 - Command name: `prox serial_num`
 - Command to send: `sensor --sel prox --get serial_num`
```
prox:
	serial_num = {{prox_serial_num}}
OK
```


baseband -p sim-card-installed
--------
 - Command name: `baseband -p sim-card-installed`
 - Command to send: `baseband -p sim-card-installed`
``` 
{{sim_card_installed}}
OK
```


baseband -p sim-tray-installed
--------
 - Command name: `baseband -p sim-tray-installed`
 - Command to send: `baseband -p sim-tray-installed`
``` 
{{sim_tray_installed}}
OK
```

Grape Offset Test1
--------
 - Command name: `smokey --clean --run TouchOffsetsTest`
 - Command to send: `smokey --clean --run TouchOffsetsTest`
```
{{/[\s\S]*/}}Passed
```


sensorreg --sel pressure -r 0x80
--------
 - Command name: `sensorreg --sel pressure -r 0x80`
 - Command to send: `sensorreg --sel pressure -r 0x80`
``` 
Reading in 1 registers from 0x80:
0x80 = {{WV_Phosphorus_Mfg_ID}}
OK
```

ensorreg --sel pressure -r 0x81
--------
 - Command name: `sensorreg --sel pressure -r 0x81`
 - Command to send: `sensorreg --sel pressure -r 0x81`
``` 
Reading in 1 registers from 0x81:
0x81 = {{WV_Phosphorus_Chip_ID}}
OK
```

sensorreg --sel pressure -r 0xA1 1
--------
 - Command name: `sensorreg --sel pressure -r 0xA1 1`
 - Command to send: `sensorreg --sel pressure -r 0xA1 1`
``` 
Reading in 1 registers from 0xA1:
0xA1 = {{WV_Phosphorus_Trim_Rev}}
OK
``` 

sensorreg --sel pressure -r 0xA3 1
--------
 - Command name: `sensorreg --sel pressure -r 0xA3 1`
 - Command to send: `sensorreg --sel pressure -r 0xA3 1`
``` 
Reading in 1 registers from 0xA3:
0xA3 = {{WV_Phosphorus_Trim_Rev2}}
OK
```

sensorreg --sel pressure -r 0xA4 1
--------
 - Command name: `sensorreg --sel pressure -r 0xA4 1`
 - Command to send: `sensorreg --sel pressure -r 0xA4 1`
``` 
Reading in 1 registers from 0xA4:
0xA4 = {{WV_Phosphorus_Trim_Rev3}}
OK
```

detect_pressure
--------
 - Command name: `detect_pressure`
 - Command to send: `sensor --listsensors`
``` 
Name: pressure
Description: Bosch BMP284 Pressure (Phosphorous) SPI
Installed: yes
```


sensor --sel pressure --sample 1000ms --stats
--------
 - Command name: `sensor --sel pressure --sample 1000ms --stats`
 - Command to send: `sensor --sel pressure --sample 1000ms --stats`
``` 
pressure:
	# of samples captured: 26
	# of bad samples (corrupted/lost): 0
	calculated odr: {{WV_Phosphorus_ODR}}Hz
	average: pressure = {{WV_Phosphorus_Average}}, temp = {{WV_Phosphorus_Temp_average}}
	std-dev: pressure = {{WV_Phosphorus_std}}, temp = {{WV_Phosphorus_Temp_std}}
	{{===}}
	{{===}}
	{{===}}
	{{===}}
	{{===}}
OK
```


sensorreg -s compass -r 0x40 62
--------
 - Command name: `sensorreg -s compass -r 0x40 62`
 - Command to send: `sensorreg -s compass -r 0x40 62`
```
Reading in 62 registers from 0x40:
0x40 = {{0x40}}
0x41 = {{0x41}}
0x42 = {{0x42}}
0x43 = {{0x43}}
0x44 = {{0x44}}
0x45 = {{0x45}}
0x46 = {{0x46}}
0x47 = {{0x47}}
0x48 = {{0x48}}
0x49 = {{0x49}}
0x4A = {{0x4A}}
0x4B = {{0x4B}}
0x4C = {{0x4C}}
0x4D = {{0x4D}}
0x4E = {{0x4E}}
0x4F = {{0x4F}}
0x50 = {{0x50}}
0x51 = {{0x51}}
0x52 = {{0x52}}
0x53 = {{0x53}}
0x54 = {{0x54}}
0x55 = {{0x55}}
0x56 = {{0x56}}
0x57 = {{0x57}}
0x58 = {{0x58}}
0x59 = {{0x59}}
0x5A = {{0x5A}}
0x5B = {{0x5B}}
0x5C = {{0x5C}}
0x5D = {{0x5D}}
0x5E = {{0x5E}}
0x5F = {{0x5F}}
0x60 = {{0x60}}
0x61 = {{0x61}}
0x62 = {{0x62}}
0x63 = {{0x63}}
0x64 = {{0x64}}
0x65 = {{0x65}}
0x66 = {{0x66}}
0x67 = {{0x67}}
0x68 = {{0x68}}
0x69 = {{0x69}}
0x6A = {{0x6A}}
0x6B = {{0x6B}}
0x6C = {{0x6C}}
0x6D = {{0x6D}}
0x6E = {{0x6E}}
0x6F = {{0x6F}}
0x70 = {{0x70}}
0x71 = {{0x71}}
0x72 = {{0x72}}
0x73 = {{0x73}}
0x74 = {{0x74}}
0x75 = {{0x75}}
0x76 = {{0x76}}
0x77 = {{0x77}}
0x78 = {{0x78}}
0x79 = {{0x79}}
0x7A = {{0x7A}}
0x7B = {{0x7B}}
0x7C = {{0x7C}}
0x7D = {{0x7D}}
OK
```


sensorreg -s compass -r 0x04
--------
 - Command name: `sensorreg -s compass -r 0x04`
 - Command to send: `sensorreg -s compass -r 0x04`
``` 
0x04 = {{value}}
```

sensorreg -s compass -r 0x03
--------
 - Command name: `sensorreg -s compass -r 0x03`
 - Command to send: `sensorreg -s compass -r 0x03`
``` 
0x03 = {{value}}
```


sensorreg -s compass -r 0x40 64
--------
 - Command name: `sensorreg -s compass -r 0x40 64`
 - Command to send: `sensorreg -s compass -r 0x40 64`
```
Reading in 64 registers from 0x40:
0x40 = {{0x40}}
0x41 = {{0x41}}
0x42 = {{0x42}}
0x43 = {{0x43}}
0x44 = {{0x44}}
0x45 = {{0x45}}
0x46 = {{0x46}}
0x47 = {{0x47}}
0x48 = {{0x48}}
0x49 = {{0x49}}
0x4A = {{0x4A}}
0x4B = {{0x4B}}
0x4C = {{0x4C}}
0x4D = {{0x4D}}
0x4E = {{0x4E}}
0x4F = {{0x4F}}
0x50 = {{0x50}}
0x51 = {{0x51}}
0x52 = {{0x52}}
0x53 = {{0x53}}
0x54 = {{0x54}}
0x55 = {{0x55}}
0x56 = {{0x56}}
0x57 = {{0x57}}
0x58 = {{0x58}}
0x59 = {{0x59}}
0x5A = {{0x5A}}
0x5B = {{0x5B}}
0x5C = {{0x5C}}
0x5D = {{0x5D}}
0x5E = {{0x5E}}
0x5F = {{0x5F}}
0x60 = {{0x60}}
0x61 = {{0x61}}
0x62 = {{0x62}}
0x63 = {{0x63}}
0x64 = {{0x64}}
0x65 = {{0x65}}
0x66 = {{0x66}}
0x67 = {{0x67}}
0x68 = {{0x68}}
0x69 = {{0x69}}
0x6A = {{0x6A}}
0x6B = {{0x6B}}
0x6C = {{0x6C}}
0x6D = {{0x6D}}
0x6E = {{0x6E}}
0x6F = {{0x6F}}
0x70 = {{0x70}}
0x71 = {{0x71}}
0x72 = {{0x72}}
0x73 = {{0x73}}
0x74 = {{0x74}}
0x75 = {{0x75}}
0x76 = {{0x76}}
0x77 = {{0x77}}
0x78 = {{0x78}}
0x79 = {{0x79}}
0x7A = {{0x7A}}
0x7B = {{0x7B}}
0x7C = {{0x7C}}
0x7D = {{0x7D}}
0x7E = {{0x7E}}
0x7F = {{0x7F}}
OK
```

sensor --sel compass --exectest selftest
--------
 - Command name: `sensor --sel compass --exectest selftest`
 - Command to send: `sensor --sel compass --exectest selftest`
``` 
Executing test 'selftest' on sensor 'compass'...

VA_Compass_Self_P_X: {{===}}
VA_Compass_Self_P_Y: {{===}}
VA_Compass_Self_P_Z: {{===}}

VA_Compass_Self_N_X: {{===}}
VA_Compass_Self_N_Y: {{===}}
VA_Compass_Self_N_Z: {{===}}

VA_Compass_Self_PMN_X: {{===}}
VA_Compass_Self_PMN_Y: {{===}}
VA_Compass_Self_PMN_Z: {{===}}

test-result: {{passed}}
PASS
```


Graphite chip_id  
Graphite rev_id   
Graphite mems_id    
Graphite asic_id 
--------
 - Command name: `sensor --sel gyro --get`
 - Command to send: `sensor --sel gyro --get`
``` 
gyro:
	manu_id = {{===}}
	chip_id = {{chip_id}}
	rev_id = {{rev_id}}
	mems_id = {{mems_id}}
	asic_id = {{asic_id}}
	lpm = {{===}}
	lpm_duty_cycle = {{===}}
	startup_time = {{===}}
	rate = {{===}}
	bw = {{===}}
	datatype = {{===}}
	dynamic_range = {{===}}
	galp = {{===}}
OK
```


Battery Present Voltage (V)
--------
 - Command name: `Battery Present Voltage (V)`
 - Command to send: `pmuadc --sel potomac --read vbat`
```
PMU ADC test
expansion potomac: vbat: {{Battery Present Voltage (mV)}} mV
```


pmuadc --sel potomac --read tbat
--------
 - Command name: `pmuadc --sel potomac --read tbat`
 - Command to send: `pmuadc --sel potomac --read tbat`
```
expansion potomac: tbat: {{NTC}} {{===}}
```


Battery GG Hardware Version
--------
 - Command name: `device -k GasGauge --get hw-version`
 - Command to send: `device -k GasGauge --get hw-version`
``` 
0x{{Battery GG Hardware Version}}
```


Battery GG Firmware Version
--------
 - Command name: `device -k GasGauge --get fw-version`
 - Command to send: `device -k GasGauge --get fw-version`
``` 
0x{{Battery GG Firmware Version}}
```

device -k GasGauge --get chem-id
--------
 - Command name: `device -k GasGauge --get chem-id`
 - Command to send: `device -k GasGauge --get chem-id`
``` 
0x{{chemId}}
```


device -k GasGauge --e test_checksum
--------
 - Command name: `device -k GasGauge --e test_checksum`
 - Command to send: `device -k GasGauge --e test_checksum`
``` 
Control Status: {{===}}
Chem Calculated Checksum = {{Static Chem ID CheckSum}}
Chem Stored Checksum = {{===}}
Chem Checksum match.
CHEM PASS
Static Calculated Checksum = {{Static Chem DF CheckSum}}
Static Stored Checksum = {{===}}
Checksum match.
PASS
```


Battery Qmax
--------
 - Command name: `device -k GasGauge --get chem-capacity`
 - Command to send: `device -k GasGauge --get chem-capacity`
```
{{Battery Cell 0 Qmax}}mAh
```

Battery FCC Range
--------
 - Command name: `device -k GasGauge --get full-capacity`
 - Command to send: `device -k GasGauge --get full-capacity`
```
{{Battery FCC Range}}mAh
```

Battery NCC
--------
 - Command name: `device -k GasGauge --get nominal-capacity`
 - Command to send: `device -k GasGauge --get nominal-capacity`
```
{{Battery NCC}}mAh
```


camisp --i2cread 1 0x18 0x0000 2 2
--------
 - Command name: `camisp --i2cread 1 0x18 0x0000 2 2`
 - Command to send: `camisp --i2cread 1 0x18 0x0000 2 2`
``` 
{{===/(0x[0-9a-fA-F]+)/}}
Pass
```



