#!/usr/bin/python
import errno
import os
import re
import termios
import time
import sys

def constructRxCL( current, current2 ):
    RXCL_VERSION = 2
    RXCL_LEN = 16

    rxcl = []

    rxcl.append((RXCL_VERSION & 0xFF00) >> 8)
    rxcl.append((RXCL_VERSION & 0xFF))

    rxcl.append(int(current, 16))
    rxcl.append(int(current2, 16))

    for x in range(0, 11):
        rxcl.append(0)

    checksum = 0
    for x in rxcl:
        checksum += x

    checksum *= -1
    checksum &= 0xFF

    rxcl.append(checksum)

    assert len(rxcl) == RXCL_LEN

    sys.stdout.write("sysconfig write -k RxCL -v ")

    for x in rxcl:
#        sys.stdout.write("0x%02X" % x + " ")
        sys.stdout.write("%02X" % x)

    sys.stdout.write("\n")

    return rxcl


assert len(sys.argv) == 3

constructRxCL(sys.argv[1], sys.argv[2])

