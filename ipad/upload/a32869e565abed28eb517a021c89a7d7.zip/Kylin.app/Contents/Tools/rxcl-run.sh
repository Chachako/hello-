curr=$(./rxcl-readnvm | cut -c11-15)

echo Raw value:
echo $curr

echo
echo Sysconfig write command:
python3 rxcl-generate.py $curr

