----------------------------Overlay Info-----------------------
OverlayVersion = "27.1.6.0"
ProductCode = "QF"
ProductStage = "P1"
TestStation = "RxCL"
--1. no need set limit

----------------------------UI Info----------------------------
package.path = Directory.home .. '/?.lua;' .. package.path
print(package.path)
require("Extern_Station")
UnitViewCount = TestUnit and #TestUnit or 1
print("------sdfsdf-----")
print(TestUnit)

--UnitViewLayout = {row=0, column=3}
--WinNormalSize = {w=640,h=480}
--AutoStart = true;
--CtrlBtnStatus = 1
--SNFieldStatus = 0
ExitAlert = true;
HaveSysLog = true;
--WillDebug = false
----------------------------Script Info-------------------------

MainScriptPath = "./Main.lua"
LogMainDirectory = Directory.homePublic .. "/Kylin/logs"

