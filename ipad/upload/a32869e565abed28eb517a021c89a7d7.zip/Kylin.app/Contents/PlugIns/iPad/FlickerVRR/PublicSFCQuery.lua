----------------------------------------------------------------------------------
pcall(require("KylinSFC"))

-----------------------------Get SFC Info-----------------------------------------
function jointQueryString(sn, tbQueryKeys)
  if (not sn) or (not tbQueryKeys) then
    return false,nil;
  end

  ---------------------------------------
  local url = app.getGHInfo("SFC_URL")
  print("url",url)

  local stationID = app.getGHInfo("STATION_ID")
  print("stationID",stationID)

  ---------------------------------------
  local strQueryKeys = "";
  for i=1,#tbQueryKeys do
    strQueryKeys = strQueryKeys .. "&p=" .. tbQueryKeys[i];
  end  
  print(strQueryKeys)

  ---------------------------------------
  if (not url) or (not stationID) or (not strQueryKeys) then
    return false,nil;
  end

  ---------------------------------------
  local querystring = url .. "?sn=".. sn .."&c=QUERY_RECORD&tsid=".. string.upper(stationID) .. strQueryKeys
  return true, querystring;
end  


function itemGetSFCInfo(self)
  g_tbSFCInfo = {}
  g_sfcStatus = false

  ---------------------------------------
  local bRt, tbSFCQueryRecord, loginfo = querySFCRecord(sn, self.tbQueryKeys)
  if (not tbSFCQueryRecord) or (not bRt) then
    tbSFCQueryRecord = {}
    local bRtJoint, queryString = jointQueryString(sn, self.tbQueryKeys)
    if (not bRtJoint) or (not queryString) then
      ResultTable.resultCode = bRtJoint;
      return
    end
    print("queryString1129:",queryString)
    ---------------------------------------
    local bRtByURL,sfcRece,loginfo = querySFCRecordByURL(queryString)
    bRt = bRtByURL;
    if not bRt then
      ResultTable.resultCode = bRt;
      return
    end  

    ---------------------------------------
    for tbKey,tbValue in string.gmatch(sfcRece or "","([%l_%w]-)=(.-)%s") do
      tbSFCQueryRecord[tbKey] = tbValue
      print(tbKey,tbValue)
    end
  end
  g_sfcStatus = bRt
  for key,value in pairs(tbSFCQueryRecord) do
    table.insert(g_ResultLog,key .. "=" .. tostring(value))
  end
  ---------------------------------------
  g_tbSFCInfo = tbSFCQueryRecord
  table.insert(g_ResultLog, loginfo);
  ResultTable.resultCode = bRt;
end

----------------------------------------------------------------------------------
function itemUnitProcessCheck(self)
  local bResult, logResult = nil;
  local url = app.getGHInfo("SFC_URL")
  print("url:", url)
  local stationID = app.getGHInfo("STATION_ID")
  print("stationID:", stationID)

  ---------------------------------------
  if (not url) or (not stationID) or (url == nil) or (stationID == nil) or sn == nil then
    ResultTable.resultCode = false
    ResultTable.resultString = "Fail"
    table.insert(g_ResultLog,"url or stationID or SN is nil") 
    return
  end  
  ---------------------------------------
  local Querystring = url .. "?sn=".. sn .."&c=QUERY_RECORD&tsid=".. string.upper(stationID) .."&p=unit_process_check"
  print(Querystring)

  local bRt,sfcRet,loginfo = querySFCRecordByURL(Querystring)
  if not bRt then
    ResultTable.resultCode = bRt;
    ResultTable.resultString = loginfo or "Fail";
    return
  end  

  ---------------------------------------
  if (not sfcRet) or (sfcRet == nil) or (sfcRet == "nil") then
    ResultTable.resultCode = false
    ResultTable.resultString = "Fail"
    table.insert(g_ResultLog,"query sfc fail by URL") 
    return
  end   

  ---------------------------------------
  table.insert(g_ResultLog,sfcRet) 
  sfcRet = string.match(sfcRet or "","unit_process_check=(.+)")

  local apNetworkStatus = app.getGHInfo("SFC_QUERY_UNIT_ON_OFF")
  if (string.match(apNetworkStatus or " ",self.set[1]) and true or false) then
    bResult = true
    logResult = "By Pass!"
  else
    if sfcRet == nil then
      bResult = false
      logResult = "no valid data"
    elseif (string.match(sfcRet or " ","OK") and true or false) then
      bResult = true
      logResult = sfcRet
    elseif (string.match(sfcRet or " ","Goto different") and true or false) then  
      bResult = false
      logResult = sfcRet
    elseif (string.match(sfcRet or " ","Over fail count") and true or false) then  
      bResult = false
      logResult = sfcRet
    else
      bResult = false
      logResult = sfcRet
    end
  end
  ResultTable.resultCode = bResult
  ResultTable.resultString = logResult
end 
----------------------------------------------------------------------------------
