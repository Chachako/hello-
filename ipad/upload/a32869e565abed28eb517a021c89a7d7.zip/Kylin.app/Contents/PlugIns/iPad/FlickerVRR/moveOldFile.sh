#!/bin/sh
a="kevin test"
echo $a
echo "Start:"


cd "/Users/gdlocal";
rm ./ADCL.bin;
echo "move ADCL.bin";
rm ./binFiles/ADCL_2wd.bin;
echo "move binFiles/ADCL_2wd.bin";
rm ./binFiles/ADCL_0wd.bin;
echo "move binFiles/ADCL_0wd.bin";
rm ./binFiles/ADCL_singlePRC_0wd.bin;
echo "move binFiles/ADCL_singlePRC_0wd.bin";
rm ./binFiles/ADCL_singlePRC_2wd.bin;
echo "move binFiles/ADCL_singlePRC_2wd.bin";
rm -rf ./binFiles;
echo "move binFiles";
