--  package.path = Directory.home .. '/?.lua;' .. package.path
--  local frameInfoPath = Directory.home.."/Iomfb"
--  local zipframeInfoPath = Directory.home .. "/iomfb.zip"
--  local osCmd1 = "rm "..frameInfoPath
--  local osCmd2 = "rm "..zipframeInfoPath
--  os.execute(osCmd1)
--  os.execute(osCmd2)

rtRecv = [[
Key  | Type | Data
SrNm |  STR | DLXVX01FJMJG

]]
sn = string.match(rtRecv or "","%|%s+STR%s+%|%s+(%w+)" )

print(sn)