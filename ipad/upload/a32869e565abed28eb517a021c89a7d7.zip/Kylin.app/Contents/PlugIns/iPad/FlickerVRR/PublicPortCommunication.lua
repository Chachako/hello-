-----------------------------------Port Communication Module-----------------------------------
print("load and do Serial Port Communication script...");

local bStatus, ip = pcall(require, "serial");
if bStatus and ip then
  print("require serial success!");
else
  print("require serial fail:", ip);
  return;
end

bStatus, ip = pcall(require, "utils");
if bStatus and ip then
  print("require utils success!");
else
  print("require utils fail:", ip);
  return;
end

function doDiagsCmd(anCmd, endCode, recvtimeOut)
  if iPadSerial == nil then 
    table.insert(ResultLog, "Error info: iPadSerial is Null!")
    return nil, nil
  end

  if not anCmd then
    table.insert(ResultLog, "Error info: anCmd is nil!")
    return nil, nil
  end

  local sendTimes = 0
  local rtSend, rtRecv, rtCode, errorLog, bReSend = nil, nil, nil, nil
  repeat
    rtSend = iPadSerial:send(anCmd, 10)
    local startTime = utils.timeStart()
    local sendStatus = (rtSend==0) and "Success" or "Fail"
    local sendFormat = string.format("send[%s:%s]:%s", sendStatus, tostring(rtSend), anCmd or "cmd empty\n")
    local sendLog =  "["..utils.timestamp().."]:"..sendFormat
    table.insert(ResultLog, sendLog)

    local strEndCode = endCode or ":-) "
    local timeOut = recvtimeOut or 10
    if rtSend == 0 then
      rtRecv, rtCode = iPadSerial:recv(strEndCode, timeOut)
      local endTime = utils.timeEnd(startTime)
      local recvStatus = (rtRecv and "Success" or "Fail")
      local recvFormat = string.format("recv[%s:%s]:%s", recvStatus, tostring(rtCode), rtRecv or "no data\n")
      local recvLog = "["..utils.timestamp().."]:".. recvFormat
      table.insert(ResultLog, recvLog)
      table.insert(ResultLog, "[recv:finish]")
    end
    sendTimes = sendTimes + 1
    errorLog = string.sub(rtRecv or "",-256)
    bReSend = string.match(errorLog or "","ommand%s+\'.-\'%s+not%s+found")
  until(sendTimes >= 2 or (not bReSend))

  return rtSend, rtRecv
end


-------------------------------------------------
function sendDiagsCmd(anCmd)
  if iPadSerial == nil then 
    table.insert(ResultLog, "Error info: iPadSerial is Null!")
    return nil, nil
  end

  if not anCmd then
    table.insert(ResultLog, "Error info: anCmd is nil!")
    return nil, nil
  end

  local rtSend = iPadSerial:send(anCmd, 25)
  local sendStatus = (rtSend==0) and "Success" or "Fail"
  local sendFormat = string.format("send[%s:%s]:%s", sendStatus, tostring(rtSend), anCmd or "cmd empty\n")
  local sendLog =  "["..utils.timestamp().."]:"..sendFormat
  table.insert(ResultLog, sendLog)

  return rtSend
end  


-------------------------------------------------
function receiveDiagsCmd(endCode, recvtimeOut)
  local rtRecv, rtCode = nil, nil
  local strEndCode = endCode or ":-) "
  local timeOut = recvtimeOut or 50

  rtRecv, rtCode = iPadSerial:recv(strEndCode, timeOut)
  local recvStatus = (rtRecv and "Success" or "Fail")
  local recvFormat = string.format("recv[%s:%s]:%s", recvStatus, tostring(rtCode), rtRecv or "no data\n")
  local recvLog = "["..utils.timestamp().."]:".. recvFormat
  table.insert(ResultLog, recvLog)
  table.insert(ResultLog, "[recv:finish]")
  return rtRecv
end  
-----------------------------------Private Function ----------------------------
--g_nanocom = nil
--function doDiagsCmd(anCmd, endCode, recvtimeOut)
--  if iPadSerial == nil then 
--    table.insert(ResultLog, "Error info: iPadSerial is Null!")
--    return nil, nil
--  end

--  if not anCmd then
--    table.insert(ResultLog, "Error info: anCmd is nil!")
--    return nil, nil
--  end

--  if not iPadPath then
--    table.insert(ResultLog, "Error info: iPadPath is Null!")
--    return nil, nil
--  end

--  if g_nanocom == nil then
--    local nanocomCmd = Directory.tools .. "/nanocom -h -d " .. iPadPath
--    g_nanocom = message.open(nanocomCmd)
--    local rtNanocom, rtCode = message.recv(g_nanocom, "New channel opened on port", 10, 0)
--    print("rtNanocom",rtNanocom)
--    app.wait(500)
--    msgNetCat = message.open("nc -4 -u localhost 31337")
--  end

--  --local sendTimes = 0
--  local rtSend, rtRecv, rtCode, errorLog, bReSend = nil, nil, nil, nil
--  -- repeat
--  --print("test start 0713-2")
--  rtSend = message.send(msgNetCat,anCmd, 25, 0) --iPadSerial:send(anCmd, 25)
--  local startTime = utils.timeStart()
--  local sendStatus = rtSend and "Success" or "Fail"
--  local sendFormat = string.format("send[%s:%s]:%s", sendStatus, tostring(rtSend), anCmd or "cmd empty\n")
--  local sendLog =  "["..utils.timestamp().."]:"..sendFormat
--  table.insert(ResultLog, sendLog)

--  local strEndCode = {"\\[\\w+\\:\\w+\\]\\s+\\:\\-\\)\\s+"}
--  local timeOut = recvtimeOut or 50
--  --if rtSend == 0 then
--  rtRecv, rtCode = message.recv(msgNetCat, strEndCode, timeOut, 0) --iPadSerial:recv(strEndCode, timeOut)
--  --print("test start 0713-3")
--  local endTime = utils.timeEnd(startTime)
--  local recvStatus = (rtRecv and "Success" or "Fail")
--  local recvFormat = string.format("recv[%s:%s]:%s", recvStatus, tostring(rtCode), rtRecv or "no data\n")
--  local recvLog = "["..utils.timestamp().."]:".. recvFormat
--  table.insert(ResultLog, recvLog)
--  table.insert(ResultLog, "[recv:finish]")
--  --  end
--  -- sendTimes = sendTimes + 1
--  -- errorLog = string.sub(rtRecv or "",-256)
--  --bReSend = string.match(errorLog or "","ommand%s+\'.-\'%s+not%s+found")
--  -- until(sendTimes >= 2 or (not bReSend))

--  return rtSend, rtRecv
--end


---------------------------------------------------
--function sendDiagsCmd(anCmd)
--  if iPadSerial == nil then 
--    table.insert(ResultLog, "Error info: iPadSerial is Null!")
--    return nil, nil
--  end

--  if not anCmd then
--    table.insert(ResultLog, "Error info: anCmd is nil!")
--    return nil, nil
--  end

--  local rtSend = message.send(msgNetCat,anCmd, 25, 0)  --iPadSerial:send(anCmd, 25)
--  local sendStatus = rtSend and "Success" or "Fail"
--  local sendFormat = string.format("send[%s:%s]:%s", sendStatus, tostring(rtSend), anCmd or "cmd empty\n")
--  local sendLog =  "["..utils.timestamp().."]:"..sendFormat
--  table.insert(ResultLog, sendLog)

--  return rtSend
--end  


---------------------------------------------------
--function receiveDiagsCmd(endCode, recvtimeOut)
--  local rtRecv, rtCode = nil, nil
--  local strEndCode = {"\\[\\w+:\\w+\\]\\s+:\\-\\)\\s+"}
--  local timeOut = recvtimeOut or 50

--  rtRecv, rtCode = message.recv(msgNetCat, strEndCode, timeOut, 0) --iPadSerial:recv(strEndCode, timeOut)
--  local recvStatus = (rtRecv and "Success" or "Fail")
--  local recvFormat = string.format("recv[%s:%s]:%s", recvStatus, tostring(rtCode), rtRecv or "no data\n")
--  local recvLog = "["..utils.timestamp().."]:".. recvFormat
--  table.insert(ResultLog, recvLog)
--  table.insert(ResultLog, "[recv:finish]")
--  return rtRecv
--end  

-------------------------------------------------
function doOrionCmd(anCmd, endCode, recvtimeOut)
  if OrionSerial == nil then 
    table.insert(ResultLog, "Error info: OrionSerial is Null!")
    return nil, nil
  end

  if not anCmd then
    table.insert(ResultLog, "Error info: anCmd is nil!")
    return nil, nil
  end

  local rtRecv, rtCode = nil, nil
  local rtSend = OrionSerial:send(anCmd, 25)
  local startTime = utils.timeStart()
  local sendStatus = (rtSend==0) and "Success" or "Fail"
  local sendFormat = string.format("send[%s:%s]:%s", sendStatus, tostring(rtSend), anCmd or "cmd empty\n")
  local sendLog =  "["..utils.timestamp().."]:"..sendFormat
  table.insert(ResultLog, sendLog)

  local strEndCode = endCode or {[[>]],[[Ping\sHigh]]}
  local timeOut = recvtimeOut or 50
  if rtSend == 0 then
    rtRecv, rtCode = OrionSerial:recv(strEndCode, timeOut)
    local endTime = utils.timeEnd(startTime)
    local recvStatus = (rtRecv and "Success" or "Fail")
    local recvFormat = string.format("recv[%s:%s]:%s", recvStatus, tostring(rtCode), rtRecv or "no data\n")
    local recvLog = "["..utils.timestamp().."]:".. recvFormat
    table.insert(ResultLog, recvLog)
    table.insert(ResultLog, "[recv:finish]")
  end

  return rtSend, rtRecv
end


-------------------------------------------------
function doFixtureCmd(anCmd, endCode, recvtimeOut)
  if fixtureSerial == nil then 
    table.insert(ResultLog, "Error info: fixtureSerial is Null!")
    return nil, nil
  end

  if not anCmd then
    table.insert(ResultLog, "Error info: anCmd is nil!")
    return nil, nil
  end

  local rtRecv, rtCode = nil, nil
  local rtSend = fixtureSerial:send(anCmd, 25)
  local startTime = utils.timeStart()
  local sendStatus = (rtSend==0) and "Success" or "Fail"
  local sendFormat = string.format("send[%s:%s]:%s", sendStatus, tostring(rtSend), anCmd or "cmd empty\n")
  local sendLog =  "["..utils.timestamp().."]:"..sendFormat
  table.insert(ResultLog, sendLog)

  local strEndCode = endCode or {[[\*_\*\s?]]}
  local timeOut = recvtimeOut or 50
  if rtSend == 0 then
    rtRecv, rtCode = fixtureSerial:recv(strEndCode, timeOut)
    local endTime = utils.timeEnd(startTime)
    local recvStatus = (rtRecv and "Success" or "Fail")
    local recvFormat = string.format("recv[%s:%s]:%s", recvStatus, tostring(rtCode), rtRecv or "no data\n")
    local recvLog = "["..utils.timestamp().."]:".. recvFormat
    table.insert(ResultLog, recvLog)
    table.insert(ResultLog, "[recv:finish]")
  end

  return rtSend, rtRecv
end

-------------------------------------------------
function sendFixtureCmd(anCmd)
  if fixtureSerial == nil then 
    table.insert(ResultLog, "Error info: fixtureSerial is Null!")
    return nil, nil
  end

  if not anCmd then
    table.insert(ResultLog, "Error info: anCmd is nil!")
    return nil, nil
  end

  local rtRecv, rtCode = nil, nil
  local rtSend = fixtureSerial:send(anCmd, 25)
  local startTime = utils.timeStart()
  local sendStatus = (rtSend==0) and "Success" or "Fail"
  local sendFormat = string.format("send[%s:%s]:%s", sendStatus, tostring(rtSend), anCmd or "cmd empty\n")
  local sendLog =  "["..utils.timestamp().."]:"..sendFormat
  table.insert(ResultLog, sendLog)

  return rtSend
end
-------------------------------------------------
function doMikeyCmd(anCmd, endCode, recvtimeOut)
  if mikeySerial == nil then 
    table.insert(ResultLog, "Error info: mikeySerial is Null!")
    return nil, nil
  end

  if not anCmd then
    table.insert(ResultLog, "Error info: anCmd is nil!")
    return nil, nil
  end

  local rtRecv, rtCode = nil, nil
  local rtSend = mikeySerial:send(anCmd, 25)
  local startTime = utils.timeStart()
  local sendStatus = (rtSend==0) and "Success" or "Fail"
  local sendFormat = string.format("send[%s:%s]:%s", sendStatus, tostring(rtSend), anCmd or "cmd empty\n")
  local sendLog =  "["..utils.timestamp().."]:"..sendFormat
  table.insert(ResultLog, sendLog)

  local strEndCode = endCode or "]"
  local timeOut = recvtimeOut or 50
  if rtSend == 0 then
    rtRecv, rtCode = mikeySerial:recv(strEndCode, timeOut)
    local endTime = utils.timeEnd(startTime)
    local recvStatus = (rtRecv and "Success" or "Fail")
    local recvFormat = string.format("recv[%s:%s]:%s", recvStatus, tostring(rtCode), rtRecv or "no data\n")
    local recvLog = "["..utils.timestamp().."]:".. recvFormat
    table.insert(ResultLog, recvLog)
    table.insert(ResultLog, "[recv:finish]")
  end

  return rtSend, rtRecv
end


-------------------------------------------------
function doProxCmd(anCmd, endCode, recvtimeOut)
  if proxSerial == nil then 
    table.insert(ResultLog, "Error info: proxSerial is Null!")
    return nil, nil
  end

  if not anCmd then
    table.insert(ResultLog, "Error info: anCmd is nil!")
    return nil, nil
  end

  local rtRecv, rtCode = nil, nil
  local rtSend = proxSerial:send(anCmd, 25)
  local startTime = utils.timeStart()
  local sendStatus = (rtSend==0) and "Success" or "Fail"
  local sendFormat = string.format("send[%s:%s]:%s", sendStatus, tostring(rtSend), anCmd or "cmd empty\n")
  local sendLog =  "["..utils.timestamp().."]:"..sendFormat
  table.insert(ResultLog, sendLog)

  local strEndCode = endCode or 6
  local timeOut = recvtimeOut or 50
  if rtSend == 0 then
    rtRecv, rtCode = proxSerial:recv(strEndCode, timeOut)
    local endTime = utils.timeEnd(startTime)
    local recvStatus = (rtRecv and "Success" or "Fail")
    local recvFormat = string.format("recv[%s:%s]:%s", recvStatus, tostring(rtCode), rtRecv or "no data\n")
    local recvLog = "["..utils.timestamp().."]:".. recvFormat
    table.insert(ResultLog, recvLog)
    table.insert(ResultLog, "[recv:finish]")
  end

  return rtSend, rtRecv
end

-------------------------------------------------
function doMotorCmd(anCmd, endCode, recvtimeOut)
  if motorSerial == nil then 
    table.insert(ResultLog, "Error info: motorSerial is Null!")
    return nil, nil
  end

  if not anCmd then
    table.insert(ResultLog, "Error info: anCmd is nil!")
    return nil, nil
  end

  local rtRecv, rtCode = nil, nil
  local rtSend = motorSerial:send(anCmd, 25)
  local startTime = utils.timeStart()
  local sendStatus = (rtSend==0) and "Success" or "Fail"
  local sendFormat = string.format("send[%s:%s]:%s", sendStatus, tostring(rtSend), anCmd or "cmd empty\n")
  local sendLog =  "["..utils.timestamp().."]:"..sendFormat
  table.insert(ResultLog, sendLog)

  local strEndCode = endCode or "%\r"
  local timeOut = recvtimeOut or 50
  if rtSend == 0 then
    rtRecv, rtCode = motorSerial:recv(strEndCode, timeOut)
    local endTime = utils.timeEnd(startTime)
    local recvStatus = (rtRecv and "Success" or "Fail")
    local recvFormat = string.format("recv[%s:%s]:%s", recvStatus, tostring(rtCode), rtRecv or "no data\n")
    local recvLog = "["..utils.timestamp().."]:".. recvFormat
    table.insert(ResultLog, recvLog)
    table.insert(ResultLog, "[recv:finish]")
  end

  return rtSend, rtRecv
end
------------------------------------------------------------------------------------------------

function doPotassiumCmd(anCmd,endStr,timeout)
  
  if not anCmd or not endStr then
    table.insert(ResultLog, "No Command or endStr")
    return nil
    end
  
  local potassiumMsg = message.open(anCmd)
  local rtSend = potassiumMsg and 0 or 1
  local sendSuccess = rtSend == 0 and "Success" or "Fail"
  local sendFormat = string.format("send[%s:%s]:%s",sendSuccess,rtSend, anCmd or "cmd empty\n")
  local sendLog =  "["..utils.timestamp().."]:"..sendFormat
  table.insert(ResultLog, sendLog)
  
  timeout = timeout or 10
  local rtRecv,rtCode = message.recv(potassiumMsg, endStr, timeout, 0)

    local recvStatus = (rtRecv and "Success" or "Fail")
  local recvFormat = string.format("recv[%s:%s]:%s", recvStatus, tostring(rtCode), rtRecv or "no data\n")
  local recvLog = "["..utils.timestamp().."]:".. recvFormat
  table.insert(ResultLog, recvLog)
  table.insert(ResultLog, "[recv:finish]")
  
  if potassiumMsg then
    message.close(potassiumMsg)
    potassiumMsg = nil
  end
  
  return rtRecv
end

function doScorpiusCmd(anCmd, endCode, recvtimeOut)
  if ScorpiusSerial == nil then 
    table.insert(ResultLog, "Error info: ScorpiusSerial is Null!")
    return nil, nil
  end

  if not anCmd then
    table.insert(ResultLog, "Error info: anCmd is nil!")
    return nil, nil
  end

  local rtRecv, rtCode = nil, nil
  local rtSend = ScorpiusSerial:send(anCmd, 25)
  local startTime = utils.timeStart()
  local sendStatus = (rtSend==0) and "Success" or "Fail"
  local sendFormat = string.format("send[%s:%s]:%s", sendStatus, tostring(rtSend), anCmd or "cmd empty\n")
  local sendLog =  "["..utils.timestamp().."]:"..sendFormat
  table.insert(ResultLog, sendLog)

  local strEndCode = endCode or {[[\*_\*\s?]]}
  local timeOut = recvtimeOut or 50
  if rtSend == 0 then
    rtRecv, rtCode = ScorpiusSerial:recv(strEndCode, timeOut)
    local endTime = utils.timeEnd(startTime)
    local recvStatus = (rtRecv and "Success" or "Fail")
    local recvFormat = string.format("recv[%s:%s]:%s", recvStatus, tostring(rtCode), rtRecv or "no data\n")
    local recvLog = "["..utils.timestamp().."]:".. recvFormat
    table.insert(ResultLog, recvLog)
    table.insert(ResultLog, "[recv:finish]")
  end

  return rtSend, rtRecv
end

function doImpedanceCmd(anCmd, endCode, recvtimeOut)
  if impedanceSerial == nil then 
    table.insert(ResultLog, "Error info: impedanceSerial is Null!")
    return nil, nil
  end

  if not anCmd then
    table.insert(ResultLog, "Error info: anCmd is nil!")
    return nil, nil
  end

  local sendTimes = 0
  local rtSend, rtRecv, rtCode, errorLog, bReSend = nil, nil, nil, nil
  repeat
    rtSend = impedanceSerial:send(anCmd, 25)
    local startTime = utils.timeStart()
    local sendStatus = (rtSend==0) and "Success" or "Fail"
    local sendFormat = string.format("send[%s:%s]:%s", sendStatus, tostring(rtSend), anCmd or "cmd empty\n")
    local sendLog =  "["..utils.timestamp().."]:"..sendFormat
    table.insert(ResultLog, sendLog)

    local strEndCode = endCode or "B11:"
    local timeOut = recvtimeOut or 50
    if rtSend == 0 then
      rtRecv, rtCode = impedanceSerial:recv(strEndCode, timeOut)
      local endTime = utils.timeEnd(startTime)
      local recvStatus = (rtRecv and "Success" or "Fail")
      local recvFormat = string.format("recv[%s:%s]:%s", recvStatus, tostring(rtCode), rtRecv or "no data\n")
      local recvLog = "["..utils.timestamp().."]:".. recvFormat
      table.insert(ResultLog, recvLog)
      table.insert(ResultLog, "[recv:finish]")
    end
    sendTimes = sendTimes + 1
    errorLog = string.sub(rtRecv or "",-256)
    bReSend = string.match(errorLog or "","ommand%s+\'.-\'%s+not%s+found")
  until(sendTimes >= 2 or (not bReSend))

  return rtSend, rtRecv
end





