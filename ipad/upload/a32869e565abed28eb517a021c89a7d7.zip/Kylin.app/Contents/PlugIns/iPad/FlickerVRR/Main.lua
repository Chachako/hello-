-----------------------------script init info-----------------------------
package.cpath = Directory.frameworks .. '/?.dylib;' .. package.cpath
package.path = Directory.config .. '/?.lua;' .. package.path
package.path = Directory.plugins .. '/Library/?.lua;' .. package.path
package.path = Directory.plugins .. '/iPad/Public/?.lua;' .. package.path
package.path = Directory.homePublic .. '/?.lua;' .. package.path


utils = require("utils") 
app = require("app")
sfc = require("sfc") 
cba = require("cba") -- for network
scb = require("scb")
ca310 = require("ca310") 
serial = require("serial")
pcall(require,"CheckSerialPort")
pcall(require,"PublicPortCommunication")
pcall(require,"PublicWriteCB")
pcall(require,"PublicNetWorkCB")
pcall(require,"PublicWritePDCA")
pcall(require,"PublicSFCQuery")

local message = require("message")  -- for OS mode
pcall(require,"InstantPudding")   -- for PDCA
require("Config")
ScriptVersion = OverlayVersion

TestItems = {}
TestItemResult = {} --store test item result
PDCAInfo = {} --store Attribute and Parametri
Attribute = {}
Parametric = {}
ProbeArray = {} --store Stobes objects
FlckrJEITAValue = {} 
SpectrumValue = {} 
local T = {"L7", "L9" , "L5", "L1", "L3"}


----------------------------------Control CA-310 Measure Flicker----------------------------------------
local localCSVFile = Directory.homePublic .. "/Kylin/Spectrum.csv"
local TPattern = {"P7", "P9" , "P5", "P1", "P3"}
local function file_exists(path)
  local file = io.open(path, "rb")
  if file then 
    file:close()
    return true
  end
  return false
end

function CA3105ProbesFirstInit()
  Ca200 = ca310.newCCa200() --new a object 20160421
  local rtCode = Ca200:SetConfiguration(1,"12345", 0)--1 usb 5 stobes
  rtCode, Cas = Ca200:get_Cas()
  rtCode, Ca = Cas:get_ItemOfNumber(1) 
  rtCode = Ca:put_DisplayMode(8)
  rtCode, OutputProbes = Ca:get_OutputProbes()
  rtCode = OutputProbes:AddAll()
  return rtCode
  --local errStr = SDK_GetLocalizedErrorMsgFromErrorCode(err)
  --print(errStr)
end

local function MeasureStrobeSNs(i)
  local rtCode, ProbeObj = OutputProbes:get_Item(i)
  ProbeArray[i] = ProbeObj
  rtCode, SerialNO = ProbeObj:get_SerialNO()
  return SerialNO
end  

local function MeasureFlickerVals(PatternName)
  local existFile = file_exists(localCSVFile) 
  if not existFile then
    local snFile1 = assert(io.open(localCSVFile,'w'))
    snFile1:write("UnitSN" .. ",")
    snFile1:write("Lcm_SN" .. ",")
    snFile1:write("CFG" .. ",")
    snFile1:write("StrobeSN" .. ",")
    snFile1:write("Pattern" .. ",")
    snFile1:write("areaID" .. ",")
    snFile1:write("FlckrJEITAFre" .. ",")
    snFile1:write("FlckrJEITA" .. ",")
    for i=6,64 do 
      snFile1:write(i .. "HZ,")
    end
    snFile1:write("\n")
    snFile1:close()
  end
  TSpectrumValue = {}
  iSpectMax = -100
  maxJeitaFrequency = 0
  maxJEITA = -100
  maxJEITAFre = 0
  maxJEITALoc = 0
  FlckrJEITAValue = nil
  SpectrumValue = nil
  FlckrJEITAValue = {} 
  SpectrumValue = {}
  HZ12Spectrum = nil
  HZ24Spectrum = nil
  HZ60Spectrum = nil
  HZ12Spectrum = {}
  HZ24Spectrum = {}
  HZ60Spectrum = {}
  rTValue = true
  rtCode, Ca = Cas:get_Item(1) 
  rtCode, Memory = Ca:get_Memory()
  rtCode = Ca:Measure()
  print("Measure")
  print(rtCode)
  for i=1,5 do
    rtCode, RJEITA = ProbeArray[i]:get_RJEITA()
    rtCode, FlckrJEITA = ProbeArray[i]:get_FlckrJEITA()
    FlckrJEITAValue[i] = FlckrJEITA
    for j=6,64 do
      local rtCode, Spectrum = ProbeArray[i]:GetSpectrum(j)
      print("12:",ProbeArray[i]:GetSpectrum(12))
      print("24:",ProbeArray[i]:GetSpectrum(24))
      _,HZ12Spectrum[i] = ProbeArray[i]:GetSpectrum(12)
      _,HZ24Spectrum[i] = ProbeArray[i]:GetSpectrum(24)
      _,HZ60Spectrum[i] = ProbeArray[i]:GetSpectrum(60)
      table.insert(TSpectrumValue,Spectrum)
      if Spectrum > iSpectMax then
        iSpectMax = Spectrum
        maxJeitaFrequency = j
      end
    end
    local snFile1 = assert(io.open(localCSVFile,'a'))
    snFile1:write(scanSN .. ",")
    snFile1:write(lcm_sn .. ",")
    snFile1:write(cfg .. ",")
    snFile1:write(tostring(MeasureStrobeSNs(i)) .. ",")
    PatternName = string.gsub(PatternName,"%s+%b[]","")
    snFile1:write(tostring(PatternName) .. ",")
    snFile1:write(TPattern[i] .. ",")
    snFile1:write(tostring(maxJeitaFrequency) .. ",")
    snFile1:write(tostring(FlckrJEITA) .. ",")
    for i=1,59,1 do
      print(TSpectrumValue[i])
      snFile1:write(TSpectrumValue[i] ..",")
    end
    snFile1:write("\n")
    snFile1:close()
    TSpectrumValue  = {}

    SpectrumValue[i] = maxJeitaFrequency
    if FlckrJEITA > maxJEITA then
      maxJEITA = FlckrJEITA
      maxJEITAFre = maxJeitaFrequency
      maxJEITALoc = 2*(i-1) + 1
    end
  end

  if not rtCode then
    rTValue = false
  end
  return rTValue
end

-----------------------------system callback function-----------------------
function onEnter(args)
  print("onEnter:")
--   msgTcprelay =  message.open("pwd")
--  print("aaa")
--  rtRecv = message.recv(msgTcprelay, { [[127.0.0.1:\d{1,} for service rsync]] }, 3, 0)
--  print(rtRecv)

  pcall(require,"Extern_Station")
  pcall(require,"Extern_Debug")
  for i=1, #TestItems do
    if TestItems[i].limitSet ~= nil then
      testitemName = TestItems[i].name
      if string.match(testitemName or "","L5") and string.match(testitemName or "","G127") then
        TestItems[i].limitSet.upper = -55
      end 
      if string.match(testitemName or "","L5") and string.match(testitemName or "","G63") then
        TestItems[i].limitSet.upper = -52
      end 
      if string.match(testitemName or "","Freq") then
        TestItems[i].limitSet.upper = "NA"
      end

      TestItems[i].name = testitemName .. "  [" .. tostring(TestItems[i].limitSet.lower) .. "," .. tostring(TestItems[i].limitSet.upper) .. "]"
    end 
  end  
  return TestItems
end

function onInit(args)
  os.execute("/usr/local/bin/tcprelay --portoffset 12000 telnet rsync &")
  print("onInit:" .. args.unitIndex)

--  initRtCode = CA3105ProbesFirstInit()
end

function onStart(args)
  args_unitIndex = args.unitIndex
  app.updateInitInfo() --Init UI
  finalResult = true
  stopTest = false
  STOP_FAIL = false
  for i=1, #TestItems do
    while true do
      if STOP_FAIL and (not TestItems[i].ESCAPE_STOP_FAIL) then 
        break
      end
      ResultTable = nil
      ResultTable = {}
      ResultLog = nil
      ResultLog = {}
      TestItems[i].number = i
      local bRt, rtInfo = pcall(TestItems[i]:action(), TestItems[i])
      if bRt then
        local anInfo = "Script exception:" .. rtInfo .. "\n"
        ResultTable.resultString=anInfo
        ResultTable.log=anInfo
      end

      if ResultTable.resultCode==false then
        finalResult = false;
        --break;
      end
      ResultTable.number = TestItems[i].number
      ResultTable.name = TestItems[i].name
      if ResultTable.resultString == nil then 
        ResultTable.resultString = ResultTable.resultCode and "Pass" or "Fail"
      end
      ResultTable.lowLimit = ResultTable.lowLimit or ""
      ResultTable.UpLimit = ResultTable.UpLimit or ""
      ResultTable.failMsg = ResultTable.resultCode and "Pass" or string.sub(ResultTable.resultString,0,510)
      ResultTable.SubTestItem = ResultTable.SubTestItem or ""
      ResultTable.SubSubTestItem = ResultTable.SubSubTestItem or ""
      Parametric={subName={low=ResultTable.lowLimit, value=ResultTable.resultString, high=ResultTable.UpLimit, result=ResultTable.resultCode, priority=0, testName=ResultTable.name,SubTestItem=ResultTable.SubTestItem,SubSubTestItem=ResultTable.SubSubTestItem,failMsg=ResultTable.failMsg,TestUnit="N/A"}}
      table.insert(PDCAInfo,Parametric)
      table.insert(ResultLog,(ResultTable.resultCode and "Pass  " or "Fail  ") .. ResultTable.resultString)

      local tmpLog = table.concat(ResultLog,"\n")
      ResultTable.log = tmpLog
      app.updateItemResult(ResultTable)
--    if stopTest or stopFail then
--      break
--    end
      if ResultTable.resultCode == false and TestItems[i].stopFailFlag == true then
        STOP_FAIL = true
      end  
      break
    end
  end
  aResultString = finalResult and "Pass" or "Fail"
  app.updateFinalResult({resultCode=finalResult, resultString=aResultString, sn = sn})
  if msgTelnet then
    message.close(msgTelnet)
    msgTelnet = nil;
  end
  if msgTcprelay then
    message.close(msgTcprelay)
    msgTcprelay = nil;
  end
  PDCAInfo={}
  Attribute = {}
  Parametric = {}
end


function onStop(args)
  if msgTelnet then
    message.close(msgTelnet)
    msgTelnet = nil;
  end
end

function onExit(args)
  os.execute("pkill -9 tcprelay &")
  os.execute("pkill -9 telnet &")
  stopTest = true
  if msgTelnet then
    message.close(msgTelnet)
    msgTelnet = nil;
  end
  if msgTcprelay then
    message.close(msgTcprelay)
    msgTcprelay = nil
  end 
  ProbeArray = nil
end
function onMessage(args)
  if string.len(args.sn) == 12 then
    scanSN = args.sn
  end
end

-----------------------------Public common function--------------------------
local function getTestItemResult()----get before test item result,if one test item is fail, the finalResult is false
  local finalResult = true
  for k,v in pairs(TestItemResult) do
    if v == false then
      finalResult = false;
    end
  end 
  return finalResult
end

local function compareAandB(strValue,LowerLimit,upperLimit,containEqual)
  if strValue == nil or tonumber(strValue) == nil  then
    return false
  end
  if tonumber(strValue) == -999 then
    return false
  end

  local BValue = false
  if (upperLimit == "NA" or upperLimit == "N/A") and (LowerLimit == "NA" or LowerLimit == "N/A") then
    BValue =  true
  elseif LowerLimit == "NA" or LowerLimit == "N/A" then
    local strValueNum, upperLimitNum = tonumber(strValue), tonumber(upperLimit)
    if containEqual == "true" or containEqual == "True" or containEqual == "TRUE" or containEqual == true then
      BValue = strValueNum <= upperLimitNum and true or false
    else
      BValue = strValueNum < upperLimitNum and true or false
    end
  elseif upperLimit == "NA" or upperLimit == "N/A" then
    local strValueNum, LowerLimitNum = tonumber(strValue), tonumber(LowerLimit)
    if containEqual == "true" or containEqual == "True" or containEqual == "TRUE" or containEqual == true then
      BValue = strValueNum >= LowerLimitNum and true or false
    else
      BValue = strValueNum > LowerLimitNum and true or false
    end 
  else
    local strValueNum, LowerLimitNum, upperLimitNum = tonumber(strValue), tonumber(LowerLimit), tonumber(upperLimit)
    if containEqual == "true" or containEqual == "True" or containEqual == "TRUE" or containEqual == true then
      BValue = strValueNum <= upperLimitNum and strValueNum >= LowerLimitNum and true or false
    else
      BValue = strValueNum < upperLimitNum and strValueNum > LowerLimitNum and true or false
    end
  end
  return BValue
end

--------------------------------------------------------------------------------
function updateMCUToPDCA(testItemName,displayMCU)
  local itemNameStr = testItemName
  local subitemTable = {"MCU Bootloader Ver", "MCU Firmware Ver", "Indx Rate FrameCnt","LIVE InvFrm Bins","LIVE RptPol Bins","LIVE CurrCaVal","LIVE MaxCaVal","LIVE Log","NVM InvFrm Bins","NVM RptPol Bins","NVM TotalFrmCt","NVM IdxLastBad","NVM PwrOnCnt","NVM PPOrSDPwrOffs","NVM PolPwrOffs","NVM MaxCaVal","NVM Log","NVM Last","NVM ConsPolPwrOffs","NVM GoodPwrOffs"}
  local bResult = true
  local failTestItem = ""

  for key,subItemName in pairs(subitemTable) do 
    local lowValue = "NA"
    local hightValue = "NA" 
    if not string.match(displayMCU or "",subItemName)then
      return false,subItemName
    end

    if string.match(subItemName or "","Bins") then
      local testValueT={}
      testValueT[1],testValueT[2],testValueT[3] = string.match(displayMCU or "",subItemName .. ".-%s+(.-)%s+(.-)%s+(.-)%c")

      for key1,value1 in pairs(testValueT) do 
        testItemName1 = subItemName .. tostring(key1)
        Parametric={subName={low=lowValue, value=tostring(tonumber(value1)), high=highValue, result=bResult, priority=0, testName=itemNameStr,SubTestItem=testItemName1,SubSubTestItem="",failMsg=tostring(tonumber(value1)),TestUnit="N/A"}}
        table.insert(PDCAInfo,Parametric)

      end
    else
      local testValue = string.match(displayMCU or "",subItemName .. ".-%s+(.-)%c")
      if string.match(subItemName or "","Indx Rate FrameCnt")then
        testValue = string.match(displayMCU or "","Live Histogram%c+Indx Rate FrameCnt.-%s+%d+%s+%d+%s+(.-)%s")
        lowValue = 1;  highValue = "NA"
      end

      if string.match(subItemName or "","LIVE Log") or string.match(subItemName or "","NVM Log") then
        lowValue = 1;  highValue = 1
      elseif  string.match(subItemName or "","NVM PwrOnCnt")  then
        lowValue = 2;  highValue = "NA"
      else
        lowValue = "NA";  highValue = "NA"
      end
      local bResult1 = compareAandB(testValue,lowValue,hightValue,true)  
      if not bResult1 then
        bResult = false
        failTestItem = failTestItem .. subItemName .. " || "
      end
      Parametric={subName={low=lowValue, value=tostring(tonumber(testValue)), high=highValue, result=bResult1, priority=0, testName=itemNameStr,SubTestItem=subItemName,SubSubTestItem="",failMsg=tostring(tonumber(testValue)),TestUnit="N/A"}}
      table.insert(PDCAInfo,Parametric)
    end
  end
  return bResult,failTestItem
end


local function doOsCmd(anCmd,endStr, timeout)
  table.insert(ResultLog,"Send:")
  message.send(msgTelnet,anCmd,5,0)
  table.insert(ResultLog,anCmd .. "\n")
  table.insert(ResultLog,"Receive:")
  rtRecv,rtIndex = message.recv(msgTelnet,{endStr}, timeout or 10, 0)
  table.insert(ResultLog,rtRecv .. "")
  return rtRecv
end

function reBootUnit()
  message.send(msgTelnet, "exit\n", 5, 0)
  message.close(msgTelnet)
  msgTelnet = nil;
  path = "/dev/cu.usbmodem14632"
  config = {baudRate=115200, parity="N", dataBits=8, stopBits=1, flowControl=0}
  iPadSerial = serial.open(path,0)
  serial.config(iPadSerial,config)

  for i=1,100 do
    local rtSend3 = iPadSerial:send("\n", 5) 
    rtRecv, rtOK = iPadSerial:recv({"login:"},3)

    local rtSend4 = iPadSerial:send("root\n", 5) 
    rtRecv, rtOK = iPadSerial:recv({"Password:"},3)

    local rtSend5 = iPadSerial:send("alpine\n", 5) 
    rtRecv, rtOK = iPadSerial:recv({"root#"},3)

    if rtOK >= 0 then
      print("login OK!")
      break;
    end
  end

  local rtSend = iPadSerial:send("reboot\n", 5) 
  table.insert(ResultLog,"reboot")
  rtRecv = iPadSerial:recv({"Darwin"},30)
  print(rtRecv)

  for i=1,30 do
    local rtSend = iPadSerial:send("\n", 5) 
    rtRecv, rtOK = iPadSerial:recv({"login: "},3)
    if rtOK >= 0 then
      print("reboot OK!")
      break;
    end
  end

  iPadSerial:close()

  app.wait(900)
  for i=1,4 do
    app.wait(5000)
    msgTelnet = message.open("/usr/local/bin/telnet localhost 12023")
    table.insert(ResultLog,"telnet localhost 12023")
    recOpenTel,rtCode = message.recv(msgTelnet, {"login:"}, 15, 0)
    print("Kevin testaqaaa")
    print(recOpenTel)
    print(rtCode) 
    if rtCode>=0 then
      break
    end  
  end  
  rtRecv = doOsCmd("root\n","Password:")
  rtRecv = doOsCmd("alpine\n","root#")
  if string.match(rtRecv or "","root#") then
    return true
  else 
    return false
  end  

end  


function loginTest()
  if msgTelnet then
    message.close(msgTelnet)
    msgTelnet = nil
  end
  for i=1,20 do
    app.wait(1000)
    msgTelnet = message.open("/usr/local/bin/telnet localhost 12023")
    table.insert(ResultLog,"telnet localhost 12023")
    recOpenTel,rtCode = message.recv(msgTelnet, {"login:"}, 5, 0)
    print("Kevin testaqaaa")
    print(recOpenTel)
    print(rtCode) 
    if rtCode>=0 then
      rtRecv = doOsCmd("root\n","Password:")
      rtRecv = doOsCmd("alpine\n","root#")
      break
    end  
    message.close(msgTelnet)
    msgTelnet = nil
  end 
end  
-----------------------------Test Items--------------------------
--1. test item "SN"


--2. test item "StartTime"
local function StartTime(self)
  startT = os.date("%Y-%m-%d %H:%M:%S")
  stime = os.time()
  local bResult = startT and true or false
  local logResult = bResult and startT or "No data"
  ResultTable.resultCode = bResult
  ResultTable.resultString = logResult
end
--table.insert(TestItems, {name="StartTime", action=StartTime})

--3. test item "Enter OS Mode"
local function EnterOSMode(self)

  local bResult1 = false
  for i = 1,5 do
    msgTelnet = message.open("/usr/local/bin/telnet localhost 12023")
    table.insert(ResultLog,"telnet localhost 12023")
    local recOpenTel, _ = message.recv(msgTelnet, {"login:"}, 5, 0)
    local rtRecv = doOsCmd("root\n","Password:")
    rtRecv = doOsCmd("alpine\n","root#")
    bResult1 = string.match(rtRecv or " ","root#") and true or false
    if bResult1 then
      break
    end
    app.wait(3000)
  end

  local rtRecv1,aLog = doOsCmd("setbright -mAmps 22.9\n","root#")
  --local rtRecv1 = doOsCmd("setbright -mAmps 22.9\n","root#")
  local bResult2 = string.match(rtRecv1 or " ","Setting mAmps") and true or false
  print("-----bResult1: ", tostring(bResult1))
  print("-----bResult2: ", tostring(bResult2))
  local bResult = bResult1 and bResult2
  local logResult = bResult and "Pass" or "No data"
  STOP_FAIL = not bResult
  ResultTable.resultCode = bResult
  ResultTable.resultString = logResult
end
table.insert(TestItems, {name="Enter OS Mode", action=EnterOSMode, set = {"root#"}})


local function itemSN(self)
  local rtRecv = doOsCmd("/usr/local/bin/sysconfig read -k SrNm\n","root#")
  sn = string.match(rtRecv or "","%|%s+STR%s+%|%s+(%w+)" )
  local bResult = sn and (string.len(sn) == 17 or string.len(sn) == 12) and true or false
  sn = bResult and sn or "No data"
  ARM_ByPass = false
  local rtRecv1 = doOsCmd("sysconfig read --key=CFG#\n","root#")
  local arm_config_read = string.match(rtRecv1 or "", "J3%w*%-%w*/%*/%*/%d*/%w*%-%w*(%-R)")
  ARM_ByPass = arm_config_read and true or false
--  STOP_FAIL = not bResult
  ResultTable.resultCode = bResult
  ResultTable.resultString = bResult and sn or "No Data"
end
table.insert(TestItems, {name="SN", action=itemSN})

function itemBurnLCM(self)
  -- body
  DUTSn_70bytes = {}
  MTDO_56bytes = {}
  DUTSn17_cmd_recv = doOsCmd("tconctl -C eeprom 0x00B0 17\n","root# ") 
  DUTSn53_cmd_recv = doOsCmd("tconctl -C eeprom 0x00C7 53\n","root# ") 
  MTDO_cmd_recv = doOsCmd("tconctl -C eeprom 0x4000 56\n","root# ") 
  
  print("-----------DUTSn17_cmd_recv111111-----------")
  print("aaa",DUTSn17_cmd_recv)
  print("bbb",DUTSn53_cmd_recv)
  print("ccc",MTDO_cmd_recv)
  
--  DUTSn17_cmd_recv = string.match(DUTSn17_cmd_recv or "", "0x00B0 17([%s%S]+)iPad:~ root#") 
--  DUTSn53_cmd_recv = string.match(DUTSn53_cmd_recv or "", "0x00C7 53([%s%S]+)%\niPad:~root#") 
--  MTDO_cmd_recv =  string.match(MTDO_cmd_recv or "", "0x4000 56([%s%S]+)%\niPad:~root#")
 DUTSn17_cmd_recv = string.match(DUTSn17_cmd_recv or "", "0x00B0 17([%s%S]+)iPad:~ root#") 
  DUTSn53_cmd_recv = string.match(DUTSn53_cmd_recv or "", "0x00C7 53([%s%S]+)iPad:~ root#") 
  MTDO_cmd_recv =  string.match(MTDO_cmd_recv or "", "0x4000 56([%s%S]+)iPad:~ root#")
  print("111",DUTSn17_cmd_recv)
  print("222",DUTSn53_cmd_recv)
  print("333",MTDO_cmd_recv)
  
   if DUTSn17_cmd_recv:match("%w") == nil or DUTSn53_cmd_recv:match("%w") == nil or MTDO_cmd_recv:match("%w")== nil then
    ResultTable.resultCode = false
    ResultTable.resultString = "OS command No Data"
    return
  end

  print("-----------DUTSn17_cmd_recv-----------")
  print(DUTSn17_cmd_recv)
  print(DUTSn53_cmd_recv)
  print(MTDO_cmd_recv)
  
  
  
  
  
 
  for strValue in string.gmatch(MTDO_cmd_recv or "","(%w%w)%s+") do
    print("strValue",strValue)
    table.insert(MTDO_56bytes,"0x" .. strValue)
  end

  local lcm70Str = ""
  for w in string.gmatch(DUTSn17_cmd_recv,"(%w%w)%s+") do
    lcm70Str = lcm70Str .. toASCII("0x"..tostring(w))
    table.insert(DUTSn_70bytes,"0x" .. w)
  end
  for w in string.gmatch(DUTSn53_cmd_recv,"(%w%w)%s+") do
    lcm70Str = lcm70Str .. toASCII("0x"..tostring(w))
    table.insert(DUTSn_70bytes,"0x" .. w)
  end

  local Syslcm = "sysconfig write -k LCM# -v " .. lcm70Str .. "\n"
  doOsCmd(Syslcm,"root#")
  local rtRecv = doOsCmd("sysconfig read -k LCM#\n","root# ") 

  local bResult = (not string.find(rtRecv or "","Error")) and true or false
  ResultTable.resultCode = bResult

end

--table.insert(TestItems, {name="Burn LCM", action=itemBurnLCM})

function itemBurnMtDO(self )
  
  if MTDO_cmd_recv:match("%w") == nil then
    ResultTable.resultCode = false
    ResultTable.resultString = "OS Burn MtDOcommand No Data"
    return
  end
  local cfgcmd = doOsCmd("sysconfig read -k CFG#\n","root# ")
  print("--sysconfig read -k CFG#---",cfgcmd) 
--  local rule = string.match(cfgcmd or "","STR.+%/(%w%-%w)")
  local rule = string.match(cfgcmd or "","STR.+%/.-%-([%w%-]+)")
--  local rule = string.match(rule_1 or "","%w+%-(.-)")
  print("--key CFG11111#---",rule)
  -- -- -- CFG# | STR  | J518-P1/*/*/10039/SOP-P18NEB-SOP2
  local syscfg = {}
  syscfg = {"P18NEW-SOP1","P18NEB-SOP2","P18NGB-SOP3","P18NGW-SOP4","P18NCB-M1","P18NEB-M2","P18NEB-M2A","P18NEW-M3","P18NDW-M4","P18NFW-M5","P18NCW-M6","P18NDW-2","P18NDW-1","P18NDW-3","P18NGB-NV1","P18NCB-NM","P18NDW-5","P17GB-SOP1","P18NDW-4","P18NDW-5A","P17GW-SOP2"} 
  local resultCFG = false
  for index,value in ipairs(syscfg) do
    if value == rule then
      resultCFG = true
      break
    end
  end
  local sumMtDO = 0
  local sumDutSN = 0
  for key,value in pairs(MTDO_56bytes) do
    print("--MTDO_56bytes_value---",value)
    sumMtDO = sumMtDO + tonumber(value)  
  end
  for key,value in pairs(DUTSn_70bytes) do
    sumDutSN = sumDutSN + tonumber(value)
  end

  local Header = {"0xF0", "0x9F", "0x93", "0xBA", "0x00", "0x02"}
  local Tail = {"0x00", "0x00", "0x00"}

  local syscfg_124bytes = {}
  local syscfg_128bytes = {}

  local MDTO_6Bytes = {}
  local MDTO_48Bytes = {}

  for i = 1, 6 do 
    table.insert(MDTO_6Bytes, MTDO_56bytes[i])
  end

  for i = 7, 54 do 
    table.insert(MDTO_48Bytes, MTDO_56bytes[i])
  end
  for i,v in ipairs(Header) do
    table.insert(syscfg_124bytes, v)
  end   

  for i,v in ipairs(DUTSn_70bytes) do
    table.insert(syscfg_124bytes, v)
  end 

  for i,v in ipairs(MDTO_48Bytes) do
    table.insert(syscfg_124bytes, v)
  end 


  local sum_syscfg_124bytes = MTDO_array_sum(syscfg_124bytes)
  local checksum = (256 - (sum_syscfg_124bytes % 256)) % 256

  for i,v in ipairs(syscfg_124bytes) do
    table.insert(syscfg_128bytes, v)
  end 
  table.insert(syscfg_128bytes, string.format("0x%02X", checksum))

  for i,v in ipairs(Tail) do
    table.insert(syscfg_128bytes, v)
  end

  for i=1, #syscfg_128bytes do
    print("---syscfg_128bytes_all---",syscfg_128bytes[i])
  end

  local sum_syscfg_128bytes = MTDO_array_sum(syscfg_128bytes)

  local finalMtDO = ""
  for i=1, #syscfg_128bytes do
    finalMtDO = finalMtDO .. " " .. string.match(syscfg_128bytes[i] or "","0x(%w+)")
  end
  finalMtDO = string.sub(finalMtDO or "",2)
  print("finalMtDO")
  print(finalMtDO)

  if not resultCFG then
    if (sumMtDO % 256 ~= 0) then
      print("sumMtDO",sumMtDO%256)
      ResultTable.resultCode = false
      ResultTable.resultString = "varify sum(MTDO)%256 FAIL"
      return
    end

    if tonumber(sumDutSN%256)~=tonumber(MTDO_56bytes[55]) then
      print("sumDutSN",sumDutSN%256)
      print("MTDO_56bytes[55]",MTDO_56bytes[55])
      ResultTable.resultCode = false
      ResultTable.resultString = "Verify SUM(DUTSN) % 256 == MTDO[55] Fail"
      return
    end

    if (sum_syscfg_128bytes % 256) ~= 0 then
      print("syscfg_128bytes",syscfg_128bytes)
      print("sum_syscfg_128bytes",sum_syscfg_128bytes)
      ResultTable.resultCode = false
      ResultTable.resultString = "sum_syscfg_128bytes FAIL"
      return
    end
  end
  if string.len(finalMtDO) < 256 then
    ResultTable.resultCode = false
     ResultTable.resultString = "MtDO size error"
    return
    end
  doOsCmd("sysconfig delete -k MtDO\n","root# ") 
  MTDO_cmd = "sysconfig write -k MtDO -v \""..finalMtDO .. "\"" .. "\n"
  doOsCmd(MTDO_cmd,"root# ") 
  local mtdo_result = doOsCmd("sysconfig read -k MtDO\n","root# ") 
  local bResult = (not string.find(mtdo_result or "","Error")) and true or false
  ResultTable.resultCode = bResult
end

--table.insert(TestItems, {name="Burn MtDO", action=itemBurnMtDO})

function backlight(self)
  os.execute("chmod 777 " .. Directory.tools .. "/lum_test")
  local msgback = message.open("sh")
  local recOpenTel,rtCode = message.recv(msgRxCL, {"3.2$ "}, 5, 0)
  local back_generate = "spawn rsync -av " .. Directory.tools .. "/lum_test" .. " rsync://root@localhost:10873/root/AppleInternal/Diags/Debug/\n"
  message.send(msgback,back_generate,5,0)
  table.insert(ResultLog,"Send:")
  table.insert(ResultLog,back_generate)
  rtRecv,rtIndex = message.recv(msgback,{"Password:"}, timeout or 1, 0)
  table.insert(ResultLog,"Receive:")
  table.insert(ResultLog,rtRecv .. "")
  message.send(msgback,"alpine\n",5,0)
  rtRecv,rtIndex = message.recv(msgback,{"3.2$ "}, timeout or 1, 0)
  table.insert(ResultLog,"Receive:")
  table.insert(ResultLog,rtRecv .. "")
  
  os.execute("interact")
  os.execute("spawn telnet 127.0.0.1 10023")
  
  local back_recv_generate = "spawn rsync -av " .. Directory.tools .. "/lum_test" .. " rsync://root@localhost:10873/root/AppleInternal/Diags/Debug/\n"
  message.send(msgback,back_generate,5,0)
  table.insert(ResultLog,"Send:")
  table.insert(ResultLog,back_generate)
  rtRecv,rtIndex = message.recv(msgback,{"Password:"}, timeout or 1, 0)
  table.insert(ResultLog,"Receive:")
  table.insert(ResultLog,rtRecv .. "")
  message.send(msgback,"alpine\n",5,0)
  rtRecv,rtIndex = message.recv(msgback,{"3.2$ "}, timeout or 1, 0)
  table.insert(ResultLog,"Receive:")
  table.insert(ResultLog,rtRecv .. "")
  
  doOsCmd("cd /AppleInternal/Diags/Debug/lum_test/Scripts/\n","iPad")
  doOsCmd("ls -l\n","iPad")
  doOsCmd("chmod 777 dump.sh\n","iPad")
  doOsCmd("chmod 777 lum_test.py\n","iPad")
  doOsCmd("chmod 777 main.sh\n","iPad")
  doOsCmd("nohup /AppleInternal/Diags/Debug/lum_test/Scripts/main.sh &\n","iPad")
  doOsCmd("\n","iPad")
  os.execute("spawn killall tcprelay")
end

function RxCLTest(self)
  os.execute("chmod 777 " .. Directory.tools .. "/rxcl-generate.py")
  os.execute("chmod 777 " .. Directory.tools .. "/rxcl-readnvm")
  os.execute("chmod 777 " .. Directory.tools .. "/rxcl-run.sh")

  doOsCmd("ls /AppleInternal/\n","root#")

  local msgRxCL = message.open("sh")
  local recOpenTel,rtCode = message.recv(msgRxCL, {"3.2$ "}, 5, 0)
  local rxcl_generate = "rsync -av " .. Directory.tools .. "/rxcl-generate.py" .. " rsync://root@localhost:12873/root/AppleInternal\n"
  message.send(msgRxCL,rxcl_generate,5,0)
  table.insert(ResultLog,"Send:")
  table.insert(ResultLog,rxcl_generate)
  rtRecv,rtIndex = message.recv(msgRxCL,{"Password:"}, timeout or 1, 0)
  table.insert(ResultLog,"Receive:")
  table.insert(ResultLog,rtRecv .. "")
  message.send(msgRxCL,"alpine\n",5,0)
  rtRecv,rtIndex = message.recv(msgRxCL,{"3.2$ "}, timeout or 1, 0)
  table.insert(ResultLog,"Receive:")
  table.insert(ResultLog,rtRecv .. "")



  rxcl_generate = "rsync -av " .. Directory.tools .. "/rxcl-readnvm" .. " rsync://root@localhost:12873/root/AppleInternal\n"
  message.send(msgRxCL,rxcl_generate,5,0)
  table.insert(ResultLog,"Send:")
  table.insert(ResultLog,rxcl_generate)
  rtRecv,rtIndex = message.recv(msgRxCL,{"Password:"}, timeout or 1, 0)
  table.insert(ResultLog,"Receive:")
  table.insert(ResultLog,rtRecv .. "")
  message.send(msgRxCL,"alpine\n",5,0)
  rtRecv,rtIndex = message.recv(msgRxCL,{"3.2$ "}, timeout or 1, 0)
  table.insert(ResultLog,"Receive:")
  table.insert(ResultLog,rtRecv .. "")

  rxcl_generate = "rsync -av " .. Directory.tools .. "/rxcl-run.sh" .. " rsync://root@localhost:12873/root/AppleInternal\n"
  message.send(msgRxCL,rxcl_generate,5,0)
  table.insert(ResultLog,"Send:")
  table.insert(ResultLog,rxcl_generate)
  rtRecv,rtIndex = message.recv(msgRxCL,{"Password:"}, timeout or 1, 0)
  table.insert(ResultLog,"Receive:")
  table.insert(ResultLog,rtRecv .. "")
  message.send(msgRxCL,"alpine\n",5,0)
  rtRecv,rtIndex = message.recv(msgRxCL,{"3.2$ "}, timeout or 1, 0)
  table.insert(ResultLog,"Receive:")
  table.insert(ResultLog,rtRecv .. "")

  message.close(msgRxCL)
  doOsCmd("ls /AppleInternal/\n","root#")
  doOsCmd("chmod 777 /AppleInternal/rxcl-generate.py\n","root#")
  doOsCmd("chmod 777 /AppleInternal/rxcl-readnvm\n","root#")
  doOsCmd("chmod 777 /AppleInternal/rxcl-run.sh\n","root#")
  doOsCmd("diagstool bootargs -a allow-raw-i2c=1\n","root#")
  doOsCmd("nvram boot-command=\"fsboot\"\n","root#",2)
  reBootUnit()

  doOsCmd("cd /AppleInternal/\n","root#")
  local rtRecv = doOsCmd("./rxcl-run.sh\n","root#")
  doOsCmd("cd /\n","root#")
  local cmdSysconfig = string.match(rtRecv or "", "RxCL %-v%s+(%w+)" )
  local cmdSys = "sysconfig write -k RxCL -v " .. cmdSysconfig .. "\n"
  doOsCmd(cmdSys,"root#")

--  local cmd1 = doOsCmd("tconctl -C eeprom 0x00B0 17\n","root#") or ""
--  local cmd2 = doOsCmd("tconctl -C eeprom 0x00C7 53\n","root#") or ""
--  local lcm70Str = ""
--  for w in string.gmatch(cmd1,"%w%w") do
--    lcm70Str = lcm70Str .. toASCII("0x"..tostring(w))
--  end
--  for w in string.gmatch(cmd2,"%w%w") do
--    lcm70Str = lcm70Str .. toASCII("0x"..tostring(w))
--  end
--  local Syslcm = "sysconfig write -k LCM# -v " .. lcm70Str .. "\n"
--  local Syslcm = doOsCmd(Syslcm,"root#") or ""

  local bResult = (string.find(rtRecv or "","sysconfig") and not string.find(rtRecv or "","Error")) and true or false
--  doOsCmd("rm -rf /AppleInternal/rxcl-generate.py\n","root#")
--  doOsCmd("rm -rf /AppleInternal/rxcl-readnvm\n","root#")
--  doOsCmd("rm -rf /AppleInternal/rxcl-run.sh\n","root#")

  doOsCmd("diagstool bootargs -r allow-raw-i2c=1\n","root#")
  doOsCmd("ls /AppleInternal/\n","root#")
--  if bResult then


  doOsCmd("nvram boot-command=\"diags\"\n","root#",2)
  doOsCmd("reboot\n","root#",2)
  app.wait(3000)

--    path = "/dev/cu.usbmodem14732"
  config = {baudRate=115200, parity="N", dataBits=8, stopBits=1, flowControl=0}
  iPadSerial = serial.open(path,0)
  serial.config(iPadSerial,config)

  local _,rtRecvDiags = doDiagsCmd("diags\n","] :-)", 50.0)
--    local bRe = string.match(rtRecvDiags or "", ":%-%)") and true or false
--    end
--  doOsCmd("reboot\n","root#",2)
  doDiagsCmd("nvram --set boot-command fsboot\n")
  doDiagsCmd("nvram --save\n")
--    end
--  doOsCmd("reboot\n","root#",2)

  ResultTable.resultCode = bResult

end

table.insert(TestItems, {name="RxCLTest", action=RxCLTest})

function varify_MTDO54(MTDO_56bytes)
  local sum_MTDO = MTDO_array_sum(MTDO_56bytes)
  return (sum_MTDO % 256) == 0
end
function toASCII(keyStr)

  keyStr = tostring(keyStr) or ""

  ASCIIDict = {
    ["0x30"]="0",["0x31"]="1",["0x32"]="2",["0x33"]="3",["0x34"]="4",["0x35"]="5",["0x36"]="6",["0x37"]="7",["0x38"]="8",["0x39"]="9",
    ["0x41"]="A",["0x42"]="B",["0x43"]="C",["0x44"]="D",["0x45"]="E",["0x46"]="F",["0x47"]="G",
    ["0x48"]="H",["0x49"]="I",["0x4A"]="J",["0x4B"]="K",["0x4C"]="L",["0x4D"]="M",["0x4E"]="N",
    ["0x4F"]="O",["0x50"]="P",["0x51"]="Q",["0x52"]="R",["0x53"]="S",["0x54"]="T",
    ["0x55"]="U",["0x56"]="V",["0x57"]="W",["0x58"]="X",["0x59"]="Y",["0x5A"]="Z",
  }

  if keyStr:match("0x") == nil then
    keyStr = "0x" .. keyStr
  end

  return ASCIIDict[keyStr] or ""
end



function MTDO_array_sum(array)
  local sum = 0
  for i,v in ipairs(array) do
    if string.match(v or "", "0x") == nil then
      v = "0x" .. v
    end  
    sum = sum + tonumber(v)
  end
  return sum
end


local function itemWritePDCA(self)
  local Ltable = {}
  apiRely, uutHandle = ip.UUTStart()
  if ip.success(apiRely) then
    reply=ip.amIOkay(uutHandle,sn)
    successBool = ip.success(reply)
    print(successBool)
    if not successBool then
      DoneError = ip.reply_getError(apiRely)
      bResult = false
      logResult = DoneError
      local testResult = {number=self.number, name=self.name, resultCode=bResult, resultString=logResult, log=aLog}
      cancelreply = ip.UUTCancel(uutHandle)
      ip.reply_destroy(cancelreply)
      ip.reply_destroy(reply)
      ip.UID_destroy(uutHandle)
      return testResult;
    end
  else
    DoneError = ip.reply_getError(apiRely)
    bResult = false
    logResult = DoneError
    local testResult = {number=self.number, name=self.name, resultCode=bResult, resultString=logResult, log=aLog} 
    cancelreply = ip.UUTCancel(uutHandle)
    ip.reply_destroy(cancelreply)
    ip.reply_destroy(reply)
    ip.UID_destroy(uutHandle)
    return testResult;
  end
  --------Attribute--------
  swversion=ScriptVersion
  bRt = puddingAttributeWithKeyName(uutHandle, IPTable.IP_ATTRIBUTE_STATIONSOFTWAREVERSION, swversion)
  swname="Kylin"
  bRt = puddingAttributeWithKeyName(uutHandle, IPTable.IP_ATTRIBUTE_STATIONSOFTWARENAME, swname)
  bRt = puddingAttributeWithKeyName(uutHandle, IPTable.IP_ATTRIBUTE_SERIALNUMBER, sn)
  bRt = puddingAttributeWithKeyName(uutHandle, "limitsversion", "10.10")
  stime = os.time()
  etime = stime + 35
  APIcheck = ip.setStartTime(uutHandle, stime);
  APIcheck = ip.setStopTime( uutHandle, etime);

  for key,val in pairs(PDCAInfo) do
    print("kevin test enter for ")
    for key1,val1 in pairs(val) do
      if key1 == "subName" then
        val1.testName = string.gsub(val1.testName,"%s+%b[]","")
        returnValue=puddingWithParametricDataForTestItem(val1.low,val1.value,val1.high,val1.result,val1.priority,val1.testName,val1.SubTestItem,val1.SubSubTestItem,val1.failMsg,val1.TestUnit,uutHandle)
        print(returnValue)
      else
        bRt = puddingAttributeWithKeyName(uutHandle, key1, val1)
      end
      if key1==nil and val1==nil then
        break
      end
    end
    --end
  end
  NameInPDCA = "RxCL"
  endT = os.date("%Y-%m-%d %H:%M:%S")
  --FilePath = app.getLogFile({resultString="", sn = sn})

  local FilePath = Directory.homePublic .. "/Kylin/" .. sn .. "_" .. endT .. "_" .. "Spectrum.csv"
  os.rename(localCSVFile,FilePath)
  local LogFilePath = app.getLogFile({resultString=finalResult, sn = sn})
  local localZipPath = Directory.homePublic .. "/Parametric.zip"

  os.execute("zip -j " .. Directory.homePublic .. "/Parametric.zip " .. "\"" .. FilePath .. "\"" .. " " .. "\"" .. LogFilePath .. "\"")


  zipPath = LogFilePath:gsub(".txt",".zip")
  os.execute("mv " .. localZipPath .. " " .. "\"" .. zipPath .. "\"")

  print("FilePath")
  print(FilePath)
  if NameInPDCA ~= nil and FilePath ~= nil then
    apiRely = ip.addBlob(uutHandle, NameInPDCA,zipPath);
    if not ip.success(apiRely) then
      print("enter ~~addBlob~~ip.success(apiRely)")
      local errorInfo = ip.reply_getError(apiRely);
      print(errorInfo)
      ip.reply_destroy(apiRely);
      ip.UUTCancel(uutHandle);
      ip.UID_destroy(uutHandle);
      return "addBlob--ip.success(apiRely) fail";
    end
  end
  comVal=puddingCommit(sn,finalResult)
  print("Kevin test 0708")
  print(comVal)
  if not comVal then
    print("Write pdca puddingCommit fail")
  end
  local bResult = comVal
  local logResult =  bResult and "Pass" or "Fail"
  ResultTable.resultCode = bResult
  ResultTable.resultString = logResult
end
table.insert(TestItems, {name="Upload Insight", action=itemWritePDCA, ESCAPE_STOP_FAIL=true}) 

