----------------------------For debug----------------------------
print "debug start..."

--local function itemTestFuncDebug(self)
--  print("itemTestFuncDebug")
--  return true;
--end
----table.insert(testItems, {name="SN Read", action=itemTestFunc, parameter="parameter"})
--testItems[1].name = "SN Debug"
--testItems[1].action = itemTestFuncDebug

--print(testItems[1].name)

--local function itemTestFunc2(self)
--  print(self.name)
--  testResult = {number=self.number, name=self.name, result="Fail"}
--  app.updateTestResult(testResult);
--end
--testItems[2].action = itemTestFunc2

--TestItems[96].limit.upper = 2.0

--local function tset(self)
--  local rtSend,rtRecv,aLog = doDiagsCmd("ver\n")
--  local _,_,version = string.find(rtRecv or " ", "%((%w*)%)")
--  local bResult = version and true or false
--  version = version or "Not find version info"
--  local testResult = {number=self.number, name=self.name, resultCode=bResult, resultString=version, log=aLog}
--  --local attribute={"ATTRIBUTE BATTERY_SN" = "abd"}
--  app.updateItemResult(testResult);
--  return bResult;
--end
--testItems[24].action = tset

--print("www:" .. package.cpath)

