----------------------------------------------------------------------------------
pcall(require("KylinPDCA"))

function itemWritePDCA(self)
  g_PDCAAttribute[g_PDCABaseAttributeKey.sn] = sn;
  g_PDCAAttribute[g_PDCABaseAttributeKey.limitVersion] = "1.1";
  g_PDCAAttribute[g_PDCABaseAttributeKey.swName] = "Kylin";
  g_PDCAAttribute[g_PDCABaseAttributeKey.swVersion] = ScriptVersion;
  g_PDCAAttribute[g_PDCABaseAttributeKey.stationID] = app.getGHInfo("STATION_ID");

  local tbBlobFile = {}
  local blobName = self.blobName
  blobFilePath = uploadDataToPDCA(self);
  tbBlobFile[blobName] = blobFilePath
  
  local tbAttribute = {}
  tbAttribute = g_PDCAAttribute
  
  local tbResultArray = {}
  for i=1,#g_PDCAParametric do

    local aResult = {}
    local testNameTmp = string.gsub(g_PDCAParametric[i].testName,"%s+%b[]","")

    aResult = {testName=testNameTmp,subTestName=g_PDCAParametric[i].SubTestItem, subSubTestName=g_PDCAParametric[i].SubSubTestItem};
  
    aResult.lower = g_PDCAParametric[i].low
    if aResult.lower and aResult.lower ~= "NA" and aResult.lower ~= "N/A" then
      aResult.lower = tostring(tonumber(aResult.lower));
    end

    aResult.upper = g_PDCAParametric[i].high
    if aResult.upper and aResult.upper ~= "NA" and aResult.upper ~= "N/A" then
      aResult.upper = tostring(tonumber(aResult.upper));
    end
    
    aResult.units = g_PDCAParametric[i].TestUnit;
    aResult.priority = g_PDCAParametric[i].priority;
    aResult.result = g_PDCAParametric[i].result;

    aResult.value = g_PDCAParametric[i].value and tostring(tonumber(g_PDCAParametric[i].value));
    if aResult.value == "nil" and aResult.lower and aResult.upper then
      aResult.value = "NA"
      if g_PDCAParametric[i].failMsg then
        local failMessage = ": Upper Limit=" .. aResult.upper .. ", Lower Limit=" .. aResult.lower;
        failMessage = failMessage .. ", Measured Value=NA(can't get measured value, execute test cmd exception.)";
        g_PDCAParametric[i].failMsg = g_PDCAParametric[i].failMsg .. failMessage;
      end
    end
    
    if (aResult.lower==nil) or (aResult.upper==nil) then
      aResult.value = nil;
    end

    if aResult.result==false or aResult.result==0 then
      aResult.message = g_PDCAParametric[i].failMsg;
    end
        
    table.insert(tbResultArray, aResult)

  end
  local nFinalResult = g_finalResult;

  ---------------------------------------------------------------------------------------------
  print("------------Attribute------------------\n")
  for key, value in pairs(g_PDCAAttribute) do
    print("key:" .. tostring(key) .. " type:" .. type(key));
    print("value:" .. tostring(value) .. " type:" .. type(value));
  end
  print("----------------------------------------\n")

  print("------------BlobFile------------------\n")
  for key, value in pairs(tbBlobFile) do
    print("key:" .. tostring(key) .. " type:" .. type(key));
    print("value:" .. tostring(value) .. " type:" .. type(value));
  end
  print("----------------------------------------\n")

  for i, v in pairs(tbResultArray) do
    print("------------ResultArray------------------\n")
    print("i:" .. tostring(i) .. " type:" .. type(i));
    print("testName:" .. tostring(v.testName) .. " type:" .. type(v.testName));
    print("subTestName:" .. tostring(v.subTestName) .. " type:" .. type(v.subTestName));
    print("subSubTestName:" .. tostring(v.subSubTestName) .. " type:" .. type(v.subSubTestName));
    print("lower:" .. tostring(v.lower) .. " type:" .. type(v.lower));
    print("upper:" .. tostring(v.upper) .. " type:" .. type(v.upper));
    print("units:" .. tostring(v.units) .. " type:" .. type(v.units));
    print("priority:" .. tostring(v.priority) .. " type:" .. type(v.priority));
    print("result:" .. tostring(v.result) .. " type:" .. type(v.result));
    print("value:" .. tostring(v.value) .. " type:" .. type(v.value));
    print("message:" .. tostring(v.message) .. " type:" .. type(v.message));
    print("----------------------------------------\n")
  end

  print("nFinalResult:" .. tostring(nFinalResult) .. " type:" .. type(nFinalResult));
  ---------------------------------------------------------------------------------------------

  local bRt, loginfo = uploadPDCA(tbAttribute, tbBlobFile, tbResultArray, nFinalResult);
  print("bRt", bRt, "loginfo", loginfo);
  table.insert(g_ResultLog, loginfo);
  ResultTable.resultCode = bRt;
end





