#!/bin/bash

#select sub page 5
tconctl -w 3 0xff 0x5
#VRR according threshold and over
tconctl -w 3 0xf4 0x40 
tconctl -w 3 0xf5 0x00 
 



