#!/bin/sh
a="kevin test"
echo $a
echo "Start:"


cd "/Users/gdlocal";
python ./ADCL_gen_run_v2.py;
echo "creat four binfiles";
mkdir ./binFiles;
echo "creat binFiles";
mv ./ADCL_2wd.bin ./binFiles;
echo "move ADCL_2wd.bin to binFiles";
mv ./ADCL_singlePRC_0wd.bin ./binFiles;
echo "move ADCL_singlePRC_0wd.bin to binFiles";
mv ./ADCL_singlePRC_2wd.bin ./binFiles;
echo "move ADCL_singlePRC_2wd.bin to binFiles";
mv ./ADCL_0wd.bin ./binFiles;
echo "move ADCL_0wd.bin to binFiles";

