#!/bin/bash

echo "usage: ./X497P0FATP_BIST_Beating_aardVark.sh FR1 FrameCount1 FR2 FrameCount2 FR3 FrameCount3 FR4 FrameCount4"
echo "usage: FR1-FR4 should be one of 60,48,40,34.3,30,26.7,24"
echo "usage: FrameCount: hex 0x0 ~ 0xFF"
##----------------------
#divisor	FR(Hz)  			VBlank
#	2		60					0x87 	
#	3		48					0x354 	
#	4		40					0x621		
#	5		34.3				0x8EB	
#	6		30					0xBBA	
#	7		26.7				0xE7F
#	8		24					0x1154	

##----------------------
function SetVBlank {
	case $1 in
	60)
	  VBlankL=0x87
	  VBlankM=0x00
	  Message="60Hz"
	  ;;
	48)
	  VBlankL=0x54
	  VBlankM=0x03
	  Message="48Hz"
	  ;;
	40)
	  VBlankL=0x21
	  VBlankM=0x06
	  Message="40Hz"
	  ;;
	34.3)
	  VBlankL=0xEB
	  VBlankM=0x08
	  Message="34.3"
	  ;;
	30)
	  VBlankL=0xBA
	  VBlankM=0x0B
	  Message="30Hz"
	  ;;
	26.7)
	  VBlankL=0x7F
	  VBlankM=0x0E
	  Message="26.7Hz"
	  ;;
	24)
	  VBlankL=0x54
	  VBlankM=0x11
	  Message="24Hz"
	  ;;
	*)
	  Message="The refresh rate is not supported, default to 60Hz"
	  ;;
	esac
}
	
### frame set 1
SetVBlank $1
echo $Message $2
## BIST_RR setting vertical active 2732 for 120Hz Vtotal = 3029
 #bist_rr[0]
tconctl -w 8	0x11 $VBlankL;
tconctl -w 8	0x12 $VBlankM;
tconctl -w 8	0x13 0x00;

### frame set 2
SetVBlank $3
echo $Message $4
#bist_rr[1]
tconctl -w 8	0x14 $VBlankL;
tconctl -w 8	0x15 $VBlankM;
tconctl -w 8	0x16 0x00;

SetVBlank $5
echo $Message $6
### frame set 3
#bist_rr[2]
tconctl -w 8	0x17 $VBlankL;
tconctl -w 8	0x18 $VBlankM;
tconctl -w 8	0x19 0x00;

SetVBlank $7
echo $Message $8
### frame set 4
#bist_rr[3]
tconctl -w 8	0x1a $VBlankL;
tconctl -w 8	0x1b $VBlankM;
tconctl -w 8	0x1c 0x00;


# bist_rr_frames[0]=count 1
# bist_rr_frames[1]=count 2
# bist_rr_frames[2]=0
# bist_rr_frames[3]=0
tconctl -w 8	0x1d $2;
tconctl -w 8	0x1e $4;
tconctl -w 8	0x1f $6;
tconctl -w 8	0x20 $8;


tconctl -w 8 0x65 0x8b

#mask bist_rr_frames
tconctl -w 8	0x21 0x02;
#enable Bist RR
tconctl -w 8	0x10 0x01; 




