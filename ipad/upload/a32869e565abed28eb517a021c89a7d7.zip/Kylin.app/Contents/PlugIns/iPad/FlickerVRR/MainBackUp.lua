local function SwitchLcd24HZ(self)
  local cmd = "clcdControl --fixed_rr=10\n"
  local rtRecv = doOsCmd(cmd,"root#")
  local bResult = string.match(rtRecv or " ",self.set[1]) and true or false 
  local logResult = bResult and "Pass" or "No data"
  ResultTable.resultCode = bResult
  ResultTable.resultString = logResult
end
table.insert(TestItems, {name="Switch LCD 24HZ", action=SwitchLcd24HZ, set = {"Success"}})

--20. test item "Turn Pattern to 127gray"
local function TurnP127Gray(self)
  local rtRecv,aLog = doOsCmd("diagstool lcdmura -rgb 127,127,127\n","root#")
  local bResult = rtRecv and true or false
  local logResult = bResult and "Pass" or "No data"
  ResultTable.resultCode = bResult
  ResultTable.resultString = logResult
end
table.insert(TestItems, {name="Turn Pattern to 127gray", action=TurnP127Gray})

--21. test item "Delay 5 Seconds"
local function Delay5s(self)
  app.wait(5000)--delay 5000ms
  table.insert(ResultLog,"Delay 5000 ms")
  local bResult = true
  local logResult = aLog
  ResultTable.resultCode = bResult
  ResultTable.resultString = logResult
end
table.insert(TestItems, {name="Delay 5 Seconds", action=Delay5s})

--22. test item "UUT24HZ_5Probe_Spectrum"
local function U24HZSpectrum(self)
  local bResult = MeasureFlickerVals(self.name)
  local logResult = bResult and "Pass" or "Fail"
  ResultTable.resultCode = bResult
  ResultTable.resultString = logResult
end
table.insert(TestItems, {name="DisplayG127at24Hz_5Probe_Spectrum", action=U24HZSpectrum})

--23. test item "L7_UUT24HZ_MAX_JEITA"
local function U24HZMaxJeitaAndFrequency(self)
  if self.name == "L5_DisplayG127at24Hz_MAX_JEITA" then
    self.limitSet.upper = -55
  end 
  if self.Pattern == 1 then
    logResult = FlckrJEITAValue[tonumber(self.Pattern4Key)]
    bResult = compareAandB(tonumber(logResult), self.limitSet.lower, self.limitSet.upper, true)
  else
    logResult = SpectrumValue[tonumber(self.Pattern4Key)]
    bResult = logResult and true or false
    logResult = bResult and logResult or "Fail"
  end
  ResultTable.lowLimit = self.limitSet.lower
  ResultTable.UpLimit = self.limitSet.upper
  ResultTable.resultCode = bResult
  ResultTable.resultString = logResult
end
for key ,val in pairs(T) do
  table.insert(TestItems, {name=val .. "_DisplayG127at24Hz_MAX_JEITA", action=U24HZMaxJeitaAndFrequency, limitSet={lower="NA", upper=-52}, Pattern4Key=key, Pattern=1})
  table.insert(TestItems, {name=val .. "_DisplayG127at24Hz_MAX_JEITA_Frequency", action=U24HZMaxJeitaAndFrequency, limitSet={lower=1, upper="NA"}, Pattern4Key=key, Pattern = 2})
end
--table.insert(TestItems, {name="L7_UUT24HZ_MAX_JEITA", action=l7U24HZMaxJeita, limit={lower="NA", upper=-55}})

--48. test item "Unit24HZ_MAX_JEITA"
local function Unit24HZMAXJeita(self)
  local logResult = maxJEITA
  Unit24HZMAXJei = maxJEITA
  local bResult = compareAandB(tonumber(logResult), self.limitSet["lower"], self.limitSet["upper"], true)
  ResultTable.resultCode = bResult
  ResultTable.resultString = logResult
end
table.insert(TestItems, {name="DisplayG127at24Hz_MAX_JEITA", action=Unit24HZMAXJeita, limitSet={lower="NA", upper=-53}})

--49. test item "Unit24HZ_MAX_JEITA_Frequency"
local function Unit24HZMAXJeitaFre(self)
  local logResult = maxJEITAFre
  local bResult = logResult and true or false
  logResult = bResult and logResult or "No data"
  ResultTable.resultCode = bResult
  ResultTable.resultString = logResult
end
--table.insert(TestItems, {name="DisplayG127at24Hz_MAX_JEITA_Frequency", action=Unit24HZMAXJeitaFre})

--50. test item "Unit24HZ_MAX_JEITA_Location"
local function Unit24HZMAXJeitaLoc(self)
  local logResult = maxJEITALoc
  local bResult = logResult and true or false
  logResult = bResult and logResult or "No data"
  ResultTable.resultCode = bResult
  ResultTable.resultString = logResult
end
--table.insert(TestItems, {name="DisplayG127at24Hz_MAX_JEITA_Location", action=Unit24HZMAXJeitaLoc})

--35. test item "Turn Pattern to 127gray2"
local function TurnP127Gray2(self)
  local rtRecv = doOsCmd("diagstool lcdmura --rgb 63,63,63\n","root#")
  local bResult = rtRecv and true or false
  local logResult = bResult and "Pass" or "No data"
  ResultTable.resultCode = bResult
  ResultTable.resultString = logResult
end
table.insert(TestItems, {name="Turn Pattern to 63gray", action=TurnP127Gray2})

--36. test item "WarmUp 5 Seconds"
local function WarmUp5s(self)
  app.wait(5000)--delay 5000ms
  local aLog = "Delay 5000 ms"
  local bResult = true
  local logResult = aLog
  ResultTable.resultCode = bResult
  ResultTable.resultString = logResult
end
table.insert(TestItems, {name="WarmUp 5 Seconds", action=WarmUp5s})

--37. test item "UUT60HZ_5Probe_Spectrum"
local function U60HZSpectrum(self)
  local bResult = MeasureFlickerVals(self.name)
  local logResult = bResult and "Pass" or "Fail"
  ResultTable.resultCode = bResult
  ResultTable.resultString = logResult
end
table.insert(TestItems, {name="DisplayG63at24Hz_5Probe_Spectrum", action=U60HZSpectrum})

--38. test item "L7_UUT60HZ_MAX_JEITA"
local function U60HZMaxJeitaAndFrequency(self)
  if self.name == "L5_DisplayG63at24Hz_MAX_JEITA" then
    self.limitSet.upper = -52
  end 
  if self.Pattern == 1 then
    logResult = FlckrJEITAValue[tonumber(self.Pattern4Key)]
    bResult = compareAandB(tonumber(logResult), self.limitSet.lower, self.limitSet.upper, true)
  else
    logResult = SpectrumValue[tonumber(self.Pattern4Key)]
    bResult = logResult and true or false
    logResult = bResult and logResult or "No data"
  end
  ResultTable.lowLimit = self.limitSet.lower
  ResultTable.UpLimit = self.limitSet.upper
  ResultTable.resultCode = bResult
  ResultTable.resultString = logResult
end
for key ,val in pairs(T) do
  table.insert(TestItems, {name=val .. "_DisplayG63at24Hz_MAX_JEITA", action=U60HZMaxJeitaAndFrequency, limitSet={lower="NA", upper=-49}, Pattern4Key=key, Pattern=1})
  table.insert(TestItems, {name=val .. "_DisplayG63at24Hz_MAX_JEITA_Frequency", action=U60HZMaxJeitaAndFrequency,limitSet={lower=1, upper="NA"}, Pattern4Key=key, Pattern = 2})
end

--51. test item "Unit60HZ_MAX_JEITA"
local function Unit60HZMAXJeita(self)
--  message.send(msgTelnet, "exit\n", 5, 0)
--  message.close(msgTelnet)
--  msgTelnet = nil;

  local logResult = maxJEITA
  Unit60HZMAXJei = maxJEITA
  local bResult = compareAandB(tonumber(logResult), self.limitSet["lower"], self.limitSet["upper"], true)
  ResultTable.resultCode = bResult
  ResultTable.resultString = logResult
end
table.insert(TestItems, {name="DisplayG63at24Hz_MAX_JEITA", action=Unit60HZMAXJeita, limitSet={lower="NA", upper=-53}})

--3. test item "Enter OS Mode"
local function EnterOSModeAgain(self)
  --os.execute("sh /Users/gdlocal/Desktop/moveOldFile.sh")
   os.execute("sh " ..  Directory.config .. "/moveOldFile.sh")

  app.wait(900)
--  msgTelnet = message.open("telnet localhost 10023")
--  table.insert(ResultLog,"telnet localhost 10023")
--  local recOpenTel, _ = message.recv(msgTelnet, {"login:"}, 5, 0)
--  local rtRecv = doOsCmd("root\n","Password:")
--  rtRecv = doOsCmd("alpine\n","root#")
  rtRecv = doOsCmd("nvram -p\n","root#")
--  rtRecv = doOsCmd("diagstool bootargs --add newLcdMura=RGBW\n","root#")
--  rtRecv = doOsCmd("diagstool bootargs --add iomfb_run_mode=2\n","root#")
  rtRecv = doOsCmd("diagstool bootargs --add hidd_no_ws\n","root#")


  msgRsync = message.open({"rsync", "-av","--include=\"*.sh\"","--exclude=\"*\"","rsync://root@localhost:10873/root/var/root/ADCL.bin ",Directory.home})-- .. BinFilePath
  table.insert(ResultLog,"rsync -av --include=\"*.sh\" --exclude=\"*\" rsync://root@localhost:10873/root/var/root/ADCL.bin /Users/gdlocal")
  rtRecv = message.recv(msgRsync, {"Password:"}, 5, 0)
  table.insert(ResultLog,rtRecv)
  message.send(msgRsync, "alpine\n", 5, 0)
  table.insert(ResultLog,"alpine")
  rtRecv,_ = message.recv(msgRsync,{[[speedup is \d{1,}.\d]]}, 8, 0)
  table.insert(ResultLog,rtRecv)
  message.close(msgRsync)
  msgRsync = nil

  local aResult = file_exists("/Users/gdlocal/ADCL.bin")
  msgpwd =  message.open("pwd")
  print("aaa")
  print(bResult)
  rtRecv = message.recv(msgpwd, { [[127.0.0.1:\d{1,} for service rsync]] }, 3, 0)
  print(rtRecv)
 
   os.execute("sh " ..  Directory.config .. "/CreatNewFile.sh")
   
  msgRsync = message.open({"rsync", "-av","--include=\"*.sh\"","--exclude=\"*\"",Directory.home..'/binFiles/',"rsync://root@localhost:10873/root/var/root/"})-- .. BinFilePath
  table.insert(ResultLog,"rsync -av --include=\"*.sh\" --exclude=\"*\" /Users/gdlocal/binFiles/ rsync://root@localhost:10873/root/var/root/")
  rtRecv = message.recv(msgRsync, {"Password:"}, 5, 0)
  table.insert(ResultLog,rtRecv)
  message.send(msgRsync, "alpine\n", 5, 0)
  table.insert(ResultLog,"alpine")
  rtRecv,_ = message.recv(msgRsync,{[[speedup is \d{1,}.\d]]}, 8, 0)
  table.insert(ResultLog,rtRecv)
  message.close(msgRsync)
  
  local bResult = reBootUnit()
  if not aResult then
    bResult = false
  end  
  
  local logResult = bResult and "Pass" or "No data"
  stopFail = not bResult
  ResultTable.resultCode = bResult
  ResultTable.resultString = logResult
end
table.insert(TestItems, {name="Set DOE root", action=EnterOSModeAgain, set = {"root#"}})

local function LoadBinFile(self)
  doOsCmd("tconctl -i -w 3 0xff 0x00\n","root#")
  doOsCmd("tconctl -i -w 3 0x8b 0x00\n","root#")
  doOsCmd(self.cmdSet[1],"root#")
  local logResult = bResult and "Pass" or "No data"
  app.wait(2000)
  ResultTable.resultCode = bResult
  ResultTable.resultString = logResult
end
table.insert(TestItems, {name="24pt_IOMFB_FDR_Loader_ADCL_singlePRC", action=LoadBinFile})
TestItems[#TestItems].cmdSet = {"IOMFB_FDR_Loader -i ./ADCL_singlePRC.bin\n"}

local function SetPatternAndFlickerTest(self)
  local bResult,logResult = nil
  if self.Pattern4Key == 1 and self.Pattern == 1 then
    
    loginTest()

    table.insert(ResultLog,"Send:")
    message.send(msgTelnet,self.cmdSet[1],15,0)
    table.insert(ResultLog,self.cmdSet[1])
    --doOsCmd("APTTester -s '2 2 2 10 10' -i 45 -g 63\n","root#")
    app.wait(900)
    MeasureFlickerVals(self.name)
    app.wait(1000)
  end
  if string.match(self.name or "","L5") then --self.name == "L5_DisplayG63OnePRC_MAX_JEITA"
    self.limitSet.upper = -55
  end 
  if self.Pattern == 1 then
    logResult = FlckrJEITAValue[tonumber(self.Pattern4Key)]
    bResult = compareAandB(tonumber(logResult), self.limitSet.lower, self.limitSet.upper, true)
    if tonumber(logResult) < -80 then
      bResult = false
      stopFail = not bResult
    end
  else
    logResult = SpectrumValue[tonumber(self.Pattern4Key)]
    bResult = logResult and true or false
    logResult = bResult and logResult or "Fail"
  end
  if self.Pattern4Key == 1 and self.Pattern == 1 then
    table.insert(ResultLog,"Receive:")
    rtRecv,rtIndex = message.recv(msgTelnet,{"root"},25, 0)
    table.insert(ResultLog,rtRecv .. "\n")
  end
  ResultTable.lowLimit = self.limitSet.lower
  ResultTable.UpLimit = self.limitSet.upper
  ResultTable.resultCode = bResult
  ResultTable.resultString = logResult
end


for key ,val in ipairs(T) do
  table.insert(TestItems, {name=val .. "_24pt_NoPRC_SPgm_G63_120(3)_24(2)", action=SetPatternAndFlickerTest, limitSet={lower="NA", upper=-53}, Pattern4Key=key, Pattern=1})
  TestItems[#TestItems].cmdSet = {"APTTester -s '2 2 2 10 10' -i 45 -g 63\n"}
  table.insert(TestItems, {name=val .. "_24pt_NoPRC_SPgm_G63_120(3)_24(2)_Freq", action=SetPatternAndFlickerTest, limitSet={lower=1, upper="NA"}, Pattern4Key=key, Pattern = 2})
end

local function EnableMultiplePgamma(self)
  loginTest()
  local rtRecv,aLog = doOsCmd("tconctl -w 3 0xff 0x05\n","root#")
  rtRecv,aLog = doOsCmd("tconctl -w 3 0xf4 0x40\n","root#")
  rtRecv,aLog = doOsCmd("tconctl -w 3 0xf5 0x00\n","root#")
  local logResult = bResult and "Pass" or "No data"
  ResultTable.resultCode = bResult
  ResultTable.resultString = logResult
end
table.insert(TestItems, {name="Enable Multiple Pgamma", action=EnableMultiplePgamma})

for key ,val in ipairs(T) do
  table.insert(TestItems, {name=val .. "_24pt_NoPRC_MPgm_G63_40_24(2)_30", action=SetPatternAndFlickerTest, limitSet={lower="NA", upper=-53}, Pattern4Key=key, Pattern=1})
  TestItems[#TestItems].cmdSet = {"APTTester -s '6 10 10 8' -i 33 -g 63\n"}
  table.insert(TestItems, {name=val .. "_24pt_NoPRC_MPgm_G63_40_24(2)_30_Freq", action=SetPatternAndFlickerTest, limitSet={lower=1, upper="NA"}, Pattern4Key=key, Pattern = 2})
end

for key ,val in ipairs(T) do
  table.insert(TestItems, {name=val .. "_24pt_NoPRC_MPgm_G63_80_40(2)_24_30", action=SetPatternAndFlickerTest, limitSet={lower="NA", upper=-53}, Pattern4Key=key, Pattern=1})
  TestItems[#TestItems].cmdSet = {"APTTester -s '3 6 6 10 8' -i 33 -g 63\n"}
  table.insert(TestItems, {name=val .. "_24pt_NoPRC_MPgm_G63_80_40(2)_24_30_Freq", action=SetPatternAndFlickerTest, limitSet={lower=1, upper="NA"}, Pattern4Key=key, Pattern = 2})
end

local function DiableMultiplePgamma1(self)
  local rtRecv,aLog = doOsCmd("tconctl -w 3 0xff 0x05\n","root#")
  rtRecv,aLog = doOsCmd("tconctl -w 3 0xf4 0xC0\n","root#")
  rtRecv,aLog = doOsCmd("tconctl -w 3 0xf5 0x00\n","root#")
  local bResult = rtRecv and true or false
  local logResult = bResult and "Pass" or "No data"
  ResultTable.resultCode = bResult
  ResultTable.resultString = logResult
end
table.insert(TestItems, {name="Disable Multiple Pgamma", action=DiableMultiplePgamma1})

for key ,val in ipairs(T) do
  table.insert(TestItems, {name=val .. "_24pt_NoPRC_SPgm_G127_120(3)_24(2)", action=SetPatternAndFlickerTest, limitSet={lower="NA", upper=-53}, Pattern4Key=key, Pattern=1})
  TestItems[#TestItems].cmdSet = {"APTTester -s '2 2 2 10 10' -i 40 -g 127\n"}
  table.insert(TestItems, {name=val .. "_24pt_NoPRC_SPgm_G127_120(3)_24(2)_Freq", action=SetPatternAndFlickerTest, limitSet={lower=1, upper="NA"}, Pattern4Key=key, Pattern = 2})
end

table.insert(TestItems, {name="Enable Multiple Pgamma 1", action=EnableMultiplePgamma})

for key ,val in ipairs(T) do
  table.insert(TestItems, {name=val .. "_24pt_NoPRC_MPgm_G127_40_24(2)_30", action=SetPatternAndFlickerTest, limitSet={lower="NA", upper=-53}, Pattern4Key=key, Pattern=1})
  TestItems[#TestItems].cmdSet = {"APTTester -s '6 10 10 8' -i 33 -g 127\n"}
  table.insert(TestItems, {name=val .. "_24pt_NoPRC_MPgm_G127_40_24(2)_30_Freq", action=SetPatternAndFlickerTest, limitSet={lower=1, upper="NA"}, Pattern4Key=key, Pattern = 2})
end

for key ,val in ipairs(T) do
  table.insert(TestItems, {name=val .. "_24pt_NoPRC_MPgm_G127_80_40(2)_24_30", action=SetPatternAndFlickerTest, limitSet={lower="NA", upper=-53}, Pattern4Key=key, Pattern=1})
  TestItems[#TestItems].cmdSet = {"APTTester -s '3 6 6 10 8' -i 33 -g 127\n"}
  table.insert(TestItems, {name=val .. "_24pt_NoPRC_MPgm_G127_80_40(2)_24_30_Freq", action=SetPatternAndFlickerTest, limitSet={lower=1, upper="NA"}, Pattern4Key=key, Pattern = 2})
end

table.insert(TestItems, {name="Diable Multiple Pgamma 2", action=DiableMultiplePgamma1})


local function RebootUnit(self)
  local bResult = reBootUnit()
  local logResult = bResult and "Pass" or "Fail"
  stopFail = not bResult
  ResultTable.resultCode = bResult
  ResultTable.resultString = logResult
end
table.insert(TestItems, {name="Multiple PRC 0wd", action=RebootUnit})

table.insert(TestItems, {name="24pt_IOMFB_FDR_Loader_ADCL_0wd", action=LoadBinFile})
TestItems[#TestItems].cmdSet = {"IOMFB_FDR_Loader -i ./ADCL_no_wd.bin\n"}


for key ,val in ipairs(T) do
  table.insert(TestItems, {name=val .. "_24pt_MultPRC_0wd_G63_60_30_48_80_120", action=SetPatternAndFlickerTest, limitSet={lower="NA", upper=-53}, Pattern4Key=key, Pattern=1})
  TestItems[#TestItems].cmdSet = {"APTTester -s '4 8 5 3 2' -i 47 -g 63\n"}
  table.insert(TestItems, {name=val .. "_24pt_MultPRC_0wd_G63_60_30_48_80_120_Freq", action=SetPatternAndFlickerTest, limitSet={lower=1, upper="NA"}, Pattern4Key=key, Pattern = 2})
end

for key ,val in ipairs(T) do
  table.insert(TestItems, {name=val .. "_24pt_MultPRC_0wd_G63_60_30_48", action=SetPatternAndFlickerTest, limitSet={lower="NA", upper=-53}, Pattern4Key=key, Pattern=1})
  TestItems[#TestItems].cmdSet = {"APTTester -s '4 8 5' -i 60 -g 63\n"}
  table.insert(TestItems, {name=val .. "_24pt_MultPRC_0wd_G63_60_30_48_Freq", action=SetPatternAndFlickerTest, limitSet={lower=1, upper="NA"}, Pattern4Key=key, Pattern = 2})
end

for key ,val in ipairs(T) do
  table.insert(TestItems, {name=val .. "_24pt_MultPRC_0wd_G63_120_48_80", action=SetPatternAndFlickerTest, limitSet={lower="NA", upper=-53}, Pattern4Key=key, Pattern=1})
  TestItems[#TestItems].cmdSet = {"APTTester -s '2 5 3' -i 100 -g 63\n"}
  table.insert(TestItems, {name=val .. "_24pt_MultPRC_0wd_G63_120_48_80_Freq", action=SetPatternAndFlickerTest, limitSet={lower=1, upper="NA"}, Pattern4Key=key, Pattern = 2})
end

for key ,val in ipairs(T) do
  table.insert(TestItems, {name=val .. "_24pt_MultPRC_0wd_G63_34_24_24", action=SetPatternAndFlickerTest, limitSet={lower="NA", upper=-53}, Pattern4Key=key, Pattern=1})
  TestItems[#TestItems].cmdSet = {"APTTester -s '7 10 10' -i 40 -g 63\n"}
  table.insert(TestItems, {name=val .. "_24pt_MultPRC_0wd_G63_34_24_24_Freq", action=SetPatternAndFlickerTest, limitSet={lower=1, upper="NA"}, Pattern4Key=key, Pattern = 2})
end

for key ,val in ipairs(T) do
  table.insert(TestItems, {name=val .. "_24pt_MultPRC_0wd_G63_60(2)_120(3)", action=SetPatternAndFlickerTest, limitSet={lower="NA", upper=-53}, Pattern4Key=key, Pattern=1})
  TestItems[#TestItems].cmdSet = {"APTTester -s '4 4 2 2 2' -i 75 -g 63\n"}
  table.insert(TestItems, {name=val .. "_24pt_MultPRC_0wd_G63_60(2)_120(3)_Freq", action=SetPatternAndFlickerTest, limitSet={lower=1, upper="NA"}, Pattern4Key=key, Pattern = 2})
end

for key ,val in ipairs(T) do
  table.insert(TestItems, {name=val .. "_24pt_MultPRC_0wd_G63_40_60_120(2)_60", action=SetPatternAndFlickerTest, limitSet={lower="NA", upper=-53}, Pattern4Key=key, Pattern=1})
  TestItems[#TestItems].cmdSet = {"APTTester -s '6 4 2 2 4' -i 60 -g 63\n"}
  table.insert(TestItems, {name=val .. "_24pt_MultPRC_0wd_G63_40_60_120(2)_60_Freq", action=SetPatternAndFlickerTest, limitSet={lower=1, upper="NA"}, Pattern4Key=key, Pattern = 2})
end


for key ,val in ipairs(T) do
  table.insert(TestItems, {name=val .. "_24pt_MultPRC_0wd_G127_60_30_48_80_120", action=SetPatternAndFlickerTest, limitSet={lower="NA", upper=-53}, Pattern4Key=key, Pattern=1})
  TestItems[#TestItems].cmdSet = {"APTTester -s '4 8 5 3 2' -i 47 -g 127\n"}
  table.insert(TestItems, {name=val .. "_24pt_MultPRC_0wd_G127_60_30_48_80_120_Freq", action=SetPatternAndFlickerTest, limitSet={lower=1, upper="NA"}, Pattern4Key=key, Pattern = 2})
end

for key ,val in ipairs(T) do
  table.insert(TestItems, {name=val .. "_24pt_MultPRC_0wd_G127_60_30_48", action=SetPatternAndFlickerTest, limitSet={lower="NA", upper=-53}, Pattern4Key=key, Pattern=1})
  TestItems[#TestItems].cmdSet = {"APTTester -s '4 8 5' -i 60 -g 127\n"}
  table.insert(TestItems, {name=val .. "_24pt_MultPRC_0wd_G127_60_30_48_Freq", action=SetPatternAndFlickerTest, limitSet={lower=1, upper="NA"}, Pattern4Key=key, Pattern = 2})
end

for key ,val in ipairs(T) do
  table.insert(TestItems, {name=val .. "_24pt_MultPRC_0wd_G127_120_48_80", action=SetPatternAndFlickerTest, limitSet={lower="NA", upper=-53}, Pattern4Key=key, Pattern=1})
  TestItems[#TestItems].cmdSet = {"APTTester -s '2 5 3' -i 100 -g 127\n"}
  table.insert(TestItems, {name=val .. "_24pt_MultPRC_0wd_G127_120_48_80_Freq", action=SetPatternAndFlickerTest, limitSet={lower=1, upper="NA"}, Pattern4Key=key, Pattern = 2})
end

for key ,val in ipairs(T) do
  table.insert(TestItems, {name=val .. "_24pt_MultPRC_0wd_G127_34_24_24", action=SetPatternAndFlickerTest, limitSet={lower="NA", upper=-53}, Pattern4Key=key, Pattern=1})
  TestItems[#TestItems].cmdSet = {"APTTester -s '7 10 10' -i 40 -g 127\n"}
  table.insert(TestItems, {name=val .. "_24pt_MultPRC_0wd_G127_34_24_24_Freq", action=SetPatternAndFlickerTest, limitSet={lower=1, upper="NA"}, Pattern4Key=key, Pattern = 2})
end

for key ,val in ipairs(T) do
  table.insert(TestItems, {name=val .. "_24pt_MultPRC_0wd_G127_60(2)_120(3)", action=SetPatternAndFlickerTest, limitSet={lower="NA", upper=-53}, Pattern4Key=key, Pattern=1})
  TestItems[#TestItems].cmdSet = {"APTTester -s '4 4 2 2 2' -i 75 -g 127\n"}
  table.insert(TestItems, {name=val .. "_24pt_MultPRC_0wd_G127_60(2)_120(3)_Freq", action=SetPatternAndFlickerTest, limitSet={lower=1, upper="NA"}, Pattern4Key=key, Pattern = 2})
end

for key ,val in ipairs(T) do
  table.insert(TestItems, {name=val .. "_24pt_MultPRC_0wd_G127_40_60_120(2)_60", action=SetPatternAndFlickerTest, limitSet={lower="NA", upper=-53}, Pattern4Key=key, Pattern=1})
  TestItems[#TestItems].cmdSet = {"APTTester -s '6 4 2 2 4' -i 60 -g 127\n"}
  table.insert(TestItems, {name=val .. "_24pt_MultPRC_0wd_G127_40_60_120(2)_60_Freq", action=SetPatternAndFlickerTest, limitSet={lower=1, upper="NA"}, Pattern4Key=key, Pattern = 2})
end

table.insert(TestItems, {name="Multiple PRC 2wd", action=RebootUnit})

table.insert(TestItems, {name="24pt_IOMFB_FDR_Loader_ADCL_2wd", action=LoadBinFile})
TestItems[#TestItems].cmdSet = {"IOMFB_FDR_Loader -i ./ADCL_2wd.bin\n"}


for key ,val in ipairs(T) do
  table.insert(TestItems, {name=val .. "_24pt_MultPRC_2wd_G63_40_24(2)_30", action=SetPatternAndFlickerTest, limitSet={lower="NA", upper=-53}, Pattern4Key=key, Pattern=1})
  TestItems[#TestItems].cmdSet = {"APTTester -s '6 10 10 8' -i 33 -g 63\n"}
  table.insert(TestItems, {name=val .. "_24pt_MultPRC_2wd_G63_40_24(2)_30_Freq", action=SetPatternAndFlickerTest, limitSet={lower=1, upper="NA"}, Pattern4Key=key, Pattern = 2})
end

for key ,val in ipairs(T) do
  table.insert(TestItems, {name=val .. "_24pt_MultPRC_2wd_G63_80_40(2)_24_30", action=SetPatternAndFlickerTest, limitSet={lower="NA", upper=-53}, Pattern4Key=key, Pattern=1})
  TestItems[#TestItems].cmdSet = {"APTTester -s '3 6 6 10 8' -i 33 -g 63\n"}
  table.insert(TestItems, {name=val .. "_24pt_MultPRC_2wd_G63_80_40(2)_24_30_Freq", action=SetPatternAndFlickerTest, limitSet={lower=1, upper="NA"}, Pattern4Key=key, Pattern = 2})
end

for key ,val in ipairs(T) do
  table.insert(TestItems, {name=val .. "_24pt_MultPRC_2wd_G127_40_24(2)_30", action=SetPatternAndFlickerTest, limitSet={lower="NA", upper=-53}, Pattern4Key=key, Pattern=1})
  TestItems[#TestItems].cmdSet = {"APTTester -s '6 10 10 8' -i 33 -g 127\n"}
  table.insert(TestItems, {name=val .. "_24pt_MultPRC_2wd_G127_40_24(2)_30_Freq", action=SetPatternAndFlickerTest, limitSet={lower=1, upper="NA"}, Pattern4Key=key, Pattern = 2})
end

for key ,val in ipairs(T) do
  table.insert(TestItems, {name=val .. "_24pt_MultPRC_2wd_G127_80_40(2)_24_30", action=SetPatternAndFlickerTest, limitSet={lower="NA", upper=-53}, Pattern4Key=key, Pattern=1})
  TestItems[#TestItems].cmdSet = {"APTTester -s '3 6 6 10 8' -i 33 -g 127\n"}
  table.insert(TestItems, {name=val .. "_24pt_MultPRC_2wd_G127_80_40(2)_24_30_Freq", action=SetPatternAndFlickerTest, limitSet={lower=1, upper="NA"}, Pattern4Key=key, Pattern = 2})
end

table.insert(TestItems, {name="Multiple PRC 5wd", action=RebootUnit})

table.insert(TestItems, {name="24pt_IOMFB_FDR_Loader_ADCL_5wd", action=LoadBinFile})
TestItems[#TestItems].cmdSet = {"IOMFB_FDR_Loader -i ./ADCL.bin\n"}


for key ,val in ipairs(T) do
  table.insert(TestItems, {name=val .. "_24pt_MultPRC_5wd_G63_30_80_120(3)_60", action=SetPatternAndFlickerTest, limitSet={lower="NA", upper=-53}, Pattern4Key=key, Pattern=1})
  TestItems[#TestItems].cmdSet = {"APTTester -s '8 3 2 2 2 4' -i 80 -g 63\n"}
  table.insert(TestItems, {name=val .. "_24pt_MultPRC_5wd_G63_30_80_120(3)_60_Freq", action=SetPatternAndFlickerTest, limitSet={lower=1, upper="NA"}, Pattern4Key=key, Pattern = 2})
end

for key ,val in ipairs(T) do
  table.insert(TestItems, {name=val .. "_24pt_MultPRC_5wd_G127_30_80_120(3)_60", action=SetPatternAndFlickerTest, limitSet={lower="NA", upper=-53}, Pattern4Key=key, Pattern=1})
  TestItems[#TestItems].cmdSet = {"APTTester -s '8 3 2 2 2 4' -i 80 -g 127\n"}
  table.insert(TestItems, {name=val .. "_24pt_MultPRC_5wd_G127_30_80_120(3)_60_Freq", action=SetPatternAndFlickerTest, limitSet={lower=1, upper="NA"}, Pattern4Key=key, Pattern = 2})
end

local function itemWritePDCA(self)
  doOsCmd("diagstool bootargs --remove hidd_no_ws\n","root#")
  doOsCmd("reboot\n","host")
  local Ltable = {}
  apiRely, uutHandle = ip.UUTStart()
  if ip.success(apiRely) then
    reply=ip.amIOkay(uutHandle,sn)
    successBool = ip.success(reply)
    print(successBool)
    if not successBool then
      DoneError = ip.reply_getError(apiRely)
      bResult = false
      logResult = DoneError
      local testResult = {number=self.number, name=self.name, resultCode=bResult, resultString=logResult, log=aLog}
      cancelreply = ip.UUTCancel(uutHandle)
      ip.reply_destroy(cancelreply)
      ip.reply_destroy(reply)
      ip.UID_destroy(uutHandle)
      return testResult;
    end
  else
    DoneError = ip.reply_getError(apiRely)
    bResult = false
    logResult = DoneError
    local testResult = {number=self.number, name=self.name, resultCode=bResult, resultString=logResult, log=aLog} 
    cancelreply = ip.UUTCancel(uutHandle)
    ip.reply_destroy(cancelreply)
    ip.reply_destroy(reply)
    ip.UID_destroy(uutHandle)
    return testResult;
  end
  --------Attribute--------
  swversion=ScriptVersion
  bRt = puddingAttributeWithKeyName(uutHandle, IPTable.IP_ATTRIBUTE_STATIONSOFTWAREVERSION, swversion)
  swname="Kylin"
  bRt = puddingAttributeWithKeyName(uutHandle, IPTable.IP_ATTRIBUTE_STATIONSOFTWARENAME, swname)
  bRt = puddingAttributeWithKeyName(uutHandle, IPTable.IP_ATTRIBUTE_SERIALNUMBER, sn)
  bRt = puddingAttributeWithKeyName(uutHandle, "limitsversion", "10.10")
  stime = os.time()
  etime = stime + 35
  APIcheck = ip.setStartTime(uutHandle, stime);
  APIcheck = ip.setStopTime( uutHandle, etime);


  for key,val in pairs(PDCAInfo) do
    print("kevin test enter for ")
    for key1,val1 in pairs(val) do
      if key1 == "subName" then
         val1.testName = string.gsub(val1.testName,"%s+%b[]","")
        returnValue=puddingWithParametricDataForTestItem(val1.low,val1.value,val1.high,val1.result,val1.priority,val1.testName,val1.SubTestItem,val1.SubSubTestItem,val1.failMsg,val1.TestUnit,uutHandle)
        print(returnValue)
      else
        bRt = puddingAttributeWithKeyName(uutHandle, key1, val1)
      end
      if key1==nil and val1==nil then
        break
      end
    end
    --end
  end
  NameInPDCA = "FlickerVRR_DOE_Sharp"
  endT = os.date("%Y-%m-%d %H:%M:%S")
  --FilePath = app.getLogFile({resultString="", sn = sn})
  local FilePath = Directory.homePublic .. "/Kylin/" .. sn .. "_" .. endT .. "_" .. "Spectrum.csv"
  os.rename(localCSVFile,FilePath)
  print("FilePath")
  print(FilePath)
  if NameInPDCA ~= nil and FilePath ~= nil then
    apiRely = ip.addBlob(uutHandle, NameInPDCA,FilePath);
    if not ip.success(apiRely) then
      print("enter ~~addBlob~~ip.success(apiRely)")
      local errorInfo = ip.reply_getError(apiRely);
      print(errorInfo)
      ip.reply_destroy(apiRely);
      ip.UUTCancel(uutHandle);
      ip.UID_destroy(uutHandle);
      return "addBlob--ip.success(apiRely) fail";
    end

  end
  comVal=puddingCommit(sn,finalResult)
  print("Kevin test 0708")
  print(comVal)
  if not comVal then
    print("Write pdca puddingCommit fail")
  end
  local bResult = comVal
  local logResult =  bResult and "Pass" or "Fail"
  ResultTable.resultCode = bResult
  ResultTable.resultString = logResult
end
table.insert(TestItems, {name="Write PDCA", action=itemWritePDCA}) 