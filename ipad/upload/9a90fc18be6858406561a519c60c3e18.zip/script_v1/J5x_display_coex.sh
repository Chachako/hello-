# This script is for J522 compass-display coex test in nonUI
# June 02, 2020
# by QC Wang

# First step is to transfer the images to DUT. Open a new terminal and example codes as below:
# scp -P 46022 /Users/qcwang/Desktop/J5xx/P0/display_coex/J5x_white.jpg root@localhost:/var/root/

MAX_BRIGHTNESS=1000  # Define max brightness allowed to test

powerswitch lcd on
set defaults ignoreDisplayTimeout=1
MultitouchTester -poweroff
setbatt drain


# Baseline Test
echo "========== TEST: 120HZ BASELINE =========="
setbrt --nits 0
compassTester -interval 0.01 -printTemperature


# Compass coex test with different pattern & brightness:
# load white pattern
killall -9 colortest; colortest -l /var/root/J5x_white.jpg

echo "========== TEST: 120HZ WHITE 300 nits =========="
setbrt --nits 300
compassTester -interval 0.01 -printTemperature

echo "========== TEST: 120HZ WHITE 600 nits =========="
setbrt --nits 600
compassTester -interval 0.01 -printTemperature

echo "========== TEST: 120HZ WHITE MAX nits =========="
setbrt --nits $MAX_BRIGHTNESS
compassTester -interval 0.01 -printTemperature

# load red pattern
killall -9 colortest; colortest -l /var/root/J5x_red.jpg

echo "========== TEST: 120HZ RED 300 nits =========="
setbrt --nits 300
compassTester -interval 0.01 -printTemperature

echo "========== TEST: 120HZ RED 600 nits =========="
setbrt --nits 600
compassTester -interval 0.01 -printTemperature

echo "========== TEST: 120HZ RED MAX nits =========="
setbrt --nits $MAX_BRIGHTNESS
compassTester -interval 0.01 -printTemperature

# load maps pattern
killall -9 colortest; colortest -l /var/root/J5x_maps.jpg

echo "========== TEST: 120HZ MAPS 300 nits =========="
setbrt --nits 300
compassTester -interval 0.01 -printTemperature

echo "========== TEST: 120HZ MAPS 600 nits =========="
setbrt --nits 600
compassTester -interval 0.01 -printTemperature

echo "========== TEST: 120HZ MAPS MAX nits =========="
setbrt --nits $MAX_BRIGHTNESS
compassTester -interval 0.01 -printTemperature



# wrap up test
setbatt on
setbrt --nits 200
killall -9 colortest
