//
//  ATDeviceCalibrationProtocol.h
//  ATDeviceElements
//
//  Created by Sai  on 11/4/19.
//  Copyright © 2019 htwe. All rights reserved.
//

#ifndef ATDeviceCalibrationDataProtocol_h
#define ATDeviceCalibrationDataProtocol_h

@protocol ATDeviceCalibrationDataCapable < NSObject >

- (BOOL) writeBlockSerialNumber: (uint64_t) serialNumber WithError:(out NSError**) error;

- (uint64_t) blockSerialNumberWithError:(out NSError**) error;

- (BOOL) writeCalibrationData: (double) data  andAddress: (NSInteger) address  WithError  :(out NSError**) error;

- (double) calibrationDataAtAddress:(NSInteger) address WithError:(out NSError**) error;


@end

#endif /* ATDeviceCalibrationProtocol_h */
