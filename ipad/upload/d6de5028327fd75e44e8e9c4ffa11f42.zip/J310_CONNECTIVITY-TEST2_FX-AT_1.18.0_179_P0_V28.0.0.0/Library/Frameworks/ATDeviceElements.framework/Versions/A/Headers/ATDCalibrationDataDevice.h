//
//  ATDCalibrationDevice.h
//  ATDeviceElements
//
//  Created by Sai  on 11/4/19.
//  Copyright © 2019 htwe. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <ATDeviceElements/ATDeviceIodine.h>
#import <ATDeviceElements/ATDeviceCalibrationDataProtocol.h>


NS_ASSUME_NONNULL_BEGIN

/**
  Generic Class for Camera Calibartion Data Device such as Bromine, Iodine, Fluorine
 */
@interface ATDCalibrationDataDevice: ATDeviceIodine <ATDeviceCalibrationDataCapable>

@end

NS_ASSUME_NONNULL_END
