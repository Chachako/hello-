//
//  ATDeviceEowyn.h
//  ATDeviceElements
//
//  Created by Sai  on 9/10/19.
//  Copyright © 2019 htwe. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <ATDeviceElements/ATDeviceElement.h>
#import <ATDeviceElements/ATDFixtureIOProtocols.h>
#import <ATDeviceElements/ATDeviceExtensionBoard.h>

NS_ASSUME_NONNULL_BEGIN

@interface ATDeviceEowyn : ATDeviceElement <ATDFixtureIOCapable>



/**
 UartCommonFunc

 @param uartId ID of the target UART
 @param wordLen Number of word
 @param stopBits UART Stop Bit
 @param parity UART Parity
 @param flowControl  UART Flow control
 @param baudRate UART BaudRate
 @param isUartStreaming streaming is on or off
 @param fifoIndex FIFO index
 @param aError aError will be set if API failed
 @return YES = Successed and NO = Error
 */
-(BOOL)     UartCommonFunc: (int) uartId
             andWordLength: (ATDFixtureUARTwordLength) wordLen
               andStopBits: (ATDFixtureUARTStopBitType) stopBits
                 andParity: (ATDFixtureUARTParityType) parity
          andHWFlowControl: (ATDFixtureUARTFlowControl) flowControl
               andBaudRate: (uint32_t) baudRate
          andUartStreaming: (BOOL) isUartStreaming
        andStreamFIFOIndex: (uint8_t)  fifoIndex
                  andError: (out NSError**) aError;


/**
 attachExtensionBoard

 @param board ATDeviceExtensionBoard
 @param aError aError will be set if API failed
 @return YES = Successed and NO = Error
 */
- (BOOL) attachExtensionBoard: ( ATDeviceExtensionBoard*) board
                     andError:(NSError **) aError;

@property (nonatomic, strong)  ATDeviceExtensionBoard* _Nullable nextBoard;

@end

NS_ASSUME_NONNULL_END
