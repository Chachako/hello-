//
//  ATDeviceElementsCommon.h
//  ATDeviceElements
//
//  Created by Sai  on 3/15/17.
//  Copyright © 2017 htwe. All rights reserved.
//

#ifndef ATDeviceElementsCommon_h
#define ATDeviceElementsCommon_h

/*!
 Device ID List for devices supported by the ATDeviceElements Framework.
 
 */
typedef NS_ENUM(uint32_t, ATDeviceElementsID) {
    /** Device ID for an invalid device. */     ATDevice_INVALID_ID         = 0,
    /** Device ID for Palladium. */             ATDevice_PALLADIUM_ID       = 0xD0010001,
    /** Device ID for Titanium. */              ATDevice_TITANIUM_ID        = 0xD0010002,
    /** Device ID for Spade. */                 ATDevice_SPADE_ID           = 0xD0020001,
    /** Device ID for Xenon. */                 ATDevice_XENON_ID           = 0xD0020002,
    /** Device ID for Potassium. */             ATDevice_POTASSIUM_ID       = 0xD0020003,
    /** Device ID for Caesium. */               ATDevice_CAESIUM_ID         = 0xD0020005,
    /** Device ID for Potassium IMU. */         ATDevice_POTASSIUM_IMU_ID   = 0xD0020006,
    /** Device ID for Spartan. */               ATDevice_SPARTAN_ID         = 0xD0020009,
    /** Device ID for Gallium. */               ATDevice_GALLIUM_ID         = 0xD0030001,
    /** Device ID for Radon. */                 ATDevice_RADON_ID           = 0xD0040001,
    /** Device ID for Dust. */                  ATDevice_DUST_ID            = 0xD0070001,
    /** Device ID for Mirage. */                ATDevice_MIRAGE_ID          = 0xD0070002,
    /** Device ID for Aztec. */                 ATDevice_AZTEC_ID           = 0xD0070004,
    /** Device ID for Molybdenum. */            ATDevice_MOLYBDENUM_ID      = 0xD0070007,
    /** Device ID for Astatine. */              ATDevice_ASTATINE_ID        = 0xD0070008,
    /** Device ID for Carbon. */                ATDevice_CARBON_ID          = 0xD0080001,
    /** Device ID for Zinc. */                  ATDevice_ZINC_ID            = 0xD0080002,
    /** Device ID for C3PO. */                  ATDevice_C3PO_ID            = 0xD0090001,
    /** Device ID for Gimli. */                 ATDevice_GIMLI_ID           = 0xD0090002,
    /** Device ID for Iodine. */                ATDevice_IODINE_ID          = 0xD0090003,
    /** Device ID for Legolas. */               ATDevice_LEGOLAS_ID         = 0xD0090004,
    /** Device ID for Mantis. */                ATDevice_MANTIS_ID          = 0xD00A0001,
    /** Device ID for Raven. */                 ATDevice_RAVEN_ID           = 0xD00A0003,
    /** Device ID for Nibbler. */               ATDevice_NIBBLER_ID         = 0xD00A0004,
    /** Device ID for Izzy. */                  ATDevice_IZZY_ID            = 0xD00A0005,
    /** Device ID for Bromine. */               ATDevice_BROMINE_ID         = 0xD00B0001,
};

/*!
 Device BCD List for devices supported by ::ATDeviceDiscovery.
 
 */
typedef NS_ENUM(uint32_t, ATDeviceBCD) {
    /** Device BCD for an invalid device. */    ATDeviceInvalidBCD          = 0x0000,
    /** Device BCD for Potassium. */            ATDevicePotassiumBCD        = 0x0001,
    /** Device BCD for Sodium. */               ATDeviceSodiumBCD           = 0x0002,
    /** Device BCD for Carbon. */               ATDeviceCarbonBCD           = 0x0003,
    /** Device BCD for Caesium. */              ATDeviceCaesiumBCD          = 0x0004,
    /** Device BCD for Titanium. */             ATDeviceTitaniumBCD         = 0x0005,
    /** Device BCD for C3PO. */                 ATDeviceC3PO_BCD            = 0x0006,
    /** Device BCD for Mantis. */               ATDeviceMantisBCD           = 0x0007,
    /** Device BCD for Zinc. */                 ATDeviceZincBCD             = 0x0008,
    /** Device BCD for Wolf. */                 ATDeviceWolfBCD             = 0x0009,
    /** Device BCD for Iodine. */               ATDeviceIodineBCD           = 0x000A,
    /** Device BCD for Molybdenum. */           ATDeviceMolybdenumBCD       = 0x000B,
    /** Device BCD for Gimli. */                ATDeviceGimliBCD            = 0x000C,
    /** Device BCD for Raven. */                ATDeviceRavenBCD            = 0x000D,
    /** Device BCD for Dalmatian. */            ATDeviceDalmatianBCD        = 0x000E,
    /** Device BCD for Spartan. */              ATDeviceSpartanBCD          = 0x000F,
    /** Device BCD for Legolas. */              ATDeviceLegolasBCD          = 0x0010,
    /** Device BCD for Nibbler. */              ATDeviceNibblerBCD          = 0x0011,
    /** Device BCD for Astatine. */             ATDeviceAstatineBCD         = 0x0012,
    /** Device BCD for Bromine. */              ATDeviceBromineBCD          = 0x0013,
    /** Device BCD for Izzy. */                 ATDeviceIzzyBCD             = 0x0016,
};

#endif /* ATDeviceElementsCommon_h */
