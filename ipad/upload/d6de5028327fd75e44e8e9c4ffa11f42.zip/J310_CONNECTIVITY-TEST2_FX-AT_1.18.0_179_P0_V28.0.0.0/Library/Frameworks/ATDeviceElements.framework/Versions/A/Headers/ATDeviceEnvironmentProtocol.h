//
//  ATDeviceEnvironmentProtocol.h
//  ATDeviceElements
//
//  Created by Arjun Agaram Mangad on 10/22/19.
//  Copyright © 2019 htwe. All rights reserved.
//

#ifndef ATDeviceEnvironmentProtocol_h
#define ATDeviceEnvironmentProtocol_h
@protocol ATDeviceEnvironmentCapable < NSObject >
/**
 Save the current environment variables
 
 @param anError set if error in setting the environment variables in fw
 @return Yes or No depending on success in setting  env variables in fw
 */
-(BOOL)saveEnvironmentVariablesWithError:(out NSError **)anError;

@end
#endif /* ATDeviceEnvironmentProtocol_h */
