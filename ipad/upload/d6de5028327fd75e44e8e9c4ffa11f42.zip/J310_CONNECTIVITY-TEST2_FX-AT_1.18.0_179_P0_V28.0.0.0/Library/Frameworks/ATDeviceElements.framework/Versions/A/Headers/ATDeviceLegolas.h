//
//  ATDeviceLegolas.h
//  ATDeviceElements
//
//  Created by Arjun Agaram Mangad on 9/10/18.
//  Copyright © 2018 htwe. All rights reserved.
//

#import <ATDeviceElements/ATDeviceElements.h>



@interface ATDeviceLegolas : ATDPowerDevice

@end


