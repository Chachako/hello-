//
//  ATDFixtureIOProtocols.h
//  ATDeviceElements
//
//  Created by Sai  on 9/10/19.
//  Copyright © 2019 htwe. All rights reserved.
//

#ifndef ATDFixtureIOProtocols_h
#define ATDFixtureIOProtocols_h

typedef NS_ENUM(uint8_t, ATDeviceDIOType) {
    ATDeviceDIOLow = 0,
    ATDeviceDIOHigh,
    ATDeviceDIOToggle,
    ATDeviceDIOFlash,
    ATDeviceDIOUnknown = 0xFF
    
};

typedef NS_ENUM(uint8_t, ATDFixtureI2CMode) {
    ATDFixtureI2CModeI2C       = 0,
    ATDFixtureI2CModeSMBusDevice,
    ATDFixtureI2CModeSMBusHost,
    ATDFixtureI2CModeTotal
};

typedef NS_ENUM(uint8_t, ATDFixtureI2CAckAddressMode) {
    ATDFixtureI2CAckAddressMode7bit       = 0,
    ATDFixtureI2CAckAddressMode10bit,
    ATDFixtureI2CAckAddressModeTotal
};

typedef NS_ENUM(uint8_t, ATDFixtureSpiCPOL){
    
    ATDFixtureSpiCPOLLow= 0,  //Clock Idle = Low
    ATDFixtureSpiCPOLHigh     //Clock Idle = High
};

typedef NS_ENUM(uint8_t, ATDFixtureSpiCPHA){
    ATDFixtureSpiCPHA1Edge= 0, //Leading Edge Falling edge
    ATDFixtureSpiCPHA2Edge     //Trailing Edge  Rising Edge
};


typedef NS_ENUM(uint8_t, ATDFixtureSpiFirstBit){
    
    ATFixtureSpiFirstBitMSB= 0,
    ATFixtureSpiFirstBitLSB
};
typedef NS_ENUM(uint16_t, ATDFixtureSpiBaudRate){
    
    ATDFixtureSpiBaudRate21MHz = 2,
    ATDFixtureSpiBaudRate10_5MHz = 4,
    ATDFixtureSpiBaudRate5_25MHz = 8,
    ATDFixtureSpiBaudRate2_63MHz = 16,
    ATDFixtureSpiBaudRate1_31MHz = 32,
    ATDFixtureSpiBaudRate656kHz = 64,
    ATDFixtureSpiBaudRate328kHz = 128,
    ATDFixtureSpiBaudRate164kHz = 255,
    ATDFixtureSpiBaudRateNumOfFixtureSPIBaudRate,
};

typedef NS_ENUM(uint8_t, ATDFixtureUARTwordLength) {
    ATDFixtureUARTWordLength8Bytes =0,
    ATDFixtureUARTWordLength9Bytes,
    ATDNumOfFixtureUartWordLength
};

typedef NS_ENUM(uint8_t, ATDFixtureUARTStopBitType) {
    ATDFixtureUARTStopBits_1 =0,
    ATDFixtureUARTStopBits_0_5,
    ATDFixtureUARTStopBits_2,
    ATDFixtureUARTStopBits_1_5,
    ATDNumOfFixtureUartStopBitsType
};

typedef NS_ENUM(uint8_t, ATDFixtureUARTParityType) {
    ATDFixtureUARTParityNone =0,
    ATDFixtureUARTParityEven,
    ATDFixtureUARTParityOdd,
    ATDNumOfFixtureUartParityType
};

typedef NS_ENUM(uint8_t, ATDFixtureUARTFlowControl) {
    ATDFixtureUARTHW_FlowControl_None =0,
    ATDFixtureUARTHW_FlowControl_RTS,
    ATDFixtureUARTHW_FlowControl_CTS,
    ATDFixtureUARTHW_FlowControl_RTS_CTS,
    ATDNumOfFixtureUartFlowControl
};

@protocol ATDFixtureIOCapable < NSObject >

/**
 write Digital Output

 @param iOIndex DIO Index
 @param value  ATDeviceDIOType
 @param error nil = NO error, or error set.
 @return YES = sucess , NO = Error;
 */
- (BOOL)  writeDigitalOutput: (NSInteger) iOIndex
                    andValue: (ATDeviceDIOType) value
                    andError: (out NSError **) error;

/**
 read Digital Input

 @param iOIndex DIO Index
 @param error nil = NO error, or error set.
 @return ATDeviceDIOLow (0) or ATDeviceDIOHigh (1).
 */
- (ATDeviceDIOType) readDigitalInput: (NSInteger) iOIndex
                            andError: (out NSError **) error;

/**
 save Digital Output Reset Configuration
 
 @param error nil = NO error, or error set.
 @return YES or NO depending on result
 */
- (BOOL)  saveDigitalOutputResetConfigWithError: (out NSError**) error;

/**
 Configure i2c bus speed, mode and ack mode

 @param i2cId bus id that can be configured for passed device
 @param mode ::ATDFixtureI2CMode
 @param i2cAddress i2c address to configure
 @param clockSpeed clock speed to configure it to
 @param enableAck Yes or NO to enable/disable ack
 @param ackAddressMode ::ATDFixtureI2CAckAddressMode
 @param aError error if method fails
 @return YES or NO depending on result
 */
-(BOOL) configureI2C: (int) i2cId
             andMode: (ATDFixtureI2CMode) mode
          andI2cAddr: (uint16_t) i2cAddress
       andClockSpeed: (uint32_t) clockSpeed
        andEnableAck: (BOOL) enableAck
       andAckAddress: (ATDFixtureI2CAckAddressMode)ackAddressMode
            andError: (out NSError ** ) aError;

/**
 Send/Receive I2C Message for unique user bus id for the device

 @param aAdress 7 bit i2c address. Some vendors incorrectly provide two 8-bit slave addresses for their device,
 one to write to the device and one to read from the device.
 This 8-bit number actually encodes the 7-bit slave address and the read/write bit.
 it is important to only use the top 7 bits of the address as the slave address.
 That is why you need shift the address 1 bit to get rid of the  read/write bit.
 e.g. 24LC02 EEPROM i2c address is 0xA0 = Write address and 0xA1 is the read address. The actual Address is (0xA0 >> 1).
 @param writeLen write dnumber of data in byte
 @param readLen Read number of data in byte
 @param data Write and Read both share this array. Size of this array must be bigger than writeLen and readLen. Max size is 255.
 @param aError returns an error if something failed
 @return returns result YES or NO based on pass or fail
 */
- (BOOL) i2cTransferWithAddress: (uint8_t) aAdress
                    andWriteLen: (uint8_t) writeLen
                     andReadLen: (uint8_t) readLen
                        andData: (uint8_t*) data
                       andError: (out NSError **) aError;


/**
 Sets spi baudrate from ::ATDFixtureSpiBaudRate And set serial clock steady state from ::ATDFixtureSpiCPOL
 and set active clock edge from ::ATDFixtureSpiCPHA and endiannes of data transfer from ::ATDFixtureSpiFirstBit
 
 @param baudRate set baud rate according to ::ATDFixtureSpiBaudRate
 @param cpol set serial clock steady state from ::ATDFixtureSpiCPOL
 @param cpha set active clock edge from ::ATDFixtureSpiCPHA
 @param firstBit endiannes of data transfer from ::ATDFixtureSpiFirstBit
 @param aError error if setting baud rate failed
 @return yes or no based on whether baud rate was succesfuly set
 */
- (BOOL) configureSPIwithBaudRate: (ATDFixtureSpiBaudRate) baudRate
                          andCPOL: (ATDFixtureSpiCPOL) cpol
                          andCPHA: (ATDFixtureSpiCPHA) cpha
                      andFirstBit: (ATDFixtureSpiFirstBit) firstBit
                         andError: (NSError **) aError;


/**
 Transfer spi data with arguments

 @param isWriteAndReadMode If set to yes function will write one byte and then read one byte
 @param writeLen Number of bytes to write
 @param readLen Number of bytes to read
 @param data spi data
 @param aError error if spi transfer failed
 @return yes or no based on whether spi data was transfered
 */
- (BOOL) spiTransferWithWriteAndRead: (BOOL) isWriteAndReadMode
                         andWriteLen: (uint8_t) writeLen
                          andReadLen: (uint8_t) readLen
                             andData: (uint8_t*) data
                            andError: (out NSError **) aError;

/**
 Read all temperatures on the fixture controller
 
 @param aError error if error (4CC Failed or invalid response)
 @return NSMutable array of temperatures of NSNumbers representing the temperatures read;
 */

- (NSArray*) readAllTemperaturesIntoArrayWithError: (out NSError **) aError;


/**
 configureUart

 @param uartId ID of the target UART
 @param wordLen Number of word
 @param stopBits UART Stop Bit
 @param parity UART Parity
 @param flowControl UART Flow control
 @param baudRate UART BaudRate
 @param aError   aError will be set if API failed
 @return YES = Successed and NO = Error
 */
-(BOOL) configureUart: (int) uartId
        andWordLength: (ATDFixtureUARTwordLength) wordLen
          andStopBits: (ATDFixtureUARTStopBitType) stopBits
            andParity: (ATDFixtureUARTParityType) parity
     andHWFlowControl: (ATDFixtureUARTFlowControl) flowControl
          andBaudRate: (uint32_t) baudRate
             andError: (out NSError**) aError;

/**
 uartStartStreaming

 @param uartId ID of the target UART
 @param wordLen  Number of word
 @param stopBits UART Stop Bit
 @param parity UART Parity
 @param flowControl UART Flow control
 @param baudRate UART BaudRate
 @param aError aError will be set if API failed
 @return YES = Successed and NO = Error
 */
-(BOOL) uartStartStreaming: (int) uartId
             andWordLength: (ATDFixtureUARTwordLength) wordLen
               andStopBits: (ATDFixtureUARTStopBitType) stopBits
                 andParity: (ATDFixtureUARTParityType) parity
          andHWFlowControl: (ATDFixtureUARTFlowControl) flowControl
               andBaudRate: (uint32_t) baudRate
                  andError: (out NSError**) aError;

/**
 uartStartStreaming

 @param uartId ID of the target UART
 @param wordLen  Number of word
 @param stopBits UART Stop Bit
 @param parity UART Parity
 @param flowControl UART Flow control
 @param baudRate UART BaudRate
 @param fifoIndex FIFO index
 @param aError aError will be set if API failed
 @return YES = Successed and NO = Error
 */
-(BOOL) uartStartStreaming: (int) uartId
             andWordLength: (ATDFixtureUARTwordLength) wordLen
               andStopBits: (ATDFixtureUARTStopBitType) stopBits
                 andParity: (ATDFixtureUARTParityType) parity
          andHWFlowControl: (ATDFixtureUARTFlowControl) flowControl
               andBaudRate: (uint32_t) baudRate
        andStreamFIFOIndex: (uint8_t)  fifoIndex
                  andError: (out NSError**) aError;

/**
 uartStopStreaming

 @param uartId ID of the target UART
 @param aError aError will be set if API failed
 @return YES = Successed and NO = Error
 */
-(BOOL) uartStopStreaming: (int) uartId
                 andError: (out NSError**) aError;

/**
 uartTransferWithBusId
 
 @brief Command = URTm: Write UART and Read UART until see the Terminator string.
 
 @param uartID is UART ID 1 to 6.
 @param writeLen is Number of bytes to write. Max 256-32 = 224.
 @param readTerminator is UART read will stop when see this terminator. Max number of character is 32. Pass nil if don't to read
 @param actualRead is The Actual Read only valid if readTerminator is non nil. Max it's 255 bytes
 @param data is The Data to read and write. Size Must be at least 256 byte.
 @param uartReadTimeOutInMiliSeconds is read time out in Milio seconds
 @param aError nil = NO error, or error set. Error code is defined in <ATDeviceElements/ATDeviceCarbonErrors.h>
 @return BOOL: YES = sucess NO = Error;
 */

- (BOOL) uartTransferWithBusId: (uint8_t)   uartID
                   andWriteLen: (uint8_t)   writeLen
             andReadTerminator: (NSString*) readTerminator
                 andActualRead: (uint16_t*) actualRead
                       andData: (uint8_t*)  data
            andUartReadTimeOut: (uint16_t)  uartReadTimeOutInMiliSeconds
                      andError: (NSError**) aError;

/**
 uartFlushWithMaxBytes
 
 @brief Flushes uart buffer by reading bytes and throwing them away.
 
 @param maxBytesToFlush                Maximum nuymber of bytes to flush, this is an upper limit
 @param uartTimeOutInMiliSeconds       This is a lower limit on the length of time this call will take.  This should be as small as possible
 
 @note: undefined behavior if UART is not oppened correctly
 */
- (void) uartFlushWithMaxBytes: (uint32_t) maxBytesToFlush
                     andTimout: (uint16_t) uartTimeOutInMiliSeconds;

@end

#endif /* ATDFixtureIOProtocols_h */
