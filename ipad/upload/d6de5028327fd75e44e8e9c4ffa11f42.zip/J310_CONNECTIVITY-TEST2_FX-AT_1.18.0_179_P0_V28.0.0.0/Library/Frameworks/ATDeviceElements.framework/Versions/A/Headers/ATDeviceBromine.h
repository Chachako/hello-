//
//  ADeviceBromine.h
//  ATDeviceElements
//
//  Created by Sai on 4/22/19.
//  Copyright © 2019 htwe. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <ATDeviceElements/ATDeviceIodine.h>

NS_ASSUME_NONNULL_BEGIN

@interface ATDeviceBromine : ATDeviceIodine

@end

NS_ASSUME_NONNULL_END
