//
//  ATDeviceGimli.h
//  ATDeviceElements
//
//  Created by Sai  on 3/26/18.
//  Copyright © 2018 htwe. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <ATDeviceElements/ATDPowerDevice.h>

@interface ATDeviceGimli : ATDPowerDevice

@end
