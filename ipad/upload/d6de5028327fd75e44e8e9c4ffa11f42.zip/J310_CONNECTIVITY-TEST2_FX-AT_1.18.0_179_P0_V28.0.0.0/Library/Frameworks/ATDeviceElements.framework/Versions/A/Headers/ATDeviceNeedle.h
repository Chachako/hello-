//
//  ATDeviceNeedle.h
//  ATDeviceElements
//
//  Created by Cody Shaw  on 7/22/19.
//  Copyright © 2019 htwe. All rights reserved.
//

#import <ATDeviceElements/ATDeviceElements.h>
#import <ATDeviceElements/ATDeviceWirelessDebug.h>


@interface ATDeviceNeedle : ATDeviceWirelessDebug


@end
