----------------------Skunk(aka InstantPudding)---------------------
print("load and do InstantPudding script...")

local bStatus, ip = pcall(require, "ip");
if bStatus and ip then
    print("require InstantPudding library success!");
else
    print("require InstantPudding library fail:", ip);
    return nil;
end

------------------------------------Smart fuction-------------------
local function CreatEnumTable(tbl, index) 
    --assert(IsTable(tbl)) 
    local enumtbl = {} 
    local enumindex = (index or 0) - 1 
    for i, v in ipairs(tbl) do 
        enumtbl[v] = enumindex + i 
    end 
    return enumtbl 
end

--------------------------------------------------------------------
IPTable = {}
---------------------------------------------------------------------
IPTable.IP_API_VERSION = 1
IPTable.IP_API_VERSION_MINOR = 1

--Test Results
IP_PASSFAILRESULT = 
{ 
    "IP_FAIL", -- test failed
    "IP_PASS", -- test passed
    "IP_NA", -- test was not run or was skipped
}
IP_PASSFAILRESULT = CreatEnumTable(IP_PASSFAILRESULT, 0) 

--Following enums are to extract the info from the gh_station_info.json 
--file which exists in the /vault/pudding/ folder
IP_ENUM_GHSTATIONINFO = 
{
    "IP_SITE",             --SiteCode for the CM from PDCA (predetermined)
    "IP_PRODUCT",              --Product code name such as N88, N82 (predetermined)
    "IP_BUILD_STAGE",			 --Build stage
    "IP_BUILD_SUBSTAGE",		 --Build sub stage
    "IP_REMOTE_ADDR",          --Test Station ip address (DHCP 24 hrs lease)
    "IP_LOCATION",             --CM building-Floor-Room and floor DA3-2FL-RM123 (predetermined)
    "IP_LINE_NUMBER",          --Official APPLE line name froom PDCA (predetermined)
    "IP_STATION_NUMBER",       --Test Station number on the line (setup when ground hogging)
    "IP_STATION_TYPE",         --PDCA station id code e.g SHIPPING-SETTINGS-OQC (should be same as GH, set up when ground hogging)
    "IP_SCREEN_COLOR",		 --Perferred default background screen color(set up, when ground hogging)
    "IP_STATION_IP",           --Test Station ip address (DHCP 24 hrs lease)
    "IP_DCS_IP",               --ip address to submit data to the Data Collection server
    "IP_PDCA_IP",              --ip address of the PDCA
    "IP_KOMODO_IP",            --ip address for monitoring server 
    "IP_SPIDERCAB_IP",		 --Spidercab IP
    "IP_FUSING_IP",			 --Fusing IP
    "IP_DROPBOX_IP",			 --Dropbox IP
    "IP_SFC_IP",				 --SFC IP
    "IP_SFC_URL",				 --SFC URL
    "IP_PROV_IP",				 --PROV IP
    "IP_DATE_TIME",            --last time when pudding updated the file
    "IP_STATION_ID",			 --GUID of the station SITE+LOCATION+LINE_NUMBER+STATION_NUMBER+STATION_TYPE
    "IP_GROUNDHOG_IP",         --ip address of the groundhog server
    "IP_MAC",					 --Station mac address
    "IP_SAVE_BRICKS",			 --Saving bricks
    "IP_LOCAL_CSV",			 --Saving csv locally 
    "IP_REALTIME_PARAMETRIC",  --Real time parametic
    "IP_SINGLE_CSV_UUT",       --Single CSV UUT
    "IP_STATION_DISPLAY_NAME", --station_display_name such as VIDEO-PREBURN
    "IP_URI_CONFIG_PATH",		 --URI Station config path
    "IP_SFC_QUERY_UNIT_ON_OFF",
    "IP_SFC_TIMEOUT",
    "IP_GHSI_LASTUPDATE_TIMEOUT",
    "IP_FERRET_NOT_RUNNING_TIMEOUT",
    "IP_NETWORK_NOT_OK_TIMEOUT",
    "IP_STATION_SET_CONTROL_BIT_ON_OFF",
    "IP_CONTROL_BITS_TO_CHECK_ON_OFF",
    "IP_CONTROL_BITS_TO_CLEAR_ON_PASS_ON_OFF",
    "IP_CONTROL_BITS_TO_CLEAR_ON_FAIL_ON_OFF",
    "IP_ACTIVATION_IP",		 --ip address of activation server
    "IP_LINE_MANAGER_IP",		 --ip for RAFT
    "IP_GDADMIN",
    "IP_RAFT_LINE",
    "IP_USB_STORAGE",
    "IP_FIREWALL",
    "IP_UNIT_PROCESS_REQUIRE_BOBCAT",
    "IP_GROUNDHOG_STARTED",
    "IP_LAST_RESTORED",
    "IP_CONTROL_RUN",
    "IP_CONTROL_RUN_CB",
    "IP_FDR_REGISTRATION",
    "IP_SEND_BLOBS_ON_FAIL_ONLY",
    "IP_SEND_BLOBS_ON",
    "IP_LIVE_VERSION",
    "IP_LIVE_CURRENT",
    "IP_LIVE_SCHEDULED",
    "IP_LIVE_VERSION_PATH",
    "IP_LINE_TYPE",
    "IP_GHSTATIONINFO_COUNT",
    "IP_MARINA_URL",
    "IP_MAX_NUMBER_BLOBS"  
}
IP_ENUM_GHSTATIONINFO = CreatEnumTable(IP_ENUM_GHSTATIONINFO, 1)

IP_ENUM_BLOBPOLICY = 
{ 
    "IP_FOREVER", 
    "IP_30DAYS", 
    "IP_60DAYS",
    "IP_90DAYS", 
    "IP_180DAYS", 
    "IP_270DAYS",
    "IP_360DAYS"
}
IP_ENUM_BLOBPOLICY = CreatEnumTable(IP_ENUM_BLOBPOLICY, 1)

--"will be deprecated"
IP_ENUM_FIXTURE_ID = 
{
    "IP_FIXTURE_ID_1",	  -- FIXTURE ID 1 
    "IP_FIXTURE_ID_2",		-- FIXTURE ID 2
    "IP_FIXTURE_ID_3",		-- FIXTURE ID 3
    "IP_FIXTURE_ID_4",		-- FIXTURE ID 4
    "IP_FIXTURE_ID_5",		-- FIXTURE ID 5
    "IP_FIXTURE_ID_6",		-- FIXTURE ID 6
    "IP_FIXTURE_ID_7",		-- FIXTURE ID 7
    "IP_FIXTURE_ID_8",		-- FIXTURE ID 8
    "IP_FIXTURE_ID_9",		-- FIXTURE ID 9
    "IP_FIXTURE_ID_10	"	  --FIXTURE ID 10
}
IP_ENUM_FIXTURE_ID = CreatEnumTable(IP_ENUM_FIXTURE_ID, 1)

--"will be deprecated"
IP_ENUM_FIXTURE_HEAD_ID = 
{
    "IP_FIXTURE_HEAD_ID_1", 	--HEAD ID 1 
    "IP_FIXTURE_HEAD_ID_2",		--HEAD ID 2
    "IP_FIXTURE_HEAD_ID_3",		--HEAD ID 3
    "IP_FIXTURE_HEAD_ID_4",		--HEAD ID 4
    "IP_FIXTURE_HEAD_ID_5",		--HEAD ID 5
    "IP_FIXTURE_HEAD_ID_6	"	--HEAD ID 6
}
IP_ENUM_FIXTURE_HEAD_ID = CreatEnumTable(IP_ENUM_FIXTURE_HEAD_ID, 1)

--special strings for results / attributes
IPTable.IP_ATTRIBUTE_SERIALNUMBER="serialnumber"--"unit_serial_number" -- the FINISHED GOODS serial number
IPTable.IP_ATTRIBUTE_STATIONSOFTWAREVERSION="softwareversion"--"software_version"
IPTable.IP_ATTRIBUTE_STATIONSOFTWARENAME="softwarename"--"software_name"
IPTable.IP_ATTRIBUTE_STATIONLIMITSVERSION="limitsversion"--"limits_version"

IPTable.IP_ATTRIBUTE_OPERATOR_ID="operatorid" --"operator_id"
IPTable.IP_ATTRIBUTE_HEAD_ID="head_id"  --
IPTable.IP_ATTRIBUTE_FIXTURE_ID="fixture_id"
IPTable.IP_ATTRIBUTE_SWVERSION="sw_version" --"software_version"

IPTable.IP_ATTRIBUTE_STATIONIDENTIFIER="STATION_IDENTIFIER"--"station_id"

IPTable.IP_ATTRIBUTE_STATIONSUBIDENTIFIER="STATION_SUB_IDENTIFIER"--"sub_station"
IPTable.IP_ATTRIBUTE_BUILD_EVENT="BUILD_EVENT"			--ex: N82PPVT
IPTable.IP_ATTRIBUTE_BUILD_MATRIX_CONFIG="BUILD_MATRIX_CONFIG"	--ex: R4
IPTable.IP_ATTRIBUTE_UNIT_NUMBER="UNIT#"
--IPTable.IP_ATTRIBUTE_UNIT_NUMBER="unitnumber"			--ex: 120
IPTable.IP_ATTRIBUTE_SPECIAL_BUILD="S_BUILD"				--ex: N82PPVT_R4_120 ( build_config_unitnumber )

IPTable.IP_ATTRIBUTE_MLBSERIALNUMBER="MLBSN"					-- the BOARD LEVEL serial number
IPTable.IP_ATTRIBUTE_MACADDRESS_WIFI="WIFI_MAC_ADDR"
IPTable.IP_ATTRIBUTE_MACADDRESS_BT="BT_MAC_ADDR"
IPTable.IP_ATTRIBUTE_MACADDRESS_ENET="EOUSB_MAC_ADDR"

IPTable.IP_ATTRIBUTE_BATTERY_SERIAL_NUMBER="BATTERY_SN"
IPTable.IP_ATTRIBUTE_REGION_CODE="REGION_CODE"
IPTable.IP_ATTRIBUTE_MPN="MPN"

IPTable.IP_ATTRIBUTE_IMEI="IMEI"
IPTable.IP_ATTRIBUTE_BASEBAND_VERSION="BASEBAND_VERSION"
IPTable.IP_ATTRIBUTE_BOOTCORE_VERSION="BOOTCORE_VERSION"
IPTable.IP_ATTRIBUTE_OS_BUILD_VERSION="OS_BUILD_VERSION"
IPTable.IP_ATTRIBUTE_CAMERA_CONFIG="CAMERA_CONFIG"
IPTable.IP_ATTRIBUTE_ECID="ECID"

IPTable.IP_ATTRIBUTE_DIAG_DATE="DIAG_DATE"
IPTable.IP_ATTRIBUTE_DIAG_VERSION="DIAG_VERSION"
IPTable.IP_ATTRIBUTE_CHIP_SN="CHIP_SN"

IPTable.IP_ATTRIBUTE_BASEBAND_SN="BASEBAND_SN"
IPTable.IP_ATTRIBUTE_PRODUCTION_SOC="PRODUCTION_SOC"
IPTable.IP_ATTRIBUTE_UDID="UDID"

--very common error strings
IPTable.IP_FAIL_ABOVE_SPEC="Above spec"
IPTable.IP_FAIL_BELOW_SPEC="Below spec"
IPTable.IP_FAIL_COMMUNICATION_UUT="Can't communicate with unit"
IPTable.IP_FAIL_COMMUNICATION_EQUIPMENT="Can't communicate with test equipment"
IPTable.IP_FAIL_WRITING_NOR="Failed to write to NOR"
IPTable.IP_FAIL_READING_NOR="Failed to read from NOR"
IPTable.IP_FAIL_CONTROL_BIT_NOT_SET="Control bit not set"
IPTable.IP_FAIL_INVALID_SERIAL_NUMBER="Serial number invalid"
IPTable.IP_FAIL_INVALID_STATION_ID="Station identifier invalid"
IPTable.IP_FAIL_NO_AUDIO="No audio from device"

--standard UNIT values

-- decibels
IPTable.IP_UNITS_DB="dB"
IPTable.IP_UNITS_DBV="dBV"
IPTable.IP_UNITS_DBM="dBm"
IPTable.IP_UNITS_DBR="dBr"
IPTable.IP_UNITS_DBW="dBW"
IPTable.IP_UNITS_DBVPASCAL="dB(V/Pa)"
IPTable.IP_UNITS_DBPASCALV="dB(Pa/V)"

-- electrical
IPTable.IP_UNITS_VOLTS="V"
IPTable.IP_UNITS_MILLIVOLTS="mV"
IPTable.IP_UNITS_WATTS="W"
IPTable.IP_UNITS_MILLIWATTS="mW"
IPTable.IP_UNITS_AMPERES="A"
IPTable.IP_UNITS_MILLIAMPERES="mA"
IPTable.IP_UNITS_OHMS="Ohms"
IPTable.IP_UNTIS_MILLIOHMS="mOhms"
IPTable.IP_UNTIS_KILOOHMS="kOhms"
IPTable.IP_UNITS_MEGAOHMS="MOhms"
IPTable.IP_UNITS_RMS="RMS"

-- misc. category
IPTable.IP_UNITS_HZ="Hz"
IPTable.IP_UNITS_KHZ="kHz"
IPTable.IP_UNITS_MHZ="MHz"
IPTable.IP_UNITS_FOOTLBS="ftLbs"
IPTable.IP_UNITS_PERCENT="%"

-- distances
IPTable.IP_UNITS_MM="mm"
IPTable.IP_UNITS_INCHES="inches"
IPTable.IP_UNITS_MILES="miles"
IPTable.IP_UNITS_PARSECS="parsecs"
--Misc defines
IPTable.IP_NOVALUE="NA"
IPTable.IP_RETVALUE="RetValue"

-- PDCA priority definitions
IP_PDCA_PRIORITY = 
{ 
    IP_PRIORITY_STATION_CALIBRATION_AUDIT = -2,
    IP_PRIORITY_STATION_GRR = -3,
    IP_PRIORITY_REALTIME_WITH_ALARMS = 0,
    IP_PRIORITY_REALTIME = 1,
    IP_PRIORITY_DELAYED_WITH_DAILY_ALARMS	= 2,
    IP_PRIORITY_DELAYED_IMPORT = 3,
    IP_PRIORITY_ARCHIVE = 4,
}

IPTable.IP_PDCA_DEFAULT_PRIORITY = IP_PDCA_PRIORITY.IP_PRIORITY_REALTIME_WITH_ALARMS

IPTable.IP_MSG_RESULT_OFFSET = 31
IPTable.IP_MSG_RESULT_PASS = 0
IPTable.IP_MSG_RESULT_FAIL = 1
--message class, 10 bits : 29-20
IPTable.IP_MSG_CLASS_OFFSET = 20

IP_MSG_CLASS = 
{
    IP_MSG_CLASS_UNCLASSIFIED = 0,
    IP_MSG_CLASS_API_ERROR = 1,
    IP_MSG_CLASS_COMM_ERR = 2,	-- some kind of communication error
    IP_MSG_CLASS_QUERY = 4,	-- used to initiate a query
    IP_MSG_CLASS_QUERY_RESPONSE = 8,	-- response from a query
    IP_MSG_CLASS_QUERY_DELAYED_RESPONSE = 16,	-- delayed response from a query 
    IP_MSG_CLASS_PROCESS_CONTROL = 32,
    IP_MSG_CLASS_COUNT = 33	-- must be the last item in this list (should always be less than 2^10)
}

--reserved, 4 bits: 19 - 16
IPTable.IP_MSG_RESERVED_OFFSET = 16
--message identifiers 16 bits : 15-0
IPTable.IP_MSG_IDENTIFIER_OFFSET	= 0

IP_QUERY_NUMBER = 
{ 
    "IP_QUERY_AMIOK", 
    "IP_QUERY_STATION_SW", 
    "IP_QUERY_COUNT",
}
IP_QUERY_NUMBER = CreatEnumTable(IP_QUERY_NUMBER, 0) 

IP_MSG_NUMBER = 
{ 
    -- api errors
    "IP_MSG_ERROR_API_UNHANDLED",		-- unhandled / system exception in catch(...)
    "IP_MSG_ERROR_UNIT_ID_INVALID",	-- no one has called 'start' or someone called 'done' or 'commit' and is trying to submit more results
    "IP_MSG_ERROR_UNIMPLEMENTED",		-- API isn't actually there (for some reason)
    "IP_MSG_ERROR_API_VERSION",		-- API version isn't right (not much resolution here)
    "IP_MSG_ERROR_API_SYNTAX",		-- API usage isn't right	
    "IP_MSG_ERROR_API_NO_ATTRIBUTE",	-- API error: attribute does not exist
    "IP_MSG_ERROR_FERRET_NOT_RUNNING",	-- Pudding hasn't touched its PID file recently
    "IP_MSG_ERROR_FILESYSTEM",	
    "IP_MSG_ERROR_NETWORK",				-- test station <==> servers (PDCA, DCS, GH, etc.)
    "IP_MSG_ERROR_INVALID_SERIAL_NUMBER",	-- serial number in a bad format
    -- Data collection AmIOK responses
    "IP_MSG_ERROR_DCS_NOT_RESPONDING",	--
    "IP_MSG_ERROR_PDCA_NOT_RESPONDING",	--
    "IP_MSG_ERROR_GROUNDHOG_NOT_RESPONDING", --
    "IP_MSG_ERROR_NETWORK_NOT_RESPONDING", --
    "IP_MSG_ERROR_ETHERNET_NOT_RESPONDING", --
    "IP_MSG_ERROR_UNIT_OUT_OF_PROCESS",
    "IP_MSG_ERROR_INVALID_STATION_TYPE", --
    "IP_MSG_ERROR_INVALID_SW_VERSION", --
    "IP_MSG_ERROR_INVALID_IP_VERSION", --
    "IP_MSG_ERROR_INVALID_FERRET_VERSION", --
    "IP_MSG_ERROR_INVALID_GHSTATIONINFO_VALUE",
    --Test, sub test, sub sub test name errors
    "IP_MSG_ERROR_INVALID_DATA_FORMAT",
    -- unit AmIOK responses (come down from PDCA, DCS, GH, SFC)
    "IP_MSG_UNIT_GOLDEN_UNIT",	-- unit is 'golden'
    "IP_MSG_UNIT_OUTLIER",		-- unit is a statistical outlier
    "IP_MSG_UNIT_ESCAPE",			-- unit has skipped previous station(s)
    "IP_MSG_UNIT_FORCE_FAIL",		-- someone is telling you to force this failure
    "IP_MSG_UNIT_RECALL",			-- Known bad hardware correlated to serial number or behavior
    "IP_MSG_UNIT_HOLD",			-- Hold this unit for someone (message contains radar# or more info)
    "IP_MSG_UNIT_NOT_IN_SFC",		-- unit can not be validated from the SFC server
    -- responses from queries
    "IP_MSG_STATION_SW_MISMATCH",	-- your station software ain't right.  The message member contains the version you should be using.
    "IP_MSG_STATION_OUTLIER",		-- your station is causing a lot of outlier failures. take it offline.
    "IP_MSG_ERROR_INVALID_SIGNATURE", --digital signature in gh_station_info.json file is not valid
    "IP_MSG_ERROR_INVALID_ATTRIBUTE",
    "IP_MSG_ERROR_SFC_QUERY_UNIT",
    "IP_MSG_ERROR_UMBRELLA_AMIOKAY",
    "IP_MSG_ERROR_INVALID_STATION_ID",
    "IP_MSG_ERROR_TIMESERVER_NOT_RESPONDING",
    "IP_MSG_USER",			-- put user messages after this one (IP_MSG_USER, IP_MSG_USER+1, +2, +3, etc.)
    "IP_MSG_COUNT"	-- this must always be the last in the enum (to determine range of this enum)
}
IP_MSG_NUMBER = CreatEnumTable(IP_MSG_NUMBER, 0)

----------------------------------------------------------------------------------
return ip;
----------------------------------------------------------------------------------
