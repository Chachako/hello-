
----------------------------------------test items------------------------------------------
function testCommand(self)
  doFixtureCmd("get_status\n")
  doFixtureCmd("move_cylinder:1,1\n") --RX
  app.wait(10000)
  doFixtureCmd("move_cylinder:1,0\n") --RX
  ResultTable.resultCode = true

end

-- function itemInitFixture(self)
--   ComTable["position_x"] = 0
--   ComTable["position_y"] = 0


--   doFixtureCmd("clear_error\n")
--   doFixtureCmd("write_output:14,0\n")
--   doFixtureCmd("write_output:14,1\n")
--   doFixtureCmd("get_status\n")
--   doFixtureCmd("move_cylinder:3,1\n")  --DUT
--   app.wait(2000)
--   doFixtureCmd("move_cylinder:1,0\n")
--   local _,rtRecv = doFixtureCmd("enable_axis\n")
--   local bResult = string.find(rtRecv or "","OK")
--   doFixtureCmd("move_abs:1,0\n")
--   doFixtureCmd("move_abs:2,0\n")
--   doFixtureCmd("clear_error\n")
--   doFixtureCmd("move_cylinder:1,1\n") --RX
--   doScorpiusCmd("set mode none\r")
--   app.wait(200)
--   doScorpiusCmd("set mode rx\r")

--   app.wait(2000)
--   ResultTable.resultCode = bResult
-- end

function itemInitFixture(self)
  ComTable["position_x"] = 0
  ComTable["position_y"] = 0
  ComTable["position_z"] = 0.83 -- The inital Gap(mm) when coil move close to Tx
  ComTable["default_max_DAC"] = 1550
  ComTable["default_min_DAC"] = 200
  
--  doFixtureCmd("lockon\n")
--  doFixtureCmd("move_cylinder:1,0\n")
--  doFixtureCmd("move_cylinder:1,1\n") --RX
--  local _, recv = doFixtureCmd(string.format("setgap:%.2f\n", ComTable["position_z"])) 
  doScorpiusCmd("set mode none\r")
  app.wait(200)
  doScorpiusCmd("set mode rx\r")
  app.wait(200)
  doScorpiusCmd("set cap 0\r")
  app.wait(2000)
  local bResult = true --string.match(recv or "", "OK") and true or false
  ResultTable.resultCode = bResult
  ResultTable.resultString = bResult and "Pass" or "Please clean edge"
end

function itemtestFixcommand(self)
  for i = 1 ,10 do
    app.wait(2000)
    doFixtureCmd("right 2")
    end
  ResultTable.resultCode =true
  end


function PotassiumVersionCheck(self)
  local potassiumCmdVer = Directory.tools .. "/ktool " .. iPadPath .. " version"
  local rtPotassiumFW  =  doPotassiumCmd(potassiumCmdVer,"INFO: HW:",5)
  local tResultFW =  string.match(tostring( rtPotassiumFW) or "","INFO:.-%((%d+)%)")
  local bResult = tResultFW and true or false
  ResultTable.resultCode = bResult
  ResultTable.resultString = tResultFW
end
--Potassium Environment check
function PotassiumEnvironmentcheck(self)
  local potassiumCmd = Directory.tools .."/ktool " .. iPadPath .. " printenv"
  local rtPotassiumVer  =  doPotassiumCmd(potassiumCmd,"INFO:%s+0xFF 0xFF 0xFF 0xFF",5)
  local cable = string.match(rtPotassiumVer or "","INFO:%s+cable.-INFO:%s+(.-)\n")
  print("cable:",cable)
  local bcable = (string.match(cable or "",self.specSet.cable1)) or (string.match(cable or "",self.specSet.cable2)) and true or false

  local swd_clock = string.match(rtPotassiumVer or "","INFO:%s+swd_clock%s+=%s+(.-)\n")
  print("swd_clock:",swd_clock)
  local bswd_clock = tonumber(self.specSet.swd_clock) == tonumber(swd_clock) and true or false
  local heartbeat = string.match(rtPotassiumVer or "","INFO:%s+heartbeat%s+=%s+(.-)ms")
  print("heartbeat:",heartbeat)
  local bheartbeat = tonumber(self.specSet.heartbeat) == tonumber(heartbeat) and true or false
  local default_channel = string.match(rtPotassiumVer or "","INFO:%s+default_channel%s+=%s+(.-)\n")
  print("default_channel:",default_channel)
  local bdefault_channel = tonumber(self.specSet.default_channel) == tonumber(default_channel) and true or false
  local channel_mask = string.match(rtPotassiumVer or "","INFO:%s+channel_mask%s+=%s+(.-)\n")
  print("channel_mask:",channel_mask)
  local bchannel_mask = string.match(channel_mask or "",self.specSet.channel_mask) and true or false
  local bResult = false
  if bcable and bswd_clock and bheartbeat and bdefault_channel and bchannel_mask then
    bResult = true
  end
  ResultTable.resultCode = bResult
end

function pendingAdd(self)
  ResultTable.resultCode = false
  ResultTable.resultString = "Pending Confirm"
end

function itemEnterDiag(self)
--  doFixtureCmd("move_cylinder:1,0\n") --RX
  ComTable["scopriusX"]= 0
  ComTable["scopriusY"]= 0

-- doFixtureCmd("move_cylinder:3,1\n")

  app.wait(2000)

  local _,recvEnter = doDiagsCmd("\n",nil,3.0)
  local _,recvEnter = doDiagsCmd("\n",nil,3.0)
  local _,recvEnter = doDiagsCmd("\n",nil,3.0)
  local _,recvEnter = doDiagsCmd("\n",nil,3.0)
  local _,recvEnter = doDiagsCmd("\n",nil,3.0)
  local _,recvEnter = doDiagsCmd("\n",nil,3.0)
  if string.match(recvEnter or "",":%-%)") then
    ResultTable.resultCode = true
    return
  end
  local _,rtRecvDiags = doDiagsCmd("diags\n","] :-) ",50.0)
  local bResult = string.match(rtRecvDiags or "",":%-%)") and true or false
  ResultTable.resultCode = bResult
end



--function itemUnitSn(self)

--  local rtSend,rtRecv = doDiagsCmd("sn\n")
--  sn = string.match(rtRecv or "","Serial:%s+(%w+)") or "No data" 
--  local bResult = string.match(rtRecv or "","Serial:%s+(%w+)") and true or false
--  local tResult = bResult and sn or "No sn"
--  ResultTable.resultCode = bResult
--  ResultTable.resultString = tResult
--end

function itemDiagVersion(self)
  local currentTime = os.date("!%Y%m%d%H%M%S")
  doDiagsCmd("rtc --set " .. currentTime .. "\n")
  local rtSend,rtRecv = doDiagsCmd("ver\n")
  local _,_,version = string.find(rtRecv or "", "%((%w*)%). Revision")
  local bResult = (string.len(version or "")>0) and true or false
  version = version or "Not find version info"
  if bResult then
    g_PDCAAttribute["DIAG_VER"] = version
  end
  ResultTable.resultCode = bResult
  ResultTable.resultString = version
end

function itemScorpiusshorttest(self)

  local spec = self.line .."%s+Line%s+:%s+(%w+)"
  local testResult = string.match(rtRecv or "",spec)
  local bResult = tonumber( testResult) == 0 and true or false
  --local bResult = compareAandB(resultValue,self.limitSet.lower,self.limitSet.upper,true)
  ResultTable.resultCode = bResult
end
function itemI2C_SWD__InterfaceCheck(self)
  local rtSend,rtRecv = doDiagsCmd("i2c -s 0\n")
  local bResult = false
  if string.match(rtRecv or "", "Address: %(7%-bit%) 0x55") then
    bResult = true
  end
  ResultTable.resultCode = bResult
end  



function itemTxPing(self)
  doDiagsCmd("i2c -v 0 0x18 0x08 0x1\n")          --Set Ping mode
  doDiagsCmd("i2c -d 0 0x18 0x07 1\n")            --Ping
  doDiagsCmd("i2c -d 0 0x18 0x05 1\n")            --Check status
  local rtSend, rtRecv = doDiagsCmd("i2c -d 0 0x18 0x06 2 multiple\n")      --Read Vrect  
  local temp = string.match(rtRecv or "", "Data:%s+(%w+  %w+)")
  if not temp then  ResultTable.resultCode = false return end
  local hexStr = ""
  for i in string.gmatch(temp or "", "0x(%w+)") do 
    hexStr = i .. hexStr
  end
  local tResult = tonumber("0x" .. hexStr)
  local bResult = tResult ~= nil
  ResultTable.resultCode = bResult
  ResultTable.resultString = tResult or "No data"
end

function itemFixtureVrectMode1_mV()
  local rtSend, rtRecv = doScorpiusCmd("getv\r")
  rtRecv = tonumber(string.match(rtRecv or "", "([.%d]+)mv"))
  local bResult = rtRecv and true or false
  ResultTable.resultCode = bResult
  ResultTable.resultString = bResult and rtRecv or "Data not catched"
end  

---this function is not used at all
function itemWakeRxModuleUpWithTxPing_nominalPosition(self)
  doDiagsCmd("i2c -v 0 0x18 0x08 0x3\n")      --Set Ping mode
  doDiagsCmd("i2c -d 0 0x18 0x07 1\n")        --Ping
  doScorpiusCmd("i40ma\r")
  doScorpiusCmd("loadoff\r") --set current to 0 on iktara
  app.wait(500)
  table.insert(g_ResultLog, "Add 500ms delay.")
  local rtSend, rtRecv = doDiagsCmd("i2c -d 0 0x18 0x05 1\n")        --Check status
  local tResult = tonumber(string.match(rtRecv or "", "Data:%s+(%w+)"))
  local bResult = tResult == 1 and true or false
  local i = 1
  while bResult ~= true and i<=5 do
    local rtSend1, rtRecv1 = doDiagsCmd("i2c -d 0 0x18 0x05 1\n")        --Check status
    tResult = tonumber(string.match(rtRecv1 or "", "Data:%s+(%w+)"))
    bResult = tResult == 1 and true or false
    i = i + 1
  end  
  ResultTable.resultCode = bResult
  ResultTable.resultString = tResult or "No data"
end  

function itemForce__5_5V__atRectifierOutput_nominalPosition(self)
  doDiagsCmd("i2c -v 0 0x18 0x08 0x2\n")      --Set to power mode  0x02            
  doDiagsCmd("i2c -d 0 0x18 0x07 1\n")        --Ping
  doDiagsCmd("i2c -d 0 0x18 0x05 1\n")        --Check status
  doDiagsCmd("i2c -d 0 0x18 0x06 2 multiple\n")        --read current Vrect output
  doDiagsCmd("i2c -v 0 0x18 0x0A 0x7C 0x15 multiple\n")      --Set Vrect to 5.5V
  local rtSend, rtRecv = doDiagsCmd("i2c -d 0 0x18 0x09 2 multiple\n")      --Read desired Vrect
  doScorpiusCmd("i40ma\r")
  doScorpiusCmd("loadoff\r") --set load current to 0
  local temp = string.match(rtRecv or "", "Data:%s+(%w+  %w+)")
  if not temp then  ResultTable.resultCode = false return end
  local hexStr = ""
  for i in string.gmatch(temp or "", "0x(%w+)") do 
    hexStr = i .. hexStr
  end
  local tResult = tonumber("0x" .. hexStr)
  local bResult = tResult ~= nil
  ResultTable.resultCode = bResult
  ResultTable.resultString = tResult or "No data"
end  

function itemRequestRxModuleReadBackPowerLevel_nominalPosition(self)
  local rtSend, rtRecv = doDiagsCmd("i2c -d 0 0x18 0x06 2 multiple\n")       --Read Vrect under 5.5V 
  local temp = string.match(rtRecv or "", "Data:%s+(%w+  %w+)")
  if not temp then  ResultTable.resultCode = false return end
  local hexStr = ""
  for i in string.gmatch(temp or "", "0x(%w+)") do 
    hexStr = i .. hexStr
  end
  local tResult = tonumber("0x" .. hexStr)
  local bResult = compareAandB(tResult,self.limitSet.lower,self.limitSet.upper,true)
  ResultTable.resultCode = bResult
  ResultTable.resultString = tResult or "No data"
end  

function itemFixtureVrectMode2_mV()
  local rtSend, rtRecv = doScorpiusCmd("getv\r")
  rtRecv = tonumber(string.match(rtRecv or "", "([.%d]+)mv"))
  local bResult = rtRecv and true or false
  ResultTable.resultCode = bResult
  ResultTable.resultString = bResult and rtRecv or "Data not catched"
end

function itemVaryRxLoading_1C_3C_5C_6C_nominalPosition(self)
  local bResult = true
  doScorpiusCmd("getv\r")
  for i=30, 300, 10 do
    doScorpiusCmd("i" .. i .. "ma\r")
    local rtSend, rtRecv = doScorpiusCmd("geti\r")
    local rtSend1, rtRecv1 = doScorpiusCmd("getv\r")
    rtRecv = tonumber(string.match(rtRecv or "", "([.%d]+)ma"))
    rtRecv1 = tonumber(string.match(rtRecv1 or "", "([.%d]+)mv"))

    if rtRecv1 and rtRecv1 < 5000 and ComTable["5000V"] == nil  then
      ComTable["Current at Vrect under 5V"] = i
      ComTable["5000V"] = 1
    end

    if (rtRecv==nil or rtRecv1==nil) then bResult = false end
    if i == 40 or i == 120 or i == 200 or i == 240 then
      local rtSend1, rtRecv2 = doDiagsCmd("i2c -d 0 0x18 0x06 2 multiple\n")
      local temp = string.match(rtRecv2 or "", "Data:  (%w+  %w+)")
      if not temp then  ResultTable.resultCode = false return end
      local hexStr = ""
      for i in string.gmatch(temp or "", "0x(%w+)") do 
        hexStr = i .. hexStr
      end
      if rtRecv2==nil then bResult = false end
      ComTable["TX_Vrect" .. i .. "_nominal"] = tonumber("0x" .. hexStr)
      ComTable["current" .. i .. "_nominal"] = rtRecv
      ComTable["fixture_Vrect" .. i .. "_nominal"] = rtRecv1
      ComTable["power" .. i .. "_nominal"] = (rtRecv~=nil and rtRecv1~=nil) and rtRecv*rtRecv1*0.000001 or nil
    end
  end

  ResultTable.resultCode = bResult
end  

function getValue(self)
  local bResult = false
  bResult = compareAandB(ComTable[self.key],self.limitSet.lower,self.limitSet.upper,true)

  if(self.name:match("Current at Vrect under 5V")) then
    bResult = true
  end

  ResultTable.resultCode = bResult
  ResultTable.resultString = ComTable[self.key] or "No data"
end  

function itemWakeRxModuleUpWithTxPing_2mmOffset(self)  
  doDiagsCmd("i2c -v 0 0x18 0x08 0x1\n")
  doDiagsCmd("i2c -v 0 0x18 0x08 0x3\n")        --Set Ping mode
  doDiagsCmd("i2c -d 0 0x18 0x07 1\n")          --Ping
  local rtSend, rtRecv = doDiagsCmd("i2c -d 0 0x18 0x05 1\n")          --Check status
  local bResult = rtSend and true or false
  local tResult = bResult and tonumber(string.match(rtRecv or "", "Data:%s+(%w+)")) or "Fail"
  ResultTable.resultCode = bResult
  ResultTable.resultString = tResult or "No data"
end  

function itemForce__5_5V__atRectifierOutputUnder_2mmOffset(self)
  doDiagsCmd("i2c -v 0 0x18 0x08 0x2\n")      --Set to power mode  0x02
  doDiagsCmd("i2c -d 0 0x18 0x07 1\n")        --Ping 
  doDiagsCmd("i2c -d 0 0x18 0x05 1\n")        --Check status
  doDiagsCmd("i2c -d 0 0x18 0x06 2 multiple\n")        --read current Vrect output
  doDiagsCmd("i2c -v 0 0x18 0x0A 0x7C 0x15 multiple\n")        --Set Vrect to 5.5V
  local rtSend, rtRecv = doDiagsCmd("i2c -d 0 0x18 0x09 2 multiple\n")       --Read desired Vrect
  doScorpiusCmd("i40ma\r")
  doScorpiusCmd("loadoff\r") -- set iktara current to 0
  local temp = string.match(rtRecv or "", "Data:%s+(%w+  %w+)")
  if not temp then  ResultTable.resultCode = false return end

  local hexStr = ""
  for i in string.gmatch(temp or "", "0x(%w+)") do 
    hexStr = i .. hexStr
  end
  local tResult = tonumber("0x" .. hexStr)
  local bResult = tResult ~= nil
  ResultTable.resultCode = bResult
  ResultTable.resultString = tResult or "No data"
end  

function itemRequestRxmoduleReadBackPowerLevel_2mmOffset(self)
  local rtSend, rtRecv = doDiagsCmd("i2c -d 0 0x18 0x06 2 multiple\n")
  local temp = string.match(rtRecv or "", "Data:%s+(%w+  %w+)")
  if not temp then  ResultTable.resultCode = false return end
  local hexStr = ""
  for i in string.gmatch(temp or "", "0x(%w+)") do 
    hexStr = i .. hexStr
  end
  local tResult = tonumber("0x" .. hexStr)
  local bResult = tResult ~= nil
  ResultTable.resultCode = bResult
  ResultTable.resultString = tResult or "No data"
end 

function itemFixtureVrectMode2_mV_2mmOffset(self)
  local rtSend, rtRecv = doScorpiusCmd("getv\r")
  rtRecv = tonumber(string.match(rtRecv or "", "([.%d]+)mv"))
  local bResult = rtRecv and true or false
  ResultTable.resultCode = bResult
  ResultTable.resultString = bResult and rtRecv or "Data not catched"
end  

function itemVaryRxLoading_1C_3C_5C_6C_2mmOffset(self)
  local bResult = true
  doScorpiusCmd("getv\r")
  for i=30, 240, 10 do
    doScorpiusCmd("i" .. i .. "ma\r")
    local rtSend, rtRecv = doScorpiusCmd("geti\r")
    local rtSend1, rtRecv1 = doScorpiusCmd("getv\r")
    rtRecv = tonumber(string.match(rtRecv or "", "([.%d]+)ma"))
    rtRecv1 = tonumber(string.match(rtRecv1 or "", "([.%d]+)mv"))
    if (rtRecv==nil or rtRecv1==nil) then bResult = false end
    if i == 40 or i == 120 or i == 200 or i == 240 then
      local rtSend1, rtRecv2 = doDiagsCmd("i2c -d 0 0x18 0x06 2 multiple\n")
      local temp = string.match(rtRecv2 or "", "Data:%s+(%w+  %w+)")
      if not temp then  ResultTable.resultCode = false return end
      local hexStr = ""
      for i in string.gmatch(temp or "", "0x(%w+)") do 
        hexStr = i .. hexStr
      end
      if rtRecv2==nil then bResult = false end
      ComTable["TX_Vrect" .. i .. "_2mmOffset"] = tonumber("0x" .. hexStr)
      ComTable["current" .. i .. "_2mmOffset"] = rtRecv
      ComTable["fixture_Vrect" .. i .. "_2mmOffset"] = rtRecv1
      ComTable["power" .. i .. "_2mmOffset"] = (rtRecv~=nil and rtRecv1~=nil) and rtRecv*rtRecv1*0.000001 or nil
    end
  end
  doScorpiusCmd("loadoff\r")-- set iktara current to 0
  doDiagsCmd("socgpio --pin 116 --output 0\n")
  doDiagsCmd("socgpio --pin 116 --output 1\n")
  ResultTable.resultCode = bResult
end  
---the function is not used
-- function itemFixtureOffset(self)
--   local _, rtRecv
--   if string.find(self.name or "","UpRight 2") then
--     doFixtureCmd("move_rel:2,-2\n")
--     _, rtRecv = doFixtureCmd("move_rel:1,-2\n")
--     print("======== before ComTable[scopriusX] =",ComTable["scopriusX"])
--     ComTable["scopriusX"] = ComTable["scopriusX"]+2
--     print("======== after ComTable[scopriusX] =",ComTable["scopriusX"])

--   elseif string.find(self.name or "", "UpLeft 2") then

--     _, rtRecv = doFixtureCmd("move_rel:1,4\n")
--     print("======== before ComTable[scopriusY] =",ComTable["scopriusY"])
--     ComTable["scopriusY"] = ComTable["scopriusY"]+2
--     print("======== after ComTable[scopriusY] =",ComTable["scopriusY"])

--   elseif string.find(self.name or "", "DownRight 2") then
    
--     _, rtRecv = doFixtureCmd("move_rel:1,-4\n")
--     print("======== before ComTable[scopriusX] =",ComTable["scopriusX"])
--     ComTable["scopriusX"] = ComTable["scopriusX"]-2
--     print("======== after ComTable[scopriusX] =",ComTable["scopriusX"])

--   elseif string.find(self.name or "", "DownLeft 2") then
--     doFixtureCmd("move_rel:1,4\n")
--     _, rtRecv = doFixtureCmd("move_rel:2,4\n")
--     print("======== before ComTable[scopriusX] =",ComTable["scopriusX"])
--     ComTable["scopriusX"] = ComTable["scopriusX"]-2
--     print("======== after ComTable[scopriusX] =",ComTable["scopriusX"])

--   elseif string.find(self.name or "", "down_left 2") then
--     _, rtRecv = doScorpiusCmd("down 2\r")
--     print("======== before ComTable[scopriusY] =",ComTable["scopriusY"])
--     ComTable["scopriusY"] = ComTable["scopriusY"]-2
--     print("======== after ComTable[scopriusY] =",ComTable["scopriusY"])
--     _, rtRecv = doScorpiusCmd("left 2\r")
--     print("======== before ComTable[scopriusX] =",ComTable["scopriusX"])
--     ComTable["scopriusX"] = ComTable["scopriusX"]-2
--     print("======== after ComTable[scopriusX] =",ComTable["scopriusX"])

--   elseif string.find(self.name or "", "Down 2") then
--     _, rtRecv = doScorpiusCmd("down 2\r")
--     print("======== before ComTable[scopriusY] =",ComTable["scopriusY"])
--     ComTable["scopriusY"] = ComTable["scopriusY"]-2
--     print("======== after ComTable[scopriusY] =",ComTable["scopriusY"])
--   end
--   --ComTable["offset"] = 0
-- app.wait(200)
--   local bResult = string.find(rtRecv or "","OK") and true or false
--   ResultTable.resultCode = bResult
-- end
function itemFixtureOffset(self)

  local move_x = self.axis[1] - ComTable["position_x"]  -- Assumed that (X > 0) == right
  local move_y = self.axis[2] - ComTable["position_y"]  -- Assumed that (Y > 0) == up

  local cmd_x = string.format("%s %.2f\n", move_x > 0 and "right" or "left", math.abs(move_x))
  local cmd_y = string.format("%s %.2f\n", move_x > 0 and "up" or "down", math.abs(move_y))
  local _,recv_x = doFixtureCmd(cmd_x)
  local _,recv_y = doFixtureCmd(cmd_y)
  ComTable["position_x"] = self.axis[1]
  ComTable["position_y"] = self.axis[2]
  app.wait(200)
  -- local bResult = string.find(recv_x or "","OK") and string.find(recv_y or "","OK") and true or false
  ResultTable.resultCode = true
end

ComTable["loopTest"]=nil


function itemDisconnectbattery(self)


  app.wait(500)
  local _,rtRecv = doFixtureCmd("write_output:14,0\n")
  app.wait(500)
  doFixtureCmd("move_cylinder:1,0\n") --RX

  local bResult = string.find(rtRecv or "","OK") and true or false

  ResultTable.resultCode = bResult --ad at 20171206 by henry
end  



-------







-- --20180410 Peter
-- function itemCpusbfs(self)
--   local i = 0
-- while i < 1 do   
--   i = i + 1
--   count=0
--   doDiagsCmd("display --off\n")

--   local usbfMsg = message.open("/Users/gdlocal/usbfs -f  /Users/gdlocal/")
--   local recvMsg = message.recv(usbfMsg,"diags...",10)

--   -- app.wait(2000)
--   doDiagsCmd("usbfs --mount\n")
  
--   local _,recvdata = doDiagsCmd("cp -r usbfs:TouchScorpiusCoexTest nandfs:AppleInternal\\Diags\\Logs\\Smokey\\\n")  --7 or 5
  
--   if string.find(recvdata or "","ERROR") then
--     for i=1,5 do
--       _,recvdata = doDiagsCmd("cp -r usbfs:TouchScorpiusCoexTest nandfs:AppleInternal\\Diags\\Logs\\Smokey\\\n")
--       if string.find(recvdata or "","ERROR") then
--         count=count+1
--         print("--------count =",count)
--       end
--       app.wait(500)
--     end
--     if count==5 then
--       doDiagsCmd("nvram --set boot-command diags\n")
--       doDiagsCmd("nvram --save\n")
--       doDiagsCmd("res\n")
-- --      app.wait(2000)
--       doDiagsCmd("\n",nil,1.0)
--       doDiagsCmd("\n",nil,1.0)
--       doDiagsCmd("\n",nil,1.0)
--       doDiagsCmd("\n",nil,1.0)
--       doDiagsCmd("\n",nil,1.0)
--       doDiagsCmd("\n",nil,1.0)
--       local _,rtRecvDiags = doDiagsCmd("diags\n","] :-) ",50.0)
--       local bResult = string.match(rtRecvDiags or "",":%-%)") and true or false
--     else
--         doDiagsCmd("usbfs --unmount\n")
--         if msgPlist then
--           message.close(msgPlist)
--         end
--         ResultTable.resultCode = true
--         ResultTable.resultString = "Pass"
--         return
--     end
--   else
--       doDiagsCmd("usbfs --unmount\n")
--       if msgPlist then
--         message.close(msgPlist)
--       end
--         ResultTable.resultCode = true
--         ResultTable.resultString = "Pass"
--       return
--   end
-- end

-- end



-- Open Terminal manually and send command '/Users/gdlocal/usbfs -f  /Users/gdlocal/', keep the window
function itemCpusbfs(self)
  local bResult = false
  doDiagsCmd("usbfs --mount\n")
  local count = 0
  repeat
    -- app.wait(1000)
    local _,recvdata = doDiagsCmd("cp -r usbfs:\\TouchScorpiusCoexTest nandfs:\\AppleInternal\\Diags\\Logs\\Smokey\\\n")  --7 or 5
    count = count + 1
    bResult = not string.find(recvdata or "","ERROR") 
  until bResult == true or count >= 5
  doDiagsCmd("usbfs --unmount\n")
  ResultTable.resultCode = bResult
end 




-- function Speaker_Coex_test(self)
-- --  doDiagsCmd("display --off\n")
-- ----  os.execute("/Users/gdlocal/usbfs-2.4.5 -f /Users/gdlocal/")--7 or 5
-- --  local msgPlist = message.open("/Users/gdlocal/usbfs -f  /Users/gdlocal/")
  
-- --  doDiagsCmd("usbfs --mount\n")
  
-- --  local _,recvdata = doDiagsCmd("cp usbfs:sweep_250Hz_4000Hz_16ch_140s.wav nandfs:AppleInternal\\Diags\\AudioTests\\J317\\sweep_250Hz_4000Hz_16ch_140s.wav\n")  --7 or 5
  
-- --  if string.find(recvdata or "","error") then
  
  
-- --  end
  
-- --  doDiagsCmd("usbfs --unmount\n")
-- --    if msgPlist then
-- --    message.close(msgPlist)
-- --  end

-- doDiagsCmd("audio -r\n")
-- doDiagsCmd("processaudio --freebufs all\n")
-- doDiagsCmd("audioparam -b spk_cn_l_w -s -n enable-mon -v true\n")
-- doDiagsCmd("audioparam -b spk_cn_r_w -s -n enable-mon -v true\n")
-- doDiagsCmd("audioparam -b spk_fh_l_w -s -n enable-mon -v true\n")
-- doDiagsCmd("audioparam -b spk_fh_r_w -s -n enable-mon -v true\n")
-- doDiagsCmd("audioreg -b spk_cn_l_w -w -a 0x007A -d 0x2A\n")
-- doDiagsCmd("audioreg -b spk_cn_r_w -w -a 0x007A -d 0x2A\n")
-- doDiagsCmd("audioreg -b spk_fh_l_w -w -a 0x007A -d 0x2A\n")
-- doDiagsCmd("audioreg -b spk_fh_r_w -w -a 0x007A -d 0x2A\n")
-- doDiagsCmd("setvol -b spk_cn_l_w -n spk-pcm-gain -v 12\n")
-- doDiagsCmd("setvol -b spk_cn_r_w -n spk-pcm-gain -v 12\n")
-- doDiagsCmd("setvol -b spk_fh_l_w -n spk-pcm-gain -v 12\n")
-- doDiagsCmd("setvol -b spk_fh_r_w -n spk-pcm-gain -v 12\n")
-- doDiagsCmd("setvol -b spk_cn_l_w -n amp-vol -v 0.25\n")
-- doDiagsCmd("setvol -b spk_cn_r_w -n amp-vol -v 0.25\n")
-- doDiagsCmd("setvol -b spk_fh_l_w -n amp-vol -v 0.25\n")
-- doDiagsCmd("setvol -b spk_fh_r_w -n amp-vol -v 0.25\n")
-- doDiagsCmd("routeaudio -b spk_cn_l_w -i spk-i2s -o spk-out -r\n")
-- doDiagsCmd("routeaudio -b spk_cn_r_w -i spk-i2s -o spk-out -r\n")
-- doDiagsCmd("routeaudio -b spk_fh_l_w -i spk-i2s -o spk-out -r\n")
-- doDiagsCmd("routeaudio -b spk_fh_r_w -i spk-i2s -o spk-out -r\n")
-- doDiagsCmd("processaudio --readfile sweep_250Hz_4000Hz_16ch_160s.wav\n")
-- doDiagsCmd("processaudio --pick gain -i process0 --options '--gain -80'\n")
-- doDiagsCmd("processaudio --pick audio-mapper -i process1 --options \"--in [0] --out [0,2,4,6,8,10,12,14]\" --out_channels 16\n")
-- doDiagsCmd("loopaudio -b socmca --txport ap-mca2 --rxport ap-mca2 --usebuf process2 --bitdepth 16 -c 16 --async\n")
  
  
-- --  doDiagsCmd("audioparam -b socmca -p ap-mca2 -s -n master-lrclk-enable -v false\n")
-- --  doDiagsCmd("processaudio --readfile sweep_1K_to_4K_90s_16ch.wav\n")
-- --  doDiagsCmd("processaudio --pick gain -i process0 --options '--gain -22'\n")
-- --  doDiagsCmd("processaudio --pick audio-mapper -i process1 --options \"--in [0] --out [0][2][4][6][8][10][12][14]\" --out_channels 16\n")
  
-- --  doDiagsCmd("audioparam -b socmca -p ap-mca2 -s -n master-lrclk-enable -v false\n")
  
--   ResultTable.resultCode = true
-- end

-- function resetAudio(self)
--   app.wait(1000)
-- doDiagsCmd("audio --turnoff spk_cn_l_w\n")
-- doDiagsCmd("audio --turnoff spk_cn_r_w\n")
-- doDiagsCmd("audio --turnoff spk_fh_l_w\n")
-- doDiagsCmd("audio --turnoff spk_fh_r_w\n")
-- doDiagsCmd("audio --turnoff socmca\n")
-- --doDiagsCmd("processaudio --writebuffer looprx0 --writefile output_f_l_w_silence\n")
--   ResultTable.resultCode = true
-- end 



function itemNoiseDataCollection(self)
  local send, recv = doDiagsCmd("smokey TouchScorpiusCoexTest --run --test ScorpiusCoexTestSpectrumNoiseDataCollection\n", "] :-)", 50)
  ResultTable.resultCode = true
end

function itemNoiseDataCollection_CL(self)
  local send, recv = doDiagsCmd("smokey TouchScorpiusCoexTest --run --test ScorpiusCoexTestSpectrumNoiseDataCollection\n", "] :-)", 50)
  -- local bResult = string.match(recv or "", "Passed")
  -- and true or false
  doDiagsCmd("smokey ScorpiusHid --run --test \"Set\" --args \"ReportID=0x26, ReportPayload={0; 0; 0; 0}\"\n")
  app.wait(200)
  doDiagsCmd("smokey ScorpiusHid --run --test \"Set\" --args \"ReportID=0x01, ReportPayload={0x00}\"\n")
  app.wait(500)
  doScorpiusCmd("eload set 0\r")
  ResultTable.resultCode = true
end



function itemNoiseDataCollection_LPP( self )
  doDiagsCmd("smokey ScorpiusHid --run --test \"Set\" --args \"ReportID=0x12, ReportPayload={1}\"\n")
  local send, recv = doDiagsCmd("smokey TouchScorpiusCoexTest --run --test ScorpiusCoexTestSpectrumNoiseDataCollection\n", "] :-)", 50)
  doDiagsCmd("smokey ScorpiusHid --run --test \"Set\" --args \"ReportID=0x12, ReportPayload={0}\"\n")
  ResultTable.resultCode = true
end


-- function EnterOSMode_fromDiags(self)
--   local bResult = false
--   doDiagsCmd("nvram --set boot-command fsboot\n")
--   doDiagsCmd("nvram --set auto-boot true\n")
--   doDiagsCmd("nvram --save\n")
--   iPadSerial:send("res\n", 1)

--   for i=1, 30 do
--     app.wait(2000)
--     msgTelnet = message.open(Directory.tools .. "/telnet localhost 10023")
--     table.insert(g_ResultLog,"[send]: telnet localhost 10023")
--     local rtRecv, _ = message.recv(msgTelnet, {"login: "}, 5,0)
--     table.insert(g_ResultLog,"[recv]:" .. rtRecv)
--     connectStatus = string.match(rtRecv or "", "login: ") and true or false

--     if connectStatus then 
--       message.close(msgTelnet)
--       break
--     end

--   end  

--   local recv = ""
--   if connectStatus then
--     _, recv = doDiagsCmd("root\n","Password:", 3)
--     _, recv = doDiagsCmd("alpine\n", "iPad:~ root# ", 3)
--   end

--   ResultTable.resultCode = string.match(recv or "", "iPad:~ root# ") and true or false
-- end

function EnterOSMode(self)
  doDiagsCmd("reset\n","output",1)
  iPadSerial:close()
  app.wait(2000)
  local bResult = false
  -- doOsCmd("", {"login: ", "iPad:~ root# "}, 1)
  -- doOsCmd("", {"login: ", "iPad:~ root# "}, 1)
  -- local _, recv = doOsCmd("", {"login: ", "iPad:~ root# "}, 1)
local recv = ""
  for i=1, 30 do
    if tostring(args_unitIndex) == "1" then
      msgTelnet = message.open(Directory.tools .. "/telnet localhost 10023")
    elseif tostring(args_unitIndex) == "2" then
      msgTelnet = message.open(Directory.tools .. "/telnet localhost 11023")
    elseif tostring(args_unitIndex) == "3" then
      msgTelnet = message.open(Directory.tools .. "/telnet localhost 12023")
    elseif tostring(args_unitIndex) == "4" then
      msgTelnet = message.open(Directory.tools .. "/telnet localhost 13023")
    end
    -- table.insert(g_ResultLog,"[send]: telnet localhost 10023")
    local rtRecv, _ = message.recv(msgTelnet, {"login: "}, 5,0)
    table.insert(g_ResultLog,"[recv]:" .. rtRecv)
    connectStatus = string.match(rtRecv or "", "login: ") and true or false

    if connectStatus then 
      _, recv = doOsCmd("root","Password:")
      _, recv = doOsCmd("alpine")
      break
    end
    app.wait(2000)
  end  

  -- if connectStatus then
  --   _, recv = doDiagsCmd("root\n","Password:", 3)
  --   _, recv = doDiagsCmd("alpine\n", "iPad:~ root# ", 3)
  -- end

  if string.match(recv or "", "iPad:~ root# ") then
    bResult = true
  end 

  ResultTable.resultCode = bResult
--  ResultTable.resultString = logResult
end

function enterDiagMode(self)
  doOsCmd("nvram boot-command=\"diags\"\n","root#")
  doOsCmd("reboot")
  app.wait(3000)
  -- message.close(msgTelnet)

  iPadPath = TestUnit[args_unitIndex].iPad.path
  iPadSerial = serial.open(TestUnit[args_unitIndex].iPad.path,0)
  serial.config(iPadSerial, TestUnit[args_unitIndex].iPad.config)

  -- local _,recvEnter = doDiagsCmd("\n",nil,3.0)
  -- local _,recvEnter = doDiagsCmd("\n",nil,3.0)
  -- local _,recvEnter = doDiagsCmd("\n",nil,3.0)
  -- local _,recvEnter = doDiagsCmd("\n",nil,3.0)
  -- local _,recvEnter = doDiagsCmd("\n",nil,3.0)
  -- local _,recvEnter = doDiagsCmd("\n",nil,3.0)

  -- if string.match(recvEnter or "",":%-%)") then
  --   ResultTable.resultCode = true
  --   return
  -- end
  local _,rtRecvDiags = doDiagsCmd("diags\n","] :-) ",50.0)
  local bResult = string.match(rtRecvDiags or "",":%-%)") and true or false
  doDiagsCmd("nvram --set boot-command fsboot\n","] :-) ")
  doDiagsCmd("nvram --save\n","] :-) ")
  ResultTable.resultCode = bResult
end


function doOsCmd_1(anCmd, endCode, recvtimeOut)
  local rtsend, rtRecv, bResult = nil,nil,nil
  local count = 0
  endCode = endCode or "iPad:~ root# "
  anCmd = anCmd .. "\n"
  recvtimeOut = recvtimeOut or 10
  repeat
    rtsend, rtRecv, bResult = doDiagsCmd(anCmd, endCode, recvtimeOut)
    count = count + 1
  until (not string.match(rtRecv or "", "Error")) or count == 1
  return rtsend, rtRecv, bResult
end

function itemUnitSn(self)
  local rtSend,rtRecv = doOsCmd("/usr/local/bin/sysconfig read -k SrNm")
  sn = string.match(rtRecv or "","SrNm%s*|%s*STR%s*|%s*(%w+)") or "No data" 
  local bResult = (sn ~= nil and sn ~= "" and sn ~= "No data") and true or false
  ResultTable.resultCode = bResult
  ResultTable.resultString = sn
end

function ratescalerTest(self)
  doOsCmd("ratescalar -t 5 -u 49\n","iPad:~ root#",360000)
  local _,testLog = doOsCmd("ratescalar -t 5 -u 49\n","iPad:~ root#",360000)
  print("----ratescalerTest----testLog22:",testLog)

  local ratescalarVal = string.match(testLog or "","ppm%s*%((%+?%-?%w+%.-%w+)%s*ppm%)")

  local bResult = compareAandB(ratescalarVal,self.limitSet.lower,self.limitSet.upper,true)
  ResultTable.resultCode = bResult
  ResultTable.resultString = ratescalarVal or "No Data"
end

function getFilefromUnit(fileName)
  local msgShell = message.open("sh")
  local a,b = message.recv(msgShell, {"$"}, 5, 0)
  print("msgShell0 = ",a)
  message.send(msgShell,"rsync -av rsync://root@localhost:10873/root/var/root/" .. fileName .. " " .. Directory.home .. "/" .. fileName .. "\n",5,0)
  a,b = message.recv(msgShell, {"Password:"}, 5, 0)
  print("msgShell1 = ",a)
  message.send(msgShell,"alpine\n",5,0)
  a,b = message.recv(msgShell, {"sh"}, 2, 0)
  print("msgShell2 = ",a)
  message.close(msgShell)
end

function putFileintoUnit(filePath)
  local msgShell = message.open("sh")
  local a,b = message.recv(msgShell, {"$"}, 5, 0)
  print("msgShell0 = ",a)
  message.send(msgShell,"rsync -av " .. filePath .. " rsync://root@localhost:10873/root/var/root/\n",5,0)
  a,b = message.recv(msgShell, {"Password:"}, 5, 0)
  print("msgShell1 = ",a)
  message.send(msgShell,"alpine\n",5,0)
  a,b = message.recv(msgShell, {"sh"}, 2, 0)
  print("msgShell2 = ",a)
  message.close(msgShell)
end

function imageCollectAtF1(self)

  blackPngPath = Directory.home .. '/black.png'
  print("blackPngPath",blackPngPath)
  putFileintoUnit(blackPngPath)
  doOsCmd("chmod 777 /var/root/black.png","iPad:~ root#",50)
  -- doOsCmd("powerswitch lcd off","iPad:~ root#",50)
  doOsCmd("powerswitch lcd on","iPad:~ root#",50)
  doOsCmd("clcdControl --fixed_rr=2","iPad:~ root#",50)
  doOsCmd("powerswitch touch on","iPad:~ root#",50)
  doOsCmd("mtreport set 0xf3 0x0a","iPad:~ root#",50)
  doOsCmd("mtreport set 0xa8 0x00","iPad:~ root#",50)
  doOsCmd("mtreport set 0xa5 0x00","iPad:~ root#",50)
  doOsCmd("mtreport set 0x42 0x03","iPad:~ root#",50)
  doOsCmd("mtreport set 0x41 0x42","iPad:~ root#",50)
  doOsCmd("mtreport set 0x27 0x01","iPad:~ root#",50)

  local _,_,recvStatus = doOsCmd("MultitouchTester -prettyimages -framecount 300 > DCsig_at_F1.txt","iPad:~ root#",15000)

  getFilefromUnit("DCsig_at_F1.txt")

  if recvStatus then
    ResultTable.resultCode = true
    -- ResultTable.resultString = "PASS"
  else
    ResultTable.resultCode = false
    -- ResultTable.resultString = "FAIL"
  end
end

function imageCollectAtF3(self)

  doOsCmd("mtreport set 0x41 0x48","iPad:~ root#",50)
  doOsCmd("mtreport set 0x27 0x01","iPad:~ root#",50)

  local _,_,recvStatus = doOsCmd("MultitouchTester -prettyimages -framecount 300 > DCsig_at_F3.txt","iPad:~ root#",15000)

  getFilefromUnit("DCsig_at_F3.txt")

  if recvStatus then
    ResultTable.resultCode = true
    -- ResultTable.resultString = "PASS"
  else
    ResultTable.resultCode = false
    -- ResultTable.resultString = "FAIL"
  end
end

function imageCollectAt500Hz(self)

  doOsCmd("mtreport set 0x41 0x41","iPad:~ root#",50)
  doOsCmd("mtreport hset F6 00 00 08 00 0D 0F 00 00 00 00 08 00 0D 0F 00 00 00 00 08 00 0D 0F 00 00 00 00 08 00 0D 0F 00 00","iPad:~ root#",50)
  doOsCmd("mtreport set 0x27 0x01","iPad:~ root#",50)
  local _,_,recvStatus = doOsCmd("MultitouchTester -prettyimages -framecount 300 > DCsig_at_500Hz.txt","iPad:~ root#",15000)

  getFilefromUnit("DCsig_at_500Hz.txt")

  if recvStatus then
    ResultTable.resultCode = true
    -- ResultTable.resultString = "Pass"
  else
    ResultTable.resultCode = false
    -- ResultTable.resultString = "FAIL"
  end
end

function collectFFFrames(self)

  doOsCmd("powerswitch lcd on","iPad:~ root#",50)
  doOsCmd("OSDDisplay draw -f /AppleInternal/Diags/LCMPatterns/2732x2048/J421/FATP/FATP8.png -d 2","iPad:~ root#",3000)
  doOsCmd("mtreport set 0x60 0x01","iPad:~ root#",50)
  doOsCmd("mtreport set 0x5e 0x00 01 00","iPad:~ root#",50)
  doOsCmd("mtreport set 0x20 0x80","iPad:~ root#",50)
  doOsCmd("mtreport hset 5F D7 A3 08 00 00 00 00 00 28 05 00 00 8F C2 03 00 00 00 00 00 28 05 00 00 6A BC 04 00 00 00 00 00 28 05 00 00 2F DD 06 00 00 00 00 00 28 05 00 00 10 58 07 00 00 00 00 00 28 05 00 00 A7 C6 07 00 00 00 00 00 28 05 00 00 8F C2 01 00 00 00 00 00 3C 05 00 00 8F C2 03 00 00 00 00 00 3C 05 00 00 10 58 07 00 00 00 00 00 3C 05 00 00 A7 C6 07 00 00 00 00 00 3C 05 00 00 F7 53 04 00 00 00 00 00 00 05 00 00 37 89 07 00 00 00 00 00 3C 05 00 00 8F C2 07 00 00 00 00 00 3C 05 00 00","iPad:~ root#",50)
  -- doOsCmd("fixed_rr=2clcdControl","iPad:~ root#",50)
  doOsCmd("clcdControl --fixed_rr=2","iPad:~ root#",50)
  doOsCmd("powerswitch touch on","iPad:~ root#",50)
  
  local _,_,recvStatus = doOsCmd("MultitouchTester -prettyimages -framecount 300 > Display_touch_noise_data.txt","iPad:~ root#",15000)

  getFilefromUnit("Display_touch_noise_data.txt")

  -- _,testLog = doOsCmd("h10isp -s /var/root/isp_flood_gsm.txt | tee testlog.txt\n","iPad:~ root#",60000)
  -- print("----h10isp----testLog:",testLog)

  -- g_gsmPath = app.getLogFile({resultString=aString , sn = sn}):gsub(".txt","") .. "_GSMRosalineCoex.csv"
  -- getFilefromUnit(g_gsmPath)

  -- local h10ispStatus = string.match(testLog or "","%sPASS%s")
  -- print("----h10isp----h10ispStatus:",h10ispStatus)
  
  if recvStatus then
    ResultTable.resultCode = true
    -- ResultTable.resultString = "PASS"
  else
    ResultTable.resultCode = false
    -- ResultTable.resultString = "FAIL"
  end
end

function resetUnit(self)
  doDiagsCmd("nvram --set boot-command fsboot\n")
  doDiagsCmd("nvram --save\n")
  doDiagsCmd("reset\n","output",1)
  iPadSerial:close()
  ResultTable.resultCode = true
end

function itemOSVersion(self)
  local rtSend,rtRecv = doOsCmd("OSDToolbox version")
  local osVersion = string.match(rtRecv or "","BuildVersion%s+(%w+)") or "No data" 
  local bResult = ( osVersion~= nil and osVersion ~= "" and osVersion ~= "No data") and true or false
  ResultTable.resultCode = bResult
  ResultTable.resultString = osVersion
end
