----------------------------Overlay Info-----------------------
OverlayVersion = "26.0.0.0"
ProductCode = "QN"
ProductStage = "P0"
TestStation = "DiagToNonUI"

----------------------------UI Info----------------------------
--package.path = Directory.config .. '/?.lua;' .. package.path
package.path = Directory.home .. '/?.lua;' .. package.path
pcall(require,"Extern_Station")
UnitViewCount = TestUnit and #TestUnit or 1
UnitViewLayout = {row=0, column=2}
--WinNormalSize = {w=840,h=680}
-- AutoStart = true
--CtrlBtnStatus = 1 --0 is normal 1
--SNFieldStatus = 0 --0 is normal 1
ExitAlert = true;
HaveSysLog = true;
--WillDebug = true


----------------------------Script Info-------------------------
MainScriptPath = "./main.lua"
LogMainDirectory = Directory.homePublic .. "/Kylin/logs"






