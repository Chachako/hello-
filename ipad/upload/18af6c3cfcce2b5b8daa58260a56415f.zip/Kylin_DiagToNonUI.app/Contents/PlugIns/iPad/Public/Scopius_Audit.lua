
function init_Position_Test(self)
  doDiagsCmd("i2c -v 7 0x55 0x00 0x01\n")
  doDiagsCmd("i2c -v 7 0x55 0x0b 0x00 0x5A multiple\n")
  doDiagsCmd("i2c -v 7 0x55 0x03 0x07 0x08 multiple\n")
  
  local _,mlbvRecv = doScorpiusCmd("getv\r")
  local testValue = string.match(mlbvRecv or "","MLB Voltage:%s+(.-)mv")
  ResultTable.resultCode = testValue and true or false
  ResultTable.resultString = testValue
end

--table.insert(TestItems,{name="Init_Vrect",action=init_Position_Test})

Position = {}
local Point = {x = 0, y = 0,z = 0, v = 0}
local X_Number = 12
local Y_Number = 12

function CommitResult(ResCode, ResString)
  ResCode = ResCode and true or false
  ResString = ResString or "Fail"
  ResultTable.resultCode = ResCode
  ResultTable.resultString = ResString
end

 function getVal(self)   
 --SSSSSS tried it
  local VauleCom = 0
  for i=1, 3 do
    app.wait(100)
    local _,mlbvRecv = doScorpiusCmd("ikt adc\r")
    print("mlbvRecv")
        print(mlbvRecv)
    local _,Vaule = string.match(mlbvRecv or "","Vrect = (.-)Vrect = (.-) V")
      print("Vaule")
        print(Vaule)

        
        
        
    VauleCom = VauleCom + Vaule
  end
   VauleCom = VauleCom/3
   return tonumber(VauleCom)
end

function Move_Position_test(self)
  doScorpiusCmd("down 6\r")
  doScorpiusCmd("left 6\r")
  Point = {x = 0, y = 0, z = 0,  v = getVal()}
  table.insert(Position, Point)
  
  local x_count, y_count = 11, 10
  for i=1, x_count do 
    if i < 11 and i>1 then
      doScorpiusCmd("right 0.2\r")
      Point = {x = (i-1)/10, y = 0, z = 0, v = getVal()}
      table.insert(Position, Point)
    end 
    
    for j=1,y_count do     
      doScorpiusCmd("up 0.2\r") 
      Point = {x = (i-1)/10, y = j/10, z = 0, v = getVal()}
      table.insert(Position, Point)
    end 
    doScorpiusCmd("down 12\r")
    
  end 
  -- return original point 
  doScorpiusCmd("left 12\r")
  local index = 1
  local max_value = 0
  for n=1, #Position do
    if tonumber(Position[n].v) > 0 then
      max_value = tonumber(Position[n].v)
      index = n
    end
    if Position[n].x and Position[n].y and Position[n].v then
      local str = "x, y <---->(" .. Position[n].x .. "," .. Position[n].y .. ")" .. "<-------->" .. Position[n].v
      table.insert(g_ResultLog, str)
    end
  end
  
  if Position[index].x and Position[index].y and Position[index].v then
    local rightCmd = "right " .. Position[index].x .. "\n"
    local upCmd = "up " .. Position[index].y .. "\n"

    --Move to the max value point 
    doScorpiusCmd(rightCmd)
    doScorpiusCmd(upCmd)
  end
    
  print("The max value is :[", max_value, "]", "The X point is [", Position[index].x, "]", "The Y point is [", Position[index].y, "]")
  CommitResult(true, max_value)
end

function Move_Position_test2(self)
  doScorpiusCmd("down 6\r")
  doScorpiusCmd("left 6\r")

  local bound_range = 6
  --move right
  local anCmd1 = "right 0.2\r"
  local xPoint, xValue = Move_toOptimal_location(anCmd1, bound_range)

  --mova up
  local anCmd2 = "up 0.2\r"
  local yPoint, yValue = Move_toOptimal_location(anCmd2, bound_range)

  --move front
  local anCmd3 = "front 0.2\r"
  local zPoint, zValue = Move_toOptimal_location(anCmd3, bound_range)
  Point = {x = xPoint, y = yPoint, z = zPoint, v = zValue}
  --table.insert(Position, Point)
  local UIFormatStr = string.format("The Optimal Point(%d, %d, %d) \nThe Optimal vaule: %d", Point.x, Point.y, Point.z, Point.v)
  table.insert(g_ResultLog, UIFormatStr)
  
  CommitResult(true, zValue)
end


function Move_toOptimal_location(aCmd, ...)
  
  if aCmd == nil then
    return
  end
  local boundLen = ... or 12 
  
  local step = aCmd:match("%d*%.*%d+") or 1
  local totalCount = tonumber(boundLen)/tonumber(step)
  local currentVal = 0
  local OptimalPoint = 0
  local returnVaule = 0
  local firstCompareFlag = false                                  
  for i = 1, totalCount do                                        --Two consecutive times reduction then break
    doScorpiusCmd(aCmd)
    local value = getVal()
    
    if firstCompareFlag then
      if value < currentVal then                                  --compared the second time 
        OptimalPoint = (i-2)*tonumber(step)
        break
      end
      firstCompareFlag = false
    end 

    if value < currentVal then                                    --compared the first time flag
      firstCompareFlag = true
    else
      returnVaule = value
    end     
    currentVal = value 
  end
  
  local DrectionT = {["left"] = "right", ["up"] = "down", ["front"] = "back", ["right"] = "left", ["down"] = "up", ["back"] = "front"}
  for key,_ in pairs(DrectionT) do
    if aCmd:match(key) then
      aCmd = aCmd:gsub(key, DrectionT[key])
      aCmd = aCmd:gsub(step, tonumber(step)*2)
    end   
  end  
  doScorpiusCmd(aCmd)
  return OptimalPoint , returnVaule
end



function searchOptimalPoint(aCmd, ...)
  if aCmd == nil then
    CommitResult(true, "Command error")
    return
  end

  local baseVal = getVal()
  local baseCmd = aCmd
  local direction = string.match(baseCmd or "", "%w+%s")
  local oppDire = "" 
  local stepVaule = 0
  local DrectionT = {["left"] = "right", ["up"] = "down", ["front"] = "back", ["right"] = "left", ["down"] = "up"}
  
  -------------------------------------------------
  repeat
    doScorpiusCmd(baseCmd)
    local currentVal = getVal()

    if currentVal < baseVal then 
      for key,_ in pairs(DrectionT) do
        if baseCmd:match(key) then
          local opCmd = baseCmd:gsub(key, DrectionT[key])
          oppDire = DrectionT[key]
          doScorpiusCmd(opCmd)
          break
        end   
      end 
      
      if stepVaule == 0.1 and ((direction == "left") or (direction == "up")) then  
        baseCmd = aCmd:gsub(direction, oppDire)
        direction = "Right_Down"
      else
        local stepVauleTemp = baseCmd:match("%d*%.*%d+") or 2
        stepVaule = tonumber(stepVauleTemp)/2
        stepVaule = (stepVaule == 0.125) and 0.1 or stepVaule
        baseCmd = baseCmd:gsub(stepVauleTemp, stepVaule)
      end
    else
      baseVal = currentVal
    end
  until (stepVaule < 0.1) and direction == "Right_Down"
  return baseVal
end


function getOptVal(baseCmd)
  local baseVal = getVal()
  local direction = string.match(baseCmd or "", "%w+")
  local DrectionT = {["left"] = "right", ["up"] = "down", ["front"] = "back", ["right"] = "left", ["down"] = "up"}
  local oppDire = DrectionT[direction]
  local stepVaule = 0
  
  repeat
    doMikeyCmd(baseCmd)
    local curVal = getVal()
    if curVal < baseVal then 
      local opCmd = baseCmd:gsub(direction, oppDire)
      doMikeyCmd(opCmd)
      local stepVauleTemp = baseCmd:match("%d*%.*%d+") or 2
      stepVaule = tonumber(stepVauleTemp)/2
      stepVaule = (stepVaule == 0.125) and 0.1 or stepVaule
      baseCmd = baseCmd:gsub(stepVauleTemp, stepVaule)
    else
      baseVal = curVal
    end
  until stepVaule < 0.1
  return baseVal
end


--function getOptValue_(baseCmd)
--  local baseStep = string.match(baseCmd or "", "%d*%.*%d+") or 0.1
--  local OptVal = 0
  
--  while(1) do
--  if tonumber(baseStep) < 0.1 or baseCmd == nil then
--    OptVal = getVal()
--    break
--  end
--    getOneOptimalPoint_(baseCmd)                                   --get one optimal point and move to in each baseStep.
--    baseStep = tonumber(baseStep)/2
--    baseStep = (baseStep == 0.125) and 0.1 or baseStep
--    baseCmd = baseCmd:gsub("%d*%.*%d+", baseStep)  
--  end
--  return OptVal
--end

---------------------------------------------------------------------------------------------------
--function getOptValue(baseCmd)
--  local baseStep = string.match(baseCmd or "", "%d*%.*%d+") or 0.1
--  local OptVal = 0
--  if tonumber(baseStep) < 0.1 or baseCmd == nil then
--    OptVal = getVal()
--    return OptVal
--  else
--    getOneOptimalPoint(baseCmd)                                    --get one optimal point and move to in each baseStep.
--    baseStep = tonumber(baseStep)/2
--    baseStep = (baseStep == 0.125) and 0.1 or baseStep
--    baseCmd = baseCmd:gsub("%d*%.*%d+", baseStep)
--    return getOptValue(baseCmd)   
--  end
--end

-- function getOptValue_(baseCmd)
--   local baseStep = string.match(baseCmd or "", ",(%d*%.*%d+)") or 0.1
--   local OptVal = 0
--   if tonumber(baseStep) < 0.1 or baseCmd == nil then
--     OptVal = getVal()
--     return OptVal
--   else
--     getOneOptimalPoint_(baseCmd)                                    --get one optimal point and move to in each baseStep.
--     baseStep = tonumber(baseStep)/2
--     baseStep = (baseStep == 0.125) and 0.1 or baseStep
--     baseCmd = baseCmd:gsub(",(%d*%.*%d+)", ","..baseStep)
--     return getOptValue_(baseCmd)   
--   end
-- end

function getOptValue_(baseCmd)
  local baseStep = string.match(baseCmd or "", "%d*%.*%d+") or 0.1
  local OptVal = 0
  if tonumber(baseStep) < 0.1 or baseCmd == nil then
    OptVal = getVal()
    return OptVal
  else
    getOneOptimalPoint(baseCmd)                                    --get one optimal point and move to in each baseStep.
    baseStep = tonumber(baseStep)/2
    baseStep = (baseStep == 0.125) and 0.1 or baseStep
    baseCmd = baseCmd:gsub("%d*%.*%d+", baseStep)
    return getOptValue(baseCmd)   
  end
end

function getOneOptimalPoint_(aCmd)
  local direction = string.match(aCmd or "", ",(%d*%.*%d+)")
  local DirecT = {[direction] = tonumber(direction)*(-1)}
  local oppDire = DirecT[direction]
  
  local baseVal = getVal()
  repeat 
    local index = aCmd:find(",")
    doFixtureCmd(aCmd)
    local curVal = getVal()
    if baseVal > curVal then
      local oppCmd = aCmd:sub(1, index)
      oppCmd = oppCmd .. oppDire .."\n"
      local index_ = oppCmd:find(",")
      doFixtureCmd(oppCmd)
      local reBaseVal = getVal()
      repeat
        doFixtureCmd(oppCmd)
        local reCurVal = getVal()
        if reBaseVal > reCurVal then
          local BaseCmd = oppCmd:sub(1, index_)
          BaseCmd = BaseCmd .. direction .. "\n"
          doFixtureCmd(BaseCmd)
        else
          reBaseVal = reCurVal
        end
      until reBaseVal > reCurVal
    else
      baseVal = curVal
    end
  until baseVal > curVal
end

-- function getOneOptimalPoint(aCmd)
--   local direction = string.match(aCmd or "", "%w+")
--   local DirecT = {["left"] = "right", ["up"] = "down", ["front"] = "back", ["right"] = "left", ["down"] = "up"}
--   local oppDire = DirecT[direction]
  
--   local baseVal = getVal()
--   repeat 
--     doMikeyCmd(aCmd)
--     local curVal = getVal()
--     if baseVal > curVal then
--       local oppCmd = aCmd:gsub(direction, oppDire)
--       doMikeyCmd(oppCmd)
--       local reBaseVal = getVal()
--       repeat
--         doMikeyCmd(oppCmd)
--         local reCurVal = getVal()
--         if reBaseVal > reCurVal then
--           local BaseCmd = oppCmd:gsub(oppDire, direction)
--           doMikeyCmd(BaseCmd)
--         else
--           reBaseVal = reCurVal
--         end
--       until reBaseVal > reCurVal
--     else
--       baseVal = curVal
--     end
--   until baseVal > curVal
-- end
function getOneOptimalPoint(aCmd)
  local direction = string.match(aCmd or "", "%w+")
  local DirecT = {["left"] = "right", ["up"] = "down", ["front"] = "back", ["right"] = "left", ["down"] = "up"}
  local oppDire = DirecT[direction]
  
  local baseVal = getVal()
  repeat 
    doFixtureCmd(aCmd)
    local curVal = getVal()
    if baseVal > curVal then
      local oppCmd = aCmd:gsub(direction, oppDire)
      doFixtureCmd(oppCmd)
      local reBaseVal = getVal()
      repeat
        doFixtureCmd(oppCmd)
        local reCurVal = getVal()
        if reBaseVal > reCurVal then
          local BaseCmd = oppCmd:gsub(oppDire, direction)
          doFixtureCmd(BaseCmd)
        else
          reBaseVal = reCurVal
        end
      until reBaseVal > reCurVal
    else
      baseVal = curVal
    end
  until baseVal > curVal
end



-- function Move_to_HomePoint()
--   doFixtureCmd("move_cylinder:1,1\n")
--     --doDiagsCmd("i2c -v 7 0x55 0x1f 0x00\n") -- Closed loop diabled
--     --doDiagsCmd("smokey ScorpiusHid --run --test “Set” --args “ReportID=0x26, ReportPayload={0; 0; 0; 0}”\n")
--     doDiagsCmd("smokey ScorpiusHid --run --test \"Set\" --args \"ReportID=0x26, ReportPayload={0; 0; 0; 0}\"\n")
--     app.wait(200)
--     --doDiagsCmd("i2c -v 7 0x55 0x0f 0x00\n") -- Debug mode 0
--     doDiagsCmd("smokey ScorpiusHid --run --test \"Set\" --args \"ReportID=0x01, ReportPayload={0x00}\"\n")
--     app.wait(200)
--     doScorpiusCmd("eload init\r")
--     app.wait(200)
--     doScorpiusCmd("set mode none\r")
--     app.wait(200)
--     --doDiagsCmd("i2c -v 7 0x55 0x0f 0x01\n") Debug mode 1
--     doDiagsCmd("smokey ScorpiusHid --run --test \"Set\" --args \"ReportID=0x01, ReportPayload={0x01}\"\n")
--     app.wait(200)

--    -- doDiagsCmd("i2c -v 7 0x55 0x0b 0x00 0xb4 multiple\n") --phase shift ( why 4 places when the phase shif is 16 bytes)
--     doDiagsCmd("smokey ScorpiusHid --run --test \"Set\" --args \"ReportID=0x22, ReportPayload={0x1; 0x3; 0xB4; 0; 0; 0}\"\n")
    
--     -- doDiagsCmd("i2c -w 7 0x55 0x03 0x05 0x78 multiple\n") --DAC value
--     doDiagsCmd("smokey ScorpiusHid --run --test \"Set\" --args \"ReportID=0x24, ReportPayload={0x78; 0x05}\"\n")
  
--     app.wait(200)
--     doScorpiusCmd("set mode rx\r")

--     app.wait(1000)
--     doScorpiusCmd("ikt signal 0\r")
--     app.wait(200)
  
--   ResultTable.resultCode = true
--   ResultTable.resultString = "Pass"
-- end
  

--table.insert(TestItems,{name="Position Move test ",action=Move_to_OptimalPoint})