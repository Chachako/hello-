-----------------------------------Port Communication Module-----------------------------------
print("load and do Serial Port Communication script...");

local bStatus, ip = pcall(require, "serial");
if bStatus and ip then
  print("require serial success!");
else
  print("require serial fail:", ip);
  return;
end

bStatus, ip = pcall(require, "utils");
if bStatus and ip then
  print("require utils success!");
else
  print("require utils fail:", ip);
  return;
end


-----------------------------------Private Function ----------------------------
function doDiagsCmd(anCmd, endCode, recvtimeOut)
  if iPadSerial == nil then 
    table.insert(g_ResultLog, "Error info: iPadSerial is Null!")
    return nil, nil
  end

  if not anCmd then
    table.insert(g_ResultLog, "Error info: anCmd is nil!")
    return nil, nil
  end

  local sendTimes = 0
  local rtSend, rtRecv, rtCode, errorLog, bReSend = nil, nil, nil, nil
  repeat
    rtSend = iPadSerial:send(anCmd, 25)
    local startTime = utils.timeStart()
    local sendStatus = (rtSend==0) and "Success" or "Fail"
    local sendFormat = string.format("send[%s:%s]:%s", sendStatus, tostring(rtSend), anCmd or "cmd empty\n")
    local sendLog =  "["..utils.timestamp().."]:"..sendFormat
    table.insert(g_ResultLog, sendLog)

    local strEndCode = endCode or ":-) "
    local timeOut = recvtimeOut or 40
    if rtSend == 0 then
      rtRecv, rtCode = iPadSerial:recv(strEndCode, timeOut)
      local endTime = utils.timeEnd(startTime)
      local recvStatus = (rtRecv and "Success" or "Fail")
      local recvFormat = string.format("recv[%s:%s]:%s", recvStatus, tostring(rtCode), rtRecv or "no data\n")
      local recvLog = "["..utils.timestamp().."]:".. recvFormat
      table.insert(g_ResultLog, recvLog)
      table.insert(g_ResultLog, "[recv:finish]")
    end
    sendTimes = sendTimes + 1
    errorLog = string.sub(rtRecv or "",-256)
    bReSend = string.match(errorLog or "","ommand%s+\'.-\'%s+not%s+found")
  until(sendTimes >= 2 or (not bReSend))

  return rtSend, rtRecv
end

-----------------
g_nanocom = nil
function doFixtureCmd_(anCmd, endCode, recvtimeOut)
  if not anCmd then
    table.insert(g_ResultLog, "Error info: anCmd is nil!")
    return nil, nil
  end

  if g_nanocom == nil then
    msgNetCat = message.open("telnet 169.254.1.1 28100")
    local rtNanocom, rtCode = message.recv(msgNetCat, "CAT>", 10, 0)
    print("rtNanocom",rtNanocom)
    app.wait(500)
    message.send(msgNetCat,"get_status\n", 25, 0) 
    message.recv(msgNetCat, "CAT>", 10, 0)
    g_nanocom = msgNetCat
  end

  --local sendTimes = 0
  local rtSend, rtRecv, rtCode, errorLog, bReSend = nil, nil, nil, nil
  -- repeat
  --print("test start 0713-2")
--  anCmd = turnCommand(anCmd)
  rtSend = message.send(msgNetCat,anCmd, 25, 0) --iPadSerial:send(anCmd, 25)
  local startTime = utils.timeStart()
  local sendStatus = rtSend and "Success" or "Fail"
  local sendFormat = string.format("send[%s:%s]:%s", sendStatus, tostring(rtSend), anCmd or "cmd empty\n")
  local sendLog =  "["..utils.timestamp().."]:"..sendFormat
  table.insert(g_ResultLog, sendLog)

  local strEndCode = "CAT>"
  local timeOut = recvtimeOut or 50
  --if rtSend == 0 then
  rtRecv, rtCode = message.recv(msgNetCat, strEndCode, timeOut, 0) --iPadSerial:recv(strEndCode, timeOut)
  --print("test start 0713-3")
  local endTime = utils.timeEnd(startTime)
  local recvStatus = (rtRecv and "Success" or "Fail")
  local recvFormat = string.format("recv[%s:%s]:%s", recvStatus, tostring(rtCode), rtRecv or "no data\n")
  local recvLog = "["..utils.timestamp().."]:".. recvFormat
  table.insert(g_ResultLog, recvLog)
  table.insert(g_ResultLog, "[recv:finish]")
  --  end
  -- sendTimes = sendTimes + 1
  -- errorLog = string.sub(rtRecv or "",-256)
  --bReSend = string.match(errorLog or "","ommand%s+\'.-\'%s+not%s+found")
  -- until(sendTimes >= 2 or (not bReSend))

  return rtSend, rtRecv
end
---------------------------------------------------
function sendDiagsCmd(anCmd)
  if iPadSerial == nil then 
    table.insert(g_ResultLog, "Error info: iPadSerial is Null!")
    return nil, nil
  end

  if not anCmd then
    table.insert(g_ResultLog, "Error info: anCmd is nil!")
    return nil, nil
  end

  local rtSend = iPadSerial:send(anCmd, 25)
  local sendStatus = (rtSend==0) and "Success" or "Fail"
  local sendFormat = string.format("send[%s:%s]:%s", sendStatus, tostring(rtSend), anCmd or "cmd empty\n")
  local sendLog =  "["..utils.timestamp().."]:"..sendFormat
  table.insert(g_ResultLog, sendLog)

  return rtSend
end  


-------------------------------------------------
function receiveDiagsCmd(endCode, recvtimeOut)
  local rtRecv, rtCode = nil, nil
  local strEndCode = endCode or ":-) "
  local timeOut = recvtimeOut or 50

  rtRecv, rtCode = iPadSerial:recv(strEndCode, timeOut)
  local recvStatus = (rtRecv and "Success" or "Fail")
  local recvFormat = string.format("recv[%s:%s]:%s", recvStatus, tostring(rtCode), rtRecv or "no data\n")
  local recvLog = "["..utils.timestamp().."]:".. recvFormat
  table.insert(g_ResultLog, recvLog)
  table.insert(g_ResultLog, "[recv:finish]")
  return rtRecv
end  

-------------------------------------------------
function doOrionCmd(anCmd, endCode, recvtimeOut)
  if OrionSerial == nil then 
    table.insert(g_ResultLog, "Error info: OrionSerial is Null!")
    return nil, nil
  end

  if not anCmd then
    table.insert(g_ResultLog, "Error info: anCmd is nil!")
    return nil, nil
  end

  local rtRecv, rtCode = nil, nil
  local rtSend = OrionSerial:send(anCmd, 25)
  local startTime = utils.timeStart()
  local sendStatus = (rtSend==0) and "Success" or "Fail"
  local sendFormat = string.format("send[%s:%s]:%s", sendStatus, tostring(rtSend), anCmd or "cmd empty\n")
  local sendLog =  "["..utils.timestamp().."]:"..sendFormat
  table.insert(g_ResultLog, sendLog)

  local strEndCode = endCode or {[[>]],[[Ping\sHigh]]}
  local timeOut = recvtimeOut or 50
  if rtSend == 0 then
    rtRecv, rtCode = OrionSerial:recv(strEndCode, timeOut)
    local endTime = utils.timeEnd(startTime)
    local recvStatus = (rtRecv and "Success" or "Fail")
    local recvFormat = string.format("recv[%s:%s]:%s", recvStatus, tostring(rtCode), rtRecv or "no data\n")
    local recvLog = "["..utils.timestamp().."]:".. recvFormat
    table.insert(g_ResultLog, recvLog)
    table.insert(g_ResultLog, "[recv:finish]")
  end

  return rtSend, rtRecv
end


-------------------------------------------------
function doScorpiusCmd(anCmd, endCode, recvtimeOut)
  if fixtureSerial == nil then 
    table.insert(g_ResultLog, "Error info: fixtureSerial is Null!")
    return nil, nil
  end

  if not anCmd then
    table.insert(g_ResultLog, "Error info: anCmd is nil!")
    return nil, nil
  end

  local rtRecv, rtCode = nil, nil
  local rtSend = fixtureSerial:send(anCmd, 25)
  local startTime = utils.timeStart()
  local sendStatus = (rtSend==0) and "Success" or "Fail"
  local sendFormat = string.format("send[%s:%s]:%s", sendStatus, tostring(rtSend), anCmd or "cmd empty\n")
  local sendLog =  "["..utils.timestamp().."]:"..sendFormat
  table.insert(g_ResultLog, sendLog)

  local strEndCode = endCode or "Ginger>"
  local timeOut = recvtimeOut or 50
  if rtSend == 0 then
    rtRecv, rtCode = fixtureSerial:recv(strEndCode, timeOut)
    local endTime = utils.timeEnd(startTime)
    local recvStatus = (rtRecv and "Success" or "Fail")
    local recvFormat = string.format("recv[%s:%s]:%s", recvStatus, tostring(rtCode), rtRecv or "no data\n")
    local recvLog = "["..utils.timestamp().."]:".. recvFormat
    table.insert(g_ResultLog, recvLog)
    table.insert(g_ResultLog, "[recv:finish]")
  end

  return rtSend, rtRecv
end

-------------------------------------------------
function sendFixtureCmd(anCmd)
  if fixtureSerial == nil then 
    table.insert(g_ResultLog, "Error info: fixtureSerial is Null!")
    return nil, nil
  end

  if not anCmd then
    table.insert(g_ResultLog, "Error info: anCmd is nil!")
    return nil, nil
  end

  local rtRecv, rtCode = nil, nil
  local rtSend = fixtureSerial:send(anCmd, 25)
  local startTime = utils.timeStart()
  local sendStatus = (rtSend==0) and "Success" or "Fail"
  local sendFormat = string.format("send[%s:%s]:%s", sendStatus, tostring(rtSend), anCmd or "cmd empty\n")
  local sendLog =  "["..utils.timestamp().."]:"..sendFormat
  table.insert(g_ResultLog, sendLog)

  return rtSend
end
-------------------------------------------------
function doMikeyCmd(anCmd, endCode, recvtimeOut)
  if mikeySerial == nil then 
    table.insert(g_ResultLog, "Error info: mikeySerial is Null!")
    return nil, nil
  end

  if not anCmd then
    table.insert(g_ResultLog, "Error info: anCmd is nil!")
    return nil, nil
  end

  local rtRecv, rtCode = nil, nil
  local rtSend = mikeySerial:send(anCmd, 10)
  local startTime = utils.timeStart()
  local sendStatus = (rtSend==0) and "Success" or "Fail"
  local sendFormat = string.format("send[%s:%s]:%s", sendStatus, tostring(rtSend), anCmd or "cmd empty\n")
  local sendLog =  "["..utils.timestamp().."]:"..sendFormat
  table.insert(g_ResultLog, sendLog)

  local strEndCode = endCode or {[[\*_\*\s?]]}
  local timeOut = recvtimeOut or 10
  if rtSend == 0 then
    rtRecv, rtCode = mikeySerial:recv(strEndCode, timeOut)
    local endTime = utils.timeEnd(startTime)
    local recvStatus = (rtRecv and "Success" or "Fail")
    local recvFormat = string.format("recv[%s:%s]:%s", recvStatus, tostring(rtCode), rtRecv or "no data\n")
    local recvLog = "["..utils.timestamp().."]:".. recvFormat
    table.insert(g_ResultLog, recvLog)
    table.insert(g_ResultLog, "[recv:finish]")
  end

  return rtSend, rtRecv
end

function doFixtureCmd(anCmd, endCode, recvtimeOut)
  return doMikeyCmd(anCmd, endCode, recvtimeOut)
end  
-------------------------------------------------
function doProxCmd(anCmd, endCode, recvtimeOut)
  if proxSerial == nil then 
    table.insert(g_ResultLog, "Error info: proxSerial is Null!")
    return nil, nil
  end

  if not anCmd then
    table.insert(g_ResultLog, "Error info: anCmd is nil!")
    return nil, nil
  end

  local rtRecv, rtCode = nil, nil
  local rtSend = proxSerial:send(anCmd, 25)
  local startTime = utils.timeStart()
  local sendStatus = (rtSend==0) and "Success" or "Fail"
  local sendFormat = string.format("send[%s:%s]:%s", sendStatus, tostring(rtSend), anCmd or "cmd empty\n")
  local sendLog =  "["..utils.timestamp().."]:"..sendFormat
  table.insert(g_ResultLog, sendLog)

  local strEndCode = endCode or 6
  local timeOut = recvtimeOut or 50
  if rtSend == 0 then
    rtRecv, rtCode = proxSerial:recv(strEndCode, timeOut)
    local endTime = utils.timeEnd(startTime)
    local recvStatus = (rtRecv and "Success" or "Fail")
    local recvFormat = string.format("recv[%s:%s]:%s", recvStatus, tostring(rtCode), rtRecv or "no data\n")
    local recvLog = "["..utils.timestamp().."]:".. recvFormat
    table.insert(g_ResultLog, recvLog)
    table.insert(g_ResultLog, "[recv:finish]")
  end

  return rtSend, rtRecv
end

-------------------------------------------------
function doMotorCmd(anCmd, endCode, recvtimeOut)
  if motorSerial == nil then 
    table.insert(g_ResultLog, "Error info: motorSerial is Null!")
    return nil, nil
  end

  if not anCmd then
    table.insert(g_ResultLog, "Error info: anCmd is nil!")
    return nil, nil
  end

  local rtRecv, rtCode = nil, nil
  local rtSend = motorSerial:send(anCmd, 25)
  local startTime = utils.timeStart()
  local sendStatus = (rtSend==0) and "Success" or "Fail"
  local sendFormat = string.format("send[%s:%s]:%s", sendStatus, tostring(rtSend), anCmd or "cmd empty\n")
  local sendLog =  "["..utils.timestamp().."]:"..sendFormat
  table.insert(g_ResultLog, sendLog)

  local strEndCode = endCode or "%\r"
  local timeOut = recvtimeOut or 50
  if rtSend == 0 then
    rtRecv, rtCode = motorSerial:recv(strEndCode, timeOut)
    local endTime = utils.timeEnd(startTime)
    local recvStatus = (rtRecv and "Success" or "Fail")
    local recvFormat = string.format("recv[%s:%s]:%s", recvStatus, tostring(rtCode), rtRecv or "no data\n")
    local recvLog = "["..utils.timestamp().."]:".. recvFormat
    table.insert(g_ResultLog, recvLog)
    table.insert(g_ResultLog, "[recv:finish]")
  end

  return rtSend, rtRecv
end
------------------------------------------------------------------------------------------------
function doPotassiumCmd(anCmd,endStr,timeout)

  if not anCmd or not endStr then
    table.insert(g_ResultLog, "No Command or endStr")
    return nil
  end

  local potassiumMsg = message.open(anCmd)
  local rtSend = potassiumMsg and 0 or 1
  local sendSuccess = rtSend == 0 and "Success" or "Fail"
  local sendFormat = string.format("send[%s:%s]:%s",sendSuccess,rtSend, anCmd or "cmd empty\n")
  local sendLog =  "["..utils.timestamp().."]:"..sendFormat
  table.insert(g_ResultLog, sendLog)

  timeout = timeout or 10
  local rtRecv,rtCode = message.recv(potassiumMsg, endStr, timeout, 0)

  local recvStatus = (rtRecv and "Success" or "Fail")
  local recvFormat = string.format("recv[%s:%s]:%s", recvStatus, tostring(rtCode), rtRecv or "no data\n")
  local recvLog = "["..utils.timestamp().."]:".. recvFormat
  table.insert(g_ResultLog, recvLog)
  table.insert(g_ResultLog, "[recv:finish]")

  if potassiumMsg then
    message.close(potassiumMsg)
    potassiumMsg = nil
  end

  return rtRecv
end


function turnCommand(cmd)
  local _,positionX = doFixtureCmd_("get_position\n")
  local distance = string.match(cmd or "","%d+")
  local xPosition,zPosition = string.match(positionX or "","POSITION%s+(.-),(.-)\n")
  local newCmd = cmd
  if string.find(cmd or "","left") then
    print("xPosition",xPosition)
    print("distance",distance)
    newCmd = "move_abs:1," .. tostring( tonumber(xPosition) + tonumber(distance) ) .. "\n"

  elseif string.find(cmd or "","right") then
    newCmd = "move_abs:1," .. tostring( tonumber(xPosition) - tonumber(distance) ) .. "\n"


  elseif string.find(cmd or "","up") then
    newCmd = "move_abs:2," .. tostring( tonumber(zPosition) - tonumber(distance) ) .. "\n"

  elseif string.find(cmd or "","down") then
    newCmd = "move_abs:2," .. tostring( tonumber(zPosition) + tonumber(distance) ) .. "\n"

  end
  return newCmd
end



function doFixtureCmd_(anCmd, endCode, recvtimeOut)
  if not anCmd then
    table.insert(g_ResultLog, "Error info: anCmd is nil!")
    return nil, nil
  end


  if g_nanocom == nil then
    msgNetCat = message.open("telnet 169.254.1.1 28100")
    local rtNanocom, rtCode = message.recv(msgNetCat, "CAT>", 10, 0)
    print("rtNanocom",rtNanocom)
    app.wait(500)
    message.send(msgNetCat,"get_status\n", 25, 0) 
    message.recv(msgNetCat, "CAT>", 10, 0)
    g_nanocom = msgNetCat
  end

  --local sendTimes = 0
  local rtSend, rtRecv, rtCode, errorLog, bReSend = nil, nil, nil, nil
  -- repeat
  --print("test start 0713-2")
  rtSend = message.send(msgNetCat,anCmd, 25, 0) --iPadSerial:send(anCmd, 25)
  local startTime = utils.timeStart()
  local sendStatus = rtSend and "Success" or "Fail"
  local sendFormat = string.format("send[%s:%s]:%s", sendStatus, tostring(rtSend), anCmd or "cmd empty\n")
  local sendLog =  "["..utils.timestamp().."]:"..sendFormat
  table.insert(g_ResultLog, sendLog)

  local strEndCode = "CAT>"
  local timeOut = recvtimeOut or 50
  --if rtSend == 0 then
  rtRecv, rtCode = message.recv(msgNetCat, strEndCode, timeOut, 0) --iPadSerial:recv(strEndCode, timeOut)
  --print("test start 0713-3")
  local endTime = utils.timeEnd(startTime)
  local recvStatus = (rtRecv and "Success" or "Fail")
  local recvFormat = string.format("recv[%s:%s]:%s", recvStatus, tostring(rtCode), rtRecv or "no data\n")
  local recvLog = "["..utils.timestamp().."]:".. recvFormat
  table.insert(g_ResultLog, recvLog)
  table.insert(g_ResultLog, "[recv:finish]")
  --  end
  -- sendTimes = sendTimes + 1
  -- errorLog = string.sub(rtRecv or "",-256)
  --bReSend = string.match(errorLog or "","ommand%s+\'.-\'%s+not%s+found")
  -- until(sendTimes >= 2 or (not bReSend))

  return rtSend, rtRecv
end






