#!/usr/bin/env python3

import display_pdca


# eDP Symbol Error with RED image,POR
def eDP_RedImg_POR(larkspur, sleepDur = 400, reset = False):

    test_name = "eDP_RedImg"
    subtest_name = "POR"
    larkspur.log(test_name + ": " + subtest_name)

    larkspur.eDPClearSymbolError()
    result = larkspur.eDPCheckSymbolError(sleepDur)


    display_pdca.add_single_test_result_to_pdca(test_name, subtest_name, result, False)

    if reset:
        # reset only for failed tests, due reset potentially causing panic.
        if not all(value == 0 for value in result.values()):
            larkspur.reset()


# eDP Symbol Error with RED image,RX EQ Sweep
def eDP_RedImg_RxEqSweep(larkspur, band_range=None, sleepDur = 30, reset = False):

    test_name = "eDP_RedImg_RxEqSweep"
    subtest_name = ""

    for band in band_range:
        # TODO set RED image
        larkspur.eDPClearSymbolError()
        result = larkspur.eDPSetRXEQ(band)
        if result != 0:
            print("eDPSetRXEQ failed with return value: ", result)

        subtest_name = "band" + str(band)
        larkspur.log(test_name + ": " + subtest_name)

        result = larkspur.eDPCheckSymbolError(sleepDur)

        display_pdca.add_single_test_result_to_pdca(test_name, subtest_name, result, True)

        if reset:
            # reset only for failed tests, due reset potentially causing panic.
            if not all(value == 0 for value in result.values()):
                larkspur.reset()


# eDP Symbol Error with RED image,RX EQ Sweep , margin low Vcore
def eDP_RedImg_LowVcore_RxEqSweep(larkspur, band_range=None, sleepDur = 30, reset = False):

    test_name = "eDP_RedImg_LowVcore_RxEqSweep"

    for band in band_range:
        # TODO set RED image

        result = larkspur.eDPSetRXEQ(band)
        if result != 0:
            print("eDPSetRXEQ failed with return value: ", result)

        result = larkspur.pmic.setVcore(voltage = 1)
        if result != 0:
            print("setVcore failed with return value: ", result)

        subtest_name = "band" + str(band) + "_" + "vcore1"
        larkspur.log(test_name + ": " + subtest_name)

        result = larkspur.eDPCheckSymbolError(sleepDur)
        display_pdca.add_single_test_result_to_pdca(test_name, subtest_name, result, True)

        if reset:
            # reset only for failed tests, due reset potentially causing panic.
            if not all(value == 0 for value in result.values()):
                larkspur.reset()


# eDP Symbol Error Rx, RED image, Eye Mon Shmoo Test
def eDP_RedImg_EyeMonShmoo(larkspur, level_range=None, sleepDur = 30, reset = False):

    test_name = "eDP_RedImg_EyeMonShmoo"

    for level in level_range:
        # TODO set RED image

        result = larkspur.eDPJitterInjection(level)
        if result != 0:
            print("eDPJitterInjection failed with return value: ", result)

        subtest_name = "level" + str(level)
        larkspur.log(test_name + ": " + subtest_name)

        result = larkspur.eDPCheckSymbolError(sleepDur)

        display_pdca.add_single_test_result_to_pdca(test_name, subtest_name, result, True)

        if reset:
            # reset only for failed tests, due reset potentially causing panic.
            if not all(value == 0 for value in result.values()):
                larkspur.reset()


# eDP Symbol Error Rx, RED image,Eye Mon Shmoo Test with margin low Vcore
def eDP_RedImg_LowVcore_EyeMonShmoo(larkspur, level_range=None, sleepDur = 30, reset = False):
    test_name = "eDP_RedImg_EyeMonShmoo"

    for level in level_range:
        # TODO set RED image

        result = larkspur.pmic.setVcore(voltage=1)
        if result != 0:
            print("setVcore failed with return value: ", result)

        result = larkspur.eDPJitterInjection(level)
        if result != 0:
            print("eDPJitterInjection failed with return value: ", result)

        subtest_name = "level" + str(level) + "_" + "vcore1"
        larkspur.log(test_name + ": " + subtest_name)
        result = larkspur.eDPCheckSymbolError(sleepDur)

        display_pdca.add_single_test_result_to_pdca(test_name, subtest_name, result, True)

        if reset:
            # reset only for failed tests, due reset potentially causing panic.
            if not all(value == 0 for value in result.values()):
                larkspur.reset()


# eDP Symbol Error Rx,RED image, Eye Mon Shmoo Test, EQ=0
def eDP_RedImg_RxEq01Sweep_EyeMonShmoo(larkspur, band_range=None, level_range=None, sleepDur = 30, reset = False):

    test_name = "eDP_RedImg_EQ0_EyeMonShmoo"

    for band in band_range:
        for level in level_range:
            # TODO set RED image

            result = larkspur.eDPSetRXEQ(band)
            if result != 0:
                print("DX_RX_EQ failed with return value: ", result)

            result = larkspur.eDPJitterInjection(level)
            if result != 0:
                print("eDPJitterInjection failed with return value: ", result)

            subtest_name = "level" + str(level) + "_" + "band" + str(band)
            larkspur.log(test_name + ": " + subtest_name)
            result = larkspur.eDPCheckSymbolError(sleepDur)

            display_pdca.add_single_test_result_to_pdca(test_name, subtest_name, result, True)

            if reset:
                # reset only for failed tests, due reset potentially causing panic.
                if not all(value == 0 for value in result.values()):
                    larkspur.reset()
