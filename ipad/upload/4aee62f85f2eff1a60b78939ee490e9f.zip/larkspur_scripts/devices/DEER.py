import display_pdca

# DPOT IC is DS3902
def autoDetect(TCON):
    Deer = DEER(TCON)
    if(Deer.verifyDevice()):
        TCON.log("Deer is present")
    else:
        TCON.log("Deer not present")

    return Deer

'''
Digital potentiometer: DPOT DS3902U-515
~~~ This is present in Engineering build only ~~~
Spec: 256 steps: R0 = 0-15Kohm, R1 = 0-50Kohm
I2C Addr: 0x51
'''
class DEER():
    def __init__(self):
        self.slaveAddress = 0x51
        self.factoryDefaultSlaveAddr = 0xA0

    # Read single byte from the register
    def rd(self, offset):
        aa_i2c_write(handle, self.slaveAddress, AA_I2C_NO_FLAGS, array('B', [offset & 0xff ]))
        length = 1
        (count, data_in) = aa_i2c_read(handle, self.slaveAddress, AA_I2C_NO_FLAGS, length) # read data
        return (data_in[0])
            
    # Read single byte from the register
    def wr(self, offset, data):
        TCON.log("Writing data")
        aa_i2c_write(handle, self.slaveAddress, AA_I2C_NO_FLAGS, array('B',[offset, data]))
        aa_sleep_ms(10)

    # Verify the device by reading the factory default slave address register
    def verifyDevice(self):
        defaultSlaveAddrRead = self.rd(0x00)
        return (defaultSlaveAddrRead == self.factoryDefaultSlaveAddr):
        
    # Read DPOT values
    def readResistors(self):
        '''By default rd will have TCON as host'''
        config = self.rd(0x01)   # xxxx xxR1R0
        resValueR0 = self.rd(0x02)
        resValueR1 = self.rd(0x03)
        print(hex(resValueR0))
        # R0 value
        if ((config&0x01)==0x01):
            print("R0 = High Z")
        else:
            print("R0 = ", resValueR0*15/255.0, "Kohm")
          
        # R1 Value
        if ((config&0x02)==0x02):
            print("R1 = High Z")
        else:
            print("R1 = ", resValueR1*50/255.0, "Kohm")
        
        # Return: [config, R0, R1]
        return (array('f', [config, resValueR0*15/255.0, resValueR1*50/255.0]))
