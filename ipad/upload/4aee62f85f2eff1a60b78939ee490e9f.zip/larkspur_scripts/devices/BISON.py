# PMIC is RT6811
def autoDetect(TCON):
    '''Detect which vendor varient of San Diego is available'''
    Bison = BISON(TCON)
    vcom_HT = Bison.rd(0x00, 1) & 0x7f
    if vcom_HT == 0x5f:
        TCON.log("BISON detected -- RT6811")
        return Bison
    else:
        TCON.log("Unknown BISON")
        TCON.log("Expected VCOM_HT = 0x5f, Logged = " + hex(vcom_HT))
        return Bison
    return Bison

class BISON():
    def __init__(self, TCON):
        self.larkspur = TCON
        self.channel = 3 # PMIC sits on TCON I2C master 3
        self.slavePmic = 0x28 << 1
       	self.controlAddr = 0xFF
       	self.controlReadDAC = 0x00


    def wr(self, offset, data):
        '''By default wr will have TCON as host'''
       	# Write the actual data
       	self.larkspur.i2cMasterWrite(self.channel, self.slavePmic, offset, data)

    def rd(self, offset, count = 1):
       	'''By default rd will have TCON as host'''
       	self.larkspur.i2cMasterWrite(self.channel, self.slavePmic, self.controlAddr, self.controlReadDAC)        
       	readback = self.larkspur.i2cMasterRead(self.channel, self.slavePmic, offset, count)

        return readback

    def setVcore(self, voltage):
        '''
        value : VCORE voltage : Is not programmable for RT6811
        '''

        # If someone is trying to set voltage, display this warning
        if (voltage != 0):
            self.larkspur.log("VCore not progammable for RT6811")

    def regDump(self):
        '''Prints out all of Bison's registers'''
        self.larkspur.log("Bison Register Dump Start")
        for reg_addr_int in range(0x00,0x18):
            reg_addr = reg_addr_int
            reg_cont = self.rd(reg_addr, 1)
            self.larkspur.log(str(hex(reg_addr)) +  ": " +  str(hex(reg_cont)))
        self.larkspur.log("Bison Register Dump End")
            # Not Complete

    def checkEnable(self):
   		'''checks the enable register'''
   		bison_en = self.rd(0x10)
   		print(bison_en & 0x40)
   		if bison_en & 0x40 == 0x40:
   			self.larkspur.log("VCC3V3 is enabled") 													
   		else:
   			self.larkspur.log("VCC3V3 is disabled")
   		if bison_en & 0x20 == 0x20:
   			self.larkspur.log("VCC1V2 is enabled") 												
   		else:
   			self.larkspur.log("VCC1V2 is disabled")
   		if bison_en & 0x10 == 0x10:
   			self.larkspur.log("VCC1V8 is enabled") 												
   		else:
   			self.larkspur.log("VCC1V8 is disabled")
   		if bison_en & 0x08 == 0x08:
   			self.larkspur.log("AVDD2 is enabled") 												
   		else:
   			self.larkspur.log("AVDD2 is disabled")
   		if bison_en & 0x01 == 0x01:
   			self.larkspur.log("AVDD1 is enabled") 												
   		else:
   			self.larkspur.log("AVDD1 is disabled")	
   			
    def healthScript(self):
        self.larkspur.log("=============Running Bison Health Script=============")
        self.checkEnable()
        self.regDump()
        self.larkspur.log("=============Bison Health Script Complete=============")
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
