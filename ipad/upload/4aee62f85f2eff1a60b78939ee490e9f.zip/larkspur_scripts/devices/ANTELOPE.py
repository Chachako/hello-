import display_pdca

# ADC is ADS8168
def autoDetect(TCON):
    '''Detect which vendor varient of San Diego is available'''
    Antelope = ANTELOPE(TCON)
    if (Antelope.VerifyADC() == 0xAA):
        TCON.log("Antelope detected")
    else:
        TCON.log("ADC is not UP, please check the firmware and board version")
        return

    return Antelope

class ANTELOPE():
    def __init__(self, TCON):
        self.larkspur = TCON

    
    def ADC_GetStatusCmd(self):
        readData = self.larkspur.ADC_ReadRegister(0x00) & 0xff
        return readData

    def VerifyADC(self):
        status = self.ADC_GetStatusCmd()
        return status

    def readChannelADC(self, ch, averagingSample=1):
        # Verify that ADC is present 1st
        if (self.VerifyADC() != 0xAA):
            self.larkspur.log("ADC is not UP, please check the firmware and board version")
            return

        # Wite ADC register data you want to read
        self.larkspur.ADC_WriteRegister(0x1D, ch)

        # Read ADC Data: ADC returns data on SECOND ITERATION for any channel change
        adcData = self.larkspur.ADC_ReadData()
        adcData = self.larkspur.ADC_ReadData()

        # Average ADC data over the number of samples requested
        adcData = 0
        for i in range(averagingSample):
            adcData += self.larkspur.ADC_ReadData()
        adcData /= averagingSample

        return(adcData)


    # ADC Channels
    # 0 - I-VIN 4.096/65536.0/.01/20 A/LSB
    # 1 - I-VDDH 4.096/65536.0/.01/20 A/LSB
    # 2 - I-VCore 4.096/65536.0/.01/20 A/LSB
    # 3 - I-PMIC_VIN 4.096/65536.0/.02/20  A/LSB   .035
    # 4 - I-HVDD_VIN 4.096/65536.0/.1/20 A/LSB     .035
    # 5 - V-VIN - Gain = 125.5/25.5 * 4.096/65536.0 V/LSB
    # 6 - I-VDD_VCOM 4.096/65536.0/.01/20 A/LSB
    # 7 - I-VCC18 4.096/65536.0/.02/20 A/LSB       .035
    def PowerMeasurementGains(self, raw=0):
        HWCID = self.larkspur.HWCID
        if HWCID == 0x00:
            Gain=[]
            Gain.append(4.096/65536.0/.01/20)
            Gain.append(4.096/65536.0/.01/20)
            Gain.append(4.096/65536.0/.01/20)
            Gain.append(4.096/65536.0/.035/20)
            Gain.append(4.096/65536.0/.035/20)
            Gain.append(125.5/25.5 * 4.096/65536.0)
            Gain.append(4.096/65536.0/.01/20)
            Gain.append(4.096/65536.0/.035/20)
        elif HWCID < 8:
            Gain=[]
            Gain.append(4.096/65536.0/.01/20)
            Gain.append(4.096/65536.0/.01/20)
            Gain.append(4.096/65536.0/.01/20)
            Gain.append(4.096/65536.0/.02/20)
            Gain.append(4.096/65536.0/.1/20)
            Gain.append(125.5/25.5 * 4.096/65536.0)
            Gain.append(4.096/65536.0/.01/20)
            Gain.append(4.096/65536.0/.02/20)
        else:
            Gain=[]
            Gain.append(4.096/65536.0)
            Gain.append(4.096/65536.0)
            Gain.append(4.096/65536.0)
            Gain.append(4.096/65536.0)
            Gain.append(4.096/65536.0)
            Gain.append(4.096/65536.0)
            Gain.append(4.096/65536.0)
            Gain.append(4.096/65536.0)
        # Output the raw ADC voltages
        if raw == 1:
            Gain=[]
            Gain.append(4.096/65536.0)
            Gain.append(4.096/65536.0)
            Gain.append(4.096/65536.0)
            Gain.append(4.096/65536.0)
            Gain.append(4.096/65536.0)
            Gain.append(4.096/65536.0)
            Gain.append(4.096/65536.0)
            Gain.append(4.096/65536.0)
        return Gain

    def PowerMeasurementOnce(self, averagingSample, color):

        test_name = "Power Measurement"
        subtest_name = color

        result = {}
        # Get power measurement gains
        Gain = self.PowerMeasurementGains()
        val=[]
        for i in range(8):
            val.append(self.readChannelADC(i, averagingSample)*Gain[i])
        #return val
        result.update({"I_VIN(mA)"   : val[0]*1000.0})
        result.update({"I_VDDH(mA)"  : val[1]*1000.0})
        result.update({"I_VCORE(mA)" : val[2]*1000.0})
        result.update({"I_PMICi(mA)" : val[3]*1000.0})
        result.update({"I_HVDDi(mA)" : val[4]*1000.0})
        result.update({"VIN(V)"      : val[5]})
        result.update({"I_VCOM(mA)"  : val[6]*1000.0})
        result.update({"I_PP1V8(mA)" : val[7]*1000.0})
        display_pdca.add_single_test_result_to_pdca(test_name, subtest_name, result, True)

        return result
        
    def healthScript(self):
        self.larkspur.log("=============Running Antelope Health Script=============")
        self.larkspur.log("Start Power Measurement Dump")
        pMeasure = self.PowerMeasurementOnce(2, "WHITE")
        self.larkspur.log(pMeasure)
        self.larkspur.log("End Power Measurement Dump")
        self.larkspur.log("=============Antelope Health Script Completed=============")

