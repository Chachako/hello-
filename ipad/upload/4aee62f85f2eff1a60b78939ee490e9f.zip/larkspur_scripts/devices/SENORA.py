import display_pdca

'''
Temperature Sensor: SENORA
Resolution: 13 bits (0.0625C/bit). -ve temperature is 2s complement.
Range: 255.9375C and down to -256C
I2C Addr: 0x48, Lock Register is C4h, Lock value: 0x5CA6, Unlock value: 0xEB19
'''

# PGAMMA+PVCOM IC is Buf18830
def autoDetect(TCON):
    Senora = SENORA(TCON)
    if (Senora.verifyDeviceID()):
        TCON.log("Senora is present")
    else:
        TCON.log("Senora not present")
        
    return Senora


class SENORA():
    def __init__(self):
        self.I2CBus = 0x48
        self.slaveAddress = 0x48
        self.manufacturerID = 0x5449
        self.manufacturerIDAddress = 0xFE
        self.slaveProtectRegister = 0xC4
        self.slaveLockValue = 0x5CA6
        self.slaveUnlockValue = 0xEB19
        
    # Read 16-bit word from the register
    def rdWord(self, offset):
        data_length = 2
        value = I2cRead(self, self.I2CBus, self.slaveAddress, data_length, offset)
        return (value[0]<<8|value[1])
     
    # Verify the device by reading the deviceID register
    def verifyDeviceID(self):
        deviceIDRead = self.rdWord(self.manufacturerIDAddress)
        return (deviceIDRead == self.manufacturerID)

     
    # Read Temp. values of the 8 connected sensors
    def readAllTemperatures(self):
        test_name = "Temperature"
        # Read values from pGamma IC
        subtest_name = ""
        result = {}
        tempC = [0, 0, 0, 0, 0, 0, 0, 0]
        for offset in range(8):
            tempC[offset] = 0.0625*(self.rdWord(offset)>>3)
            
        result.update({"SNS1(C)": tempC[0]})
        result.update({"SNS2(C)": tempC[1]})
        result.update({"SNS3(C)": tempC[2]})
        result.update({"SNS4(C)": tempC[3]})
        result.update({"OUT(C)": tempC[4]})
        result.update({"BUF18830(C)": tempC[5]})
        result.update({"0ohm_D7(C)": tempC[6]})
        result.update({"0ohm_D8(C)": tempC[7]})
        display_pdca.add_single_test_result_to_pdca(test_name, subtest_name, result, True)

        return result
