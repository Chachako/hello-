import display_pdca

# Silego IC is SLG4AP43669
def autoDetect(TCON):
    Saola = SAOLA(TCON)
    if(Saola.verifyDevice()):
        TCON.log("Saola is present")
    else:
        TCON.log("Saola not present")

    return Saola
    
'''
Silego: SLG4AP43669
I2C Addr: 0x51
'''
class SAOLA():
    def __init__(self):
        self.slaveAddress = 0x0A
        self.programFile = "SLG4AP43669_GP_r004U_11192019.csv" # File to be progeammed to Silego
        self.dumpFile = "SilegoDump.csv" # File to be read and dump Silego data

    # Write single byte from the register
    def wr(self, address,offset,byte1):
        aa_i2c_write(handle,address,AA_I2C_NO_FLAGS,array('B',[offset,byte1]))
        aa_sleep_ms(1)
        return

    # Write 16-bytes from the register
    def wr16(self, address, offset, bytearr):
        writeval=array('B',[offset])
        for i in range(16):
            writeval.append(bytearr[i])
        aa_i2c_write(handle,address,AA_I2C_NO_FLAGS,writeval)
        aa_sleep_ms(1)
        return

    # Read single byte from the register
    def rd(self, slave_addr, offset):
        slave_addr = slave_addr
        aa_i2c_write(handle, slave_addr, AA_I2C_NO_FLAGS, array('B', [offset & 0xff ]))
        length = 1
        (count, data_in) = aa_i2c_read(handle, slave_addr, AA_I2C_NO_FLAGS, length) # read data
        return data_in[0]
       
    # Read 16-bytes from the register
    def rd16(self, slave_addr, offset):
        slave_addr = slave_addr
        aa_i2c_write(handle, slave_addr, AA_I2C_NO_FLAGS, array('B', [offset & 0xff ]))
        length = 16
        (count, data_in) = aa_i2c_read(handle, slave_addr, AA_I2C_NO_FLAGS, length) # read data
        return data_in
        
    # Read 16-bytes from the register
    def rd256(self, slave_addr, offset):
        slave_addr = slave_addr
        aa_i2c_write(handle, slave_addr, AA_I2C_NO_FLAGS, array('B', [offset & 0xff ]))
        length = 256
        (count, data_in) = aa_i2c_read(handle, slave_addr, AA_I2C_NO_FLAGS, length) # read data
        return data_in
                
    # Erase the Silego EEPROM
    def Erase(self):
        DevAddr = 0x08
        RegAddr = 0xE3
        for i in range(15):
            data=0x80 + i
            self.wr(DevAddr,RegAddr, data)
            time.sleep(0.02)

    # Program 1-page (16-bytes) of Silego EEPOROM
    def Prog(self, page, data):
        DevAddr = 0x0A
        RegAddr = page << 4
        self.wr16(DevAddr, RegAddr, data)
        time.sleep(0.02)
        
    # Read 1-page (16-bytes) of Silego EEPOROM
    def Read(self, page):
        DevAddr = 0x0A
        RegAddr = page << 4
        return self.rd16(DevAddr, RegAddr)

    # Read 1-page (16-bytes) of Silego EEPOROM
    def Read256(self, page):
        DevAddr = 0x0A
        RegAddr = page << 8
        return self.rd256(DevAddr, RegAddr)

    # Reprogram Silego from .csv file
    def ReprogramSaola(self):
        with open(self.programFile,'r') as f:
            x=f.readlines()
        f.close()
            
        data=[]
        for i in range(256):
            data.append(int(x[i],16))
            
        Erase()
        print "\n Erase Successful!"
        
        Success=1
        for i in range(15):
            progdata=data[i*16:(i*16)+16]
            self.Prog(i,progdata)
            veridata=list(self.Read(i))
            if progdata == veridata:
                print "Page %d success" %i
            else:
                print "Page %d fail" %i
                Success = 0

        if Success == 1:
            print "\n Programming of Silego was successful!"
        else:
            print "\n ERROR - Programming failed"

    # Memory dump Silego to .csv file
    def DumpSaola(self):
        SilegoData = self.Read256(0x00)
        with open(self.dumpFile,'w') as f:
            for i in range(256):
                f.write(format(SilegoData[i], '02x'))
                f.write("\n")
        f.close()
        print "\n Dump Successful!"




########## Silego #########
#Silego = SILEGO()
##Silego.ReprogramSilego()
##Silego.DumpSilego()
#
### SilegoTerminal Dump
#SilegoData = (Silego.Read256(0x00))
#print("Silego Data = ", SilegoData)
