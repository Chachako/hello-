def autoDetect(TCON):
    '''Detect which vendor varient of San Diego is available'''
    SantaBarbara = SANTA_BARBARA(TCON)
    vendorID = SantaBarbara.rd(0xe0, 1)
    chipID = SantaBarbara.rd(0xe1, 1)
    if (chipID != 0x67):
        TCON.log("Device Found, but it's not a Santa Barbara")
        return None
    if vendorID == 0x61:
        TCON.log("TI SB detected")
        return SANTA_BARBARA_TI(TCON)
    elif vendorID == 0x09:
        TCON.log("ISL SB detected")
        return SANTA_BARBARA_ISL(TCON)
    else:
        TCON.log("Unknown SB")
        return None

class SANTA_BARBARA():
    def __init__(self, TCON):
        self.larkspur = TCON
        self.channel = 3 # PMIC sits on TCON I2C master 3
        self.writeAddr = 0xe2
        self.slavePmic = 0x4f << 1
        self.slaveProtectAddr = 0x74 << 1 # This is actually 7 bit 0x74

    def healthScript(self):
        self.larkspur.log("=============Running Santa Barbara Health Script=============")
        self.larkspur.log("=============Santa Barbara Health Script Complete=============")


    def wr(self, offset, data):
        '''By default wr will have TCON as host'''
        # Enable write operation on San Diego
        self.larkspur.i2cMasterWrite(self.channel, self.slaveProtectAddr, self.writeAddr, offset)
        # Write the actual data
        self.larkspur.i2cMasterWrite(self.channel, self.slavePmic, offset, data)

    def rd(self, offset, count = 1):
        '''By default rd will have TCON as host'''
        # First write the register to read from
        readback = self.larkspur.i2cMasterRead(self.channel, self.slavePmic, offset, 1)

        return readback

    def setVcore(self, voltage, config = None):
        '''
        value : VCORE voltage
        config : Top 3 bits of the same register. Value can be same for TI and ISL
        '''
        if config == None:
            config = self.vcoreConfig

        # bottom 5 bits is the voltage value
        vcoreBinary = int(40 * voltage - 36) & 0x1f

        regVcore = config | vcoreBinary

        for register in self.vcoreOffset:
            self.wr(register, regVcore)

        return 0

    def shutDown(self):
        self.wr(0x03, 0xac)


class SANTA_BARBARA_TI(SANTA_BARBARA):
    def __init__(self, TCON):
        super().__init__(TCON)

        self.vcoreOffset = [0x0b, 0x0c] # Setting up the PMIC registers depending on vendor
        self.vcoreConfig = 0xE0         # TI default is buck 1 high current mode, Automatic PFM/PWM mode


class SANTA_BARBARA_ISL(SANTA_BARBARA):
    def __init__(self, TCON):
        super().__init__(TCON)

        self.vcoreOffset = [0x14, 0x15] # Setting up the PMIC registers depending on vendor
        self.vcoreConfig = 0x20         # ISL default is same setting, but register arrangement is different
