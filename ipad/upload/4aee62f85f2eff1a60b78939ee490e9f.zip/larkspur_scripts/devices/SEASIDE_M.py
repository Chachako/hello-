def autoDetect(TCON):
    '''Detect which vendor varient of Seaside M is available'''
    Seaside = SEASIDE_M(TCON)
    vendor_ID = Seaside.rd(0xe0)
    IC_ID = Seaside.rd(0xe1)
    if (vendor_ID == 0x0009 and IC_ID == 0x0060):
        TCON.log("Seaside M detected")
        return SEASIDE_M(TCON)
    else:
        TCON.log("Unknown Seaside M")

        return None

class SEASIDE_M():
    def __init__(self, TCON):
        self.larkspur = TCON
        ''' use FW API instead of I2C tunneling
        self.channel = 3 # PLS sits on TCON I2C master 3
        self.writeAddr = 0xe2
        self.slavePls = 0x40 << 1
        self.slaveProtectAddr = 0x71 << 1
        '''

    def healthScript(self):
        self.larkspur.log("=============Running Seaside M Health Script=============")

        self.larkspur.log("=============Seaside M Health Script Complete=============")

    def wr(self, offset, data):
        if not self.larkspur.mcu:
            return -1
        '''Use FW API'''
        # Disable single reg write to EEPROM
        if (data & 0x4000): # Detect if WRITE_EE bit[14] = 1
            data = data & 0xbfff # Set WRITE_EE bit[14] = 0
        return self.larkspur.PLS_wr(offset,data,2)

    def rd(self, offset):
        if not self.larkspur.mcu:
            return -1
        '''Use FW API'''
        read_data = self.larkspur.PLS_rd(offset)
        return (read_data[0]<<8)+read_data[1]
