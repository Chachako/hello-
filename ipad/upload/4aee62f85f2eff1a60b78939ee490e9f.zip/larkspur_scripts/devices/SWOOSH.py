def autoDetect(TCON):
    ''' Just inform about the non-programable level shifter is available'''
    Swoosh = SWOOSH(TCON)
    if (Swoosh.larkspur.boardID == 0x03):
        TCON.log("SWOOSH expected: SW50024 LS is not programmable")
        return SWOOSH(TCON)
    else:
        TCON.log("Unknown SWOOSH. TI is only currently supported.")
        return None

class SWOOSH():
    def __init__(self, TCON):
        self.larkspur = TCON
        self.channel = None
        self.writeAddr = None
        self.slavePls = None
        self.slaveProtectAddr = None

    def healthScript(self):
        self.larkspur.log("=============Running SWOOSH Health Script=============")
        self.larkspur.log("=============SWOOSH Health Script Complete=============")
