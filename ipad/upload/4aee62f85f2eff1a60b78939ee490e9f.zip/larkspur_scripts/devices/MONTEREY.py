def autoDetect(TCON):
    '''Detect which vendor varient of Monterey is available'''
    Monterey = MONTEREY(TCON)
    vendor_ID = Monterey.rd(0xe0, 1)
    if vendor_ID == 0x61:
        TCON.log("TI Monterey detected")
        return MONTEREY(TCON)
    else:
        TCON.log("Unknown Monterey. TI is only currently supported.")
        return None

class MONTEREY():
    def __init__(self, TCON):
        self.larkspur = TCON
        self.channel = 3 # PLS sits on TCON I2C master 3
        self.writeAddr = 0xe2
        self.slavePls = 0x42 << 1
        self.slaveProtectAddr = 0x73 << 1 # This is actually 7 bit 0x73

    def healthScript(self):
        self.larkspur.log("=============Running Monterey Health Script=============")
        self.larkspur.log("=============Monterey Health Script Complete=============")

    def wr(self, offset, data):
        '''By default wr will have TCON as host'''
        isArray = True

        try:
            if len(offset) != len(data):
                raise ValueError("Error! Input array for offset values which map to each data byte to be written.")
        except TypeError:
            self.larkspur.log("Writing only 1 byte...")
            isArray = False

        if isArray:
            for i in range(len(data)):
                # Enable write operation on Monterey
                self.larkspur.i2cMasterWrite(self.channel, self.slaveProtectAddr, self.writeAddr, offset[i])
                # Write the actual data
                self.larkspur.i2cMasterWrite(self.channel, self.slavePls, offset[i], data[i])
        else:
            # Enable write operation on Monterey
            self.larkspur.i2cMasterWrite(self.channel, self.slaveProtectAddr, self.writeAddr, offset)
            # Write the actual data
            self.larkspur.i2cMasterWrite(self.channel, self.slavePls, offset, data)

    def rd(self, offset, count = 1):
        '''By default rd will have TCON as host'''
        # First write the register to read from
        readback = self.larkspur.i2cMasterRead(self.channel, self.slavePls, offset, count)

        return readback
