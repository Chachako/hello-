#!/usr/bin/env python3
import display_pdca

# PGAMMA+PVCOM IC is Buf18830
def autoDetect(TCON):
    '''Detect which vendor varient of San Diego is available'''
    Buffalo = BUFFALO(TCON)
    TCON.log("Expecting Buffalo")
#    Buffalo.rd(0x00)
#    Buffalo.readPGamma()
#    Buffalo.readVCOM()
    return Buffalo


class BUFFALO():
    def __init__(self, TCON):
        self.larkspur = TCON
        self.addressOriginalValues = 0x1D100
        self.addressCalibrationvalues = 0x1D200

    # Reads 2-bytes (word) of data
    def rd(self, offset):
        read_data = self.larkspur.PGAMMA_rd(offset)
        return read_data

    # Reads 18 pGamma + 2 VCOM regosters
    def readPGammaVCOM(self):
        test_name = "PGAMMA_VCOM"
        
        # Read values from pGamma IC
        subtest_name = ""
        result = {}
        pGammaIC_data = [0x00 for i in range(20)]
        for i in range(20):
            pGammaIC_data[i] = self.larkspur.PGAMMA_rd(i)
            result.update({"Buffalo_"+str(i) : pGammaIC_data[i]})
        display_pdca.add_single_test_result_to_pdca(test_name, subtest_name, result, True)

        # Read Original Values from TCON
        subtest_name = ""
        result = {}
        TCON_pGamma_orig_data = [0x00 for i in range(20)]
        origValue = self.larkspur.fwApiReadNVMPage(self.addressOriginalValues)
        for i in range(20):
            TCON_pGamma_orig_data[i] = (origValue[2*i]<<8) + origValue[2*i+1]
            result.update({"TCON_Ideal_"+str(i) : TCON_pGamma_orig_data[i]})
        display_pdca.add_single_test_result_to_pdca(test_name, subtest_name, result, True)

        # Read Calibration Values from TCON
        subtest_name = ""
        result = {}
        TCON_pGamma_calibration_data = [0x00 for i in range(20)]
        calibrationValue = self.larkspur.fwApiReadNVMPage(self.addressCalibrationvalues)
        for i in range(20):
            TCON_pGamma_calibration_data[i] = (calibrationValue[2*i]<<8) + calibrationValue[2*i+1]
            result.update({"TCON_Calibration_"+str(i) : TCON_pGamma_calibration_data[i]})
        display_pdca.add_single_test_result_to_pdca(test_name, subtest_name, result, True)

        # Check if the calibration data matches
        TCON_calibrated_data = [0x00 for i in range(20)]
        for i in range(20):
            TCON_calibrated_data[i] = TCON_pGamma_orig_data[i] + TCON_pGamma_calibration_data[i]
        if(pGammaIC_data == TCON_calibrated_data):
            self.larkspur.log("PGAMMA VCOM calibration values MATCH")
            return 0
        else:
            self.larkspur.log("ERROR: PGAMMA VCOM calibration values DON'T MATCH")
            return (-1)
            
            
    def healthScript(self):
        self.larkspur.log("=============Running Buffalo Health Script=============")
        self.larkspur.log("Start Buffalo Reg Dump")
        gamma_vcom_reg = self.readPGammaVCOM()
        self.larkspur.log(gamma_vcom_reg)
        self.larkspur.log("End Buffalo Reg Dump")
        self.larkspur.log("=============Buffalo Health Script Complete=============")
