def autoDetect(TCON):
    '''Detect which vendor varient of San Diego is available'''
    SanDiego = SAN_DIEGO(TCON)
    vendorID = SanDiego.rd(0xe0, 1)
    chipID = SanDiego.rd(0xe1, 1)
    if (chipID != 0x63):
        TCON.log("Device Found, but it's not a San Diego")
        return None
    if vendorID == 0x61:
        TCON.log("TI SD detected")
        return SAN_DIEGO_TI(TCON)
    elif vendorID == 0x09:
        TCON.log("ISL SD detected")
        return SAN_DIEGO_ISL(TCON)
    else:
        TCON.log("Unknown SD")
        return None

class SAN_DIEGO():
    def __init__(self, TCON):
        self.larkspur = TCON
        self.channel = 3 # PMIC sits on TCON I2C master 3
        self.writeAddr = 0xe2
        self.slavePmic = 0x4f << 1
        self.slaveProtectAddr = 0x74 << 1 # This is actually 7 bit 0x74

    def healthScript(self):
        self.larkspur.log("=============Running San Diego Health Script=============")
        self.larkspur.log("=============San Diego Health Script Complete=============")

    def wr(self, offset, data):
        '''By default wr will have TCON as host'''
        # Enable write operation on San Diego
        self.larkspur.i2cMasterWrite(self.channel, self.slaveProtectAddr, self.writeAddr, offset)
        # Write the actual data
        self.larkspur.i2cMasterWrite(self.channel, self.slavePmic, offset, data)

    def rd(self, offset, count = 1):
        '''By default rd will have TCON as host'''
        # First write the register to read from
        readback = self.larkspur.i2cMasterRead(self.channel, self.slavePmic, offset, 1)

        return readback

    def setVcore(self, voltage, config = 0xE0):
        '''
        voltage : VCORE voltage
        config : Top 3 bits of the same register. Value can be same for TI and ISL
        '''
        # bottom 5 bits is the voltage value
        vcoreBinary = int(40 * voltage - 36) & 0x1f

        regVcore = config | vcoreBinary

        self.wr(self.vcore_offset, regVcore)

        return 0


class SAN_DIEGO_TI(SAN_DIEGO):
    def __init__(self, TCON):
        super().__init__(TCON)

        self.vcore_offset = 0x02 # Setting up the PMIC registers depending on vendor


class SAN_DIEGO_TI_CHT(SAN_DIEGO_TI):
    def __init__(self):
        super().__init__(None)
        # And add Cheetah detect etc.

class SAN_DIEGO_ISL(SAN_DIEGO):
    def __init__(self, TCON):
        super().__init__(TCON)

        self.vcore_offset = 0x01 # Setting up the PMIC registers depending on vendor
