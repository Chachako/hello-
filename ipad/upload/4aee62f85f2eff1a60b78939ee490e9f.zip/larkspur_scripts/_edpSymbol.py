def eDPCheckSymbolError (self, sleepDur = 400):
    '''This fucntion will read the eDP symbol error counter'''
    self.eDPClearSymbolError()

    self.sleep(sleepDur)

    result = {}
    if (self.rd(0x3, 0x3d) & 0x80 == 0x80):
        Lane0_symbol_error = (self.rd(0x3, 0x3d) << 8 | self.rd(0x3, 0x3c)) & 0x7FFF
        result.update({"Lane0" : Lane0_symbol_error})
    else:
        result.update({"Lane0" : -1})
    if (self.rd(0x3, 0x3f) & 0x80 == 0x80):
        Lane1_symbol_error = (self.rd(0x3, 0x3f) << 8 | self.rd(0x3, 0x3e)) & 0x7FFF
        result.update({"Lane1" : Lane1_symbol_error})
    else:
        result.update({"Lane1": -1})
    if (self.rd(0x3, 0x41) & 0x80 == 0x80):
        Lane2_symbol_error = (self.rd(0x3, 0x41) << 8 | self.rd(0x3, 0x40)) & 0x7FFF
        result.update({"Lane2" : Lane2_symbol_error})
    else:
        result.update({"Lane2": -1})
    if (self.rd(0x3, 0x43) & 0x80 == 0x80):
        Lane3_symbol_error = (self.rd(0x3, 0x43) << 8 | self.rd(0x3, 0x42)) & 0x7FFF
        result.update({"Lane3" : Lane3_symbol_error})
    else:
        result.update({"Lane3": -1})

    self.log(result)
    return result

def eDPSetRXEQ(self, band):
    ''' band : 0 to 9 '''
    if self.edp == "HBR":
        self.wrMask(0x0f, 0x70, band << 4, 0x0f)
    elif self.edp == "HBR2":
        self.wrMask(0x0f, 0x71, band, 0xf0)
    elif self.edp == "HBR3":
        self.wrMask(0x0f, 0x71, band << 4, 0x0f)
    else:
        self.log("Using RBR (1620Mbps), are you sure this is what you want?")
        self.wrMask(0x0f, 0x70, band, 0xf0)

    return 0

def eDPJitterInjection(self, level):
    ''' level : 0 to 7 '''

    self.wrMask(0x0f, 0x88, 0x80, 0x7f) # enable jitter injection

    self.wr(0x0f, 0xae, 0x40) ## select jitter injection frequency RCK/1
    if level == 0 :
        jitter_lev = 0x80
    elif level == 1 :
        jitter_lev = 0x90
    elif level == 2 :
        jitter_lev = 0xa0
    elif level == 3 :
        jitter_lev = 0xb0
    elif level == 4 :
        jitter_lev = 0xc0
    elif level == 5 :
        jitter_lev = 0xd0
    elif level == 6 :
        jitter_lev = 0xe0
    elif level == 7 :
        jitter_lev = 0xf0
    else:
        self.log("Wrong jitter level")
        raise ValueError("Wrong jitter level")
    self.wrMask(0x0f, 0x88, jitter_lev, 0x8f)

    return 0

def eDPDisableJitterInjection(self):
    self.wrMask(0x0f, 0x88, 0x00, 0x7f)

    return 0

def eDPClearSymbolError(self):
    self.wr(0x03, 0x22, 0x00) # Enable and Clear symbol error counters
    self.wr(0x02, 0xf0, 0x04)
    self.wr(0x02, 0xf0, 0x06)
    self.wr(0x02, 0xf0, 0x07)

    return 0

def eDPCheckLinkStatus(self):
    dpcd00202h = self.rd(0x03, 0x32)
    dpcd00203h = self.rd(0x03, 0x33)
    dpcd00204h = self.rd(0x03, 0x34)

    lane0_symbol_locked = dpcd00202h & (1 << 2)
    lane1_symbol_locked = dpcd00202h & (1 << 6)
    lane2_symbol_locked = dpcd00203h & (1 << 2)
    lane3_symbol_locked = dpcd00203h & (1 << 6)

    interlane_align_done = dpcd00204h & 1

    self.log("DPCD 202h: " + hex(dpcd00202h))
    self.log("DPCD 203h: " + hex(dpcd00203h))
    self.log("DPCD 204h: " + hex(dpcd00204h))

    self.log("Lane 0 Locked: " + str(lane0_symbol_locked != 0))
    self.log("Lane 1 Locked: " + str(lane1_symbol_locked != 0))
    self.log("Lane 2 Locked: " + str(lane2_symbol_locked != 0))
    self.log("Lane 3 Locked: " + str(lane3_symbol_locked != 0))

    self.log("Interlane Aligned: " + str(interlane_align_done != 0))

def eDPCheckMSA(self):
    self.log("MISC Attributes: ")
    miscInfo = self.rd(0x00, 0x19)


    compFormatList = ["RGB", "YCbCr422", "YCbCr444"]
    bitDepthList = ["6 bits", "8 bits", "10 bits", "12 bits", "16 bits"]

    synchronousClock = miscInfo & 0x01
    self.log("Synchronous Clock: " + str(synchronousClock))
    componentFormat = (miscInfo & 0x06) >> 1
    self.log("Component Format: " + str(compFormatList[componentFormat]))
    dynamicRange = (miscInfo >> 3) & 1
    if dynamicRange:
        self.log("CEA range")
    else:
        self.log("VESA range")
    YCbCrColorimetry = (miscInfo >> 4) & 1
    if YCbCrColorimetry:
        self.log("ITU-R BT709")
    else:
        self.log("ITU-R BT601")
    bitDepth = (miscInfo >> 5) & 0x07
    self.log("Bit Depth per Component: " + str(bitDepthList[bitDepth]))
    self.log(" ")


    self.log("Software Set Attributes: ")
    HTotal0 = self.rd(0x00, 0x09)
    HTotal1 = self.rd(0x00, 0x0a)
    HTotal = HTotal0 + (HTotal1 << 8)

    HStart0 = self.rd(0x00, 0x0b)
    HStart1 = self.rd(0x00, 0x0c)
    HStart = HStart0 + (HStart1 << 8)

    HWidth0 = self.rd(0x00, 0x0d)
    HWidth1 = self.rd(0x00, 0x0e)
    HWidth = HWidth0 + (HWidth1 << 8)

    HBlank = HTotal - HWidth

    self.log("H Total: " + str(HTotal))
    self.log("H Start: " + str(HStart))
    self.log("H Width: " + str(HWidth))
    self.log("H Blank: " + str(HBlank))

    VTotal0 = self.rd(0x00, 0x0f)
    VTotal1 = self.rd(0x00, 0x10)
    VTotal = VTotal0 + (VTotal1 << 8)

    VStart0 = self.rd(0x00, 0x11)
    VStart1 = self.rd(0x00, 0x12)
    VStart = VStart0 + (VStart1 << 8)

    VHeight0 = self.rd(0x00, 0x13)
    VHeight1 = self.rd(0x00, 0x14)
    VHeight = VHeight0 + (VHeight1 << 8)

    VBlank = VTotal - VHeight

    self.log("V Total: " + str(VTotal))
    self.log("V Start: " + str(VStart))
    self.log("V Width: " + str(VHeight))
    self.log("V Blank: " + str(VBlank))
    self.log(" ")


    self.log("Received Attributes from Source: ")
    rxHTotal0 = self.rd(0x00, 0x1b)
    rxHTotal1 = self.rd(0x00, 0x1c)
    rxHTotal = rxHTotal0 + (rxHTotal1 << 8)

    rxHStart0 = self.rd(0x00, 0x1d)
    rxHStart1 = self.rd(0x00, 0x1e)
    rxHStart = rxHStart0 + (rxHStart1 << 8)

    rxHWidth0 = self.rd(0x00, 0x1f)
    rxHWidth1 = self.rd(0x00, 0x20)
    rxHWidth = rxHWidth0 + (rxHWidth1 << 8)

    rxHBlank = rxHTotal - rxHWidth

    self.log("H Total: " + str(rxHTotal))
    self.log("H Start: " + str(rxHStart))
    self.log("H Width: " + str(rxHWidth))
    self.log("H Blank: " + str(rxHBlank))

    rxVTotal0 = self.rd(0x00, 0x21)
    rxVTotal1 = self.rd(0x00, 0x22)
    rxVTotal = rxVTotal0 + (rxVTotal1 << 8)

    rxVStart0 = self.rd(0x00, 0x23)
    rxVStart1 = self.rd(0x00, 0x24)
    rxVStart = rxVStart0 + (rxVStart1 << 8)

    rxVHeight0 = self.rd(0x00, 0x25)
    rxVHeight1 = self.rd(0x00, 0x26)
    rxVHeight = rxVHeight0 + (rxVHeight1 << 8)

    rxVBlank = rxVTotal - rxVHeight

    self.log("V Total: " + str(rxVTotal))
    self.log("V Start: " + str(rxVStart))
    self.log("V Width: " + str(rxVHeight))
    self.log("V Blank: " + str(rxVBlank))

def eDPCheckALPDPStatus(self):
    dpcd00101h = self.rd(0x03, 0x21)
    lane_count_set = dpcd00101h & 0x1F
    self.log("DPCD 101h: " + hex(dpcd00101h))
    self.log("eDP Lane Count: " + str(lane_count_set))

    dpcd00451h = self.rd(0x03, 0x11)
    self.log("DPCD 451h: " + hex(dpcd00451h))

    if dpcd00451h & 1:
        self.log("ALP-DP Source Detected")
    else:
        self.log("Source is not ALP-DP")
        dpcd00100h = self.rd(0x03, 0x20)
        self.log("DPCD 100h: " + hex(dpcd00100h))
        if dpcd00100h == 0x06:
            self.log("DP link rate: 1.62Gbps/lane")
        elif dpcd00100h == 0x0A:
            self.log("DP link rate: 2.7Gbps/lane")
        elif dpcd00100h == 0x14:
            self.log("DP link rate: 5.4Gbps/lane")
        elif dpcd00100h == 0x1E:
            self.log("DP link rate: 8.1Gbps/lane")
        else:
            self.log("Not a recognized DP link rate")
