def checkMBC(self):
    DPCD00441h = self.rd(0x03, 0xf6)
    if DPCD00441h & 0x01:
        self.log("MBC is locked")
    else:
        self.log("MBC is not locked")


def enableBIST(self):
    pass
