#!/usr/bin/env python3
import time

import DP855
import display_cdicBert
import display_edp
import display_fcBist
import display_pdca

from shell import run

CDIC_SLEEP_DUR = 30
EDP_SLEEP_DUR = 30
RESET_AFTER_SHMOO = True

startTime = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
print("Display test start at: ", startTime)

# Detect panel
larkspur = DP855.autoDetect()

# Delete existing plist file
display_pdca.delete_plist_file()

# eDP Test Suite
larkspur.log("Start eDP symbol error test suite!")
# Show red image
larkspur.log("Display red image on panel!")
# Pick internal is required currently
run("display --pick internal")
run("pattern --pick internal")
run("pattern --rgb10 1023 0 0")

larkspur.log("eDP Symbol Error with RED image,POR!")
display_edp.eDP_RedImg_POR(larkspur, 400, reset = RESET_AFTER_SHMOO)
larkspur.reset()

larkspur.log("eDP Symbol Error with RED image, RX EQ Sweep!")
display_edp.eDP_RedImg_RxEqSweep(larkspur,[0, 1, 2, 3, 4, 5, 6, 7, 8, 9], EDP_SLEEP_DUR, reset = RESET_AFTER_SHMOO)
larkspur.reset()

larkspur.log("eDP Symbol Error with RED image, RX EQ Sweep, margin low Vcore!")
display_edp.eDP_RedImg_LowVcore_RxEqSweep(larkspur, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9], EDP_SLEEP_DUR, reset = RESET_AFTER_SHMOO)
larkspur.reset()

larkspur.log("eDP Symbol Error Rx, RED image, Eye Mon Shmoo Test!")
display_edp.eDP_RedImg_EyeMonShmoo(larkspur, [0, 1, 2, 3, 4, 5, 6, 7], EDP_SLEEP_DUR, reset = RESET_AFTER_SHMOO)
larkspur.reset()

larkspur.log("eDP Symbol Error Rx, RED image, Eye Mon Shmoo Test with margin low Vcore")
display_edp.eDP_RedImg_LowVcore_EyeMonShmoo(larkspur, [0, 1, 2, 3, 4, 5, 6, 7], EDP_SLEEP_DUR, reset = RESET_AFTER_SHMOO)
larkspur.reset()

larkspur.log("eDP Symbol Error Rx,RED image, Eye Mon Shmoo Test, EQ=0!")
display_edp.eDP_RedImg_RxEq01Sweep_EyeMonShmoo(larkspur, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9], [0, 1, 2, 3, 4, 5, 6, 7], EDP_SLEEP_DUR, reset = RESET_AFTER_SHMOO)
larkspur.reset()

# cdicBert Test Suite
larkspur.log("Start cdicBert test suite!")

larkspur.log("COG BERT with RED pattern at POR COG Freq!")
display_cdicBert.COG_Bert_RED_Pattern_POR(larkspur = larkspur, sleepDur = CDIC_SLEEP_DUR, reset = RESET_AFTER_SHMOO)
larkspur.reset()

larkspur.log("COG BERT with RED image at +15% COG Freq!")
display_cdicBert.COG_Bert_RED_Pattern_115POR(larkspur = larkspur, sleepDur = CDIC_SLEEP_DUR, reset = RESET_AFTER_SHMOO)
larkspur.reset()

larkspur.log("COG BERT Vcore and Jitter Schmoo (Corners)!")
display_cdicBert.Vcore_Jitter_Shmoo(larkspur = larkspur, vcore_range = [0.75, 1, 1.025, 1.05], jitter_div = [1, 2], jitter_range = [1, 2, 3, 4, 5, 6, 7], sleepDur = CDIC_SLEEP_DUR, reset = RESET_AFTER_SHMOO)
larkspur.reset()

larkspur.log("COG BERT Jitter and EQ Schmoo (Corners)!")
display_cdicBert.Jitter_EQ_Shmoo(larkspur = larkspur, jitter_div = [1, 2, 4], jitter_range = [1, 2, 3, 4, 5, 6, 7], eq_range = [], sleepDur = CDIC_SLEEP_DUR, reset = RESET_AFTER_SHMOO)
larkspur.reset()

larkspur.log("COG BER Test(Vcore Shmoo, RED pattern)!")
display_cdicBert.Vcore_Shmoo(larkspur = larkspur, vcore_range = [1, 1.075], sleepDur = CDIC_SLEEP_DUR, reset = RESET_AFTER_SHMOO)
larkspur.reset()

larkspur.log("COG BERT Current Shmoo Red Pattern!") # Separate Current and EQ. TODO: This currently has to be put last, because reset is not functional
# Need more points on bias_current_range
display_cdicBert.Current_Shmoo(larkspur, current_range = [0, 1, 2], bias_current_range = [28, 31, 34, 38, 41, 44, 47, 50, 53], sleepDur = CDIC_SLEEP_DUR, reset = RESET_AFTER_SHMOO)
larkspur.reset()

larkspur.log("Larkspur TCON BIST @HBR3!")
display_fcBist.fcBistHbr3(larkspur)

stopTime = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
print("Display test finish at: ", stopTime)

print("Generate plist file!")
display_pdca.generate_pdca_plist(startTime, stopTime)
