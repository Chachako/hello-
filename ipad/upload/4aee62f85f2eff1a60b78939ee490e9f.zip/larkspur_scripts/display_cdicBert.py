#!/usr/bin/env python3

import display_pdca

# COG BERT with RED pattern at POR COG Freq.
def COG_Bert_RED_Pattern_POR(larkspur, sleepDur = 30, reset = False):

    test_name = "COG_Bert_RED_Pattern_POR"
    subtest_name_arr = ""

    print("COG_Bert_RED_Pattern_POR testing...")
    larkspur.cdicSetFrequency(larkspur.cdicFreq)

    larkspur.log(test_name + ": " + subtest_name_arr)
    result = larkspur.cdicBert(sleepDur = sleepDur)

    display_pdca.add_single_test_result_to_pdca(test_name, subtest_name_arr, result, False)

    if reset:
        # reset only for failed tests, due reset potentially causing panic.
        if not all(value == 0 for value in result.values()):
            larkspur.reset()


# COG BERT with RED image at +15% COG Freq.
def COG_Bert_RED_Pattern_115POR(larkspur, sleepDur = 30, reset = False):

    test_name = "COG_Bert_RED_Pattern_115POR"
    subtest_name_arr = ""

    print("COG_Bert_RED_Pattern_115POR testing...")

    larkspur.cdicSetFrequency(int(larkspur.cdicFreq * 1.15))

    larkspur.log(test_name + ": " + subtest_name_arr)
    result = larkspur.cdicBert(sleepDur = sleepDur)

    display_pdca.add_single_test_result_to_pdca(test_name, subtest_name_arr, result, False)

    if reset:
        # reset only for failed tests, due reset potentially causing panic.
        if not all(value == 0 for value in result.values()):
            larkspur.reset()


# COG BERT  Vcore and Jitter Schmoo  (Corners)
def Vcore_Jitter_Shmoo(larkspur, vcore_range = None, jitter_div = None, jitter_range = None, sleepDur = 30, reset = False):

    test_name = "Vcore_Jitter_Shmoo"

    print("Vcore_Jitter_Shmoo testing...")

    for vcore in vcore_range:
        for div in jitter_div:
            for ampl in jitter_range:

                larkspur.pmic.setVcore(voltage = vcore)
                larkspur.cdicJitterInjection(enable = 1, div = div, ampl = ampl)

                subtest_name_arr = "vcore" + str(vcore) + "_" + "div" + str(div) + "_" + "ampl" + str(ampl)
                larkspur.log(test_name + ": " + subtest_name_arr)
                result = larkspur.cdicBert(sleepDur = sleepDur)

                display_pdca.add_single_test_result_to_pdca(test_name, subtest_name_arr, result, True)

                if reset:
                    # reset only for failed tests, due reset potentially causing panic.
                    if not all(value == 0 for value in result.values()):
                        larkspur.reset()


# COG BERT Jitter and EQ Schmoo (Corners)
def Jitter_EQ_Shmoo(larkspur, jitter_div = None, jitter_range = None, eq_range = None, sleepDur = 30, reset = False):

    test_name = "Jitter_EQ_Shmoo"

    print("Jitter_EQ_Shmoo testing...")

    for div in jitter_div:
        for ampl in jitter_range:
            if (larkspur.cdic == 'EPI'):
                band_range = range(0, 4, 1)
            elif (larkspur.cdic == 'eRVDS'):
                band_range = range(0, 8, 1)
            for band in band_range:

                larkspur.cdicSetEQ(0) # Set EQ OFF
                larkspur.cdicJitterInjection(enable = 1, div = div, ampl = ampl)
                larkspur.cdicSetEQ(band)

                subtest_name_arr = "div" + str(div) + "_" + "ampl" + str(ampl) + "_" + "band" + str(band)
                larkspur.log(test_name + ": " + subtest_name_arr)
                result = larkspur.cdicBert(sleepDur = sleepDur)

                print(subtest_name_arr)
                display_pdca.add_single_test_result_to_pdca(test_name, subtest_name_arr, result, True)

                if reset:
                    # reset only for failed tests, due reset potentially causing panic.
                    if not all(value == 0 for value in result.values()):
                        larkspur.reset()


# COG BER Test(Vcore Shmoo , RED pattern)
def Vcore_Shmoo(larkspur, vcore_range = None, sleepDur = 30, reset = False):

    test_name = "Vcore_Shmoo"

    print("Vcore_Shmoo testing...")

    for vcore in vcore_range:

        larkspur.wr(0x03, 0xf5, 0x0e) # Enable VBERT Pattern
        larkspur.pmic.setVcore(voltage = vcore)

        subtest_name_arr = "vcore" + str(vcore)
        larkspur.log(test_name + ": " + subtest_name_arr)
        result = larkspur.cdicBert(sleepDur = sleepDur)

        display_pdca.add_single_test_result_to_pdca(test_name, subtest_name_arr, result, True)

        if reset:
            # reset only for failed tests, due reset potentially causing panic.
            if not all(value == 0 for value in result.values()):
                larkspur.reset()


# COG BERT Current Shmoo Red Pattern
def Current_Shmoo(larkspur, current_range = None, bias_current_range = None, sleepDur = 30, reset = False):

    test_name = "Current_Shmoo"

    print("Current_Shmoo testing...")

    for current in current_range:
        for bias_current in bias_current_range:

            larkspur.wr(0x03, 0xf5, 0x0e) # Enable VBERT Pattern
            larkspur.cdicSetBiasCurrent(bias_current)
            larkspur.cdicSetCurrentDriver(current)

            subtest_name_arr = "current" + str(current) + "_" + "bias_current" + str(bias_current)
            larkspur.log(test_name + ": " + subtest_name_arr)
            result = larkspur.cdicBert(sleepDur = sleepDur)

            display_pdca.add_single_test_result_to_pdca(test_name, subtest_name_arr, result, True)

            if reset:
                # reset only for failed tests, due reset potentially causing panic.
                if not all(value == 0 for value in result.values()):
                    larkspur.reset()
