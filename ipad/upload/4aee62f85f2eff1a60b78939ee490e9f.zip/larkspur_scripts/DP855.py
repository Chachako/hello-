try:
    import _uefi
except ImportError:
    pass

import types
import time
import Lib

import _hwcidMapping
import _fwApi
import _miscFunc

# These contain methods used to communicate with slave devices to Larkspur
import _i2cMaster

# These contain the test item functions to be added to the DP855 class
import _cdicBert
import _edpSymbol
import _fcBistHbr3

def autoDetect(logFile = None):
    '''Detect which transport is available to talk to Larkspur. Prioritizing Diags'''
    #    for larkspur in [DP855_EFI_SPI(), DP855_EFI_I2C(), DP855_CHT(), DP855_AARD()]: # Running SPI version on I2C causes iEFI panic
    for larkspur in [DP855_EFI_I2C(), DP855_CHT(), DP855_AARD()]:
        try:
            if larkspur.DeviceType != None:
                # Setup logging
                larkspur.logFile = logFile

                larkspur.boardID = larkspur.rd(0x0f, 0xf8, 1) & 0xf
                if not larkspur.boardID == 0x04:
                    # Identify if the TCON has MCU
                    if larkspur.rd(0x10, 0xa4, 1) & 0x01 == 0x00:
                        larkspur.log("MCU Config Detected")
                        larkspur.mcu = True

                        larkspur.firmwareVersion = (larkspur.rd(0x04, 0x96) << 8) + larkspur.rd(0x04, 0x97)
                        larkspur.log("Firmware Version: " + hex(larkspur.firmwareVersion))
                    else:
                        larkspur.log("Non-MCU Config Detected")
                        larkspur.mcu = False

                # Detect the CDICs (Programmed in TCON config)
                if larkspur.rd(0x19, 0x1a, 1) & 0x01 == 0x00:
                    larkspur.log("EPI Panel Configuration")
                    larkspur.cdic = 'EPI'
                elif larkspur.rd(0x19, 0x1a, 1) & 0x01 == 0x01:
                    larkspur.log("eRVDS Panel Configuration")
                    larkspur.cdic = 'eRVDS'
                else:
                    larkspur.log("No Valid Panel")


                larkspur.HWCID = larkspur._getHWCID_()

                # Read the TCON bundle version
                larkspur.bundleVersion = (larkspur.rd(0x03, 0xca) << 8) + larkspur.rd(0x03, 0xcb)
                larkspur.log("Bundle Version: " + hex(larkspur.bundleVersion))

                larkspur._setupSlaves_(larkspur.boardID, larkspur.HWCID)


                return larkspur
        except AttributeError:
            pass
    return None

# List of methods added from other files
funcList = []

moduleList = [_cdicBert,
              _edpSymbol,
              _i2cMaster,
              _fwApi,
              _miscFunc]

for module in moduleList:
    for func_name in dir(module):
        func = getattr(module,func_name)
        if isinstance(func,types.FunctionType):
            funcList.append(func)

@Lib.addFunctionsAsMethods([
    _hwcidMapping._setupSlaves_,
    _fcBistHbr3.fcBIST,
] + funcList)

class DP855:
    LARKSPUR_ID = 0x0855 # Chip ID for Larkspur
    READ_START = 6       # Number of bytes MISO waits to respond after receiving MOSI commands
    SPI_MODE = 0
    CHANNEL = 4          # SPI Channel used in system

    # Used to acquire the lock for I2C and SPI master buses.
    SPI_LOCK = 0x0c
    I2C_LOCK = 0x0d
    AUX_LOCK = 0x0b

    # The data registers for MCU FW API. Refer to FW ERS
    MCU_DATA_REG = [[0x03, 0x70],
                    [0x03, 0x71],
                    [0x03, 0x72],
                    [0x03, 0x73],
                    [0x03, 0x74],
                    [0x03, 0x75],
                    [0x03, 0x76],
                    [0x03, 0x77],
                    [0x04, 0x88],
                    [0x04, 0x89],
                    [0x04, 0x8a],
                    [0x04, 0x8b],
                    [0x04, 0x8c],
                    [0x04, 0x8d],
                    [0x04, 0x8e],
                    [0x04, 0x8f]]

    def __init__(self):
        self.SPI_BAUDRATE = 5000000
        self.I2C_BAUDRATE = 400000

        self.i2c_device = None
        self.spi_device = None
        self.aux_device = None

        self.pmic = None
        self.cdic = None
        self.pls = None
        self.nvm = None
        self.mcu = None
        self.pgamma = None
        self.adc = None

        self.boardID = None
        self.HWCID = None

        self.bundleVersion = None
        self.firmwareVersion = None

        self.cdicFreq = None
        self.cdicCount = None
        self.edp = None
        self.refresh = None

        self.panel_vendor = None

        self.forceLock = 100 # Number of times to retry while waiting for the lock
        self.fwRetry = 10000 # Number of times to retry while waiting for FW API to respond

        self.logFile = None

    @staticmethod
    def sleep(seconds):
        time.sleep(seconds)

    def log(self, string = None):
        if self.logFile:
            self.logFile.write(str(string) + "\n")
        else:
            print (string)

    def swReset(self, disableNvmLoad = 0):
        '''soft reset Larkspur. With NVM load enabled (0), or disabled (1)'''
        self.wr(0x0e, 0xc4, disableNvmLoad)
        self.wr(0x0e, 0x44, 0x10)

    def reset(self):
        try:
            from shell import run
            run("display --off")
            run("display --on")
            run("pattern --rgb10 1023 0 0")
        except ImportError:
            self.wr(0x0e, 0x44, 0x10)
            self.log("Could not import shell from EFI, only sw reset was performed")
            return 0

    def _getHWCID_(self):
        '''Reads the HWCID from register'''
        if not self.mcu:
            self.log("Reading HWCID from GPIO")
            LSB = self.rd(0x12, 0x4c, 1)
            MSB = self.rd(0x12, 0x4d, 1)

            HWCID = (LSB & 0xc0) >> 6 | (MSB & 0x07) << 2

            HWCID_0 = (HWCID >> 1) & 0x01
            HWCID_1 = (HWCID >> 2) & 0x01
            HWCID_2 = (HWCID >> 4) & 0x01
            HWCID_3 = (HWCID >> 3) & 0x01
            HWCID_4 = HWCID & 0x01

            HWCID = (HWCID_4 << 4) | (HWCID_3 << 3) | (HWCID_2 << 2) | (HWCID_1 << 1) | (HWCID_0)

        else:
            self.log("Reading HWCID from MCU")
            HWCID = self.rd(0x03, 0xcc) & 0x7f

        return HWCID

    @property
    def DeviceType(self):
        if self.spi_device:
            return "SPI"
        elif self.i2c_device:
            return "I2C"
        elif self.aux_device:
            return "AUX"
        return None

    def _FindDP855_(self):
        reg_chip_id = self.rd(15, 0xfe, 2)
        if reg_chip_id == None or len(reg_chip_id) != 2:
            found = False
        else:
            chip_id = reg_chip_id[0] | (reg_chip_id[1] << 8)
            self.log(hex(chip_id))
            if chip_id != self.LARKSPUR_ID:
                found = False
            else: found = True

        return found


    def rd(self, page, offset, count = 1):
        # rd implemented in subclasses
        return 0

    def wr(self, page, offset, value):
        # wr implemented in subclasses
        return 0

    def wrMask(self, page, offset, value, mask):
        '''Write to register but keep masked bits intact. 0 to write bit, 1 to protect bit'''
        readValue = self.rd(page, offset, 1)
        maskedValue = ~mask & value
        readValue &= mask
        writeValue = maskedValue | readValue
        self.wr(page, offset, writeValue)

    def checkReg(self, page, offset, data, mask = 0xff):
        if self.DeviceType == None:
            return None
        else:
            val = self.rd(page, offset)
            if mask == 0 :  # just print data out no compare
                self.log('0x%02X.0x%03X= 0x%02X' %(page, offset, val))
                return val  # compatible with ReadReg
            else:
                val_compare = val & mask
                data_expected = data & mask
                if val_compare == data_expected:
                    self.log('@@@@ PASS @@@@  0x%02X.0x%02X= 0x%02X' %(page, offset, val))
                    return 0

                else:
                    self.log('#### FAIL ####  0x%02X.0x%02X= 0x%02X (!= 0x%02X expected)' %(page, offset, val, data_expected))
                    return 1



class DP855_CHT(DP855):
    def __init__(self):
        try:
            import cheetah_func as Cht
        except ImportError:
            return

        super().__init__()
        if not Cht.FindUSB():
            return
        else:
            self.spi_device = Cht.GetSPI()
            if self.spi_device == None:
                return
            else:
                self.log("\tTrying to check the slave SPI device")
                self.spi_device.configure_spi(BitRate = 5000)
                self.log("\tSPI data rate: %dkbps" % self.spi_device.spi_bitrate)

                super()._FindDP855_()

                return


    @staticmethod
    def sleep_ms(ms):
        time.sleep(ms/1000)

    def rd(self, page, offset, count = 1):
        if self.spi_device == None:
            return None
        else:
            data = self.spi_device.single_bit_io((0x20,page,offset), self.READ_START + count)
            if data != None:
                if len(data) >= self.READ_START + count:
                    if count == 1:
                        return data[self.READ_START]
                    else:
                        return data[self.READ_START:]


    def wr(self, page, offset, value):
        if self.spi_device == None:
            return None
        else:
            data = [0x10, page, offset]
            if isinstance(value, (list, tuple)):
                data += list(value)
            else:
                data.append(value)
            count = self.spi_device.single_bit_io(data)
            if 3 < count:
                return count - 3


class DP855_AARD(DP855):

    def __init__(self):
        try:
            import aardvark_func as Aard
        except ImportError:
            return

        super().__init__()
        if not Aard.FindUSB():
            return
        else:
            self.i2c_device = Aard.FindDUT()
            if not super()._FindDP855_():
                self.i2c_device = None
                self.spi_device = Aard.FindSPIDUT()
                if not super()._FindDP855_():
                    self.spi_device = None
                    return
                return
            else:
                self.log("\tI2C data rate: %dkbps" % self.i2c_device.bitrate)

                super()._FindDP855_()
                return


    @staticmethod
    def sleep_ms(ms):
        time.sleep(ms/1000)

    def rd(self, page, offset, count = 1):
        if self.i2c_device == None:
            if self.spi_device == None:
                return None
            else:
                data = self.spi_device.single_bit_io((0x20,page,offset), self.READ_START + count)
                if data != None:
                    if len(data) >= self.READ_START + count:
                        if count == 1:
                            return data[self.READ_START + 3]
                        else:
                            return data[self.READ_START + 3:]

        else:
            data = self.i2c_device.read_byte(page, offset, count)
            if data != None:
                if count == 1:
                    return data[0]
                else:
                    return data[1:]


    def wr(self, page, offset, value):
        if self.i2c_device == None:
            if self.spi_device == None:
                return None
            else:
                data = tuple()
                if isinstance(value, tuple):
                    pass
                elif isinstance(value, list):
                    for item in value:
                        data += (item,)
                else:
                    data += (value,)
                    self.spi_device.single_bit_io((0x10, page, offset) + data, 0)
                    return 0

        else:
            data = self.i2c_device.write_byte(page, offset, value)

        return 0


class DP855_EFI_SPI(DP855):
    def __init__(self):
        try:
            import test.spi as spi
        except ImportError:
            return

        self.interface = spi.SpiCommand()

        super().__init__()
        #Efi._ConfigureSpi(self.CHANNEL, self.SPI_MODE, self.SPI_BAUDRATE)
        if super()._FindDP855_() == True:
            self.spi_device = 1
        return

    @staticmethod
    def sleep_ms(ms):
        time.sleep_ms(ms)

    def rd(self, page, offset, count = 1):
        status = 0

        sendSize = count + 3 + self.READ_START
        SendBuf = []

        SendBuf.append(0x20)
        SendBuf.append(page)
        SendBuf.append(offset)
        for i in range(3, sendSize):
            SendBuf.append(0x00)

        RcvBuf = []

        #Efi._ToggleChipSelect(self.CHANNEL, True)
        #(status, RcvBuf) = Efi._SendData(SendBuf, RcvBuf, sendSize, self.CHANNEL)
        #Efi._ToggleChipSelect(self.CHANNEL, False)

        self.interface.Transfer(self.CHANNEL, sendSize, SendBuf)
        RcvBuf = self.interface.RcvBuf

        if count == 1:
            return RcvBuf[-count]
        else:
            return RcvBuf[-count:]

    def wr(self, page, offset, value):
        sendSize = 4

        if isinstance(value, (list, tuple)):
            sendSize = len(value) + 3

        status = 0 # Status is just a dummy now due to new upy library

        RcvBuf = []
        SendBuf = []

        SendBuf.append(0x10)
        SendBuf.append(page)
        SendBuf.append(offset)

        if isinstance(value, (list, tuple)): # Sending multiple bytes at a time
            for i in range(3, sendSize):
                SendBuf.append(value [i - 3])

        else: # Sending 1 byte at a time
            SendBuf.append(value)
            # Efi._ToggleChipSelect(self.CHANNEL, True)
            # (status, RcvBuf) = Efi._SendData(SendBuf, RcvBuf, sendSize, self.CHANNEL)
            # Efi._ToggleChipSelect(self.CHANNEL, False)

        self.interface.Transfer(self.CHANNEL, sendSize, SendBuf)

        return status

class DP855_EFI_I2C(DP855):
    def __init__(self):
        try:
            import test.i2c as i2c
        except ImportError:
            return

        self.interface = i2c.I2cCmd()

        super().__init__()
        if super()._FindDP855_() == True:
            self.i2c_device = 1
        return

    @staticmethod
    def sleep_ms(ms):
        time.sleep_ms(ms)

    def rd(self, page, offset, count = 1):
        status = 0

        # equivalent of page << 8 & offset, but that isn't working in iEFI
        register = page * 256 + offset

        RcvBuf = _uefi.mem(count)

        if count == 1:
            multiple = False
        else:
            multiple = True

        RcvBuf = self.interface.I2cDevRead(self.CHANNEL, 0x08, register, count, multiple, 2)

        if count == 1:
            return RcvBuf[-count]
        else:
            return RcvBuf[-count:]

    def wr(self, page, offset, value):
        if isinstance(value, (list, tuple)):
            toSend = value
            sendSize = len(value)
            multiple = True
        else:
            toSend = [value]
            sendSize = 1
            multiple = False

        status = 0 # Status is just a dummy now due to new upy library

        # equivalent of page << 8 & offset, but that isn't working in iEFI
        register = page * 256 + offset

        status = self.interface.I2cDevWrite(self.CHANNEL, 0x08, register, toSend, multiple, 2)

        return status
