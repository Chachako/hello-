Reach out to Anlang <anlang_lu@apple.com> if you would like to contribute to this repository

Removed older scripts including burn_spirom.py. If you are looking for older scripts, go to tag v1.0.0

#This script is designed to interface with the Larkspur TCON using 1 of the following devices:

##Already implemented:
1. Cheetah
2. EFI_SPI
3. EFI_I2C
4. Aardvark (Only supports I2C right now)

##Depending on need:
5. OS (tconctl)

##Depending on Anlang's bandwidth:
6. Raspberry PI


#Python Versions:

There are 2 versions of python this script should be able to run on:

1. Python 3 for lab use, and health scripts
2. micropython for EFI

Due to the limitations of micropython, please read the following requirements before commiting to this repository

1. Try to test run all your scripts using python 3 (while we do not have a tool to emulate micropython on our computers). Micropython is quite different from python 2.7
   1.1. Whenever print is used, you have to use print ("string to print"), instead of print "string to print"
   1.2. In current Diags environment, print to screen is really cluttered. In DP855 class, there is a log() method. This method will print the output to a log file, specified when constructing the class (easiest way is to use DP855.autoDetect(fileName)). If you think a message might be useful in a log file, use self.log("string to log") instead of the print() command.

2. Do not use time.sleep() for delay durations less than 1 second. In micropython, this should be sleep_ms(). I have included static methods in the DP855.py class to handle the different sleep commands.

3. Keep in mind, micropython does not support some libraries that is frequently used in past Display EE scripts. Such as ctypes, numpy, etc.


#Architecture:

1. DP855.py is the interface wrapper that supports different interfaces. DP855_XXX are subclasses of the DP855.py, that inherits methods from DP855 class. DP855 class will include 4 inner classes: pls, pmic, pgamma and adc. This is purely for organization purposes, since on the hardware, PGAMMA, ADC, PLS and PMIC are slaves to the TCON, in scripting, you would address them the same way. For example: larkspur.pmic.wr()

2. Any tests that will be extensively used should be a method of the DP855 class. All of DP855's subclasses (such as DP855_CHT) will inherite the methods from DP855 class. This will ensure the scripts run exactly the same way with any transports attached.

3. However, we will not be putting all of the methods inside of DP855.py. We do not want to end up with a 7000 line .py file that is impossible to navigate. Please see _cdic_Bert.py for an example of how to import methods from a different .py file into a class.

4. On the flip side, we do not want to end up with a directory with hundreds of .py files. So we should group test items into catagories. Such as PLS tests, PMIC tests, CDIC tests, etc. We will also be naming test items related files with a '_' prefix. This way it is easy to tell which files are test item libraries. For example: _cdicBert.py.

5. The test items discussed in (3) and (4) should be called from a separate file, such as a healthScript.py (you can use this as an example to develop your scripts), or a diagsP0.py, or something among these lines.

6. Any "private methods" should also be imported from another file, as to hide from the user that might just want to read DP855.py to understand what the script can do. See _i2cMaster.py for an example of this

7. Test items that are part of the DP855 class should have enough variables parametrized to be flexible enough to be used by both iPad and Mac platforms. For example, if your script would need to change a register number based on the VBLANK time, you should probably pass that as a parameter.

8. If you don't think your test is generic to everyone, don't write it as a method to the DP855 class. Instead write a script that instentiates the DP855 class.


#Style Conventions (We should have a serious discussion about this):

1. Please use 4 spaces for indentation. Change this setting in your text editor(All the BBEdit users, please change this setting).

2. If you make a test item python file, please follow this naming convension: _testName.py
   2.1 Since the '_' is used as indication that the file is a test item library, do not use any more '_' in the file name. AVOID: _test_name.py

3. Follow the PEP 8 style guide as much as possible, even tho I am not even following the style guide at this point (do as I say, not as I do). https://www.python.org/dev/peps/pep-0008/
