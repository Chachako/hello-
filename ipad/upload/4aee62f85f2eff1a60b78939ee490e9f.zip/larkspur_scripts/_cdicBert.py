def cdicBert(self, sleepDur = 30):
    result = {}

    #self.log("Panel = " + self.cdic)

    # 1) Enable CDI VBERT
    self.wr(0x03, 0xf5, 0x0e) # Enable VBERT Pattern

    # 2) Set CDI read back parameters
    if (self.refresh == 120): ## 120 Hz panels only use eRVDS so far
        self.wr(0x19, 0x68, 0xa3) ## RGREAD_BIT_T[7:0]
        self.wr(0x19, 0x69, 0x02) ##RGREAD_BIT_T[15:8]
        self.wr(0x19, 0x6a, 0x51) ##RGREAD_SAMPLE[7:0]
        self.wr(0x19, 0x6b, 0x01) ##RGREAD_SAMPLE[15:8]
    else:
        if (self.cdic == 'EPI'):
            #self.log("Configuring CDIC BERT FOR EPI")
            self.wr(0x19, 0x68, 0x70) ## RGREAD_BIT_T[7:0]
            self.wr(0x19, 0x69, 0x00) ## RGREAD_BIT_T[15:8]
            self.wr(0x19, 0x6a, 0x38) ## RGREAD_SAMPLE[7:0]
            self.wr(0x19, 0x6b, 0x00) ## RGREAD_SAMPLE[15:8]
        elif (self.cdic == 'eRVDS'):
            self.wr(0x19, 0x68, 0xe0) ## RGREAD_BIT_T[7:0]
            self.wr(0x19, 0x69, 0x00) ##RGREAD_BIT_T[15:8]
            self.wr(0x19, 0x6a, 0x70) ##RGREAD_SAMPLE[7:0]
            self.wr(0x19, 0x6b, 0x00) ##RGREAD_SAMPLE[15:8]

    # 3) Disable MBC monitoring
    self.wr(0x19, 0x6d, 0x45) ## Disable MBC monitoring

    # --) clear errors
    self.wr(0x1a, 0x0b, 0xe3)
    self.wr(0x1a, 0x0b, 0x03) # Clears error

    # Sleep
    self.sleep(sleepDur)

    # 4) Read back data
    addr = 0x00
    length = 0x02

    self.wr(0x03, 0x90, 0x00) ####[7:2]0x00,read;0x01,readandclear;0x02,write, [1:0] RBS_ADDR[9:8]
    self.wr(0x03, 0x91, addr) ###[7:0] RBS_ADDR[7:0]
    self.wr(0x03, 0x92, length) ####[7:0] RBS_LEN

    for i in range(0, self.cdicCount):
        cdicNameString = 'cdic' + str(i)
        self.wr(0x03, 0x93, 0x80 + i) ####[7] command valid [6] RBS data valid [3:0] CD_SEL
        self.sleep_ms(100)
        regValue = self.rd(0x03, 0x93)

        if ((self.rd(0x03, 0x93) & 0x40) == 0x40):
            lsb = self.rd(0x03, 0x98) # LSB
            msb = self.rd(0x03, 0x99) # MSB

            result.update({cdicNameString : msb << 8 | lsb})
        else :
            result.update({cdicNameString : -1})
            self.log("RBS data is not valid")

    self.wr(0x03, 0xf5,0x00) # Disable VBERT Pattern

    self.log(result)

    return result


def cdicSetFrequency(self, Frequency) :
    '''Frequency: 442,450,475,500,525,550,575,600,625,650MHz'''
    self.wr(0x03, 0x61, 0x00) # Disable CDI Agile clocking
    self.wr(0x05, 0xb3, 0x04)
    self.wr(0x0e, 0x3a, 0xb0)
    self.wr(0x0e, 0x40, 0x02)
    N = (float(Frequency) * 2) / 27 * 1024
    N_div = int(N)

    CDPLL_DIV_N_7_0 = N_div & 0xFF
    CDPLL_DIV_N_15_8 = (N_div & 0x0ff00) >> 8
    CDPLL_DIV_N_17_16 = (N_div & 0x030000) >> 16
    CDPLL_DIV_TAG_N = ((CDPLL_DIV_N_17_16 & 0x0f) << 4) | ((CDPLL_DIV_N_17_16) & 0x0f)

    Mask1 = self.rd(0x0e, 0x67, 1) & 0xfc

    self.wr(0x0e, 0x48, CDPLL_DIV_N_7_0) # Cal0
    self.wr(0x0e, 0x49, CDPLL_DIV_N_15_8)
    self.wr(0x0e, 0x58, CDPLL_DIV_TAG_N)
    self.wr(0x0e, 0x65, CDPLL_DIV_N_7_0) # CDI PLL DIV
    self.wr(0x0e, 0x66, CDPLL_DIV_N_15_8)
    self.wr(0x0e, 0x67, Mask1 | CDPLL_DIV_N_17_16 | 0x80)
    self.wr(0x0f, 0x1a, 0x10) # CDIPLL cal enable
    self.wr(0x0f, 0x1b, 0x40)
    self.wr(0x0e, 0x40, 0x1b) # SW CDIPLL start
    self.sleep_ms(100)
    self.wr(0x0e, 0x40, 0x1f)

    return 0

def cdicJitterInjection(self, enable = 0, div = 1, ampl = 1):
    status = self._cdicSetJitterFrequencyDiv_(div) | self._cdicSetJitterAmplitude_(ampl) | self._cdicEnableJitterInjection_(enable)

    self.log("CDIC Jitter Injection Register: " + hex(self.rd(0x0f, 0x16)))

    return status

def _cdicSetJitterFrequencyDiv_(self, div):
    '''div: 1,2,3 (Cannot use 3)'''
    self.wrMask(0x0f, 0x16, div << 4, 0x8f)

    return 0

def _cdicSetJitterAmplitude_(self, ampl):
    '''ampl : 1,2,3,4,5,6,7'''
    self.wrMask(0x0f, 0x16, ampl, 0xf8)

    return 0

def _cdicEnableJitterInjection_(self, enable):
    '''enable : 1: enable; 0: disable'''
    self.wrMask(0x0f, 0x16, enable << 3, 0xf7)

    return 0

def cdicSetEQ(self, band):
    '''
    EPI: band 0 (EQ off), 1 (Low Boost); 2 (Mid Boost); 3 (High Boost)
    eRVDS: band 0 (EQ off), 1 (-1dB); 2 (-2dB); 3 (-3dB); 4 (-4dB); 5 (-5dB); 6 (-6dB); 7 (-7dB)
    '''
    if (self.cdic == 'EPI'):
        if band == 0 :
            p1 = (self.rd(0x1a, 0x0a, 1) & 0x0f) | ((0x00 & 0x07) << 4) | ((0x00 & 0x01) << 7)
            p2 = (self.rd(0x1a, 0x0b, 1) & 0xfc) | (0x00 & 0x03)
            self.wr(0x1a, 0x0a, p1)
            self.wr(0x1a, 0x0b, p2)
        elif band == 1 :
            p1 = (self.rd(0x1a, 0x0a, 1) & 0x0f) | ((0x00 & 0x07) << 4) | ((0x01 & 0x01) << 7)
            p2 = (self.rd(0x1a, 0x0b, 1) & 0xfc) | (0x03 & 0x03)
            self.wr(0x1a, 0x0a, p1)
            self.wr(0x1a, 0x0b, p2)
        elif band == 2 :
            p1 = (self.rd(0x1a, 0x0a, 1) & 0x0f) | ((0x07 & 0x07) << 4) | ((0x00 & 0x01) << 7)
            p2 = (self.rd(0x1a, 0x0b, 1) & 0xfc) | (0x00 & 0x03)
            self.wr(0x1a, 0x0a, p1)
            self.wr(0x1a, 0x0b, p2)
        elif band == 3 :
            p1 = (self.rd(0x1a, 0x0a, 1) & 0x0f) | ((0x07 & 0x07) << 4) | ((0x01 & 0x01) << 7)
            p2 = (self.rd(0x1a, 0x0b, 1) & 0xfc) | (0x03 & 0x03)
            self.wr(0x1a, 0x0a, p1)
            self.wr(0x1a, 0x0b, p2)
        else:
            raise ValueError("invalid EQ band for EPI")

        return 0

    elif (self.cdic == 'eRVDS'):
        if band == 0 :
            p1 = (self.rd(0x1a, 0x01, 1) & 0xfc) | ((0x00 & 0x03))
            self.wr(0x1a, 0x01, p1)
            p2 = (self.rd(0x1a, 0x02, 1) & 0x03) | ((0x00 & 0x01) << 7) | ((0x00 & 0x07) << 2) | ((0x00 & 0x03) << 5)
            self.wr(0x1a, 0x0a, p2)
        elif band == 1 :
            p1 = (self.rd(0x1a, 0x01, 1) & 0xfc) | ((0x03 & 0x03))
            self.wr(0x1a, 0x01, p1)
            p2 = (self.rd(0x1a, 0x02, 1) & 0x03) | ((0x01 & 0x01) << 7) | ((0x00 & 0x07) << 2) | ((0x00 & 0x03) << 5)
            self.wr(0x1a, 0x0a, p2)

        elif band == 2 :
            p1 = (self.rd(0x1a, 0x01, 1) & 0xfc) | ((0x00 & 0x03))
            self.wr(0x1a, 0x01, p1)
            p2 = (self.rd(0x1a, 0x02, 1) & 0x03) | ((0x00 & 0x01) << 7) | ((0x07 & 0x07) << 2) | ((0x00 & 0x03) << 5)
            self.wr(0x1a, 0x0a, p2)

        elif band == 3 :
            p1 = (self.rd(0x1a, 0x01, 1) & 0xfc) | ((0x03 & 0x03))
            self.wr(0x1a, 0x01, p1)
            p2 = (self.rd(0x1a, 0x02, 1) & 0x03) | ((0x01 & 0x01) << 7) | ((0x07 & 0x07) << 2) | ((0x00 & 0x03) << 5)
            self.wr(0x1a, 0x0a, p2)

        elif band == 4 :
            p1 = (self.rd(0x1a, 0x01, 1) & 0xfc) | ((0x00 & 0x03))
            self.wr(0x1a, 0x01, p1)
            p2 = (self.rd(0x1a, 0x02, 1) & 0x03) | ((0x00 & 0x01) << 7) | ((0x00 & 0x07) << 2) | ((0x07 & 0x03) << 5)
            self.wr(0x1a, 0x0a, p2)

        elif band == 5 :
            p1 = (self.rd(0x1a, 0x01, 1) & 0xfc) | ((0x03 & 0x03))
            self.wr(0x1a, 0x01, p1)
            p2 = (self.rd(0x1a, 0x02, 1) & 0x03) | ((0x01 & 0x01) << 7) | ((0x00 & 0x07) << 2) | ((0x07 & 0x03) << 5)
            self.wr(0x1a, 0x0a, p2)


        elif band == 6 :
            p1 = (self.rd(0x1a, 0x01, 1) & 0xfc) | ((0x00 & 0x03))
            self.wr(0x1a, 0x01, p1)
            p2 = (self.rd(0x1a, 0x02, 1) & 0x03) | ((0x00 & 0x01) << 7) | ((0x07 & 0x07) << 2) | ((0x07 & 0x03) << 5)
            self.wr(0x1a, 0x0a, p2)

        elif band == 7 :
            p1 = (self.rd(0x1a, 0x01, 1) & 0xfc) | ((0x03 & 0x03))
            self.wr(0x1a, 0x01, p1)
            p2 = (self.rd(0x1a, 0x02, 1) & 0x03) | ((0x01 & 0x01) << 7) | ((0x00 & 0x07) << 2) | ((0x07 & 0x03) << 5)
            self.wr(0x1a, 0x0a, p2)
        else :
            raise ValueError("invalid EQ band for eRVDS")

        return 0
    else:
        self.log("unknown CDIC type")
        raise ValueError("unknown CDIC type")

def cdicSetCurrentDriver(self, current_driver):
    '''
    current_driver:
    3 : 5.2mA,
    2 : 3.9mA,
    1 : 2.6mA,
    0 : 1.3mA
    '''
    self.wrMask(0x0f, 0x00, current_driver << 5, 0x9f)

    self.log ("Set Current Driver: " + hex(self.rd(0x0f, 0x00)))

    return 0

def cdicSetBiasCurrent(self, bias_current):
    ''''bias_current 53, 50, 47, 44, 41, 38, 34, 31, 28'''
    if bias_current == 50:
        currentReg = 0x00

    elif bias_current == 47:
        currentReg = 0x11

    elif bias_current == 44:
        currentReg = 0x22

    elif bias_current == 41:
        currentReg = 0x33

    elif bias_current == 38:
        currentReg = 0x44

    elif bias_current == 34:
        currentReg = 0x55

    elif bias_current == 31:
        currentReg = 0x66

    elif bias_current == 28:
        currentReg = 0x77

    elif bias_current == 53:
        currentReg = 0xff

    else :
        raise ValueError("Not acceptable bias current value")

    self.wr(0x0f, 0x02, currentReg)
    self.wr(0x0f, 0x03, currentReg)
    self.wr(0x0f, 0x04, currentReg)
    self.wr(0x0f, 0x05, currentReg)

    self.log ("Set Bias Current")
    self.log (hex(self.rd(0x0f, 0x02)))
    self.log (hex(self.rd(0x0f, 0x03)))
    self.log (hex(self.rd(0x0f, 0x04)))
    self.log (hex(self.rd(0x0f, 0x05)))

    return 0
