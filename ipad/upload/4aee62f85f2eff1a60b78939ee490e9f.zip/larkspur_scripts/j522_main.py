#!/usr/bin/env python3
import time

import DP855
import display_cdicBert
import display_edp
import display_fcBist
import display_pdca

from shell import run

CDIC_SLEEP_DUR = 1
EDP_SLEEP_DUR = 1
RESET_AFTER_SHMOO = True

startTime = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
print("Display test start at: ", startTime)

# Detect panel
larkspur = DP855.autoDetect()

# Delete existing plist file
display_pdca.delete_plist_file()

# eDP Test Suite
print("Start eDP symbol error test suite!")
# Show red image
print("Display red image on panel!")
run("display --pick internal")
run("pattern --pick internal")
run("pattern --rgb10 1023 0 0")

print("eDP Symbol Error with RED image,POR!")
display_edp.eDP_RedImg_POR(larkspur, EDP_SLEEP_DUR, reset = RESET_AFTER_SHMOO)
larkspur.reset()

print("eDP Symbol Error with RED image, RX EQ Sweep!")
display_edp.eDP_RedImg_RxEqSweep(larkspur,[0, 1, 2, 3, 4, 5, 6, 7, 8, 9], EDP_SLEEP_DUR, reset = RESET_AFTER_SHMOO)
larkspur.reset()

print("eDP Symbol Error with RED image, RX EQ Sweep, margin low Vcore!")
display_edp.eDP_RedImg_LowVcore_RxEqSweep(larkspur, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9], EDP_SLEEP_DUR, reset = RESET_AFTER_SHMOO)
larkspur.reset()

print("eDP Symbol Error Rx, RED image, Eye Mon Shmoo Test!")
display_edp.eDP_RedImg_EyeMonShmoo(larkspur, [0, 1, 2, 3, 4, 5, 6, 7], EDP_SLEEP_DUR, reset = RESET_AFTER_SHMOO)
larkspur.reset()

print("eDP Symbol Error Rx, RED image, Eye Mon Shmoo Test with margin low Vcore")
display_edp.eDP_RedImg_LowVcore_EyeMonShmoo(larkspur, [0, 1, 2, 3, 4, 5, 6, 7], EDP_SLEEP_DUR, reset = RESET_AFTER_SHMOO)
larkspur.reset()

print("eDP Symbol Error Rx,RED image, Eye Mon Shmoo Test, EQ=0!")
display_edp.eDP_RedImg_RxEq01Sweep_EyeMonShmoo(larkspur, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9], [0, 1, 2, 3, 4, 5, 6, 7], EDP_SLEEP_DUR, reset = RESET_AFTER_SHMOO)
larkspur.reset()

# cdicBert Test Suite
print("Start cdicBert test suite!")

print("COG BERT with RED pattern at POR COG Freq!")
display_cdicBert.COG_Bert_RED_Pattern_POR(larkspur = larkspur, sleepDur = CDIC_SLEEP_DUR, reset = RESET_AFTER_SHMOO)
larkspur.reset()

print("COG BERT with RED image at +15% COG Freq!")
display_cdicBert.COG_Bert_RED_Pattern_115POR(larkspur = larkspur, sleepDur = CDIC_SLEEP_DUR, reset = RESET_AFTER_SHMOO)
larkspur.reset()

print("COG BERT Vcore and Jitter Schmoo (Corners)!")
display_cdicBert.Vcore_Jitter_Shmoo(larkspur = larkspur, vcore_range = [0.75, 1, 1.025, 1.05], jitter_div = [1, 2], jitter_range = [1, 2, 3, 4, 5, 6, 7], sleepDur = CDIC_SLEEP_DUR, reset = RESET_AFTER_SHMOO)
larkspur.reset()

print("COG BERT Jitter and EQ Schmoo (Corners)!")
display_cdicBert.Jitter_EQ_Shmoo(larkspur = larkspur, jitter_div = [1, 2, 4], jitter_range = [1, 2, 3, 4, 5, 6, 7], eq_range = [], sleepDur = CDIC_SLEEP_DUR, reset = RESET_AFTER_SHMOO)
larkspur.reset()

print("COG BER Test(Vcore Shmoo, RED pattern)!")
display_cdicBert.Vcore_Shmoo(larkspur = larkspur, vcore_range = [1, 1.075], sleepDur = CDIC_SLEEP_DUR, reset = RESET_AFTER_SHMOO)
larkspur.reset()

print("COG BERT Current Shmoo Red Pattern!") # Separate Current and EQ
display_cdicBert.Current_Shmoo(larkspur, current_range = [0, 1, 2], bias_current_range = [50, 47, 44, 41, 38, 34, 31, 28], sleepDur = CDIC_SLEEP_DUR, reset = RESET_AFTER_SHMOO)
larkspur.reset()

larkspur.log("Larkspur TCON BIST @HBR3!")
display_fcBist.fcBistHbr3(larkspur)

stopTime = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
print("Display test finish at: ", stopTime)

print("Generate plist file!")
display_pdca.generate_pdca_plist(startTime, stopTime)
