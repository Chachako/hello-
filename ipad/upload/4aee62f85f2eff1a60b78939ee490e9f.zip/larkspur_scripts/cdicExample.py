import DP855

larkspur = DP855.autoDetect()


def cdicTests():
    print ("Setting VCORE")
    larkspur.pmic.setVcore(voltage = 0.9)
    larkspur.wr(0x05, 0x73, 2)   # Display Red Pattern
    larkspur.sleep(1)
    larkspur.wr(0x3, 0xf5, 0x0e) # Visual BERT Pattern


    print ("Setting Frequency")
    larkspur.setFrequency(442)

    print ("Jitter Injection")
    larkspur.cdicJitterInjection(enable = 1, div = 1, ampl = 1)

    print ("Setting EQ")
    larkspur.cdicSetEQ(3)

    print ("Setting current driver")
    larkspur.cdicSetCurrentDriver(0)

    print ("Setting bias current")
    larkspur.cdicSetBiasCurrent(28)


    print ("CDIC BERT")
    larkspur.cdicBert(sleepDur = 1)


def POR_CDIC_BERT():
    # Turn on Display to make sure this is default setting
    # COG BERT
    result = larkspur.cdicBert(sleepDur = 1)
    print (result)
    return result

def Vcore_Jitter_Shmoo(vcore_range = None, jitter_div = None, jitter_range = None):
    '''This is an example Shmoo test'''
    for vcore in vcore_range:
        for div in jitter_div:
            for ampl in jitter_range:
                print ("doing 1 of the tests")
                larkspur.pmic.setVcore(voltage = vcore)
                larkspur.cdicJitterInjection(enable = 1, div = div, ampl = ampl)

                larkspur.cdicBert(sleepDur = 1)


# print (larkspur.rd(0x05, 0x73, 1))

# larkspur.wr(0x05, 0x73, 0xFF)

# print (larkspur.rd(0x05, 0x73, 1))
larkspur.cdicJitterInjection(0, 2, 5)
#larkspur.cdicSetCurrentDriver(0)
#larkspur.cdicSetBiasCurrent(28)

#larkspur.cdicSetFrequency(442)
#larkspur.cdicSetFrequency(1280)
larkspur.cdicBert(10)

# print ("setting frequency to 2000")
# larkspur.cdicSetFrequency(2000)

# larkspur.cdicBert(1)
#print ("setting frequency to 442")
#larkspur.cdicSetFrequency(442)
#larkspur.cdicBert(10)

#larkspur.fcBIST()
#cdicTests()
#POR_CDIC_BERT()
#Vcore_Jitter_Shmoo([1, 1.05], [1, 2], [1, 2, 3, 4, 5, 6, 7])

# Jitter, ampl, curr, freq.
