#!/usr/bin/env python3
import time

import DP855
import display_cdicBert
import display_edp
import display_pdca


CDIC_SLEEP_DUR = 30
EDP_SLEEP_DUR = 30
COLOR_TEST_SLEEP_DUR = 5
POWER_TEST_SLEEP_DUR = 2
RESET_AFTER_SHMOO = True


# Use these options to enable/disable some tests
ENABLE_FOS_TESTS = True
ENABLE_POWER_MEASUREMENT = True
ENABLE_EDP_TESTS = True
ENABLE_COG_BERT_TESTS = True

resource_path = "nandfs:/AppleInternal/Diags/Logs/Smokey/DisplayTest/J456/resources_J456/"

# Log start time of the tests
startTime = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
print("Display test start at: ", startTime)



# Detect panel
larkspur = DP855.autoDetect()
print('Detected Larkspur = ', larkspur)

# Delete existing plist file
display_pdca.delete_plist_file()
print('Deleted existing plist file')

# START DIAGS ===========================================
print("")
print("====================")
print("====== DIAGS =======")
print("====================")
print("")



print("1) EDID Binary Test:")
# Read EDID from the reference file for exact match
fileEDID = open(resource_path + "X1521_EDID_LGD_V02.txt", "r")
valueEDID_REF = []
for rowEDID in fileEDID:
    colEDID = rowEDID.split()
    for charEDID in colEDID:
        valueEDID_REF.append(int(charEDID, 16))
fileEDID.close()
# Read NVM for EDID
valueEDID_NVM=larkspur.fwApiReadNVMPage(0x6100);
result = {}
test_name = "EDID Verification"
subtest_name = ""
if (valueEDID_REF == valueEDID_NVM):
    print(">>> EDID values match")
else:
    print("========")
    print("$$$$ EDID values DON'T MATCH")
    print("========")
    print("Expected EDID value:")
    print(valueEDID_REF)
    print("NVM EDID value:")
    print(valueEDID_NVM)
result.update({"EDID_Value" : valueEDID_NVM})
display_pdca.add_single_test_result_to_pdca(test_name, subtest_name, result, valueEDID_REF == valueEDID_NVM)
print(result)
print("========")


print("20) Read Serial Number")
test_name = "Serial Number"
subtest_name = ""
result = {}
TCON_serial_no = [0x00 for i in range(96)]
serialNo_page = larkspur.fwApiReadNVMPage(0x2000)
for i in range(96):
    TCON_serial_no[i] = serialNo_page[i]
result.update({"96_byte" : TCON_serial_no})
display_pdca.add_single_test_result_to_pdca(test_name, subtest_name, result, True)
print(result)
print("========")


if(ENABLE_FOS_TESTS):
    print("2) Solid Image - White 255")
    larkspur.wr(0x03, 0x2a, 0x01) # Stop rolling BIST
    larkspur.wr(0x05, 0x73, 0x00) # Code for white
    print(">>>> Displaying white image for >5 seconds")
    larkspur.sleep(COLOR_TEST_SLEEP_DUR)
    print("========")

    print("3) Solid Image - Black 255")
    larkspur.wr(0x03, 0x2a, 0x01) # Stop rolling BIST
    larkspur.wr(0x05, 0x73, 0x01) # Code for Black
    print(">>>> Displaying black image for >5 seconds")
    larkspur.sleep(COLOR_TEST_SLEEP_DUR)
    print("========")

    print("4) Solid Image - Red 255")
    larkspur.wr(0x03, 0x2a, 0x01) # Stop rolling BIST
    larkspur.wr(0x05, 0x73, 0x02) # Code for Red
    print(">>>> Displaying red image for >5 seconds")
    larkspur.sleep(COLOR_TEST_SLEEP_DUR)
    print("========")

    print("5) Solid Image - Green 255")
    larkspur.wr(0x03, 0x2a, 0x01) # Stop rolling BIST
    larkspur.wr(0x05, 0x73, 0x03) # Code for Green
    print(">>>> Displaying green image for >5 seconds")
    larkspur.sleep(COLOR_TEST_SLEEP_DUR)
    print("========")

    print("6) Solid Image - Blue 255")
    larkspur.wr(0x03, 0x2a, 0x01) # Stop rolling BIST
    larkspur.wr(0x05, 0x73, 0x04) # Code for Blue
    print(">>>> Displaying blue image for >5 seconds")
    larkspur.sleep(COLOR_TEST_SLEEP_DUR)
    print("========")

    print("7) Vertical Ramp RGBW")
    larkspur.wr(0x03, 0x2a, 0x01) # Stop rolling BIST
    larkspur.wr(0x05, 0x73, 0x0B) # Code for RGBW
    print(">>>> Vertical ramp RGBW for >5 seconds")
    larkspur.sleep(COLOR_TEST_SLEEP_DUR)
    print("========")

    print("8) Solid Image - Gray63")
    larkspur.wr(0x03, 0x2a, 0x01) # Stop rolling BIST
    larkspur.wr(0x05, 0x73, 0x10)
    larkspur.wr(0x05, 0x0c, 0xfc)
    larkspur.wr(0x05, 0x0d, 0xf0)
    larkspur.wr(0x05, 0x0e, 0xc3)
    larkspur.wr(0x05, 0x0f, 0x0f)
    print(">>>> Displaying Gray63 for >5 seconds")
    larkspur.sleep(COLOR_TEST_SLEEP_DUR)
    print("========")

    print("9) Solid Image - Gray128")
    larkspur.wr(0x03, 0x2a, 0x01) # Stop rolling BIST
    larkspur.wr(0x05, 0x73, 0x10)
    larkspur.wr(0x05, 0x0c, 0x00)
    larkspur.wr(0x05, 0x0d, 0x02)
    larkspur.wr(0x05, 0x0e, 0x08)
    larkspur.wr(0x05, 0x0f, 0x20)
    print(">>>> Displaying Gray128 for >5 seconds")
    larkspur.sleep(COLOR_TEST_SLEEP_DUR)
    print("========")


if(ENABLE_POWER_MEASUREMENT):
    print("25-26) Power Measurement Dump")
    # Set White
    larkspur.wr(0x03, 0x2a, 0x01) # Stop rolling BIST
    larkspur.wr(0x05, 0x73, 0x00) # Code for White
    larkspur.sleep(POWER_TEST_SLEEP_DUR)
    print("White: ")
    print(larkspur.adc.PowerMeasurementOnce(4, "WHITE"))

    # Set Black
    larkspur.wr(0x03, 0x2a, 0x01) # Stop rolling BIST
    larkspur.wr(0x05, 0x73, 0x01) # Code for Black
    larkspur.sleep(POWER_TEST_SLEEP_DUR)
    print("Black: ")
    print(larkspur.adc.PowerMeasurementOnce(4, "BLACK"))

    # Set 2DOT_H_STRIPE (Worst Case VCOM) -- Virus patter for V2D
    larkspur.wr(0x03, 0x2a, 0x01) # Stop rolling BIST
    larkspur.wr(0x05, 0x73, 0x26) # Code for 2DOT_H_STRIPE
    larkspur.sleep(POWER_TEST_SLEEP_DUR)
    print("2DOT_H_STRIPE: ")
    print(larkspur.adc.PowerMeasurementOnce(4, "2DOT_H_STRIPE"))

    # Set SVS
    larkspur.wr(0x03, 0x2a, 0x01) # Stop rolling BIST
    larkspur.wr(0x05, 0x73, 0x0F) # Code for SVS
    larkspur.sleep(POWER_TEST_SLEEP_DUR)
    print("SVS: ")
    print(larkspur.adc.PowerMeasurementOnce(4, "SVS"))

    # Set H_1ON_1OFF -- Virus patter for V2D
    larkspur.wr(0x03, 0x2a, 0x01) # Stop rolling BIST
    larkspur.wr(0x05, 0x73, 0x11) # Code for H_1ON_1OFF
    larkspur.sleep(POWER_TEST_SLEEP_DUR)
    print("H_1ON_1OFF: ")
    print(larkspur.adc.PowerMeasurementOnce(4, "H_1ON_1OFF"))

    # Set V_1ON_1OFF -- Virus patter for V2D
    larkspur.wr(0x03, 0x2a, 0x01) # Stop rolling BIST
    larkspur.wr(0x05, 0x73, 0x12) # Code for V_1ON_1OFF
    larkspur.sleep(POWER_TEST_SLEEP_DUR)
    print("V_1ON_1OFF: ")
    print(larkspur.adc.PowerMeasurementOnce(4, "V_1ON_1OFF"))

    print(">>>> Done: Power measurement with different patterns")
    print("========")


if(ENABLE_EDP_TESTS):
    # eDP Test Suite
    print("Start eDP symbol error test suite!")
    # Show red image
    print("Display red image on panel!")
    larkspur.wr(0x03, 0x2a, 0x01) # Stop rolling BIST
    larkspur.wr(0x05, 0x73, 0x02) # Code for Red

    print("10-11) eDP Symbol Error with RED image,POR!")
    display_edp.eDP_RedImg_POR(larkspur, EDP_SLEEP_DUR, reset = RESET_AFTER_SHMOO)

    # TB fixed
    print("22) eDP Symbol Error with RED image, RX EQ Sweep!")
    display_edp.eDP_RedImg_RxEqSweep(larkspur,[0, 1, 2, 3, 4, 5, 6, 7, 8, 9], EDP_SLEEP_DUR, reset = RESET_AFTER_SHMOO)

    print("23) eDP Symbol Error Rx, RED image, Eye Mon Shmoo Test!")
    display_edp.eDP_RedImg_EyeMonShmoo(larkspur, [0, 1, 2, 3, 4, 5, 6, 7], EDP_SLEEP_DUR, reset = RESET_AFTER_SHMOO)

    # TB fixed
    print("24) eDP Symbol Error Rx,RED image, Eye Mon Shmoo Test, EQ=0!")
    display_edp.eDP_RedImg_RxEq01Sweep_EyeMonShmoo(larkspur, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9], [0, 1, 2, 3, 4, 5, 6, 7], EDP_SLEEP_DUR, reset = RESET_AFTER_SHMOO)




print("12a) TCON Bundle version Test")
# Read the reference minimum bundle version
fileEDID = open(resource_path + "Minimum_Bundle_Version.txt", "r")
valueBundle_ref_txt = []
for rowEDID in fileEDID:
    colEDID = rowEDID.split()
    for charEDID in colEDID:
        valueBundle_ref_txt.append(int(charEDID, 16))
fileEDID.close()
valueBundle_ref = (valueBundle_ref_txt[0]<<8)|(valueBundle_ref_txt[1]) # List to decimal
if (larkspur.bundleVersion >= valueBundle_ref):
    print(">>> Bundle version above the required min.")
else:
    print("$$$$ Error: Bundle Version is obsolete")
result = {}
test_name = "TCON Bundle Version"
subtest_name = ""
result.update({"TCON_Bundle" : larkspur.bundleVersion})
display_pdca.add_single_test_result_to_pdca(test_name, subtest_name, result, larkspur.bundleVersion >= valueBundle_ref)
print(result)
print("========")


print("12b) TCON FW version Test")
# Read the reference minimum bundle version
fileEDID = open(resource_path + "Minimum_Firmware_Version.txt", "r")
valueFW_ref_txt = []
for rowEDID in fileEDID:
    colEDID = rowEDID.split()
    for charEDID in colEDID:
        valueFW_ref_txt.append(int(charEDID, 16))
fileEDID.close()
valueFW_ref = (valueFW_ref_txt[0]<<8)|(valueFW_ref_txt[1]) # List to decimal
if (larkspur.firmwareVersion >= valueFW_ref):
    print(">>> Firmware version above the required min.")
else:
    print("$$$$ Error: Firmware Version is obsolete")
result = {}
test_name = "TCON Firmware Version"
subtest_name = ""
result.update({"TCON_Firmware" : larkspur.firmwareVersion})
display_pdca.add_single_test_result_to_pdca(test_name, subtest_name, result, larkspur.firmwareVersion >= valueFW_ref)
print(result)
print("========")


# CDIC BERT Suite
if(ENABLE_COG_BERT_TESTS):
    print("Start cdicBert test suite!")
    # SET: White color = CDIC pass, Black color = CDIC fail
    larkspur.wr(0x1a, 0x92, 0x38)

    print("13) COG BERT with RED pattern at POR COG Freq!")
    display_cdicBert.COG_Bert_RED_Pattern_POR(larkspur, CDIC_SLEEP_DUR)
    print("========")

    #print(">>>> Power measurement with different colors: DONE")
    print("14) COG BERT with RED image at +15% COG Freq!")
    display_cdicBert.COG_Bert_RED_Pattern_115POR(larkspur, CDIC_SLEEP_DUR)
    print("========")
    
    print("15) COG BERT Jitter Schmoo!")
    display_cdicBert.Vcore_Jitter_Shmoo(larkspur, [0], [1, 2], [1, 2, 3, 4, 5, 6, 7], CDIC_SLEEP_DUR)
    print("========")
    
    print("16) COG BERT Jitter and EQ Schmoo (Corners)!")
    display_cdicBert.Jitter_EQ_Shmoo(larkspur, [1, 2], [1, 2, 3, 4, 5, 6, 7], CDIC_SLEEP_DUR)
    print("========")
    
    print("17) COG BERT Current Shmoo!")
    display_cdicBert.Current_Shmoo(larkspur, current_range = [0, 1, 2], bias_current_range = [50, 47, 44, 41, 38, 34, 31, 28], sleepDur = CDIC_SLEEP_DUR)
    print("========")


# Pgamma + VCOM dump
print("27) PGAMMA and VCOM dump")
print(larkspur.pgamma.readPGammaVCOM())
print(">>>> PGAMMA and VCOM Dump: DONE")
print("========")


# Log Stop time and generate the PLIST file
# -----------------------------
stopTime = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
print("Display test start at: ", startTime)
print("Display test finish at: ", stopTime)
print("Generate plist file!")
display_pdca.generate_pdca_plist(startTime, stopTime)















