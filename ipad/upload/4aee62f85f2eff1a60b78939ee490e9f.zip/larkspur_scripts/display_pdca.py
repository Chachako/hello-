#!/usr/bin/python3
from plistlib import load, dump
import sys
import os

PDCA_FOLDER = "AdditionalPDCA"
PDCA_FILE_NAME = "display_test.plist"
PDCA_DEFAULT_CURRENT_PATH = "nandfs:\\AppleInternal\\Diags\\Logs\\Smokey\\DisplayTest\\"
pdca_test_array = []

'''
Function:
    Get current path
Description:
    Returns the current path of the file. If the system call to get the path fails, use a default path
'''
def get_current_path():
    #current_path = sys.path[0]
    #if (current_path is None):
        #current_path = PDCA_DEFAULT_CURRENT_PATH

    return PDCA_DEFAULT_CURRENT_PATH

'''
Function: 
	add_single_test_result_to_pdca_data (test_name, subtest_name_arr, test_result)
Description:
	add single test record to 'pdca_test_array'
	parameters:
		test_name: the name of the test. eg: 'Vcore_Jitter_Shmoo'
		subtest_name_arr: the array of the subtests' names. eg: ['vc1', 'freq442', 'div1', 'ampl1']
		test_result: the 'result' returned from cdic_bert(). eg: { "cdic0": 0, "cdic1": 0, "cdic2": 0, "cdic3": 0, "cdic4": 0, "cdic5": 0 }
'''
def add_single_test_result_to_pdca (test_name, sub_test_name, test_result, always_pass):

	global pdca_test_array

	if not (isinstance (test_name, str) and isinstance (sub_test_name, str)):
		print ("Error - Both test_name({}) and sub_test_name({}) must be the type of String".format(test_name))
		return -1

	if not (isinstance (test_result, dict)):
		print ("Error - Invalid data type. The type of test_result ({}) is neither dictionary nor array".format(type(test_result)))
		return -1

	if not (isinstance (always_pass, bool)):
		print ("Error - Invalid data type. The type of always_pass ({}) is not bool".format(type(always_pass)))
		return -1		

	# print ("record single test result to pdca plist")
	test_name += "_"

	if len(sub_test_name) > 0:
		test_name += sub_test_name + '_'

	# for i in range(0, len(test_result)):
	for key,value in test_result.items():
		single_test_plist = {}
		result = "PASS"

		if (not always_pass) and (value != 0):
			result = "FAIL"

		pdca_test_name = test_name + key
		if len(pdca_test_name) > 48:
			print ("Error - the length of pdca_test_name ({}) is over 48 characters".format(pdca_test_name))
			return -1

		single_test_plist.update({"testname": pdca_test_name})
		single_test_plist.update({"result":result})
		single_test_plist.update({"value":value})
		single_test_plist.update({"lowerlimit":"NA"})
		single_test_plist.update({"upperlimit":"NA"})
		single_test_plist.update({"units":"NA"})
		single_test_plist.update({"priority":'0'})

		pdca_test_array += [single_test_plist]

	return 0

'''
Function: 
	get_pdca_file_path()
Description:
	get the file path of display_test.plist.
Parameters:
	output: a string of pdca file path
'''
def get_pdca_file_path():
	current_path = get_current_path()
	print("current_path: ", current_path)

	pdca_plist_folder = current_path + "\\"+ PDCA_FOLDER
	print("pdca_plist_folder: ", pdca_plist_folder)

	pdca_plist_path = os.path.join(pdca_plist_folder, PDCA_FILE_NAME)
	print("pdca_plist_path: ", pdca_plist_path)

	if pdca_plist_path.find("/") >= 0:
		pdca_plist_path = pdca_plist_path.replace("/", "\\")
	pdca_plist_path = pdca_plist_path.replace("\\", "\\\\")
	print("pdca_plist_path again: {}".format(pdca_plist_path))

	return pdca_plist_path


'''
Function: 
	delete_plist_file()
Description:
	delete display_test.plist file under ..\\AdditionalPDCA\\
Parameters:
	input/output: N/A
'''
def delete_plist_file():
	pdca_plist_path = get_pdca_file_path()
	if os.path.exists(pdca_plist_path):
		print("the old display_test.plist file exists...remove the old one")
		os.remove(pdca_plist_path)

'''
Function: 
	get_overall_result()
Description:
	Get overall result
Parameters:
	input/output:	pdca_test_array

'''
def get_overall_result():
	global pdca_test_array
	for dict in pdca_test_array:
		if ( dict["result"] == "FAIL" ):
			return "FAIL"
	return "PASS"


'''
Function: 
	get_overall_result()
Description:
	Get overall result
Parameters:
	input/output:	pdca_test_array

'''
def generate_pdca_plist(startTime, stopTime):
	global pdca_test_array
	print ("Enter generate_pdca_plist")
	overall_result = get_overall_result()
	plist_data = {'0':
					{
						'Attributes':{
							'serialnumber': 'NA',
							'softwarename': 'DISPLAY_TEST',
							'softwareversion': '0.1',
							'limitsversion': '0.1',
							'STATION_ID': 'DISPLAY_TEST',
							'SUB_STATION_ID': 'DISPLAY_TEST'
						},
						'Tests':pdca_test_array,
						'overallresult': overall_result,
						'startTime': startTime,
						'stopTime': stopTime,
					}
				}

	current_path = get_current_path()
	print("current_path: ", current_path)

	pdca_plist_folder = current_path + "\\"+ PDCA_FOLDER
	print("pdca_plist_folder: ", pdca_plist_folder)

	pdca_plist_path = os.path.join(pdca_plist_folder, PDCA_FILE_NAME)
	print("pdca_plist_path: ", pdca_plist_path)

	# pdca_plist_path = get_pdca_file_path()
	
	if not os.path.exists(pdca_plist_folder):
		# print("current directory:", get_current_path())
		os.makedirs(pdca_plist_folder)
	elif os.path.exists(pdca_plist_path):
		os.remove(pdca_plist_path)

	with open(pdca_plist_path, mode='wb+') as fp:
		dump(plist_data, fp)
		fp.close()


