def i2cMasterWrite(self, channel, address, offset, data):
    self._setupI2cLockRegisters_(channel)
    self._setupI2cControlRegisters_(channel)

    if not self._i2cMasterLocked_():
        for _ in range (0, self.forceLock):
            if self._lockI2cMaster_():
                break
            # Cannot acquired lock
            self.log("Cannot acquire I2C Master Lock")
            return None

    # I am not sure what these do yet.
    wrLen = 0
    rdLen = 0
    addrLen = 1
    rw = 0

    # Clear the I2C status.
    self.wr(self.i2c_status_page, 0x00, 0xff)
    # Clear the I2C buffer.
    self.wr(self.i2c_config_page, self.mi2c_ctl_2, 0x02)

    self._configureI2cMaster_(channel, rdLen, wrLen, addrLen, rw)

    self._i2cMasterWriteAddress_(channel, address, offset)

    self.wr(self.i2c_data_page, self.mi2c_reg_wdata, data)

    # Start the write.
    self.wr(self.i2c_config_page, self.mi2c_ctl_2, 0x01)

    result = self.rd(self.i2c_data_page, self.mi2c_reg_rdata, rdLen + 1)

    self._unlockI2cMaster_()

    return result

def i2cMasterRead(self, channel, address, offset, rdLen):
    self._setupI2cLockRegisters_(channel)
    self._setupI2cControlRegisters_(channel)

    if not self._i2cMasterLocked_():
        for _ in range (0, self.forceLock):
            if self._lockI2cMaster_():
                break
            # Cannot acquired lock
            self.log("Cannot acquire I2C Master Lock")
            return None

    # I am not sure what these do yet.
    wrLen = 0
    addrLen = 1
    rw = 1

    # Clear the I2C status.
    self.wr(self.i2c_status_page, 0x00, 0xff)
    # Clear the I2C buffer.
    self.wr(self.i2c_config_page, self.mi2c_ctl_2, 0x02)

    self._configureI2cMaster_(channel, rdLen, wrLen, addrLen, rw)

    self._i2cMasterWriteAddress_(channel, address, offset)

    self.wr(self.i2c_data_page, self.mi2c_reg_wdata, address | rw) # Last bit of address is r/w

    # Start the write.
    self.wr(self.i2c_config_page, self.mi2c_ctl_2, 0x01)

    result = self.rd(self.i2c_data_page, self.mi2c_reg_rdata, rdLen)

    self._unlockI2cMaster_()

    return result

def _setupI2cLockRegisters_(self, channel = 3):
    # Refer to Programming guide for register values here.

    if channel == 3: # I2C Master 3
        # The page for the I2C Master lock requests
        self.lock_req_page = 0x3b
        # The page for the I2C Master lock status
        self.lock_status_page = 0x3b

        if self.DeviceType == "SPI":
            self.lock_req_offset = 0x92
            self.lock_req_data = self.SPI_LOCK

            self.lock_status_offset = 0x9a
        elif self.DeviceType == "I2C":
            self.lock_req_offset = 0x93
            self.lock_req_data = self.I2C_LOCK

            self.lock_status_offset = 0x9b
        elif self.DeviceType == "AUX":
            self.lock_req_offset = 0x94
            self.lock_req_data = self.AUX_LOCK

            self.lock_status_offset = 0x9c

    else: # I2C Master 0
        # The page for the I2C Master lock requests
        self.lock_req_page = 0x37
        # The page for the I2C Master lock status
        self.lock_status_page = 0x37

        if self.DeviceType == "SPI":
            self.lock_req_offset = 0x12
            self.lock_req_data = self.SPI_LOCK

            self.lock_status_offset = 0x1a
        elif self.DeviceType == "I2C":
            self.lock_req_offset = 0x13
            self.lock_req_data = self.I2C_LOCK

            self.lock_status_offset = 0x1b
        elif self.DeviceType == "AUX":
            self.lock_req_offset = 0x14
            self.lock_req_data = self.AUX_LOCK

            self.lock_status_offset = 0x1c


def _setupI2cControlRegisters_(self, channel = 3):
    # Using I2C Master 3
    if channel == 3:
        self.i2c_config_page = 0x38
        self.i2c_data_page = 0x3a
        self.i2c_status_page = 0x39

    # Using I2C Master 0 (Not yet tested)
    else:
        self.i2c_config_page = 0x30
        self.i2c_data_page = 0x32
        self.i2c_status_page = 0x31

    self.mi2c_cfg = 0x00
    self.mi2c_ctl_0 = 0x04
    self.mi2c_ctl_1 = 0x08
    self.mi2c_ctl_2 = 0x0c
    self.mi2c_status = 0x10

    self.mi2c_reg_wdata = 0x00
    self.mi2c_reg_rdata = 0x10


def _configureI2cMaster_(self, master = 3, rdLen = 0, wrLen = 0, addrLen = 0, rw = 1):
    ''' rw: 1 = read, 0 = write'''
    para_0 = ((wrLen << 3) | (addrLen << 1) | rw) & 0xff
    para_1 = ((rdLen << 5) | (wrLen >> 5)) & 0xff
    para_2 = (rdLen >> 3) & 0xff
    self.wr(self.i2c_config_page, self.mi2c_cfg, 0x01) # speed = 400K for master 3
    self.wr(self.i2c_config_page, self.mi2c_ctl_0, [para_0, para_1, para_2])


def _i2cMasterWriteAddress_(self, master = 3, slaveAddr = 0, regAddr = 0):
    self.wr(self.i2c_config_page, self.mi2c_ctl_1, [slaveAddr & 0xff, regAddr & 0xff, (regAddr >> 8) & 0xff])

def _i2cMasterLocked_(self):
    status_reg = self.rd(self.lock_status_page, self.lock_status_offset, 1)

    if (status_reg & 0x01) and (status_reg & 0x02):
        # Not locked
        return 0
    else:
        # Locked
        return 1

def _lockI2cMaster_(self):
    # Acquire the lock
    self.wr(self.lock_req_page, self.lock_req_offset, self.lock_req_data)
    # Check that the lock is acquired
    return self._i2cMasterLocked_()

def _unlockI2cMaster_(self):
    # Release the lock
    self.wr(self.lock_req_page, self.lock_req_offset, 0x00)
    # Check that the lock is released
    return self._i2cMasterLocked_()
