# ! /usr/bin/python

import atexit
import os
import readline
import rlcompleter

historyPath = os.path.expanduser("~/.pyhistory")

def save_history(historyPath=historyPath):
    import readline
    readline.write_history_file(historyPath)

if os.path.exists(historyPath) and os.stat(historyPath).st_size!=0:
    readline.read_history_file(historyPath)

atexit.register(save_history)
del os, atexit, readline, rlcompleter, save_history, historyPath

import DP855

l = DP855.autoDetect()

print("TCON Bundle Version:\t 0x%02X%02X"%(l.rd(0x03,0xca),l.rd(0x03,0xcb)))
print("TCON FW Version:\t 0x%02X%02X"%(l.rd(0x04,0x96),l.rd(0x04,0x97)))



if __name__ == "__main__":
    try:
        import readline
    except ImportError:
        print("Module readline not available.")
    else:
        import rlcompleter
        if 'libedit' in readline.__doc__:
            readline.parse_and_bind("bind ^I rl_complete")
        else:
            readline.parse_and_bind("tab: complete")
    import code
    code.interact(local=locals())

def DumpAllSeaSideRegisters(self):
    for address in range (0, 0x100):
        status, read_data = l.PLS_GetInfoCmd(l.PLS_READ_REG_BANK1, address)
        #print 'Cmd: 0x{:02X} Status: 0x{:02X} Address: 0x{:02X} Value: 0x{:02X}{:02X}'.format(l.PMIC_READ_REG, status, address, read_data[1], read_data[0])
        #print 'Address: 0x{:02X} Value: {:02X}{:02X}'.format(address, read_data[0], read_data[1])
        print('{:02X}{:02X}'.format(read_data[0], read_data[1]))
