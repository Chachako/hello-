#!/bin/env python
from array import array
import aardvark_py as adv

#==========================================================================
# Interface Layer
#==========================================================================

class SPI:
        port = -1
        handle = 0
        bitrate = 1000

        def __init__ (self, port):
                self.handle = adv.aa_open(port)
                if 0 < self.handle:
                        self.port = port

        def __del__(self):
                if 0 < self.handle:
                        adv.aa_close(self.handle)
                        self.handle = 0

        def configure(self, bitrate):
                if 0 < self.handle:
                        adv.aa_configure(self.handle, adv.AA_CONFIG_SPI_I2C)
                        adv.aa_target_power(self.handle, adv.AA_TARGET_POWER_BOTH)
                        self.bitrate = adv.aa_spi_bitrate(self.handle, bitrate)
                        adv.aa_spi_configure(self.handle, 0, 0, adv.AA_SPI_BITORDER_MSB)


        def single_bit_io(self, data, read_count = 0):
                if self.handle < 0:
                        return None

                data_out = array('B')
                for item in data:
                        data_out.append(item & 0xff)

                for _ in range(0, read_count):
                        data_out.append(0)

                data_in = array('B', data_out)
                (status, data_in) = adv.aa_spi_write(self.handle, data_out, data_in)
                return data_in

class IIC:
        port = -1
        handle = 0
        bitrate = 100
        slave_address = 0x08

        def __init__ (self, port):
                self.handle = adv.aa_open(port)
                if 0 < self.handle:
                        self.port = port

        def __del__(self):
                if 0 < self.handle:
                        adv.aa_close(self.handle)
                        self.handle = 0

        def configure(self, bitrate, pullup, device_address = None):
                if 0 < self.handle:
                        adv.aa_configure(self.handle, adv.AA_CONFIG_SPI_I2C)
                        if pullup:
                                adv.aa_i2c_pullup(self.handle, adv.AA_I2C_PULLUP_BOTH)
                                adv.aa_target_power(self.handle, adv.AA_TARGET_POWER_BOTH)
                        self.bitrate = adv.aa_i2c_bitrate(self.handle, bitrate)
                        if device_address != None:
                                self.slave_address = device_address

        def read(self, addr, offset, count = 1):
                if 0x100 < offset + count:
                        return None
                if 0 < self.handle:
                        data_out = array('B', [0x08, addr, offset])
                        data_in  = array('B', bytearray(count))
                        count = adv.aa_i2c_write_read(self.handle, addr, adv.AA_I2C_NO_FLAGS, data_out, data_in)
                        #if 0 < count:
                        return data_in
                return None

        def read_byte(self, addr, offset, count = 1):
                #data_in = self.read(addr, offset, count)
                data_out = array('B', [addr, offset])
                data_in = array('B', bytearray(count))


                adv.aa_i2c_write_read(self.handle, 0x08, adv.AA_I2C_NO_FLAGS, data_out, data_in)
                return data_in

        def read_word(self, addr, offset, count = 1):
                data_in = self.read(addr, offset, count << 1)
                if data_in != None:
                        if len(data_in) == (count << 1):
                                data  = array('I')
                                c = 0
                                for i in range(count):
                                        v = data_in[c] + (data_in[c+1] << 8)
                                        if 1 == count:
                                                return v
                                        data.append(v)
                                        c += 2
                                return data
                return None

        def read_triple(self, addr, offset, count = 1):
                data_in = self.read(addr, offset, count * 3)
                if data_in != None:
                        if len(data_in) == (count * 3):
                                data  = array('L')
                                c = 0
                                for i in range(count):
                                        v = data_in[c] + (data_in[c+1] << 8) + (data_in[c+2] << 16)
                                        if 1 == count:
                                                return v
                                        data.append(v)
                                        c += 3
                                return data
                return None

        def read_dword(self, addr, offset, count = 1):
                data_in = self.read(addr, offset, count << 2)
                if data_in != None:
                        if len(data_in) == (count << 2):
                                data  = array('L')
                                c = 0
                                for i in range(count):
                                        v = data_in[c] + (data_in[c+1] << 8) + (data_in[c+2] << 16) + (data_in[c+3] << 24)
                                        if 1 == count:
                                                return v
                                        data.append(v)
                                        c += 4
                                return data
                return None

        def write(self, addr, offset, data):
                if 0x100 < offset + len(data):
                        return 0
                if 0 < self.handle:
                        data_out = array('B', [offset])
                        if isinstance(data, int):
                                data_out.append(data)
                        else:
                                for value in data:
                                        data_out.append(value)
                        count = adv.aa_i2c_write(self.handle, addr, adv.AA_I2C_NO_FLAGS, data_out)
                        if 1 < count:
                                return count - 1
                return 0


        def write_byte(self, addr, offset, data):
                if type(data) is int:
                        count = 1
                else:
                        count = len(data)
                data_out = array('B', [addr, offset, data])

                return adv.aa_i2c_write(self.handle, 0x08, adv.AA_I2C_NO_FLAGS, data_out)

        def write_word(self, addr, offset, data):
                data_out = array('B')
                if isinstance(data, (list, tuple)):
                        for value in data:
                                data_out.appen(value & 0xFF)
                                data_out.append((value >> 8) & 0xff)
                else:
                        data_out.appen(data & 0xFF)
                        data_out.append((data >> 8) & 0xff)
                count = self.write(addr, offset, data_out)
                return count >> 1

        def write_triple(self, addr, offset, data):
                data_out = array('B')
                if isinstance(data, (list, tuple)):
                        for value in data:
                                data_out.appen(value & 0xFF)
                                data_out.append((value >> 8) & 0xff)
                                data_out.append((value >> 16) & 0xff)
                else:
                        data_out.appen(data & 0xFF)
                        data_out.append((data >> 8) & 0xff)
                        data_out.append((data >> 16) & 0xff)
                count = self.write(addr, offset, data_out)
                return count / 3

        def write_dword(self, addr, offset, data):
                data_out = array('B')
                if isinstance(data, (list, tuple)):
                        for value in data:
                                data_out.appen(value & 0xFF)
                                data_out.append((value >> 8) & 0xff)
                                data_out.append((value >> 16) & 0xff)
                                data_out.append((value >> 24) & 0xff)
                else:
                        data_out.appen(data & 0xFF)
                        data_out.append((data >> 8) & 0xff)
                        data_out.append((data >> 16) & 0xff)
                        data_out.append((data >> 24) & 0xff)
                count = self.write(addr, offset, data_out)
                return count >> 2

        def rd(self, page, offset):
                return self.read_byte(self.slave_address + page, offset)

        def rd2(self, page, offset):
                return self.read_word(self.slave_address + page, offset)

        def rd3(self, page, offset):
                return self.read_triple(self.slave_address + page, offset)

        def rd4(self, page, offset):
                return self.read_dword(self.slave_address + page, offset)

        def rd_n(self, page, offset, count):
                return self.read(self.slave_address + page, offset, count)

        def wr(self, page, offset, data):
                return self.write_byte(self.slave_address + page, offset, data)

        def wr2(self, page, offset, data):
                return self.write_word(self.slave_address + page, offset, data)

        def wr3(self, page, offset, data):
                return self.write_triple(self.slave_address + page, offset, data)

        def wr4(self, page, offset, data):
                return self.write_dword(self.slave_address + page, offset, data)

        def wr_n(self, page, offset, data):
                return self.write(self.slave_address + page, offset, data)

#==========================================================================
# Function Layer
#==========================================================================

def FindUSB(verbose = True):
        (num, ports) = adv.aa_find_devices(16)
        if verbose:
                # Print the information on each device
                print ("Detected %d Aardvark device(s)" %num)
        return 0 < num

def FindDUT(device_address = None, verbose = True):
        # Find all the attached devices
        (num, ports, unique_ids) = adv.aa_find_devices_ext(16, 16)

        if num < 0:
                return None
        for i in range(num):
                port      = ports[i]
                unique_id = unique_ids[i]

                if verbose:
                        print ("#%d:" %i)
                        print ("\tPort&Status: %x" % port)
                        print ("\tID: %s" % unique_id)

                if (port & adv.AA_PORT_NOT_FREE) == 0:
                        iic = IIC(port)
                        #iic.configure(100, False, 0x08)
                        return iic
                        # for address in range(0x08, 0x28, 0x10):
                        #       if device_address != None:
                        #               slave_address = device_address >> 1
                        #       else:
                        #               slave_address = address
                        #       iic.configure(100, False, slave_address)
                        #       # if subpage != None:
                        #       #       if iic.wr(15, 0xfe, subpage) < 1:
                        #       #               continue
                        #       # chip_id = iic.rd2(4, 0xf2)
                        #       if verbose:
                        #               if chip_id != 0:
                        #                       print ("\tChip ID: %04x" % chip_id)
                        #       if chip_id == id:
                        #               return iic
                        #       if device_address != None:
                        #               return None
                #                       del iic
        return None


def FindSPIDUT(verbose = True):
        # Find all the attached devices
        (num, ports, unique_ids) = adv.aa_find_devices_ext(16, 16)

        if num < 0:
                return None
        for i in range(num):
                port      = ports[i]
                unique_id = unique_ids[i]

                if verbose:
                        print ("#%d:" %i)
                        print ("\tPort&Status: %x" % port)
                        print ("\tID: %s" % unique_id)

                if (port & adv.AA_PORT_NOT_FREE) == 0:
                        spi = SPI(port)
                        spi.configure(100)
                        return spi
                        # for address in range(0x08, 0x28, 0x10):
                        #       if device_address != None:
                        #               slave_address = device_address >> 1
                        #       else:
                        #               slave_address = address
                        #       iic.configure(100, False, slave_address)
                        #       # if subpage != None:
                        #       #       if iic.wr(15, 0xfe, subpage) < 1:
                        #       #               continue
                        #       # chip_id = iic.rd2(4, 0xf2)
                        #       if verbose:
                        #               if chip_id != 0:
                        #                       print ("\tChip ID: %04x" % chip_id)
                        #       if chip_id == id:
                        #               return iic
                        #       if device_address != None:
                        #               return None
                #                       del iic
        return None
