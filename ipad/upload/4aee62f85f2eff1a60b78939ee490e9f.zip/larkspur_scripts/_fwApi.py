import time
# Larkspur DPCD Registers for FW Commands
DPCD00410 = 0x370 # Data0
DPCD00411 = 0x371
DPCD00412 = 0x372
DPCD00413 = 0x373
DPCD00414 = 0x374
DPCD00415 = 0x375
DPCD00416 = 0x376
DPCD00417 = 0x377 # Data7
DPCD00418 = 0x488 # Data8
DPCD00419 = 0x489
DPCD0041a = 0x48a
DPCD0041b = 0x48b
DPCD0041c = 0x48c
DPCD0041d = 0x48d
DPCD0041e = 0x48e
DPCD0041f = 0x48f # Data15

DPCD004f8 = 0x490 # OPTION2
DPCD004f9 = 0x491 # OPTION1
DPCD004fa = 0x492 # SUB-CMD
DPCD004fb = 0x493 # FW-API-CMD-CODE
DPCD004fc = 0x494 # AUX CMD/STATUS
DPCD004fd = 0x495 # COUNT

STARTADDR0_7 = DPCD00410
STARTADDR8_F = DPCD00418

SET_ACK = 0x08
SEND_PACKET = 0x08

STATUS_READY = 0x08
STATUS_COMPLETE = 0x10
STATUS_ERROR = 0x20
STATUS_BUSY  = 0x40
SUBMIT_CMD = 0x80

# SPI SLAVE Commands
LARKSPUR_SPI_READ_CMD = 0x20
LARKSPUR_SPI_WRITE_CMD = 0x00

WRITE_CMD_BIT = 0x80

# API List
GET_STATUS_CMD		= 0x00
GET_VERSION_CMD		= 0x01
GET_INFO_CMD		= 0x02
SET_INFO_CMD		= 0x83

TCON_READ_REG1_CMD	= 0x10
TCON_WRITE_REG1_CMD	= 0x94

NVM_ERASE_BLOCK_CMD	= 0xA0
NVM_READ_PAGE_CMD	= 0x22
NVM_WRITE_PAGE_CMD	= 0xA4

START_FW_UPDATE_CMD = 0x97
DOWNLOAD_FW_CMD		= 0x98
END_FW_UPDATE_CMD	= 0x99
UPDATE_CONFIG_CMD	= 0x9A
GET_ECID_CMD		= 0x1B
SUBMIT_DEVICEID_CMD	= 0x9C

# VALID CONFIG HEADERS
HEADER_FW_CONFIG			= 0x5501
HEADER_TCON_CONFIG			= 0x5502
HEADER_EDID					= 0x5503
HEADER_LUTS_CONFIG			= 0x5504
HEADER_PMIC_CONFIG			= 0x5505
HEADER_PLS_CONFIG			= 0x5506
HEADER_VCOM_CONFIG			= 0x5507
HEADER_PGAMMA_CONFIG		= 0x5508
HEADER_EQ_SETTING_CONFIG	= 0x5509

CONFIG_MEMORY_MAP_DICT = {
            HEADER_FW_CONFIG: 0xA000,
            HEADER_TCON_CONFIG: 0x7000,
            HEADER_EDID: 0x6000,
            HEADER_LUTS_CONFIG: 0x9000,
            HEADER_PMIC_CONFIG: 0x1B000,
            HEADER_PLS_CONFIG: 0x1C000,
            HEADER_VCOM_CONFIG: 0x1D000,
            HEADER_PGAMMA_CONFIG: 0x1E000,
            HEADER_EQ_SETTING_CONFIG: 0x1F000
            }

# VERSION SUB-CMD
VER_SUB_CMD_FW      = 0x00
VER_SUB_CMD_CHIPID  = 0x01
VER_SUB_CMD_BOARDID = 0x02
VER_SUB_CMD_CONFIG  = 0x03
VER_SUB_CMD_BUNDLE  = 0x04

# PERIPHERAL SUB-CMD
SUB_CMD_PMIC    = 0x04
SUB_CMD_PLS     = 0x05
SUB_CMD_ADC     =0x06
SUB_CMD_VCOM_PGAMMA  = 0x02
SUB_CMD_OTP     = 0x0F

# PLS SUB-CMD Parameters
PLS_STATUS          = 0x00
PLS_READ_REG_BANK1  = 0x01
PLS_READ_REG_BANK2  = 0x02
PLS_READ_REG_ALL    = 0x03

PLS_WRITE_REG_BANK1  = 0x11
PLS_WRITE_REG_BANK2  = 0x12
PLS_WRITE_REG_ALL    = 0x13
PLS_SAVE_TO_FLASH    = 0x21
PLS_LOAD_FROM_FLASH  = 0x31

# PGAMMA SUB-CMD Parameters
VCOM_PGAMMA_STATUS          = 0x00
VCOM_PGAMMA_READ_REG        = 0x01
VCOM_PGAMMA_READ_REG_ALL    = 0x02

VCOM_PGAMMA_WRITE_REG           = 0x11
VCOM_PGAMMA_WRITE_REG_ALL       = 0x12
VCOM_PGAMMA_SAVE_TO_FLASH       = 0x21
VCOM_PGAMMA_LOAD_FROM_FLASH     = 0x31
VCOM_PGAMMA_ENABLE_CALIBRATION  = 0x41
VCOM_PGAMMA_ERASE_CALIBRATION_DATA  = 0x51
VCOM_PGAMMA_READ_CALIBRATION_DATA   = 0x61
VCOM_PGAMMA_WRITE_CALIBRATION_DATA  = 0x71

# PMIC SUB-CMD Parameters
PMIC_STATUS         = 0x00
PMIC_READ_REG       = 0x01

PMIC_WRITE_REG      = 0x11
PMIC_SAVE_TO_FLASH   = 0x21
PMIC_LOAD_FROM_FLASH  = 0x31

# OTP SUB-CMD Parameters
OTP_CHECK_SDOM_STATUS	= 0x01
OTP_CHECK_PROD_STATUS	= 0x02
OTP_SET_SDOM			= 0x11
OTP_SET_PROD			= 0x12

# ADC related Sub commands
ADC_GET_STATUS = 0x00
ADC_READ_REG = 0x01
ADC_READ_ALL = 0x02
ADC_READ_DATA = 0x03
ADC_WRITE_REG = 0x11
ADC_WRITE_ALL = 0x12
ADC_SET_BITS = 0x21
ADC_CLEAR_BITS = 0x22

def fwApiWriteReg(self, page = 0, offset = 0, data = None):
    if len(data) > 4:
        raise ValueError("To many registers to write, FW API only supports 16 bytes write at a time.")

    return self._fwApiWriteCommand_(command = 0x94, arg1 = page, arg2 = offset, data = data)

def fwApiReadNVMPage(self, page):
    data = [page & 0xff, (page & 0xff00) >> 8, (page & 0xff0000) >> 16, (page & 0xff000000) >> 24]
    print (data)
    return self._fwApiReadCommand_(command = 0x22, count = 1, data = data)

#===== start PLS cmd
'''
def sendCmd(self, cmd, sub_cmd, option1, option2, write_data, data_count):
    return self._fwApiWriteCommand_(cmd, sub_cmd, option1, option2, data_count, write_data)
'''

def PLS_GetInfoCmd(self, option1, option2):
    return self._fwApiReadCommand_(GET_INFO_CMD, SUB_CMD_PLS, option1, option2, 0)

def PLS_SetInfoCmd(self, option1, option2 = 0, count = 0, data = None):
    return self._fwApiWriteCommand_(SET_INFO_CMD, SUB_CMD_PLS, option1, option2, count, data)

def PLS_SaveSettingsCmd(self):
    return self.PLS_SetInfoCmd(PLS_SAVE_TO_FLASH)

def PLS_LoadFromFlashCmd(self):
    status = self.PLS_SetInfoCmd(PLS_LOAD_FROM_FLASH)
    return status

def PLS_rd(self,address):
    return self.PLS_GetInfoCmd(PLS_READ_REG_BANK1, address)

def PLS_wr(self,address,data,byte_count=2):
    write_data = array.array('B', [ 0x00 for i in range(byte_count) ])
    for i in range(byte_count):
        write_data[byte_count-1-i] = (data >> 8*i) & 0xff
    return self.PLS_SetInfoCmd(PLS_WRITE_REG_BANK1, address, byte_count, write_data)

#===== end PLS cmd

#===== start PMIC cmd
def PMIC_GetInfoCmd(self, option1, option2):
    return self._fwApiReadCommand_(GET_INFO_CMD, SUB_CMD_PMIC, option1, option2, 0)

def PMIC_SetInfoCmd(self, option1, option2 = 0, count = 0, data = None):
    return self._fwApiWriteCommand_(SET_INFO_CMD, SUB_CMD_PMIC, option1, option2, count, data)

def PMIC_SaveSettingsCmd(self):
    return self.PMIC_SetInfoCmd(PMIC_SAVE_TO_FLASH)

def PMIC_LoadFromFlashCmd(self):
    status = self.PMIC_SetInfoCmd(PMIC_LOAD_FROM_FLASH)
    return status

def PMIC_rd(self,address):
    return self.PMIC_GetInfoCmd(PMIC_READ_REG, address)

def PMIC_wr(self,address,data):
    write_data = array.array('B',[data & 0xff])
    return self.PMIC_SetInfoCmd(PMIC_WRITE_REG, address, 1, write_data)

#===== end PMIC cmd

def _fwApiReadCommand_(self, command = 0x01, subCommand = 0, arg1 = 0, arg2 = 0, count = 1, data = None):
    if not self.mcu:
        raise NotImplementedError("MCU not enabled, FW API not implemented on this config")

    status = self._fwApiCheckStatus_()

    readBuffer = []

    # Setting up the API command
    self.wr(0x04, 0x93, command)
    self.wr(0x04, 0x92, subCommand)
    self.wr(0x04, 0x91, arg1)
    self.wr(0x04, 0x90, arg2)
    self.wr(0x04, 0x95, count)


    # Also setup the data register if it is used
    if data:
        for byte, reg in zip(data, self.MCU_DATA_REG):
            self.wr(reg[0], reg[1], byte)

    # Submit the packet
    self.wr(0x04, 0x94, 0x80)

    status = self._fwApiCheckStatus_()
    while status & (0x08 | 0x10):
        for reg in self.MCU_DATA_REG:
            readBuffer.append(self.rd(reg[0], reg[1]))

        if status == 0x08:
            self.wr(0x04, 0x94, 0x88)
            status = self._fwApiCheckStatus_()
        else:
            break

    return readBuffer

def _fwApiWriteCommand_(self, command = 0x01, subCommand = 0, arg1 = 0, arg2 = 0, count = 1, data = None):
    if not self.mcu:
        raise NotImplementedError("MCU not enabled, FW API not implemented on this config")


    status = self._fwApiCheckStatus_()

    # Setting up the API command
    self.wr(0x04, 0x93, command)
    self.wr(0x04, 0x92, subCommand)
    self.wr(0x04, 0x91, arg1)
    self.wr(0x04, 0x90, arg2)
    self.wr(0x04, 0x95, count)

    if count == 0 : #ignore data if count is 0
        self.wr(0x04, 0x94,  SUBMIT_CMD)
        return self._fwApiCheckStatus_()
    elif data is None:
        raise ValueError("Data packet is empty")
    else:
        first_data = 1

    while data:
        # Setup the data register
        dataCount = 0
        for byte, reg in zip(data, self.MCU_DATA_REG):
            self.wr(reg[0], reg[1], byte)
            dataCount += 1

        # Submit the packet
#         self.wr(0x04, 0x94, 0x80)
        if (first_data):
            self.wr(0x04, 0x94,  SUBMIT_CMD)
            first_data = 0
        else:
            self.wr(0x04, 0x94,  SUBMIT_CMD | SEND_PACKET)

        del data[0 : dataCount]
        status = self._fwApiCheckStatus_()

    # Write Done Status
#     self.wr(0x04, 0x94, 0x10)

    return status


def _fwApiCheckStatus_(self):
    '''
    Check and return the FW API status byte.
    This will only return if status is ready or complete. Otherwise an exception is raised.
    '''

    status = self.rd(0x04, 0x94)
    busyWait = 0
    while not ((status & 0x08) | (status & 0x10) | (status == 0x00)):
        if (status & 0x20):
            self._fwApiCheckError_()
        if (status & 0x80):
            print ("Command has been submitted, waiting for it to complete...")
        if (status & 0x40):
            if busyWait < self.fwRetry:
                busyWait += 1
            else:
                raise RuntimeError("Busy.")

        status = self.rd(0x04, 0x94)
    return status


def _fwApiCheckError_(self):
    error = self.rd(0x04, 0x91)
    if (error & 0x1f) == 0x01:
        raise NotImplementedError("ERROR_INVALID_COMMAND")
    elif (error & 0x1f) == 0x02:
        raise RuntimeError("ERROR_SECURITY_LEVEL_NOT_MET")
    elif (error & 0x1f) == 0x03:
        raise ValueError("ERROR_INTEGRITY_ERROR")
    elif (error & 0x1f) == 0x04:
        raise RuntimeError("ERROR_NOT_INITIALIZED")
    elif (error & 0x1f) == 0x05:
        raise RuntimeError("ERROR_TIMEOUT")
    elif (error & 0x1f) == 0x06:
        raise RuntimeError("ERROR_COMMAND_FIFO_FULL")
    elif (error & 0x1f) == 0x07:
        raise ValueError("ERROR_COMMAND_CRC_MISMATCH")
    elif (error & 0x1f) == 0x08:
        raise ValueError("ERROR_COMMAND_TAG_MISMATCH")
    elif (error & 0x1f) == 0x09:
        raise ValueError("ERROR_INCORRECT_HEADER")
    elif (error & 0x1f) == 0x0A:
        raise RuntimeError("ERROR_NVM_ERASE_ERROR")
    elif (error & 0x1f) == 0x0B:
        raise RuntimeError("ERROR_NVM_READ_ERROR")
    elif (error & 0x1f) == 0x0C:
        raise RuntimeError("ERROR_NVM_WRITE_ERROR")
    elif (error & 0x1f) == 0x0D:
        raise RuntimeError("ERROR_PLS_INITIALIZATION")
    elif (error & 0x1f) == 0x0E:
        raise RuntimeError("ERROR_PLS_CONFIGURATION")
    elif (error & 0x1f) == 0x0F:
        raise RuntimeError("ERROR_PMIC_INITIALIZATION")
    elif (error & 0x1f) == 0x10:
        raise RuntimeError("ERROR_PMIC_CONFIGURATION")
    elif (error & 0x1f) == 0x11:
        raise RuntimeError("ERROR_FIRMWARE_UPDATE_FAILED")
    elif (error & 0x1f) == 0x12:
        raise ValueError("ERROR_NONCE_MISMATCH")
    elif (error & 0x1f) == 0x13:
        raise ValueError("ERROR_HASH_MISMATCH")
    elif (error & 0x1f) == 0x14:
        raise ValueError("ERROR_RSA_VERIFY")
    else:
        raise RuntimeError("Error was reported, but error register is empty")



#===== start PGAMMA/VCOM cmd
'''
def sendCmd(self, cmd, sub_cmd, option1, option2, write_data, data_count):
    return self._fwApiWriteCommand_(cmd, sub_cmd, option1, option2, data_count, write_data)
'''
def PGAMMA_rd(self, address):
    read_data = self._fwApiReadCommand_(GET_INFO_CMD, SUB_CMD_VCOM_PGAMMA, VCOM_PGAMMA_READ_REG, address, 0)
    return (read_data[0]<<8|read_data[1])

#===== end PGAMMA/VCOM cmd



#===== start ADC cmd
'''
def sendCmd(self, cmd, sub_cmd, option1, option2, write_data, data_count):
    return self._fwApiWriteCommand_(cmd, sub_cmd, option1, option2, data_count, write_data)
'''

def ADC_ReadRegister(self, registerAddress):
    registerAddressInBytes = [0x00,0x00]
    registerAddressInBytes[0] = registerAddress
    registerAddressInBytes[1] = registerAddress >> 8
    self._fwApiWriteCommand_(GET_INFO_CMD, SUB_CMD_ADC, ADC_READ_REG, 0, 2, registerAddressInBytes)
    data = self.rd((DPCD00412>>8),DPCD00412)
    return data

def ADC_WriteRegister(self, registerAddress, data):
    adcFrame = [0x00,0x00,0x00]
    adcFrame[0] = registerAddress
    adcFrame[1] = registerAddress >> 8
    adcFrame[2] = data # copy data
    self._fwApiWriteCommand_(SET_INFO_CMD, SUB_CMD_ADC, ADC_WRITE_REG, 0, 3, adcFrame)

def ADC_ReadData(self):
    write_data = [0x00, 0x00, 0x00, 0x00, 0x00]
    adcData = [0xFF,0xFF,0xFF,0xFF]
    self._fwApiWriteCommand_(GET_INFO_CMD, SUB_CMD_ADC, ADC_READ_DATA, 0, 2, write_data)
    adcData[0] = self.rd((DPCD00410>>8),DPCD00410)
    adcData[1] = self.rd((DPCD00411>>8),DPCD00411)
    adcData[2] = self.rd((DPCD00412>>8),DPCD00412)
    return ((adcData[0]<<8)|adcData[1])
#===== end ADC cmd
