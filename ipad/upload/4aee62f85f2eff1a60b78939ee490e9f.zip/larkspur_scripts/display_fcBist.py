#!/usr/bin/env python3
import display_pdca

# Larkspur TCON BIST @HBR3
def fcBistHbr3(larkspur):

    test_name = "fcBist"
    subtest_name = "Hbr3"

    larkspur.log(test_name + ": " + subtest_name)
    result = larkspur.fcBIST()

    display_pdca.add_single_test_result_to_pdca(test_name, subtest_name, result, False)
