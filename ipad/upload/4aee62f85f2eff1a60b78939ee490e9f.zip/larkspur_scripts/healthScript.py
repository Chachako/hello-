import sys

if len(sys.argv) > 1:
    fileName = sys.argv[1]
    logFile = open(str(fileName), "w")
else:
    logFile = None

import DP855
l = DP855.autoDetect(logFile)

l.reset()

l.checkMBC()

l.log("=============Checking MSA=============")
l.eDPCheckMSA()

l.log("=============Checking ALP-DP Status=============")
l.eDPCheckALPDPStatus()

l.log("=============Checking eDP Status for 15 Seconds=============")
l.eDPCheckLinkStatus()
l.log("eDP Symbol Error...")
l.eDPCheckSymbolError(sleepDur = 15)

l.log("=============Running CDIC BERT for 15 Seconds=============")
l.log("CDIC Symbol Error...")
l.cdicBert(sleepDur = 15)

for device in [l.pls, l.pgamma, l.adc, l.pmic]:
    if device:
        device.healthScript()
