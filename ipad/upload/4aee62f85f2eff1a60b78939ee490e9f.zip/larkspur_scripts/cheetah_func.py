#!/bin/env python
from array import array
import cheetah_py as cht
import time

#==========================================================================
# Interface Layer
#==========================================================================

class SPI:
	def __init__ (self, port):
		self.handle = cht.ch_open(port)
		self.port = port
		self.cpol = cht.CH_SPI_POL_RISING_FALLING
		self.cpha = cht.CH_SPI_PHASE_SAMPLE_SETUP
		self.spi_bitorder = cht.CH_SPI_BITORDER_MSB
		self.cs_polarity = 0
		self.spi_bitrate = 0

	def __del__(self):
		if 0 < self.handle:
			if cht != None:
				cht.ch_close(self.handle)

	def configure_spi(self, ClockPolarity = None, ClockPhase = None, Endian = None, CSPolarity = False, BitRate = 0 ):
		if 0 < self.handle:
			if ClockPolarity != None:
				if ClockPolarity:
					self.cpol = cht.CH_SPI_POL_FALLING_RISING
				else:
					self.cpol = cht.CH_SPI_POL_RISING_FALLING
			if ClockPhase != None:
				if ClockPhase:
					self.cpha = cht.CH_SPI_PHASE_SETUP_SAMPLE
				else:
					self.cpha = cht.CH_SPI_PHASE_SAMPLE_SETUP
			if Endian != None:
				if Endian:
					self.spi_bitorder = cht.CH_SPI_BITORDER_MSB
				else:
					self.spi_bitorder = cht.CH_SPI_BITORDER_LSB
			if CSPolarity != None:
				if isinstance(CSPolarity, (list, tuple)):
					cs = 0
					bit = 1
					for v in CSPolarity:
						if v:
							cs |= bit
						bit <<= 1
						if bit > 7:
							break
					self.cs_polarity = cs
				else:
					if CSPolarity:
						self.cs_polarity = 7
					else:
						self.cs_polarity = 0
			cht.ch_spi_configure(self.handle, self.cpol, self.cpha, self.spi_bitorder, self.cs_polarity)
			self.spi_bitrate = cht.ch_spi_bitrate(self.handle, BitRate)

	def reset(self):
		if self.handle < 0:
			return False
		cht.ch_spi_queue_clear(self.handle)
		cht.ch_spi_queue_ss(self.handle, 0)
		cht.ch_spi_queue_oe(self.handle, 0)
		cht.ch_spi_batch_shift(self.handle, 0)
		return True

	def single_bit_io(self, data, read_count = 0):
		if self.handle < 0:
			return None
		cht.ch_spi_queue_clear(self.handle)
		cht.ch_spi_queue_oe(self.handle, 1)
		cht.ch_spi_queue_ss(self.handle, 1)

		write_count = len(data)
		total_count = write_count + read_count

		for v in data:
			cht.ch_spi_queue_byte(self.handle, 1, v)
		for i in range(read_count):
			cht.ch_spi_queue_byte(self.handle, 1, 0)

		cht.ch_spi_queue_ss(self.handle, 0)
		count, read_data = cht.ch_spi_batch_shift(self.handle, total_count)
		if count != total_count:
			if 0 < read_count:
				return None
			else:
				return 0
		if 0 == read_count:
			return count
		if write_count < len(read_data):
			return read_data[write_count:]
		return None

#==========================================================================
# Function Layer
#==========================================================================

def FindUSB(verbose = True):
	(num, ports) = cht.ch_find_devices(16)
	if verbose:
		print ("Detected %d Cheetah device(s)" % num)
	return 0 < num

def GetSPI(verbose = True):
	# Find all the attached devices
	(num, ports, unique_ids) = cht.ch_find_devices_ext(16, 16)
	if num < 0:
		return None
	device_found = None
	for i in range(num):
		port      = ports[i]
		unique_id = unique_ids[i]

		if verbose:
			print ("#%d:" %i)
			print ("\tPort&Status: %x" % port)
			print ("\tID: %s" % unique_id)
		if (port & cht.CH_PORT_NOT_FREE) != 0:
			print ("=> used already")
		else:
			device = SPI(port)
			if 0 < device.handle:
				device.configure_spi()
				device.reset()
				if device_found == None:
					device_found = device
				else:
					print ("Found more than two controllers")
					return None
	return device_found
