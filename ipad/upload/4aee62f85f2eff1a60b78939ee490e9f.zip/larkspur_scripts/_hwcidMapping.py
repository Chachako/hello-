import devices.SAN_DIEGO as SAN_DIEGO
import devices.MONTEREY as MONTEREY
import devices.SANTA_BARBARA as SANTA_BARBARA
import devices.SEASIDE_M as SEASIDE_M
import devices.SWOOSH as SWOOSH
import devices.BISON as BISON
import devices.BUFFALO as BUFFALO
import devices.ANTELOPE as ANTELOPE

def _setupSlaves_(self, boardID, HWCID):
    # Set up other attributes based on Board ID and HWCID
    self.log ("Board ID: " + hex(boardID))
    self.log ("HWCID: " + hex(HWCID))
    if boardID == 0x01:
        self.edp = "HBR"
        self.cdicFreq = 442
        self.cdicCount = 6
        self.refresh = 60
        self.pmic = SAN_DIEGO.autoDetect(self)
        self.pls  = MONTEREY.autoDetect(self)
        if HWCID == 0x03:
            self.panel_vendor = "P0 LGD"
        elif HWCID == 0x04:
            self.panel_vendor = "P0 Sharp GIS"
        elif HWCID == 0x06:
            self.panel_vendor = "P1 LGD"
        elif HWCID == 0x07:
            self.panel_vendor = "P1 Sharp GIS"
        elif HWCID == 0x09:
            self.panel_vendor = "P2 LGD"
        elif HWCID == 0x0A:
            self.panel_vendor = "P2 Sharp GIS"
        else:
            self.panel_vendor = "UNKNOWN"
            self.log ("HWCID Not Valid")
            raise ValueError("HWCID Not Valid")

    elif boardID == 0x02:
        self.edp = "HBR"
        self.cdicFreq = 442
        self.cdicCount = 6
        self.refresh = 60
        self.pmic = SAN_DIEGO.autoDetect(self)
        self.pls  = MONTEREY.autoDetect(self)
        if HWCID == 0x03:
            self.panel_vendor = "PP0 LGD"
        elif HWCID == 0x04:
            self.panel_vendor = "PP0 Sharp GIS"
        elif HWCID == 0x05:
            self.panel_vendor = "P0-1 BOE"
        elif HWCID == 0x06:
            self.panel_vendor = "P0-1 LGD"
        elif HWCID == 0x07:
            self.panel_vendor = "P0-1 Sharp GIS"
        elif HWCID == 0x08:
            self.panel_vendor = "P1 BOE"
        elif HWCID == 0x09:
            self.panel_vendor = "P1 LGD EPI"
        elif HWCID == 0x02:
            self.panel_vendor = "P1 LGD eRVDS"
        elif HWCID == 0x0A:
            self.panel_vendor = "P1 Sharp GIS"
        else:
            self.panel_vendor = "UNKNOWN"
            self.log ("HWCID Not Valid")
            raise ValueError("HWCID Not Valid")

    elif boardID == 0x03:
        self.edp = "HBR3"
        self.cdicFreq = 783
        self.cdicCount = 8
        self.refresh = 60
        self.pmic = BISON.autoDetect(self)
        self.pls  = SWOOSH.autoDetect(self)
        self.pgamma  = BUFFALO.autoDetect(self)
        self.adc = ANTELOPE.autoDetect(self)
        if HWCID == 0x00:
            self.panel_vendor = "LGD X1521 DEV PCB"
        elif HWCID == 0x01:
            self.panel_vendor = "LGD X1521 P0 PCB"
        elif HWCID == 0x02:
            self.panel_vendor = "Reserved"
        elif HWCID == 0x03:
            self.panel_vendor = "LGD X1521 P1 FBU PCB"
        elif HWCID == 0x04:
            self.panel_vendor = "LGD X1521 P1 PCB"
        elif HWCID == 0x05:
            self.panel_vendor = "LGD X1521 P1 Buck PCB"
        elif HWCID == 0x06:
            self.panel_vendor = "LGD X1521 P1 PCB Corner"
        elif HWCID == 0x07:
            self.panel_vendor = "LGD X1521 P1 PCB - CFG6 TCON"
        else:
            self.panel_vendor = "UNKNOWN"
            self.log ("HWCID Not Valid")
            raise ValueError("HWCID Not Valid")

    elif boardID == 0x04:
        self.edp = "HBR3"
        self.mcu = False
        self.cdicFreq = 1045.45
        self.cdicCount = 6
        self.refresh = 120
        self.pmic = SANTA_BARBARA.autoDetect(self)
        self.pls = SEASIDE_M.autoDetect(self)

    elif boardID == 0x05:
        self.edp = "HBR3"
        self.cdicFreq = 1000
        self.cdicCount = 8
        self.refresh = 120
        self.pmic = SANTA_BARBARA.autoDetect(self)
        self.pls = SEASIDE_M.autoDetect(self)

    elif boardID == 0x06:
        self.edp = "HBR3"
        self.cdicFreq = 1000
        self.cdicCount = 7
        self.refresh = 120
        self.pmic = SANTA_BARBARA.autoDetect(self)
        self.pls = SEASIDE_M.autoDetect(self)

    else:
        self.log ("Board ID Not Valid")
        raise ValueError("Board ID Not Valid")
